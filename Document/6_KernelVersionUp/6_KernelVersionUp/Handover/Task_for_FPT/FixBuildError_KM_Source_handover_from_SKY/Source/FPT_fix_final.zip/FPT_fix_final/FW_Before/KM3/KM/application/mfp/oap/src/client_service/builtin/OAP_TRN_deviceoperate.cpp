//  
//�t�@�C�����FOAP_CNV_deviceoperate.cpp 
//�T�v�@�@�@�F�f�o�C�X���� 
//  


// ================================================================  
//  �C���N���[�h�t�@�C�� 
// ================================================================ 
#include <new>
#include <map>
#include <vector>
#include <string>

#include "OAP_COM_sync.h"
#include "OAP_COM_copyop.h"
#include "OAP_COM_lock.h"
#include "OAP_COM_InternalApi.h"
#include "OAP_COM_error.h"
#include "OAP_COM_dbgtrace.h"
#include "OAP_COM_database.h"

#include "../OAP_CLI_AccountMan.h"
#include "../OAP_SVC_transact.h"
#include "../OAP_SVC_templates.h"
#include "../OAP_SVC_library.h"
#include "../OAP_SVC_customlib.h"
#include "../OAP_SVC_sysmodeman.h"
#include "../OAP_TRN_macro.h"
#include "../OAP_CNV_structconv.h"
#include "../OAP_CNV_enumconv.h"
#include "system/sys/APIC_Enabler.h"

// FW���t�@�N�^�����O APIC_Setting.h�̕���.
#include "system/nvd/APIC_Setting_TcpIpSetting.h"
#include "system/nvd/APIC_Setting_Network.h"
#include "system/nvd/APIC_Setting_SystemSetting.h"
#include "system/nvd/APIC_Setting_CopyScanJobSetting.h"
#include "system/nvd/APIC_Setting_PrintJobSetting.h"
#include "system/nvd/APIC_Setting_RdsSetting.h"
#include "system/nvd/APIC_Setting_EnablerSetting.h"
#include "system/nvd/APIC_Setting_UbiquitousSetting.h"
#include "system/nvd/APIC_SettingNVDF.h"
#include "system/job/APIC_Log.h"

#include "system/sys/APIC_IISWClient.h"

// [V30 Mosel] inoken add 2006/04/28 
#include "../OAP_CLI_timer.h"
// [V30 Mosel] inoken end 2006/04/28 
#include "system/sys/APIC_SystemServiceFunction.h"
#include "system/jlg/APIC_JLG.h"
#include "../OAP_SVC_notifymgr.h"
#include "system/sys/APIC_InternetISW.h"	// Minerva UV-00971 InternetISW�@�\���P nishida 2010/10/07 �ǉ�.
// GaiaFUM 2009/07/03 sone START.
#include "system/pwr/APIC_Power.h"		
#include "system/sys/APIC_RdsApi.h"		
#include "system/prt/APIC_Printer.h"	
// GaiaFUM 2009/07/21 sone END.
#include "system/doc/APIC_UbiquitousBox.h"	// ZeusCD UV-01324 Gayathri 2013/12/30 Added. 
// HeliosFUM(MAv2) UV-01378 SMB�ł̃f�[�^ExportImport�̉��P ���� �F�� 2013/10/01 �ǉ�Start .
#include "system/sys/APIC_System.h"
#include "system/sys/APIC_RemoteFWUpdateLog.h"
// HeliosFUM(MAv2) UV-01378 SMB�ł̃f�[�^ExportImport�̉��P ���� �F�� 2013/10/01 �ǉ�End .
#include "../OAP_SVC_notify_cmnapi.h"		// Zeus5BK RQ-174�Ή� 2014/06/11 HCL-Kavitha Added.

#include "system/nvd/APIC_SaaSGatewayInfo.h"	//Zeus5BK UV.����\���ύX_No.19 Sundar 2014/06/16 Added.
#include "system/nvd/APIC_SMBCleaningSetting.h"	//IT5_4.2 RQ-707 Message_Addition 20170825 HCL-Neeraj Added.//2017-10-10 IT6�y�}�[�W�Ή��p�ۑ�z1030046 Hcl-Rajeshwari added
// IT5_4.0 RQ-421 2016/09/13 HCL-Naveen Added Start.
#include "system/sys/APIC_RDTManager.h"
#include "system/nvd/APIC_RDTSetting.h"
// IT5_4.0 RQ-421 2016/09/13 HCL-Naveen Added End.
#include "system/sys/APIC_NetworkDevice.h"	//�l�b�g���[�N���Z�b�g XML��ՋZ�p�J��v2 2017/03/31 Pactera Added Start.
#include "system/prt/prtc/prtcImp/ENGC_PrinterImpColor.h"	//��[�Y���␳(�����␳) XML��ՋZ�p�J��v2 2017/03/31 Pactera Added Start.
// �Ǘ��V�X�e���������J�� �v���d�l2-b 2021/03/02 Sky �勴 START.
#include "system/nvd/APIC_CSRASetting.h"
// �Ǘ��V�X�e���������J�� �v���d�l2-b 2021/03/02 Sky �勴 END.

#undef new
using namespace std;

//
//�X�^�e�B�b�N�֐��̒�` 
//

// ================================================================ 
//�T�v�@�@�F�f�o�C�X���b�N
//���l�@�@�F
//�쐬�ҁ@�F
//���r���[�F�� 
//�ύX�����F2004.08.31:gunji		:����  
//          2004.11.10:tsuboi		:walk through ���C��
// ================================================================ 
template<> class __OAPC_TransactImp<OAPS_AppReqEnterDeviceLock> :// Amur_GCC4.1�Ή�_No023
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqEnterDeviceLock , OAPE_Result_FaultRequest_AppReqEnterDeviceLock > 
{
friend class OAPC_TransactImp<OAPS_AppReqEnterDeviceLock>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[���� 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqEnterDeviceLock)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqEnterDeviceLock)

	e.setKind(OAPE_Fault_faultcode_Client);

	//OperatorInfo�`�F�b�N 
	if (!p_req->s_OperatorInfo.empty()) {
		if (!p_req->s_OperatorInfo.check()) {
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "at OperatorInfo");
			return false;
		}
	}
	if (p_req->e_LockType.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "LockType");
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqEnterDeviceLock)

	if (!p_req->s_OperatorInfo.empty()) {
		int authority = 0;
		OAPC_ApiLock<OAPC_AuthManager> p_authmanager(&_authmanager, &_slock);
		OAPC_AuthManager::OAPE_State e_state = p_authmanager->getStatus();
		if (OAPC_AuthManager::OAPE_State_Auth        ==e_state ||
			OAPC_AuthManager::OAPE_State_AuthAndTrack==e_state ||
			OAPC_AuthManager::OAPE_State_Track==e_state) {
			authority = OAPE_UserType_Admin|OAPE_UserType_System;
		}
		else {
			authority = OAPE_UserType_Admin|OAPE_UserType_System;
		}

		authority |= OAPE_UserType_CE;		// ZM3rd 2013/04/03 UV-01198 Sky_Muratani OAPE_UserType_CE�ǉ�.

		//////////////////////////////////// 
		// �I�y���[�^�[���O�C�� 
		OAPC_User op(p_req->s_OperatorInfo, authority);
		if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
			return false;
		}
	}

OAPD_END_TRANSACT_AUTHORIZE

// Poseidon ����\���ύXNo.37 IT Bug�yCQ501700�z�Ή� 2014/07/23 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_ENTERDVICELOCK(AppReqEnterDeviceLock, AppResEnterDeviceLock)
// Poseidon ����\���ύXNo.37 IT Bug�yCQ501700�z�Ή� 2014/07/23 mod end.

	OAPD_TRACE_SCOPE("AppReqEnterDeviceLock");
	// Minerva/Zeus CQ338217 2011/2/14 HDD�A�N�Z�X�t���OOFF�Ή� heima add.
	OAPC_HddAccessManager	c_HddAccessManager;
	// Minerva/Zues CQ349777 kubota 2011/7/9 START.
	// �f�o�C�X���b�N���|����Ƃ��ɁA��2�������w��.
	// EnterDeviceLock�ȊO�͑�2�������w�肵�Ȃ�����.
	c_HddAccessManager.setHddAccessOn( True, True );
	// Minerva/Zues CQ349777 kubota 2011/7/9 END.
	// Minerva/Zeus CQ338217 2011/2/14 HDD�A�N�Z�X�t���OOFF�Ή� heima end.

	char* lock_key = 0;
	short timer = p_req->ss_TimeOut;
//�yIT6_1.0MR2�zRQ-537-13 HCL-Garima 04/04/2019 Start.
	Bool b_SecurityMode = False;
	OAPC_ApiWrapper<APIC_SystemStatus> pc_SystemStatus(APIC_SystemStatus::newInstanceAdmin() );
	OAPC_ApiWrapper<APIC_PrinterWarning> pc_Printerwarning(APIC_PrinterWarning::newInstanceAdmin() );
	OAPC_ApiWrapper<APIC_ScannerWarning> pc_Scannerwarning(APIC_ScannerWarning::newInstanceAdmin() );
	OAPC_ApiWrapper<APIC_SoftDipSw> pc_SoftDipSw( APIC_SoftDipSw::newInstanceAdmin());
	if( !pc_SystemStatus 
		||!pc_Printerwarning
		||!pc_Scannerwarning
		||!pc_SoftDipSw)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	} 
	if( (True == APIC_SystemSetting::newInstance()->getSecurityLevelUpOn()) && (True == OAPC_AccountMan::getInstance()->getIsWebUIFromPanel(p_req->s_OperatorInfo.sc_AuthKey.get()))); 
	{
				if ( True == pc_SoftDipSw->getSoftDipSwBit(136, 8) ){ //bit 164, bit2 
					b_SecurityMode = True;
				}
	}
//�yIT6_1.0MR2�zRQ-537-13 HCL-Garima 04/04/2019 End.
// Minerva �Ǘ�No306 UV-00884 taguchi 2010/07/15 START.
	// CSRC���ʒm.
	APIC_CsrcDataNotice* p_CsrcDataNotice = APIC_CsrcDataNotice::newInstanceAdmin();
	if( !p_CsrcDataNotice )
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "newInstance error");
		// Minerva/Zues CQ349777 kubota 2011/7/9 START.
		// �G���[�̂��߁A�f�o�C�X���b�N�t���O�𗎂Ƃ�.
		c_HddAccessManager.setSubPowerDeviceLockOff();
		// Minerva/Zues CQ349777 kubota 2011/7/9 END.
		return false;
	}
// Minerva �Ǘ�No306 UV-00884 taguchi 2010/07/15 END.

// MinervaZeus3rd UV-01198 OPS1���� 2013/04/05 Start.
	// AuthKey����A�J�E���g�����擾���ACE���O�C���̔��菈�����s��.
	OAPE_UserType e_AccountUserType = OAPE_UserType_None;
	OAPS_AccountUser accountuser;
	if( OAPC_AccountMan::getInstance()->findAccount( p_req->s_OperatorInfo.sc_AuthKey.get(), accountuser ) ){
		 e_AccountUserType = accountuser.e_UserType;
	}
	if(OAPE_UserType_CE == e_AccountUserType){
		OAPC_ApiLock<APIC_SystemStatus> p_sysst(APIC_SystemStatus::newInstanceAdmin(), 0);						// IT5_4.0 RQ-421_IT 1006796 2016/11/03 HCL-Naveen Moved Up.
		// �f�o�C�X���b�N(�T�[�r�X).
		sysman.setCeMode( true );	// CE���O�C���̏ꍇ�A�Ǘ��N���X��CE���[�h��ON.
		if (OAPC_SystemModeManager::modeError(sysman.lockDevice(timer, lock_key, accountuser, True, _slock),e)) {	// Zeus5BK 2014/06/19 ����\���ύXNo.37 WP2056 Muratani.	
			// �G���[�̂��߁A�f�o�C�X���b�N�t���O�𗎂Ƃ�.
			c_HddAccessManager.setSubPowerDeviceLockOff();
			// �V�X�e�����[�h�Ǘ��N���X��CE���[�h����������.
			// IT5_4.0 RQ-421_IT 1006796 2016/11/03 HCL-Naveen Modified Start.
			if(p_sysst->getDeviceLockOn() == false )
			{
				sysman.setCeMode( false );
			}
			// IT5_4.0 RQ-421_IT 1006796 2016/11/03 HCL-Naveen Modified End.
			return false;
		}
		// API���s���ʂ�NG�̏ꍇ�A�G���[��ݒ�.
		if(False == sysman.getCallbackResult()){
// ZM3rd 2013/07/05 CQ379858 OPS1���J Start.
			if(!p_sysst){
				e.setKind(OAPE_Fault_faultcode_Server);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "newInstance error");
				
			} else {
				e.setCodeDescription(OAPE_Result_ErrorDetails_DeviceSettingOtherError, "ServiceModeErr");
				p_sysst->setDeviceLockOn( false );
			}
// ZM3rd 2013/07/05 CQ379858 OPS1���J End.
			
			// �G���[�̂��߁A�f�o�C�X���b�N�t���O�𗎂Ƃ�.
			c_HddAccessManager.setSubPowerDeviceLockOff();
			// �V�X�e�����[�h�Ǘ��N���X��CE���[�h����������.
			sysman.setCeMode( false );
//			e.setCodeDescription(OAPE_Result_ErrorDetails_DeviceSettingOtherError, "ServiceModeErr");
			return false;
		}
	} else {
		// Zeus5BK 2014/06/19 ����\���ύXNo.37 WP2056 Muratani Start.
		Bool b_checkjob = True;
		Bool b_LocalHostLogin = False;					//IT5_4.0(1003843) XSLT�v���Z�b�T�L�������DeviceLock���̑Ή� 1003843 2016/09/07 HCL-Vijay Added Start�B									//IT5_4.0 XSLT�v���Z�b�T�L�������DeviceLock���̑Ή� 2016/09/07 HCL-Vijay Added�B
		if(True == accountuser.b_AdminMode && !p_req->e_CheckJob.empty())
		{
			b_checkjob = (OAPE_OnOff_On == p_req->e_CheckJob ) ? True : False;
		} 
		
		//IT5_4.0(1003843) XSLT�v���Z�b�T�L�������DeviceLock���̑Ή� 2016/09/07 HCL-Vijay Added Start�B
		APIC_SystemStatus *p_SystemStatus = APIC_SystemStatus::newInstanceAdmin();
		if ( !p_SystemStatus ) {
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
			return false;
		}
		if( !p_req->e_LocalHostDeviceLock.empty()) {
			b_LocalHostLogin = (OAPE_Bool_true == p_req->e_LocalHostDeviceLock ) ? True : False;
		}	
		p_SystemStatus->setDeviceLockDisplayOff(b_LocalHostLogin);
		//IT5_4.0(1003843) XSLT�v���Z�b�T�L�������DeviceLock���̑Ή� 2016/09/07 HCL-Vijay Added End�B
		
		// �f�o�C�X���b�N(�Ǘ���).
// Poseidon ����\���ύXNo.37 CQ507044 2014/11/25 mod start.
		// [Eagle][RQ-698-37] SingleSignOn 2018/07/20 Sky Start.
		OAPE_SystemMode e_SystemMode;
		if(!p_req->s_OperatorInfo.sc_AuthKey.empty()){
			e_SystemMode = sysman.lockDevice(timer, lock_key, accountuser, b_checkjob, _slock, p_req->s_OperatorInfo.sc_AuthKey.get(), b_SecurityMode);//�yIT6_1.0MR2�zRQ-537-13 HCL-Garima 04/04/2019 Added.
		} else {
			e_SystemMode = sysman.lockDevice(timer, lock_key, accountuser, b_checkjob, _slock);
		}
		// [Eagle][RQ-698-37] SingleSignOn 2018/07/20 Sky End.
		if(OAPE_SYSMODE_ScannerBusy == e_SystemMode
		&& True == accountuser.b_AdminMode)
		{ // PSWC(AdminMode On��) �� ScannerBusy ���� EnterDeviceLock �� DuringBusy �ł͂Ȃ� DuringJobExist �Ƃ��ĕԂ�.
			// ����AScannerBusy��ErrorDetail��GeneralDuringBusy�Ƃ��Ă���.
			// �����A��L��GeneralDuringJobExist�ɕύX������A�{�����͕s�v�ƂȂ�̂ŏ������邱��.
			e_SystemMode = OAPE_SYSMODE_JobRunning;
		}
//�yIT6_1.0MR2�zRQ-537-13 HCL-Garima 04/04/2019 Start.		
		Bool b_err = False;
		if(OAPC_SystemModeManager::modeError(e_SystemMode, e)) 
		{
			b_err = True; 
		}			
		if(b_err == True)
		{ 
			if(True == b_SecurityMode)
			{
					if (OAPE_SYSMODE_Fatal == e_SystemMode) 
					{
						 b_err = False;
					}
					else if ( (OAPE_SYSMODE_ScannerError == e_SystemMode) && ( TYPE_FatalLevel_A == pc_Scannerwarning->getFatalLevel() || TYPE_FatalLevel_B == pc_Scannerwarning->getFatalLevel()  ) )
					{
						 b_err = False;
					}	
					else if ( (OAPE_SYSMODE_PrinterError == e_SystemMode) && ( TYPE_FatalLevel_A == pc_Printerwarning->getFatalLevel() || TYPE_FatalLevel_B == pc_Printerwarning->getFatalLevel()  ) )
					{
						 b_err = False;
					}
					else if ( (OAPE_SYSMODE_SystemError == e_SystemMode) && ( TYPE_FatalLevel_A == pc_SystemStatus->getFatalLevel() || TYPE_FatalLevel_B == pc_SystemStatus->getFatalLevel()  ) )
					{
						 b_err = False;
					}
			}
		}

		if(b_err == True) 
		// Zeus5BK 2014/06/19 ����\���ύXNo.37 WP2056 Muratani End.
		{
			c_HddAccessManager.setSubPowerDeviceLockOff();		// �G���[�̂��߁A�f�o�C�X���b�N�t���O�𗎂Ƃ�.
			return false;
		}
	}
//�yIT6_1.0MR2�zRQ-537-13 HCL-Garima 04/04/2019 End.
// Poseidon ����\���ύXNo.37 CQ507044 2014/11/25 mod end.
// MinervaZeus3rd UV-01198 OPS1���� 2013/04/08 End.

	//////////////////////////////////// 
	// �V�X�e�����A�N�e�B�u�� 
	// SubPower��Hard�L�[�̂��߁A�����[�g�ł͑���ł��Ȃ� 2005/10/19 
	//del sysman.subPowerOn();
	sysman.systemWakeUp(_slock);
	
	// [�č����O] �ꊇ�o�^�Ή� 
	// �č����O�ۑ��t���O�̏����� 
	OAPC_InspectLog* p_InspectLog = OAPC_InspectLog::getInstance();

	////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////// 2006/12/18 machida start ///////////////////////////////////////////
	//
	// �T�v		�F�č����O�ۑ��^�C�v�ݒ� 
	// �΍���	�F2006/12/18 
	// �΍��	�Fmachida (����13�J��) 
	// �d�l		�F�ꊇ�o�^���쎞�̊č����O�ۑ������̐ݒ� 
	// 			�F�č����O�ɕۑ�����ۂɈꊇ�o�^�Ƃ��Ĉ������ǂ������w��) 
	//			�F�ȗ�����Normal�Ƃ��Ĉ����B
	//
	// OpenAPI version check 
	// Version�`�F�b�N��Macro�� 2007.08.18 Y.Sanda 
	if(OAPD_VERSION_CHECK(p_res->getVersion(), OAPD_OVER_V31) == true)
	{
		if( !p_req->e_PackageEntryFlg.empty() )
		{
			// �o�[�W����OK���l���ݒ肳��Ă���ꍇ�̂ݐݒ� 
			p_InspectLog->setRegistType(p_req->e_PackageEntryFlg.get());
// Minerva �Ǘ�No306 UV-00884 taguchi 2010/07/15 START.
			// �ꊇ�̐ݒ蒆�������ꍇ�̂݃C���|�[�g��Ԃ����s��(True)�ɂ���.
			p_CsrcDataNotice->AuthInfoImportStatus( True );
// Minerva �Ǘ�No306 UV-00884 taguchi 2010/07/15 END.
		}
	}

	/////////////////////// 2006/12/18 machida end /////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////

	p_InspectLog->clearRegistrationInfo();
	// [�č����O] �ꊇ�o�^�Ή� END 

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

	p_res->sc_LockKey = lock_key;

// Poseidon ����\���ύXNo.37 IT Bug�yCQ501700�z�Ή� 2014/07/23 mod start.
OAPD_END_TRANSACT_EXECUTE_ENTERDEVICELOCK
// Poseidon ����\���ύXNo.37 IT Bug�yCQ501700�z�Ή� 2014/07/23 mod end.

// ================================================================ 
//�T�v�@�@�F�f�o�C�X���b�N����
//���l�@�@�F
//�쐬�ҁ@�F
//���r���[�F�� 
//�ύX�����F2004.08.31:gunji		:����  
//          2004.11.10:tsuboi		:walk through ���C��
// ================================================================ 
template<> class __OAPC_TransactImp<OAPS_AppReqExitDeviceLock> :// Amur_GCC4.1�Ή�_No023
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqExitDeviceLock , OAPE_Result_FaultRequest_AppReqExitDeviceLock > 
{
friend class OAPC_TransactImp<OAPS_AppReqExitDeviceLock>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[���� 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqExitDeviceLock)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqExitDeviceLock)

	e.setKind(OAPE_Fault_faultcode_Client);

	//OperatorInfo�`�F�b�N 
	if (!p_req->s_OperatorInfo.empty()) {
		if (!p_req->s_OperatorInfo.check()) {
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "at OperatorInfo");
			return false;
		}
	}
// [V30 Mosel] inoken add 2006/04/28 
	// LockKey 
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, false ) == false )
	{
		return false;
	}
// [V30 Mosel] inoken end 2006/04/28 

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqExitDeviceLock)

	if (!p_req->s_OperatorInfo.empty()) {
		int authority = 0;
		OAPC_ApiLock<OAPC_AuthManager> p_authmanager(&_authmanager, &_slock);
		OAPC_AuthManager::OAPE_State e_state = p_authmanager->getStatus();
		if (OAPC_AuthManager::OAPE_State_Auth        ==e_state ||
			OAPC_AuthManager::OAPE_State_AuthAndTrack==e_state ||
			OAPC_AuthManager::OAPE_State_Track==e_state) {
			authority = OAPE_UserType_Admin|OAPE_UserType_System;
		}
		else {
			authority = OAPE_UserType_Admin|OAPE_UserType_System;
		}

		authority |= OAPE_UserType_CE;		// ZM3rd 2013/04/03 UV-01198 Sky_Muratani OAPE_UserType_CE�ǉ�.

		//////////////////////////////////// 
		// �I�y���[�^�[���O�C�� 
		OAPC_User op(p_req->s_OperatorInfo, authority);
		if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
			return false;
		}
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqExitDeviceLock, AppResExitDeviceLock)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("AppReqExitDeviceLock");

// Minerva �Ǘ�No306 UV-00884 taguchi 2010/07/15 START.
	// CSRC���ʒm.
	APIC_CsrcDataNotice* p_CsrcDataNotice = APIC_CsrcDataNotice::newInstanceAdmin();
	if( !p_CsrcDataNotice )
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "newInstance error");
		return false;
	}
// Minerva �Ǘ�No306 UV-00884 taguchi 2010/07/15 END.

// MinervaZeus3rd UV-01198 OPS1���� 2013/04/05 Start.
	// AuthKey����A�J�E���g�����擾���ACE���O�C���̔��菈�����s��.
	OAPE_UserType e_AccountUserType = OAPE_UserType_None;
	OAPS_AccountUser accountuser;
	if( OAPC_AccountMan::getInstance()->findAccount( p_req->s_OperatorInfo.sc_AuthKey.get(), accountuser ) ){
		 e_AccountUserType = accountuser.e_UserType;
	}
	if(OAPE_UserType_CE == e_AccountUserType){
		// �f�o�C�X���b�N����(�T�[�r�X).
		if (!sysman.unlockDevice(p_req->sc_LockKey.get(), false, &_slock)) {
		e.setKind(OAPE_Fault_faultcode_Client);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalLockKey, "");
		return false;
	}
		// �T�[�r�X���[�h�����̃G���[�𔻒�A�G���[���Ȃ���΃T�[�r�X���[�h������Ԃɂ���.
		// API���s���ʂ�NG�̏ꍇ�A�G���[��ݒ�.
		if(False == sysman.getCallbackResult()){
			e.setCodeDescription(OAPE_Result_ErrorDetails_DeviceSettingOtherError, "ServiceModeErr");
			return false;
		}
	}else{
		// �f�o�C�X���b�N����(�Ǘ���).
		if (!sysman.unlockDevice(p_req->sc_LockKey.get(), false, NULL)) {
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalLockKey, "");
			return false;
		}
	}
// MinervaZeus3rd UV-01198 OPS1���� 2013/04/05 End.
	
	// [�č����O] �ꊇ�o�^�Ή� 
	// �č����O�ۑ��t���O�̃N���A 
	OAPC_InspectLog* p_InspectLog = OAPC_InspectLog::getInstance();

	/////////////////////////////////////////////////////////////
	// �f�o�C�X���b�N�������Ɋč����O�ꊇ�L�^���[�h�𔲂��� 
	p_InspectLog->setRegistType( OAPE_AppReqDeviceLock_PackageEntryFlg_Normal );	// 2007/1/19 machida

	p_InspectLog->clearRegistrationInfo();
	// [�č����O] �ꊇ�o�^�Ή� END 

// Minerva �Ǘ�No306 UV-00884 taguchi 2010/07/15 START.
	// �ꊇ�̏�ԂɊ֌W�Ȃ��C���|�[�g��Ԃ𖢎��s(False)�ɂ���.
	p_CsrcDataNotice->AuthInfoImportStatus( False );
// Minerva �Ǘ�No306 UV-00884 taguchi 2010/07/15 END.

	// Minerva/Zues CQ349777 kubota 2011/7/9 START.
	// �f�o�C�X���b�N�t���O����������.
	OAPC_HddAccessManager	c_HddAccessManager;
	c_HddAccessManager.setSubPowerDeviceLockOff();
	// Minerva/Zues CQ349777 kubota 2011/7/9 END.

	////////////////////////////////////
	//IT5_4.0(1003843) XSLT�v���Z�b�T�L�������DeviceLock���̑Ή� 2016/06/15 HCL-Vijay Added Start�B
	APIC_SystemStatus *p_SystemStatus = APIC_SystemStatus::newInstanceAdmin();
	
	if ( !p_SystemStatus ) {
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}
	p_SystemStatus->setDeviceLockDisplayOff(False);			// Resetting Local Host Device Lock Flag.			
	//IT5_4.0(1003843) XSLT�v���Z�b�T�L�������DeviceLock���̑Ή� 2016/06/15 HCL-Vijay Added End�B
	
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// [V30 Mosel] inoken add 2006/04/28 
// ================================================================ 
//�T�v�@�@�F�f�o�C�X���b�N�X�V 
//���l�@�@�F 
//�쐬�ҁ@�F 
//���r���[�F�� 
//�ύX�����F2006.04.28:inoken		:����  
// ================================================================ 
template<> class __OAPC_TransactImp< OAPS_AppReqRenewDeviceLock > :// Amur_GCC4.1�Ή�_No023
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqRenewDeviceLock , OAPE_Result_FaultRequest_AppReqRenewDeviceLock > 
{
friend class OAPC_TransactImp< OAPS_AppReqRenewDeviceLock >;
private:
	OAPC_AuthManager		_authmanager;		// �F�؃}�l�[�W���[���� 

	__OAPC_TransactImp()	{}
	~__OAPC_TransactImp()	{}
	
	inline OAPE_Response	_response() const;
	inline bool				_pre_check( const OAPC_Memory& msg, OAPC_Error& e );
	inline bool				_authorize( const OAPC_Memory& msg, OAPC_Error& e );
	inline bool				_execute  ( const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e );
};

OAPD_TRANSACT_HANDLING( AppReqRenewDeviceLock )

OAPD_BEGIN_TRANSACT_PRECHECK( AppReqRenewDeviceLock )

	e.setKind(OAPE_Fault_faultcode_Client);

	//OperatorInfo 
	if ( p_req->s_OperatorInfo.empty() == true )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo" );
		return false;
	}
	else if ( p_req->s_OperatorInfo.check() == false )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo" );
		return false;
	}

	// LockKey 
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) == false )
	{
		return false;
	}

	// Time 
	if ( p_req->ss_Time.empty() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "Time" );
		return false;
	}
	// 30Step Check 
	if ( ( p_req->ss_Time.get() % 30 ) != 0 )
	{
		e.setKind( OAPE_Fault_faultcode_Client );
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralIllegalValue, "Time" );
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE( AppReqRenewDeviceLock )

	if ( p_req->s_OperatorInfo.empty() == false )
	{
		int		authority = 0;
		OAPC_ApiLock<OAPC_AuthManager>	p_authmanager( &_authmanager, &_slock );
		OAPC_AuthManager::OAPE_State	e_state = p_authmanager->getStatus();
		if ( OAPC_AuthManager::OAPE_State_Auth			== e_state ||
			 OAPC_AuthManager::OAPE_State_AuthAndTrack	== e_state ||
			 OAPC_AuthManager::OAPE_State_Track			== e_state
			 )
		{
			authority = OAPE_UserType_Admin | OAPE_UserType_System;
		}
		else
		{
			authority = OAPE_UserType_Admin | OAPE_UserType_System;
		}

		authority |= OAPE_UserType_CE;		// ZM3rd 2013/04/03 UV-01198 Sky_Muratani OAPE_UserType_CE�ǉ�.

		//////////////////////////////////// 
		// �I�y���[�^�[���O�C�� 
		OAPC_User	op( p_req->s_OperatorInfo, authority );
		if ( op.authCheck( TYPD_UserFunctionMask_None, e ) == false )
		{
			return false;
		}
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE( AppReqRenewDeviceLock, AppResRenewDeviceLock )

	OAPD_TRACE_SCOPE( "AppReqRenewDeviceLock" );

	short	timer = p_req->ss_Time;

	// �^�C�}�̍ċN�� 
	if ( sysman.renewDevice( timer, p_req->sc_LockKey.get() ) == false )
	{
		e.setKind( OAPE_Fault_faultcode_Client );
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralIllegalLockKey, "" );
		return false;
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////// 2006/12/18 machida start ///////////////////////////////////////////
	//
	// �T�v		�F�č����O�ۑ��^�C�v�ݒ� 
	// �΍���	�F2006/12/18 
	// �΍��	�Fmachida (����13�J��) 
	// �d�l		�F�ꊇ�o�^���쎞�̊č����O�ۑ������̐ݒ� 
	// 			�F�č����O�ɕۑ�����ۂɈꊇ�o�^�Ƃ��Ĉ������ǂ������w��) 
	//			�F�ȗ�����Normal�Ƃ��Ĉ����B
	//
	OAPC_InspectLog* p_InspectLog = OAPC_InspectLog::getInstance();
	// OpenAPI version check 
	// Version�`�F�b�N��Macro�� 2007.08.18 Y.Sanda 
	if(OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V31) == true)
	{
		if( !p_req->e_PackageEntryFlg.empty() )
		{
			// �o�[�W����OK���l���ݒ肳��Ă���ꍇ�̂ݐݒ� 
			p_InspectLog->setRegistType(p_req->e_PackageEntryFlg.get());
		}
	}
	/////////////////////// 2006/12/18 machida end /////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////

	// �ʒm���ݒ� 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// [V30 Mosel] inoken end 2006/04/28 

// add 020613 matumoto >>>
// ================================================================ 
//�T�v�@�@�F�g�[�^���J�E���^�ʒm�����ʒm 
//���l�@�@�F
//�쐬�ҁ@�F�܁B 
//���r���[�F�� 
//�ύX�����F2006.02.15:�܁B			:����
// ================================================================ 
template<> class __OAPC_TransactImp<OAPS_AppReqReportCounter> :// Amur_GCC4.1�Ή�_No023
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqReportCounter , OAPE_Result_FaultRequest_AppReqReportCounter > 
{
friend class OAPC_TransactImp<OAPS_AppReqReportCounter>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[���� 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check( const OAPC_Memory& , OAPC_Error& );
	inline bool _authorize( const OAPC_Memory& , OAPC_Error& );
	inline bool _execute( const OAPC_Memory& , OAPC_Memory& , OAPC_Error& );
};

OAPD_TRANSACT_HANDLING( AppReqReportCounter );

OAPD_BEGIN_TRANSACT_PRECHECK( AppReqReportCounter )

	e.setKind( OAPE_Fault_faultcode_Client );

	//OperatorInfo�`�F�b�N 
	if( !p_req->s_OperatorInfo.empty() ) 
	{
		if( !p_req->s_OperatorInfo.check() ) 
		{
			e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing , "at OperatorInfo" );
			return false;
		}
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE( AppReqReportCounter )

	if( !p_req->s_OperatorInfo.empty() ) 
	{
		int authority( 0 );
		OAPC_ApiLock<OAPC_AuthManager> p_authmanager( &_authmanager , &_slock );
		const OAPC_AuthManager::OAPE_State e_state( p_authmanager->getStatus() );
		if(   OAPC_AuthManager::OAPE_State_Auth         == e_state 
		   || OAPC_AuthManager::OAPE_State_AuthAndTrack == e_state 
		   || OAPC_AuthManager::OAPE_State_Track == e_state ) 
		{
			authority = OAPE_UserType_Admin | OAPE_UserType_System;
		} else {
			authority = OAPE_UserType_Admin | OAPE_UserType_System;
		}

		//////////////////////////////////// 
		// �I�y���[�^�[���O�C�� 
		OAPC_User op( p_req->s_OperatorInfo , authority );
		if( !op.authCheck( TYPD_UserFunctionMask_None , e ) ) 
		{
			return false;
		}
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING( AppReqReportCounter , AppResReportCounter )
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE( "AppReqReportCounter" );
	e.setMessage( OAPE_Result_FaultRequest_AppReqReportCounter );		// ��O�I�u�W�F�N�g���� 

	// CommonAPI�C���X�^���X�����ƁAI/F Lock 
	OAPC_ApiLock<APIC_CounterMailSendSetting> pc_CounterMailSendSetting( APIC_CounterMailSendSetting::newInstanceAdmin() , &_slock );

	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ��Fault��Ԃ� 
	if( !pc_CounterMailSendSetting )
	{
		e.setKind( OAPE_Fault_faultcode_Server );
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance" );
		return false;
	}

	pc_CounterMailSendSetting->indNoDelaySend();

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// ================================================================ 
//�T�v�@�@�F����
//���l�@�@�F
//�쐬�ҁ@�F
//���r���[�F�� 
//�ύX�����F2004.10.04:tsuboi		:����  
//        �F2007.03.06:Sudo			:�����ύX(i-Option�Ή�) 
// ================================================================ 
//static bool setAddressData(
//TYPS_AddressData&							s_AddressData,
//OAPS_PrintInfoPage_AddressPrintInfo&		s_AddressPrintInfo,
//OAPE_AppReqPrintInfoPage_PrintInfoPage	e_PrintInfoPage,
//OAPC_SyncLock&							slock,
//OAPC_Error&								e,
//unsigned char								version = VERNON
//)
static bool setAddressData(
	TYPS_AddressData&						s_AddressData,
	const OAPS_AppReqPrintInfoPage*			p_req,
	OAPC_SyncLock&							slock,
	OAPC_Error&								e )
{
	OAPS_PrintInfoPage_AddressPrintInfo		s_AddressPrintInfo	= p_req->s_AddressPrintInfo;
	OAPE_AppReqPrintInfoPage_PrintInfoPage	e_PrintInfoPage		= p_req->e_PrintInfoPage;
	unsigned char							version				= p_req->getVersion();

	//2018/02/28 1036947 Pactera start Added.
	OAPC_ApiLock<APIC_HddInfo>				pc_HddInfo(APIC_HddInfo::newInstanceAdmin(), &slock);
	//2018/02/28 1036947 Pactera end Added.

	short max_addr;		// �ő�o�^�� 
	short max_length;	// �ő�o�͔͈� 
	short OutputNum;	// �o�͌��� 2018/02/28 1036947 Pactera Added.
// �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/02 HCL-Palani Modified Start.			
	switch(e_PrintInfoPage)
	{
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_AbbrList:
			if( True == pc_HddInfo->getHddExist() ){					// HDD�L��
				// HDD��������1�`4000�܂œo�^�\.
				max_addr	= TYPD_MaxShorteningAddressWithHDD;
			} else {									// HDD����
				// HDD�񑕒�����1�`1000�܂œo�^�\.
				max_addr = TYPD_MaxShorteningAddressWithoutHDD;	// �ő� 1000��
			}
	
		//	max_addr	= TYPD_MaxPublicShorteningAddressWithIGC;
			max_length	= OAPC_PrintInfoPage_AddressData::getMaxShorteningAddressLength();
			OutputNum = NVDF_getMaxShorteningAddress(); //2018/02/28 1036947 Pactera Added.
			if((true == checkVLANSetting(e)) && 
			( (!p_req->e_NetworkType.empty())&& (p_req->e_NetworkType.get() == OAPE_NetworkType_NW2))){    				
                max_addr = TYPD_MaxShorteningAddressIndex_NW2;
			}			
			break;
		
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_GroupAbbrList:
			max_addr	= TYPD_MaxPublicGroupAddressWithIGC;
			if((true == checkVLANSetting(e)) && 
			( (!p_req->e_NetworkType.empty())&& (p_req->e_NetworkType.get() == OAPE_NetworkType_NW2))){    				
                max_addr = TYPD_MaxGroupAddressIndex_NW2;
			}
			
			max_length	= OAPC_PrintInfoPage_AddressData::getMaxGroupAddressLength();
			OutputNum	= 100; //2018/02/28 1036947 Pactera Added.
			break;
		
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_ProgramKeyList:
		//	max_addr	= TYPD_MaxProgramKeyWithIGC;			
			max_length	= OAPC_PrintInfoPage_AddressData::getMaxProgramKeyLength();
//2018/02/28 1036947 Pactera start Added.
#ifdef DEF_SupportSSD
			if( True == pc_HddInfo->getHddExist() )											// HDD �������ł͂Ȃ����ǂ����̃`�F�b�N.
#else	// #ifdef DEF_SupportSSD.
			TYPE_HddStatus e_HddStatus = pc_HddInfo->getHddStatus();						// Hdd Status �̎擾 
			if( TYPE_HddStatusNon != e_HddStatus)											// HDD �������ł͂Ȃ����ǂ����̃`�F�b�N 
#endif	// #ifdef DEF_SupportSSD.
			{
				max_addr	= TYPD_MaxProgramKeyWithIGC;
				OutputNum	= 400;
			} else {
				max_addr	= TYPD_MaxProgramKeyWithoutHDD;
				OutputNum	= 200;
			}
//2018/02/28 1036947 Pactera end Added.
				if((true == checkVLANSetting(e)) && 
			( (!p_req->e_NetworkType.empty())&& (p_req->e_NetworkType.get() == OAPE_NetworkType_NW2))){    				
                max_addr = TYPD_MaxProgramKeyIndex_NW2;
			}
			
			break;
		
		default:
			max_addr	= 0;
			max_length	= 0;
			OutputNum	= 0;	//2018/02/28 1036947 Pactera Added.
			break;
	}
	// �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/02 HCL-Palani Modified End.			
//	short max_addr = 0;		// �ő�o�^�� 
//	short max_length = 0;	// �ő�o�͔͈�
//	if( OAPE_AppReqPrintInfoPage_PrintInfoPage_AbbrList == e_PrintInfoPage ) {
//		OAPC_ApiLock<APIC_ShorteningAddress> pc_ShorteningAddress(APIC_ShorteningAddress::newInstanceAdmin(1), &slock); 
//		if(!pc_ShorteningAddress) {	// �擾���s
//			e.setKind(OAPE_Fault_faultcode_Server);
//			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
//			return false;
//		}
//		max_addr = pc_ShorteningAddress->getMaxShorteningAddress();
// worry : shozaki (2004/11/5) 
// �ő�o�͔͈͂́A�@��ɂ���ĈقȂ�H 
// �����A�����ł���΋@��J�X�^�}�C�Y�ӏ��� define �Ȃǂ������������Ǝv���c 
// �@��J�X�^�}�C�Y�ӏ��Ȃ�Ė����H 
// 2004.11.11 tsuboi �ύX
//		max_length = OAPC_PrintInfoPage_AddressData::getMaxShorteningAddressLength();
//	} else if( OAPE_AppReqPrintInfoPage_PrintInfoPage_ProgramKeyList == e_PrintInfoPage ) {
//		OAPC_ApiLock<APIC_ProgramKey> pc_ProgramKey(APIC_ProgramKey::newInstanceAdmin(1), &slock); 
//		if(!pc_ProgramKey) {	// �擾���s
//			e.setKind(OAPE_Fault_faultcode_Server);
//			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
//			return false;
//		}
//		max_addr = pc_ProgramKey->getMaxProgramKey();
// worry : shozaki (2004/11/5) 
// �ő�o�͔͈͂́A�@��ɂ���ĈقȂ�H 
// �����A�����ł���΋@��J�X�^�}�C�Y�ӏ��� define �Ȃǂ������������Ǝv���c 
// �@��J�X�^�}�C�Y�ӏ��Ȃ�Ė����H 
// 2004.11.11 tsuboi �ύX
//		max_length = OAPC_PrintInfoPage_AddressData::getMaxProgramKeyLength();
//	} else if( OAPE_AppReqPrintInfoPage_PrintInfoPage_GroupAbbrList == e_PrintInfoPage ) {
//		max_addr = TYPD_MaxGroupAddress;
// worry : shozaki (2004/11/5) 
// �ő�o�͔͈͂́A�@��ɂ���ĈقȂ�H 
// �����A�����ł���΋@��J�X�^�}�C�Y�ӏ��� define �Ȃǂ������������Ǝv���c 
// �@��J�X�^�}�C�Y�ӏ��Ȃ�Ė����H 
// 2004.11.11 tsuboi �ύX
//		max_length = OAPC_PrintInfoPage_AddressData::getMaxGroupAddressLength();
//	}

	//2017/03/31 �w��/�S��_XML��ՋZ�p�J��v2 pactera mod start.
	if( s_AddressPrintInfo.ss_ListAllSpecified.empty() || s_AddressPrintInfo.ss_ListAllSpecified.get() == 0 ){
// 2019/12/12 �yIT6_SparrowBK�zOP_BTS-16371 HIENG Start.
		short ss_AddrRangeStart = (short)s_AddressPrintInfo.s_AddressRange.ss_Start.get();
		short ss_AddrRangeLength = (short)s_AddressPrintInfo.s_AddressRange.ss_Length.get();
		// [IT6_EagleH]OP_BTS-3670�Ή� 2019/03/06 Pactera Modify Start.
		// short length = (short)(s_AddressPrintInfo.s_AddressRange.ss_Start.get() + s_AddressPrintInfo.s_AddressRange.ss_Length.get() - 1);	// Minerva Warning Removal. Ravi Tej modified on 15-Feb-2011.
		short length = ss_AddrRangeStart + ss_AddrRangeLength - 1;
		// [IT6_EagleH]OP_BTS-3670�Ή� 2019/03/06 Pactera Modify End.
		// if( max_addr < length || 0 >= length ) {	// �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/02 HCL-Palani Modified.
		//     e.setKind(OAPE_Fault_faultcode_Client);
		//     e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "Start, Length");
		//     return false;
		// }
		if( ((max_addr < ss_AddrRangeStart) || (0 >= ss_AddrRangeStart)) && ((max_length < ss_AddrRangeLength) || (0 >= ss_AddrRangeLength)) ) {
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "Start, Length");
			return false;
		} else if( (max_addr < ss_AddrRangeStart) || (0 >= ss_AddrRangeStart) ) {
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "Start");
			return false;
		} else if( (max_length < ss_AddrRangeLength) || (0 >= ss_AddrRangeLength) ) {
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "Length");
			return false;
		}
// 2019/12/12 �yIT6_SparrowBK�zOP_BTS-16371 HIENG End.
		// �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/02 HCL-Palani Added Start.
		if( (!p_req->e_NetworkType.empty())&& (p_req->e_NetworkType.get() == OAPE_NetworkType_NW2)){
				switch(e_PrintInfoPage)
				{
					case OAPE_AppReqPrintInfoPage_PrintInfoPage_AbbrList:
					s_AddressData.us_StartNum = static_cast<unsigned short>(s_AddressPrintInfo.s_AddressRange.ss_Start.get() - TYPD_MaxShorteningAddressWithHDD );
						if(length <= OAPD_ABBRNO_NW1_MAXLIST){							
							e.setKind(OAPE_Fault_faultcode_Client);
							e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "AbbrList NW2: Start, Length");
							return false;
						}
					break;
					case OAPE_AppReqPrintInfoPage_PrintInfoPage_GroupAbbrList:
					s_AddressData.us_StartNum = static_cast<unsigned short>(s_AddressPrintInfo.s_AddressRange.ss_Start.get() - TYPD_MaxPublicGroupAddressWithIGC ); // �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/20 HCL-Mangai Added.
						if(length <= OAPD_GROUP_ABBRNO_NW1_MAXLIST){							
							e.setKind(OAPE_Fault_faultcode_Client);
							e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "GroupAbbrList NW2: Start, Length");
							return false;
						}
					break;
					case OAPE_AppReqPrintInfoPage_PrintInfoPage_ProgramKeyList:
						s_AddressData.us_StartNum = static_cast<unsigned short>(s_AddressPrintInfo.s_AddressRange.ss_Start.get() - TYPD_MaxProgramKeyWithIGC ); // �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/20 HCL-Mangai Added.
						if(length <= OAPD_PROGKEY_ABBRNO_NW1_MAXLIST){							
							e.setKind(OAPE_Fault_faultcode_Client);
							e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "ProgramKeyList NW2: Start, Length");
							return false;
						}
					break;
					default:
					break;
				}
		}
		// �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/20 HCL-Mangai Modified Start.
		else{
			s_AddressData.us_StartNum = static_cast<unsigned short>(s_AddressPrintInfo.s_AddressRange.ss_Start.get());
//			s_AddressData.us_EndNum = static_cast<unsigned short>(s_AddressPrintInfo.s_AddressRange.ss_Length.get());			
		}		
		s_AddressData.us_OutputNum = static_cast<unsigned short>(s_AddressPrintInfo.s_AddressRange.ss_Length.get());// IT6_EagleH OP_BTS-8447 2019/07/02 HCL-Palani Moved.		
		// �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/20 HCL-Mangai Modified End.
		// �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/02 HCL-Palani Added End.	
// 2019/12/12 �yIT6_SparrowBK�zOP_BTS-16371 HIENG Start.
		// if( max_length < s_AddressPrintInfo.s_AddressRange.ss_Length.get() ) {	// �yIT6_EagleH�z OP_BTS- 4664�Ή� 2019/05/02 HCL-Palani Modified.
		//     e.setKind(OAPE_Fault_faultcode_Client);
		//     e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "Length");
		//     return false;
		// }
// 2019/12/12 �yIT6_SparrowBK�zOP_BTS-16371 HIENG End.
		//s_AddressData.us_StartNum = static_cast<unsigned short>(s_AddressPrintInfo.s_AddressRange.ss_Start.get());
//		s_AddressData.us_EndNum = static_cast<unsigned short>(s_AddressPrintInfo.s_AddressRange.ss_Length.get());
		//s_AddressData.us_OutputNum = static_cast<unsigned short>(s_AddressPrintInfo.s_AddressRange.ss_Length.get());
	}
	else{
		s_AddressData.us_StartNum = static_cast<unsigned short>(1);
//		s_AddressData.us_EndNum = static_cast<unsigned short>(OutputNum);
		s_AddressData.us_OutputNum = static_cast<unsigned short>(OutputNum);
	}
	s_AddressData.us_EndNum = static_cast<unsigned short>(OutputNum);
	//2017/03/31 �w��/�S��_XML��ՋZ�p�J��v2 pactera mod end.

	// ���
	if( OAPE_AppReqPrintInfoPage_PrintInfoPage_GroupAbbrList == e_PrintInfoPage ) {
		s_AddressData.e_AddressKind = TYPE_ListAddressDataKindNotSetting;	// �w�薳��
	} else {
		switch( s_AddressPrintInfo.e_SendMode ) {
		case OAPE_SendMode_Fax:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindFax;	// G3Fax
			break;
		case OAPE_SendMode_Email:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindEmail;	// E-Mail
			break;
		case OAPE_SendMode_Ftp:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindFtp;	// FTP
			break;
		case OAPE_SendMode_Smb:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindSmb;	// SMB
			break;
		case OAPE_SendMode_Box:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindBox;	// Box
			break;
		case OAPE_SendMode_Abbr:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindShorteningAddress;	// �Z�k���� 
			break;
		case OAPE_SendMode_GroupAbbr:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindGroupAddress;	// �O���[�v���� 
			break;
// [V30 Mosel] inoken add Ifax Merge 2006/06/02 
		// Ifax 
		case OAPE_SendMode_Ifax:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindIfax;
			break;
// [V30 Mosel] inoken end Ifax Merge 2006/06/02 
//#ifndef OPEN_API_NETWORK_FAX
		case OAPE_SendMode_IPAddressFax:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindIPFax;	// IP�A�h���XFax 
			break;
//#endif OPEN_API_NETWORK_FAX
		case OAPE_SendMode_WebDav:	// SCAN_TO_WEB_DAV
			// Version�`�F�b�N��Macro�� 2007.08.18 Y.Sanda 
			if(OAPD_VERSION_CHECK(version, OAPD_OVER_V32) == true)
			{			
				s_AddressData.e_AddressKind = TYPE_ListAddressDataKindWebDav;
			}
			else
			{
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "SendMode");
				return false;
			}
			break;
//2018/02/28 1036947 Pactera start Added.
		// �yIT6_EagleH�z  RQ-272 OP_BTS-3194�Ή� 2019/02/14 HCL-Palani Added Start.
		case OAPE_SendMode_IPFaxT38:			
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindT38;	//T38 
			break;
		// �yIT6_EagleH�z  RQ-272 OP_BTS-3194�Ή� 2019/02/14 HCL-Palani Added End.
		case OAPE_SendMode_None:
			s_AddressData.e_AddressKind = TYPE_ListAddressDataKindAll;	// ALL
			break;
//2018/02/28 1036947 Pactera end Added.
		default:
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "SendMode");
			return false;
			break;
		}
	}
	return true;
}
// 2023/06/15 FPT-VietDQ11�yIT6_2.3�z�y����\���ύX_No.75�z Add Start.
#ifdef DEF_A4_Cus 
static bool OAPI_CheckIsSparrowSupportPaperSource2()
{
	APIC_SystemInfo* p_SystemInfo = APIC_SystemInfo::newInstanceAdmin();
	p_SystemInfo->lock();
	TYPE_MachineType e_Type = p_SystemInfo->getMachineType();
	p_SystemInfo->unlock();
	if( (TYPE_MachineTypeSparrowBK0MFP == e_Type) || (TYPE_MachineTypeSparrowBK1MFP == e_Type)
		|| (TYPE_MachineTypeSparrowBK0SFP == e_Type)
		|| (TYPE_MachineTypeSparrow1SFP == e_Type) || (TYPE_MachineTypeSparrow2SFP == e_Type) 
		|| (TYPE_MachineTypeSparrow1MFP == e_Type) || (TYPE_MachineTypeSparrow2MFP == e_Type) )
	{
		if(TYPE_ModelTypeIII == p_SystemInfo->getModelType())
		{
			return true;
		}
	}
	return false;
}
#endif //#ifdef DEF_A4_Cus
// 2023/06/15 FPT-VietDQ11�yIT6_2.3�z�y����\���ύX_No.75�z Add End.
// IT6_2.3_MIF_3rd OP_BTS-44614 2023/09/13 FPT-VietDQ11 Added Start.
bool checkLineType2(MsgEnum<OAPE_AppReqPrintInfoPage_Line> e_LineType, OAPC_Error& e )
{
	APIC_SystemInfo* pc_SystemInfo = APIC_SystemInfo::newInstance();
	if(NULL == pc_SystemInfo)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}
	if((OAPE_AppReqPrintInfoPage_Line_Line1 == e_LineType) && (pc_SystemInfo->isFax1Exist() == False))
	{
		return false;	
	}
	if((OAPE_AppReqPrintInfoPage_Line_Line2 == e_LineType) && (pc_SystemInfo->isFax2Exist() == False))
	{
		return false;	
	}
	if((OAPE_AppReqPrintInfoPage_Line_Line3 == e_LineType) && (pc_SystemInfo->isFaxExistAll( TYPE_CommLine3 ) == False))
	{
		return false;	
	}
	if((OAPE_AppReqPrintInfoPage_Line_Line4 == e_LineType) && (pc_SystemInfo->isFaxExistAll( TYPE_CommLine4 ) == False))
	{
		return false;	
	}
	return true;
}
// IT6_2.3_MIF_3rd OP_BTS-44614 2023/09/13 FPT-VietDQ11 Added End.

static void ans_startListPrint( unsigned short us_Result )
{
	// OpenAPI�ł̓��X�g�̈󎚌��ʂɊւ��Ă͊֗^���Ȃ����� 
	// �����ł͉������Ȃ��B
}
template<> class __OAPC_TransactImp<OAPS_AppReqPrintInfoPage> :// Amur_GCC4.1�Ή�_No023
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqPrintInfoPage , OAPE_Result_FaultRequest_AppReqPrintInfoPage > 
{
friend class OAPC_TransactImp<OAPS_AppReqPrintInfoPage>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[���� 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqPrintInfoPage)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqPrintInfoPage)

	e.setKind(OAPE_Fault_faultcode_Client);

	if( p_req->e_PrintInfoPage.empty() ) {
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "PrintInfoPage");
			return false;
	}

// worry : shozaki (2004/11/5) 
// �F��ON/OFF �ɂ���� OperaterInfo �̕K�v/�s�K�v�����肷��݂����ł����APRECHECK �� OperatorInfo �̃`�F�b�N�����Ă������́H 
// �� 2004.12.8 tsuboi UserName, Password �̏ȗ��^�s�̓f�o�C�X�̏�Ԃɂ�����炸�`�F�b�N����
	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	// IT6_1 Sparrow AR1043928 2018/07/26 Start.
	OAPC_ApiWrapper<APIC_SystemInfo> pc_SystemInfo(APIC_SystemInfo::newInstanceAdmin() );
	if( !pc_SystemInfo ) {
		 e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Cannot Get Instance" );
		return false;
	}
	//TYPE_MachineType e_MachineType = pc_SystemInfo->getMachineType();
	if(False == checkExpImpAccountCheck( p_req->s_OperatorInfo.sc_AuthKey.get()))
	{
		if ( (OAPE_AppReqPrintInfoPage_PrintInfoPage_ProgramKeyList == p_req->e_PrintInfoPage) && 
			(OAPI_CheckIsSparrowSFPModel()))	//IT6_SparrowBK ����\���ύX_No.36 HCL-Palani 2019/08/06 Modified.
		{
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "Application: This Message not supported in Sparrow SPF1/2");
			return false;
		}
	}
	// IT6_1 Sparrow AR1043928 2018/07/26 End.
	if( OAPE_AppReqPrintInfoPage_PrintInfoPage_AbbrList == p_req->e_PrintInfoPage 
	 || OAPE_AppReqPrintInfoPage_PrintInfoPage_ProgramKeyList == p_req->e_PrintInfoPage 
	 || OAPE_AppReqPrintInfoPage_PrintInfoPage_GroupAbbrList == p_req->e_PrintInfoPage ) {
		if (p_req->s_AddressPrintInfo.empty()) {
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "AddressPrintInfo");
			return false;
		}
	 	//2018/02/28 1036947 Pactera start Moded.
		if( OAPE_AppReqPrintInfoPage_PrintInfoPage_AbbrList == p_req->e_PrintInfoPage 
		 && !p_req->s_AddressPrintInfo.checkAbbr() && p_req->s_AddressPrintInfo.e_SendMode != OAPE_SendMode_None) {
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "AddressPrintInfo");
			return false;
		}
		if( OAPE_AppReqPrintInfoPage_PrintInfoPage_ProgramKeyList == p_req->e_PrintInfoPage 
		 && !p_req->s_AddressPrintInfo.checkProgramKey() && p_req->s_AddressPrintInfo.e_SendMode != OAPE_SendMode_None ) {
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "AddressPrintInfo");
			return false;
		}
	 	//2018/02/28 1036947 Pactera end Moded.
		if( OAPE_AppReqPrintInfoPage_PrintInfoPage_GroupAbbrList == p_req->e_PrintInfoPage 
		 && !p_req->s_AddressPrintInfo.checkGroupAbbr() ) {
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "AddressPrintInfo");
			return false;
		}
	 	//2017/05/26 �w��/�S��_XML��ՋZ�p�J��v2 pactera Start Added.
	 	if ( !p_req->s_AddressPrintInfo.ss_ListAllSpecified.empty() &&  !p_req->s_AddressPrintInfo.ss_ListAllSpecified.range() ) {
	 		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "ListAllSpecified");
			return false;
	 	}
	 	//2017/05/26 �w��/�S��_XML��ՋZ�p�J��v2 pactera End Added.
	}
	if( p_req->e_PaperSource.empty() ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "PaperSource");
		return false;
	}
//VenusMLK �Ǘ�No.98 WP_No.406 Prashanthi 2015/12/22 Added Start.
#ifdef DEF_A4_Cus
//2017-10-10 IT6�y�}�[�W�Ή��p�ۑ�z1030046 Hcl-Rajeshwari add start.
#ifdef DEF_KRONOSS_Cus
	if( OAPE_TrayID_Tray5 == p_req->e_PaperSource ){
#else
// 2023/06/15 FPT-VietDQ11�yIT6_2.3�z�y����\���ύX_No.75�z Add Start.
	if(OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V734) == true)
	{
		if( OAPE_TrayID_Tray4 == p_req->e_PaperSource )
		{
			if(false == OAPI_CheckIsSparrowSupportPaperSource2())
			{
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "PaperSource");
				return false;
			}
		} else if( OAPE_TrayID_Tray5 == p_req->e_PaperSource )
		{
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "PaperSource");
			return false;
		}
// 2023/06/15 FPT-VietDQ11�yIT6_2.3�z�y����\���ύX_No.75�z Add End.
	} 
	else if(( OAPE_TrayID_Tray4 == p_req->e_PaperSource ) || ( OAPE_TrayID_Tray5 == p_req->e_PaperSource )){
#endif	// #ifdef DEF_KRONOSS_Cus
//2017-10-10 IT6�y�}�[�W�Ή��p�ۑ�z1030046 Hcl-Rajeshwari add end.
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "PaperSource");
		return false;
	}
#endif
//VenusMLK �Ǘ�No.98 WP_No.406 Prashanthi 2015/12/22 Added End.
	if( OAPE_TrayID_Auto == p_req->e_PaperSource ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "PaperSource");
		return false;
	}

	if( p_req->e_DuplexMode.empty() ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Duplex");
		return false;
	}

	//2017/03/21 �g�p�Ǘ��J�E���^�[���X�g_XML��ՋZ�p�J��v2 pactera Added Start.
	if( OAPE_AppReqPrintInfoPage_PrintInfoPage_NetworkConfiguration == p_req->e_PrintInfoPage ) {
		if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V999) )
		{
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "NetworkConfiguration");
			return false;
		}
	}
	
	if( OAPE_AppReqPrintInfoPage_PrintInfoPage_CounterForPanel == p_req->e_PrintInfoPage ) {
		if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V999) )
		{
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "CounterForPanel");
			return false;
		}
		//2020-05-21 IT6_2.0MR2 OP_BTS-24026 �y�s����Ή��zTAS000000003422 Pactera Added Start.
		if( p_req->s_CounterPanelPrintInfo.e_CounterDetails.empty() && OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V714) == true )
		{
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "CounterPanelPrintInfo.CounterDetails");
			return false;
		}
		//2020-05-21 IT6_2.0MR2 OP_BTS-24026 �y�s����Ή��zTAS000000003422 Pactera Added End.
	}

	if( OAPE_AppReqPrintInfoPage_PrintInfoPage_UserInfoForPanel == p_req->e_PrintInfoPage ) {
		if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V999) )
		{
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "UserInfoForPanel");
			return false;
		}
		if( p_req->s_UserPrintInfo.e_PrintItem.empty() ) 
		{
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "PrintItem");
			return false;
		}
		if( p_req->s_UserPrintInfo.e_CounterDetails.empty() ) 
		{
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "CounterDetails");
			return false;
		}
	}
	//2017/03/21 �g�p�Ǘ��J�E���^�[���X�g_XML��ՋZ�p�J��v2 pactera Added End.

// 2017/08/28  ����I��_XML��ՋZ�p�J��v2  Pactera Added Start.
	if( OAPE_AppReqPrintInfoPage_PrintInfoPage_FaxSetting == p_req->e_PrintInfoPage ) {
		if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V999) )
		{
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "FaxSetting");
			return false;
		}
		if( p_req->s_FaxPrintInfo.e_Line.empty() ) 
		{
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Line");
			return false;
	// IT6_2.3_MIF_3rd OP_BTS-44614 2023/09/13 FPT-VietDQ11 Added Start.
		}
		else
		{
			if(!checkLineType2( p_req->s_FaxPrintInfo.e_Line, e) )
			{
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "FaxPrintInfo::Line");
				return false;	
			}
		}	
	// IT6_2.3_MIF_3rd OP_BTS-44614 2023/09/13 FPT-VietDQ11 Added End.
	}
// 2017/08/28  ����I��_XML��ՋZ�p�J��v2  Pactera Added End.

// 2018/06/26 ���Օi��� IT6_Eagle_KRQ-314-22 Pactera Added Start.
	if( OAPE_AppReqPrintInfoPage_PrintInfoPage_ConsumableLifeList == p_req->e_PrintInfoPage ) {
		if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V999) )
		{
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "ConsumableLifeList");
			return false;
		}
	}
// 2018/06/26 ���Օi��� IT6_Eagle_KRQ-314-22 Pactera Added End.

	// �E�B���X�X�L����_���X�N���O [SecV6][RQ-909].
	if( (OAPE_AppReqPrintInfoPage_PrintInfoPage_VirusScanRiskLog == p_req->e_PrintInfoPage)) {
		if (OAPE_RequestDeviceType_PSWC == OAPC_AccountMan::getInstance()->findDeviceType(p_req->s_OperatorInfo.sc_AuthKey.get())) {
			if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V70) )
			{
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "VirusScanRiskLog");
				return false;
			}
		}else{
			if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V734) )
			{
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "VirusScanRiskLog");
				return false;
			}
		}
	}

	// �E�B���X�X�L����_�X�L�������O [SecV6][RQ-909].
	if( (OAPE_AppReqPrintInfoPage_PrintInfoPage_VirusScanScanLog == p_req->e_PrintInfoPage)) {
		if (OAPE_RequestDeviceType_PSWC == OAPC_AccountMan::getInstance()->findDeviceType(p_req->s_OperatorInfo.sc_AuthKey.get())) {
			if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V70) )
			{
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "VirusScanScanLog");
				return false;
			}
		}else{
			if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V734) )
			{
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "VirusScanScanLog");
				return false;
			}
		}
	}


OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqPrintInfoPage)

	if (!p_req->s_OperatorInfo.empty()) {
		int authority = 0;
		OAPC_ApiLock<OAPC_AuthManager> p_authmanager(&_authmanager, &_slock);
		OAPC_AuthManager::OAPE_State e_state = p_authmanager->getStatus(p_req->e_NetworkType.get());//IT6_Eagle AR1058015 Hcl-Palani 2018/09/04 Modified.
		if (OAPC_AuthManager::OAPE_State_Auth        ==e_state ||
			OAPC_AuthManager::OAPE_State_AuthAndTrack==e_state ||
			OAPC_AuthManager::OAPE_State_Track==e_state) {	// �F��ON �̏ꍇ
			authority = OAPE_UserType_User|OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
		}
		else {
			authority = OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
		}

		//////////////////////////////////// 
		// �I�y���[�^�[���O�C�� 
		OAPC_User op(p_req->s_OperatorInfo, authority);
		if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
			return false;
		}
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqPrintInfoPage, AppResPrintInfoPage)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("AppReqPrintInfoPage");

	OAPC_ApiLock<APIC_ListPrint> pc_ListPrint(APIC_ListPrint::newInstanceAdmin(), &_slock);
	OAPC_ApiLock<APIC_PrintJobSetting> pc_PrintJobSetting(APIC_PrintJobSetting::newInstanceAdmin(), &_slock);
	OAPC_ApiLock<APIC_CopyJobSetting> pc_CopyJobSetting(APIC_CopyJobSetting::newInstanceAdmin(), &_slock);
	OAPC_ApiLock<APIC_FeedTray> pc_FeedTray(APIC_FeedTray::newInstanceAdmin(), &_slock); 

	// [V30 Mosel] 
	OAPC_ApiLock<APIC_DoneJobList> pc_DoneJobList(APIC_DoneJobList::newInstanceAdmin(), &_slock); 
	OAPC_ApiLock<APIC_SystemSetting> pc_SystemSetting(APIC_SystemSetting::newInstanceAdmin(), &_slock);
	OAPC_ApiLock<APIC_SystemInfo> pc_SystemInfo(APIC_SystemInfo::newInstanceAdmin() , &_slock);	//2017/03/23 �g�p�Ǘ��J�E���^�[���X�g_XML��ՋZ�p�J��v2 pactera Added.
	if(!pc_ListPrint || !pc_PrintJobSetting || !pc_CopyJobSetting || !pc_FeedTray || !pc_DoneJobList || !pc_SystemSetting	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ�͗�O���X���[ 
		|| !pc_SystemInfo ) {			//2017/03/23 �g�p�Ǘ��J�E���^�[���X�g_XML��ՋZ�p�J��v2 pactera Added.
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}

	// Amur CQNo315878 inoue 2009/02/24 �j�A�t�����̔�����폜.
	//IT6_Sparrow AR1047042 HCL-Palani 2018/06/11 Added Start.
	TYPE_NetworkSpecific e_NetworkSpecific = TYPE_NetworkSpecific_NW1;
		if((!p_req->e_NetworkType.empty()) && (OAPE_NetworkType_NW2 == p_req->e_NetworkType.get())){
			if(true == checkVLANSetting(e)){
				getCommAPIEnum( p_req->e_NetworkType, e_NetworkSpecific );
			}
			else{
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "VLAN setting is disabled");
				return false;
			}
		}
	//IT6_Sparrow AR1047042 HCL-Palani 2018/06/11 Added End.
	// [V30 Mosel] �o�͂�����e�ɂ���āA�����`�F�b�N���s�� 
	OAPE_UserType e_UserType;
	// ���O�C������Ă��郆�[�U�^�C�v�̎擾 
	if(!p_req->s_OperatorInfo.sc_AuthKey.empty())
	{
		OAPC_AccountMan* p_AccountMan = OAPC_AccountMan::getInstance();
		OAPS_AccountUser s_AccountUser;
		if(!p_AccountMan->findAccount(p_req->s_OperatorInfo.sc_AuthKey.get(), s_AccountUser)) 
		{
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "AuthKey");
			return false;
		}
		e_UserType = s_AccountUser.e_UserType;
	}
	else
	{
		e_UserType = p_req->s_OperatorInfo.e_UserType;
	}

	switch(p_req->e_PrintInfoPage)
	{
		// Admin, BoxAdmin, User, Public -> OK 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_Configuration:			// �v�����^�ݒ��񃊃X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_DemoPage:				// PCL�f���y�[�W 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_PclFontList:			// PCL�t�H���g���X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_PsFontList:				// PS�t�H���g���X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_Counter:				// �J�E���^���X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_UnitLife:				// ���j�b�g�`�F�b�N 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_OOXMLFontList:			// OOXML�t�H���g���X�g 	// Helios CQ514472�Ή� 2015/06/11 HCL-Kavitha Added.
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_NetworkConfiguration:	//�l�b�g���[�N�ݒ�l���X�g XML��ՋZ�p�J��v2 2017/03/24 Pactera Added.
//2017/03/23 �Z�[���X�J�E���^�[_XML��ՋZ�p�J��v2 pactera add start.
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_CounterForPanel:
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_UserInfoForPanel:
//2017/03/23 �Z�[���X�J�E���^�[_XML��ՋZ�p�J��v2 pactera add end.
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_ConsumableLifeList:		// ���Օi��� IT6_Eagle_KRQ-314-22 2018/06/26 Pactera Added.
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_VirusScanRiskLog:		// �E�B���X�X�L����_���X�N���O [SecV6][RQ-909].
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_VirusScanScanLog:		// �E�B���X�X�L����_�X�L�������O [SecV6][RQ-909].
			break;
		// Admin, BoxAdmin�̂݃��X�g�v�����g�\. 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_UserChoice:				// �ݒ�l���X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_UserInfo:				// �g�p�Ǘ����X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_AbbrList:				// �Z�k���惊�X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_ProgramKeyList:			// �v���O�����L�[���X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_GroupAbbrList:			// �O���[�v���惊�X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_FaxSetting:				// FAX�ݒ胊�X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_SendSubject:			// �^�C�g���E�{�����X�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_IfaxSetting:			// IFAX�ݒ胊�X�g.	// 2006/06/29 13�J���呺�y61601�z.
			// ���[�U�^�C�v��Public�AUser�̏ꍇ�̓G���[ 
			if( OAPE_UserType_Public == e_UserType ||
				OAPE_UserType_User   == e_UserType )
			{
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_AuthNotAllowedAuthSetting, "you cannot operate by your authority");
				return false;
			}
			break;
		// �u�ʐM����\���ݒ�v���u��\���v�̏ꍇ�AAdmin, BoxAdmin�̂݃��X�g�v�����g�\.  
		// �u�ʐM����\���ݒ�v���u�\���v�̏ꍇ�A���ׂẴ��[�U�^�C�v�����X�g�v�����g�\.  
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_CommunicationHistory:	// FAX����M�Ǘ����|�[�g
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_SendHistory:			// FAX���M�Ǘ����|�[�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_ReceiveHistory:			// FAX��M�Ǘ����|�[�g 
		case OAPE_AppReqPrintInfoPage_PrintInfoPage_ScanSendHistory:		// Scan���M�Ǘ����|�[�g 
			// �u�ʐM����\���ݒ�v���u��\���v�̏ꍇ
			if(!pc_SystemSetting->getEnableCommunicationsRecord())
			{
				// ���[�U�^�C�v��Public�AUser�̏ꍇ�̓G���[ 
				if( OAPE_UserType_Public == e_UserType ||
					OAPE_UserType_User   == e_UserType )
				{
					e.setKind(OAPE_Fault_faultcode_Client);
					e.setCodeDescription(OAPE_Result_ErrorDetails_AuthNotAllowedAuthSetting, "you cannot operate by your authority");
					return false;
				}
			}
			break;
		default:
			// �����l�G���[ 
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "Value is invalid in PrintInfoPage.");
			return false;
	}

	// PaperSource 
	TYPE_FeedTray e_FeedTray = TYPE_FeedTrayUnselect;
// worry : shozaki (2004/11/5)
// ���L�� getCommAPIEnum �Ӗ�������͉̂��ł����H
	if( p_req->e_PaperSource.empty() ) {	// V1
		// V1 FeedBack : 05.07.07 shozaki 
		// �g�p���郁�\�b�h�̏C�� 
		// #39136 
		e_FeedTray = pc_PrintJobSetting->getFeedTrayAtListPrint();
	} else {	// V2
		if( !getCommAPIEnum( p_req->e_PaperSource, e_FeedTray ) ) {
// PaperSource ���ȗ����ꂽ�ꍇ�ǂ̋�������I�����邩�H
// �� 2004.11.17 tsuboi PaperSource V2 �ł͏ȗ��s�ɕύX
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "PaperSource");
			return false;
		}
	}
	if ( TYPE_FeedTrayUnselect == e_FeedTray ) { // ���ݒ�̏ꍇ�͗D��x�̍����g���C��I������ 
		e_FeedTray = TYPE_FeedTray1;
		TYPS_TraySearchPriority s_TraySearchPriority;
		s_TraySearchPriority = pc_CopyJobSetting->getTraySearchPriority();
		for (int i=0;i<6;i++) {
			if (TYPE_FeedTrayUnselect != s_TraySearchPriority.e_FeedTray[i]) {
				e_FeedTray = s_TraySearchPriority.e_FeedTray[i];
				break;
			}
		}
	}
// worry : shozaki (2004/11/5)
// �����ŁATray�̑��݊m�F�͕K�v�Ȃ��H
// �w�肳�ꂽPaperSource �����݂��Ȃ�Tray�̏ꍇ �G���[�ɂ���̂��H 
// �G���[�ɂ��Ȃ��ꍇ�A�ǂ̋����������񂽂����邩�H
// �� 2004.11.17 tsuboi ���݂��Ȃ��ꍇ�G���[�ɂ���
//	if( TYPE_TrayTypeNon == pc_FeedTray->getTrayType( e_FeedTray ) ) {
	if(TYPE_TrayStatusNon == pc_FeedTray->getTrayStatus( e_FeedTray )) {
		e.setKind(OAPE_Fault_faultcode_Client);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "PaperSource");
		return false;
	}
	OAPD_TRACE("List Print FeedTray : " << e_FeedTray)

// 2005.2.17 shozaki 
// #18539 �Ή� 
//
	bool b_print = false;
	TYPC_PaperSize c_PaperSize;
	{
		OAPC_ApiLock<APIC_FeedTray> 			c_LockFdTray(pc_FeedTray);
		c_PaperSize = pc_FeedTray->getPaperSize( e_FeedTray );
	}
	switch(c_PaperSize.e_SizeCode)
	{
		case 	TYPE_SizeCodeA3Sef:
		case	TYPE_SizeCodeB4Sef:
		case 	TYPE_SizeCodeA4Sef:
		case 	TYPE_SizeCodeA4Lef:
		case 	TYPE_SizeCodeLedgerSef:
		case 	TYPE_SizeCodeLegalSef:
		case 	TYPE_SizeCodeLetterSef:
		case 	TYPE_SizeCodeLetterLef:
		case	TYPE_SizeCode8KSef:
		case	TYPE_SizeCode16KSef:
		case	TYPE_SizeCode16KLef:
			b_print = true;
			break;
		default:
			break;
	}
	if (!b_print)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_JobOperationCanNotCreateJob, "Paper Size Error");
		return false;
	}

	// Duplex
	Bool duplex = False;
	getCommAPIEnum(p_req->e_DuplexMode, duplex);

	// ZeusMLK CQ362327 taguchi 2012/02/27 ��6�����C��.
	// ��6�����p��`.
	TYPE_ListPrintInfo		 e_ListPrintInfo = TYPE_ListPrintInfoOnly;
	TYPE_FaxJournalListPrint e_FaxJournalListPrint = TYPE_FaxJournalListPrintComm;
	// ZeusMLK CQ362327 taguchi 2012/02/27 ��6�����C��.

	//////////////////////////////////// 
	// �V�X�e�����A�N�e�B�u�� 
	// 2007.01.16 T.Akasako ����BugDB 74937�Ή� 
	// pc_ListPrint->req_startListPrint�ɓn��������ǉ�(TYPE_JobEntryIF_ISOpenAPI) 

// BugDB_77583�Ή� �Ή� IT2 -> i-Option�o�O�}�[�W urakawa 2007/06/26 
// 2007.02.28 ����BugDB_77583�Ή� BSKK_Kajitani
// �ȓd�͂��畜�A�����ꍇ�ɁA�u�����ڍs�v�𐳏�ɓ��삳���邽�߂ɏC��
	if (sysman.systemWakeUp2(_slock)) {		// BSKK_Kajitani systemWakeUp -> systemWakeUp2
		TYPS_AddressData s_AddressData;
		switch(p_req->e_PrintInfoPage) {
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_DemoPage:
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_PclDemoPage:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintPclDemo,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_PsDemoPage:
//D8			pc_ListPrint->req_startListPrint( TYPE_ListPrintPsDemo,			e_FeedTray, ans_startListPrint, -1, 0, 0, duplex );
//D8			break;
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_ConfigurePage:
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_Configuration:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintPrinterSetting,	e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_PclFontList:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintPclFont,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_PsFontList:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintPsFont,			e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_NetworkConfiguration:
//D8			pc_ListPrint->req_startListPrint( TYPE_ListPrintNetworkSetting,	e_FeedTray, ans_startListPrint, -1, 0, 0, duplex );
//D8			break;
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_JobLog:
//D8			pc_ListPrint->req_startListPrint( TYPE_ListPrintJobLog,			e_FeedTray, ans_startListPrint, -1, 0, 0, duplex );
//D8			break;
//2017/03/23 �Z�[���X�J�E���^�[_XML��ՋZ�p�J��v2 pactera add start.
			//2020-05-21 IT6_2.0MR2 OP_BTS-24026 �y�s����Ή��zTAS000000003422 Pactera Modified Start.
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_CounterForPanel:
				if( OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V714) == true ){
					Bool b_isCounterDetails = False;
					getCommAPIEnum( p_req->s_CounterPanelPrintInfo.e_CounterDetails, b_isCounterDetails );
					TYPS_CounterOption s_CounterOption;
					// �\���̏�����
					memset(&s_CounterOption, 0, sizeof(s_CounterOption));
					// �ڍ׃J�E���^�[�̈󎚗L�� �ݒ�
					s_CounterOption.b_AdditionalCounterEnable = b_isCounterDetails;
					pc_ListPrint->req_startListPrint( TYPE_ListPrintCounter,		e_FeedTray, ans_startListPrint, -1, 0, &s_CounterOption, duplex, TYPE_JobEntryIF_ISOpenAPI );
				} else {
					pc_ListPrint->req_startListPrint( TYPE_ListPrintCounter,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				}
				break;
			//2020-05-21 IT6_2.0MR2 OP_BTS-24026 �y�s����Ή��zTAS000000003422 Pactera Modified End.
//2017/03/23 �Z�[���X�J�E���^�[_XML��ՋZ�p�J��v2 pactera add end.
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_Counter:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintCounter,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_BoxJobList:
//D8			pc_ListPrint->req_startListPrint( TYPE_,						e_FeedTray, ans_startListPrint, -1, 0, 0, duplex );
//D8			break;
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_JobMemoryList:
//D8			pc_ListPrint->req_startListPrint( TYPE_ListPrintJobMemory,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex );
//D8			break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_UserChoice:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintUserChoice,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
//2017/03/23 �g�p�Ǘ��J�E���^�[���X�g_XML��ՋZ�p�J��v2 pactera Added Start.
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_UserInfoForPanel:
				{
					getCommAPIEnum( p_req->s_UserPrintInfo.e_PrintItem, e_ListPrintInfo );
					Bool b_isCounterDetails = False;
					getCommAPIEnum( p_req->s_UserPrintInfo.e_CounterDetails, b_isCounterDetails );
					TYPS_CounterOption s_CounterOption;
					s_CounterOption.e__ListPrintInfo = e_ListPrintInfo;
					s_CounterOption.b_AdditionalCounterEnable = b_isCounterDetails;
					pc_ListPrint->req_startListPrint( TYPE_ListPrintTrackCounter, e_FeedTray, ans_startListPrint, -1, 0, &s_CounterOption, duplex, TYPE_JobEntryIF_ISOpenAPI );
				}
				break;
//2017/03/23 �g�p�Ǘ��J�E���^�[���X�g_XML��ՋZ�p�J��v2 pactera Added End.
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_UserInfo:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintTrackCounter,	e_FeedTray, ans_startListPrint, -1, 0, &e_ListPrintInfo, duplex, TYPE_JobEntryIF_ISOpenAPI );		// ZeusMLK CQ362327 taguchi 2012/02/27 ��6�����C��.
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_UnitLife:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintUnitCheck,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_BoxList:
//D8			pc_ListPrint->req_startListPrint( TYPE_,						e_FeedTray, ans_startListPrint, -1, 0, 0, duplex );
//D8			break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_AbbrList:
//				if( setAddressData(s_AddressData, p_req->s_AddressPrintInfo, p_req->e_PrintInfoPage, _slock, e, p_req->getVersion() ) ) {
				if( setAddressData(s_AddressData, p_req, _slock, e) ) {
					/* IT6_Eagle�@��J��_RQ-698_2portLAN�Ή�_1054588 Pactera mod start 2018/07/28 */
					s_AddressData.e_NetworkSpecific = e_NetworkSpecific;
					pc_ListPrint->req_startListPrint( TYPE_ListPrintReduceAddr,		e_FeedTray, ans_startListPrint, -1, 0, &s_AddressData, duplex, TYPE_JobEntryIF_ISOpenAPI, e_NetworkSpecific );
					/* IT6_Eagle�@��J��_RQ-698_2portLAN�Ή�_1054588 Pactera mod end 2018/07/28 */
				} else {
					return false;
				}
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_ProgramKeyList:
//				if( setAddressData(s_AddressData, p_req->s_AddressPrintInfo, p_req->e_PrintInfoPage, _slock, e, p_req->getVersion() ) ) {
				if( setAddressData(s_AddressData, p_req, _slock, e) ) {
					/* IT6_Eagle�@��J��_RQ-698_2portLAN�Ή�_1054588 Pactera mod start 2018/07/28 */
					s_AddressData.e_NetworkSpecific = e_NetworkSpecific;
					pc_ListPrint->req_startListPrint( TYPE_ListPrintProgramKey,		e_FeedTray, ans_startListPrint, -1, 0, &s_AddressData, duplex, TYPE_JobEntryIF_ISOpenAPI, e_NetworkSpecific );
					/* IT6_Eagle�@��J��_RQ-698_2portLAN�Ή�_1054588 Pactera mod end 2018/07/28 */
				} else {
					return false;
				}
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_GroupAbbrList:
//				if( setAddressData(s_AddressData, p_req->s_AddressPrintInfo, p_req->e_PrintInfoPage, _slock, e, p_req->getVersion() ) ) {
				if( setAddressData(s_AddressData, p_req, _slock, e) ) {
					/* IT6_Eagle�@��J��_RQ-698_2portLAN�Ή�_1054588 Pactera mod start 2018/07/28 */
					s_AddressData.e_NetworkSpecific = e_NetworkSpecific;
					pc_ListPrint->req_startListPrint( TYPE_ListPrintGroupAddr,		e_FeedTray, ans_startListPrint, -1, 0, &s_AddressData, duplex, TYPE_JobEntryIF_ISOpenAPI, e_NetworkSpecific );
					/* IT6_Eagle�@��J��_RQ-698_2portLAN�Ή�_1054588 Pactera mod end 2018/07/28 */
				} else {
					return false;
				}
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_CommunicationHistory:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintComm,			e_FeedTray, ans_startListPrint, -1, 0, &e_FaxJournalListPrint, duplex, TYPE_JobEntryIF_ISOpenAPI );		// ZeusMLK CQ362327 taguchi 2012/02/27 ��6�����C��.
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_SendHistory:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintTx,				e_FeedTray, ans_startListPrint, -1, 0, &e_FaxJournalListPrint, duplex, TYPE_JobEntryIF_ISOpenAPI );		// ZeusMLK CQ362327 taguchi 2012/02/27 ��6�����C��.
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_ReceiveHistory:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintRx,				e_FeedTray, ans_startListPrint, -1, 0, &e_FaxJournalListPrint, duplex, TYPE_JobEntryIF_ISOpenAPI );		// ZeusMLK CQ362327 taguchi 2012/02/27 ��6�����C��.
				break;
			// [V30 Mosel] 
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_ScanSendHistory:		// Scan���M�Ǘ����|�[�g 
				pc_ListPrint->req_startListPrint( TYPE_ListPrintScanTx,			e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_FaxSetting:
				/* IT6_2.1�@��J��_RQ-865 FAX�ݒ��ʂ̉��P�Ή� Pactera mod Started 2020/08/24 */
				{
					TYPE_CommLine e_FaxLineNum = TYPE_CommLineAll;
					if (!p_req->s_FaxPrintInfo.e_Line.empty()) {
						getCommAPIEnum( p_req->s_FaxPrintInfo.e_Line, e_FaxLineNum );
					}
					if(checkLineType2( p_req->s_FaxPrintInfo.e_Line, e))	// IT6_2.3_MIF_3rd OP_BTS-44614 2023/09/13 FPT-VietDQ11 Added.
					{
						pc_ListPrint->req_startListPrint( TYPE_ListPrintFaxSetting,		e_FeedTray, ans_startListPrint, -1, 0, &e_FaxLineNum, duplex, TYPE_JobEntryIF_ISOpenAPI );
					}
				}
				/* IT6_2.1�@��J��_RQ-865 FAX�ݒ��ʂ̉��P�Ή� Pactera mod Ended 2020/08/24 */
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_SendSubject:
				pc_ListPrint->req_startListPrint( TYPE_ListPrintTitleSubject,e_FeedTray,ans_startListPrint,-1,0,&e_NetworkSpecific,  /*���|�C���^�w��ɂȂ�܂��B*/duplex,TYPE_JobEntryIF_ISOpenAPI);//IT6_Sparrow AR1047042 HCL-Palani 2018/06/11 Modified.
				//pc_ListPrint->req_startListPrint( TYPE_ListPrintTitleSubject,	e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI,0,e_NetworkSpecific );
				break;
// [V30 Mosel] inoken add Ifax Merge 2006/06/02 
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_IfaxSetting:
				//�b���FaxSetting���o���Ƃ��B 
				pc_ListPrint->req_startListPrint( TYPE_ListPrintFaxSetting,	e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
// [V30 Mosel] inoken end Ifax Merge 2006/06/02 
			// Helios CQ514472�Ή� 2015/06/11 HCL-Kavitha Added START.
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_OOXMLFontList:			// OOXML�t�H���g���X�g
				pc_ListPrint->req_startListPrint( TYPE_ListPrintOOXMLFont,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
			// Helios CQ514472�Ή� 2015/06/11 HCL-Kavitha Added END.
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_ColorChart:			// �g�p���Ȃ����߁A�����l�G���[�Ƃ���B 
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_FontPattern:		// �@�\�d�l�폜
//D8		case OAPE_AppReqPrintInfoPage_PrintInfoPage_Kcpdl2FontList:		// �@�\�d�l�폜
//D8			case OAPE_AppReqPrintInfoPage_PrintInfoPage_ScanSetting:		// �@�\�d�l�폜
			//�l�b�g���[�N�ݒ�l���X�g XML��ՋZ�p�J��v2 2017/03/24 Pactera Added Start.
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_NetworkConfiguration:			// �l�b�g���[�N�ݒ�l���X�g
				pc_ListPrint->req_startListPrint( TYPE_ListPrintNetworkConfig,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
			//�l�b�g���[�N�ݒ�l���X�g XML��ՋZ�p�J��v2 2017/03/24 Pactera Added End.
			// 2018/06/26 ���Օi��� IT6_Eagle_KRQ-314-22 Pactera Added Start.
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_ConsumableLifeList:			// ���Օi���
				pc_ListPrint->req_startListPrint( TYPE_ListPrintUnitCheck,		e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
			// 2018/06/26 ���Օi��� IT6_Eagle_KRQ-314-22 Pactera Added End.
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_VirusScanRiskLog:		// �E�B���X�X�L����_���X�N���O [SecV6][RQ-909].
				pc_ListPrint->req_startListPrint( TYPE_ListPrintVirusScanRiskLog, e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
			case OAPE_AppReqPrintInfoPage_PrintInfoPage_VirusScanScanLog:			// �E�B���X�X�L����_�X�L�������O [SecV6][RQ-909].
				pc_ListPrint->req_startListPrint( TYPE_ListPrintVirusScanScanLog, e_FeedTray, ans_startListPrint, -1, 0, 0, duplex, TYPE_JobEntryIF_ISOpenAPI );
				break;
			default:
				// �����l�G���[ 
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "Value is invalid in PrintInfoPage.");
				return false;
				break;
		}
	}
	else {
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "Sleep Exit Error");
		return false;
	}

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// ================================================================ 
//�T�v�@�@�F�J�E���^�p�X���[�h���Z�b�g 
//���l�@�@�F
//�쐬�ҁ@�F
//���r���[�F�� 
//�ύX�����F2007.03.27:Kanazawa 
// ================================================================ 
// Amur_GCC4.1�Ή�_ #TODO
template <> class __OAPC_TransactImp<OAPS_AppReqClearCounterPassword> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqClearCounterPassword , OAPE_Result_FaultRequest_AppReqClearCounterPassword > 
{
friend class OAPC_TransactImp<OAPS_AppReqClearCounterPassword>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[���� 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqClearCounterPassword)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqClearCounterPassword)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
	// LockKey 
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqClearCounterPassword)

	int authority = 0;
	OAPC_ApiLock<OAPC_AuthManager> p_authmanager(&_authmanager, &_slock);
	OAPC_AuthManager::OAPE_State e_state = p_authmanager->getStatus();
	if (OAPC_AuthManager::OAPE_State_Auth        ==e_state ||
		OAPC_AuthManager::OAPE_State_AuthAndTrack==e_state ||
		OAPC_AuthManager::OAPE_State_Track==e_state) {
		authority = OAPE_UserType_Admin;
	}
	else {
		authority = OAPE_UserType_Admin;
	}

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C�� 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqClearCounterPassword, AppResClearCounterPassword)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqClearCounterPassword");

	OAPC_ApiLock<APIC_WebDAVdSetting> pc_WebDav(APIC_WebDAVdSetting::newInstanceAdmin(), &_slock);
	if (pc_WebDav) {
		pc_WebDav->initWebDAVdAccountPassword();
	} else {
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// ================================================================ 
//�T�v�@�@�F���N�G�X�g�R�[�h���� 
//���l�@�@�F
//�쐬�ҁ@�F
//���r���[�F�� 
//�ύX�����F2007.04.06:Kanazawa 
// ================================================================ 
// Amur_GCC4.1�Ή�_ #TODO
template <> class __OAPC_TransactImp<OAPS_AppReqCreateRequestCode> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqCreateRequestCode , OAPE_Result_FaultRequest_AppReqCreateRequestCode > 
{
friend class OAPC_TransactImp<OAPS_AppReqCreateRequestCode>;
private:
	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
	
	static TYPE_EnablerResult e_CallbackResult;
	static uchar c_RequestCode[OAPD_DEVICE_REQUESTCODE_MAXSTRING];
	
	static void func_reqCreateRequestCode( TYPE_EnablerResult e_Result, uchar *p_char)
	{
		e_CallbackResult = e_Result;
		OAPC_CallbackObserverMgr<TYPE_EnablerResult , 1211>::getInstance().notify( &e_CallbackResult );
	}
};
TYPE_EnablerResult __OAPC_TransactImp<OAPS_AppReqCreateRequestCode>::e_CallbackResult = TYPE_EnablerResult_ParamError;
#if !(__GNUC__ < 4)	// Amur_GCC4.1�Ή�.
template 
#endif
OAPC_CallbackObserverMgr<TYPE_EnablerResult , 1211> OAPC_CallbackObserverMgr<TYPE_EnablerResult , 1211>::_c_theInstance;

uchar __OAPC_TransactImp<OAPS_AppReqCreateRequestCode>::c_RequestCode[OAPD_DEVICE_REQUESTCODE_MAXSTRING] = {0, };

OAPD_TRANSACT_HANDLING(AppReqCreateRequestCode)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqCreateRequestCode)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	if (p_req->sc_DeviceSerialNumber.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "DeviceSerialNumber");
		return false;
	}
	
	// LockKey 
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqCreateRequestCode)

	int authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C�� 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqCreateRequestCode, AppResCreateRequestCode)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqCreateRequestCode");
	
	/* �V���A���ԍ��̎擾�J�n */ 
	// APIC_SystemInfo      �C���X�^���X�̎擾 
	OAPC_ApiLock<APIC_SystemInfo> p_SystemInfo(APIC_SystemInfo::newInstanceAdmin() , &_slock);
	if(!p_SystemInfo)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	char sc_SerialNumber[OAPD_DEVICEINFODETAIL_SYSTEM_SERIALNUMBER_MAXSTRING] = {0 , };
	//	 SerialNumber�̐������`�F�b�N 
	p_SystemInfo->getSerialNoPrinter(sc_SerialNumber);
	
	if(strcmp(p_req->sc_DeviceSerialNumber.get(),sc_SerialNumber) != 0)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "SerialNumber is not correct");
		return false;
	}
	/* �V���A���ԍ��̎擾�I�� */ 
	
	/* ���N�G�X�g�R�[�h�̎擾�J�n */ 
	//�C���X�^���X�̎擾 
	APIC_Enabler* p_Enabler = APIC_Enabler::newInstanceAdmin();
	if(!p_Enabler)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	//�N���X�̏����� 
	//APIC_Enabler::initClass();

	//2007/7/18 Kanazawa add 
	if(p_Enabler->isLicenseManagementAbnormal() == True)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Abnormal State");
		INC_ERROR_COUNT(CreateReqCode_LicenseManagementAbnormal_AbnormalError);	// ZeusS_ZX0 ����\���ύX_No.76-2 Sahana 2015/11/06 Added.  
		return false;
	}

	//���N�G�X�g�R�[�h�����v�� 
	OAPC_CallbackObserver obs( _slock );
	OAPC_CallbackObserverMgr<TYPE_EnablerResult, 1211>::getInstance().addList( &e_CallbackResult , &obs );

	p_Enabler->req_startGetRequestCode(func_reqCreateRequestCode);
	// Call Back�҂�.....
	_slock.wait();
	
	if(e_CallbackResult == TYPE_EnablerResult_WriteFailed)
	{
		// �������ݎ��s�̏ꍇ 
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Failed to execute");
		return false;
	} else if((e_CallbackResult == TYPE_EnablerResult_Initializing)||
			  (e_CallbackResult == TYPE_EnablerResult_VicePowerOff)||
			  (e_CallbackResult == TYPE_EnablerResult_RequetAndVicePowerOff))
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralDuringSubPowerOff , "GeneralDuringSubPowerOff");
		return false;
	} else if(e_CallbackResult == TYPE_EnablerResult_DuplicateRequest)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralDuringBusy , "Busy");
		return false;
	} else {
		if(e_CallbackResult != TYPE_EnablerResult_OK)
		{
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Failed to execute");
			return false;
		}
	}
	
	/* ���N�G�X�g�R�[�h�̎擾�I�� */ 
	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();
	p_res->sc_DeviceSerialNumber = p_req->sc_DeviceSerialNumber;
	p_Enabler->getRequestCode( c_RequestCode );
	p_res->sc_RequestCode = reinterpret_cast<const char*>(c_RequestCode);
OAPD_END_TRANSACT_EXECUTE

// Donau �Ǘ�No219 akutaya 2008/02/26 START 
// ================================================================ 
//�T�v�@�@�F�A�N�e�B�x�[�V�������� 
//���l�@�@�F
//�쐬�ҁ@�F
//���r���[�F�� 
//�ύX�����F2008/02/26 
// ================================================================ 
// Amur_GCC4.1�Ή�_ #TODO
template <> class __OAPC_TransactImp<OAPS_AppReqSetActivateCode2> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqSetActivateCode2 , OAPE_Result_FaultRequest_AppReqSetActivateCode2 > 
{
friend class OAPC_TransactImp<OAPS_AppReqSetActivateCode2>;
private:
	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
	
	static TYPE_EnablerResult e_CallbackResult;
	
	static void func_reqActivateCode( TYPE_EnablerResult e_Result )
	{
		e_CallbackResult = e_Result;
		OAPC_CallbackObserverMgr<TYPE_EnablerResult , 1211>::getInstance().notify( &e_CallbackResult );
	}
};
TYPE_EnablerResult __OAPC_TransactImp<OAPS_AppReqSetActivateCode2>::e_CallbackResult = TYPE_EnablerResult_ParamError;
OAPD_TRANSACT_HANDLING(AppReqSetActivateCode2)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqSetActivateCode2)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (p_req->sc_DeviceSerialNumber.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "DeviceSerialNumber");
		return false;
	}
	if (p_req->s_FunctionStatus.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "FunctionStatus");
		return false;
	}
	if (p_req->s_FunctionStatus.sc_FunctionCode.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "FunctionCode");
		return false;
	}
	// ZeusMLK CQ372336 kiriike 2012/9/20 START.
	else if (!OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V52) && p_req->s_FunctionStatus.sc_FunctionCode.size() > OAPD_FUNCTIONCODE_MAX_UNDER_V51) {
		//MLK�ȑO�͍ő�4����.
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "FunctionCode");
		return false;
	}
	// ZeusMLK CQ372336 kiriike 2012/9/20 END.
	
	if (p_req->s_FunctionStatus.sc_ActivateCode.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "ActivateCode");
		return false;
	}
	// LockKey 
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqSetActivateCode2)

	int authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C�� 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e))
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// ZeusMLK UV-01023 heima 2012/2/21 start.
// �@�\Code=�@��i���x�P�j�A�@��i���x�Q�j�A�@��i���x�R�j�ȊO�̓G���[��Ԃ�.
// 11_���C�Z���X�Ǘ��@�\�iEnabler�j�Q��.
Bool checkFunctionNGCode(const char* pc_Input)
{
	Bool ret = False;
	if ( 4 == strlen(pc_Input)
		&& 'A' == pc_Input[0]
		&& 'A' == pc_Input[1]
		&& 'A' == pc_Input[2] )	// 4byte�Œ� [AAA-].
	{
		switch(pc_Input[3])
		{
			case 'C':	// 00010 �@��i���x1�j.
			case 'E':	// 00100 �@��i���x2�j.
			case 'G':	// 00110.
			case '8':	// 01000 �@��i���x3�j.
			case 'K':	// 01010.
			case 'M':	// 01100.
			case '9':	// 01110.
				ret = True;
				break;
			default:
				break;
		}
	}
	
	return ret;
}
//MinervaBK2nd CQ380289 Bairavi 2013/06/04 Added Start. 
Bool checkFunctionCodeValue(const char* pc_InputFuncCode)
{
	Bool b_Ret = False;

	if( !pc_InputFuncCode ) {
		return b_Ret;
	}

	ushort us_InputFuncCodeLen = strlen(pc_InputFuncCode);
	if (us_InputFuncCodeLen != 0 ) {
		for(ushort us_LoopIndex = 0; us_LoopIndex < us_InputFuncCodeLen-1; us_LoopIndex++) {
			if( 'A' != (*(pc_InputFuncCode+us_LoopIndex)) ) {
				return b_Ret;
			}
		}
		switch(pc_InputFuncCode[us_InputFuncCodeLen-1])
		{
				case 'C':	// 00010 �@��i���x1�j.
				case 'E':	// 00100 �@��i���x2�j.
				case '8':	// 01000 �@��i���x3�j.
					b_Ret = True;
					break;
				default:
					break;
		}
	}
	return b_Ret;
}
//MinervaBK2nd CQ380289 Bairavi 2013/06/04  Added End. 

//ZeusMLK CQ377321 2013/01/17 shobuke Start.
// ���͂��ꂽ�@�\Code���A�ړI�̋@�\Code�����`�F�b�N����.
// �����@�\���L���ɂȂ��Ă���P�[�X�͍l�����Ȃ�.
// 11_���C�Z���X�Ǘ��@�\�iEnabler�j�Q��.
Bool checkFunctionCodeSpecifyStr(const char* pc_InputFuncCode, const char* pc_SearchCode)
{
	Bool b_Ret = False;
	//char* pc_SearchResult=0; // Helios 2015/04/06 Warning Removal HCL-Sahana Commented.

	if( !pc_InputFuncCode || !pc_SearchCode)
	{
		return False;
	}

	//���͕����񂩂�A�ړI�̋@�\Code����������.
	const char* pc_SearchResult = strstr(pc_InputFuncCode, pc_SearchCode); //Helios 2015/04/06 Warning Removal HCL-Sahana Modified.

	if( pc_SearchResult )
	{
		int i_InputFuncCodeLen = strlen(pc_InputFuncCode);
		int i_SearchResultLen  = strlen(pc_SearchResult);

		//���͕����񒆂ɂ����āA�ړI�̋@�\Code�̑O�ɕ����񂪑��݂���ꍇ.
		if( i_InputFuncCodeLen > i_SearchResultLen )
		{
			for(int i=0; i<(i_InputFuncCodeLen - i_SearchResultLen); i++)
			{
				if( 'A' != (*(pc_InputFuncCode+i)) )
				{
					//'A'�ȊO��Code�����݂���ꍇ�͕s��v.
					return False;
				}
			}
		}

		//�����������ʂƁA�ړI�̋@�\Code����v���邩���m�F.
		if(0 == strcmp(pc_SearchResult, pc_SearchCode))
		{
			b_Ret = True;
		}
	}
	
	return b_Ret;
}
//ZeusMLK CQ377321 2013/01/17 shobuke End.

// CommonAPI�ɓn���̈�̍ő�l. 
#define OAPD_FEKCODEMAX	8		// Donau ����No302603 kobayasi 2008/4/28 bug�C��. 

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqSetActivateCode2, AppResSetActivateCode2)

	OAPD_TRACE_SCOPE("OAPS_AppReqSetActivateCode2");

	// �V���A���ԍ��̎擾�J�n 
	// APIC_SystemInfo �C���X�^���X�̎擾 
	OAPC_ApiLock<APIC_SystemInfo> p_SystemInfo(APIC_SystemInfo::newInstanceAdmin() , &_slock);
	if(!p_SystemInfo)
	{
		e.setKind(OAPE_Fault_faultcode_Server);		// Donau ����No302543 kobayashi 2008/4/30 �o�O�Ή�. 
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	char sc_SerialNumber[OAPD_DEVICEINFODETAIL_SYSTEM_SERIALNUMBER_MAXSTRING] = {0 , };
	// SerialNumber�̐������`�F�b�N 
	p_SystemInfo->getSerialNoPrinter(sc_SerialNumber);
	
	if(strcmp(p_req->sc_DeviceSerialNumber.get(),sc_SerialNumber) != 0)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "SerialNumber is not correct");
		return false;
	}
	// �V���A���ԍ��̎擾�I�� 
	
	// �A�N�e�B�x�[�V�����R�[�h�̃`�F�b�N�J�n 
	//�C���X�^���X�̎擾 
	APIC_Enabler* p_Enabler = APIC_Enabler::newInstanceAdmin();
	OAPC_ApiLock<APIC_EnablerSetting> pc_EnablerSetting(APIC_EnablerSetting::newInstanceAdmin(), &_slock);		// Poseidon CQ505898 Sela 2014/10/24 Added. 
	if(!p_Enabler
    || !pc_EnablerSetting) 	// Poseidon CQ505898 Sela 2014/10/24 Added. 
	{
		e.setKind(OAPE_Fault_faultcode_Server);		// Donau ����No302543 kobayashi 2008/4/30 �o�O�Ή�. 
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}

	//ZeusMLK CQ377321 2013/01/17 shobuke Start.
	//MinervaZeus3rd CQ382787 Sela 2013/09/18 Modified Start. 
	//���x�ύX or ThinPrint or TPM�̏ꍇ�́A�g���������̃`�F�b�N�͂��Ȃ��B
	if( True == isExtendedMemoryCheckRequired(p_req->s_FunctionStatus.sc_FunctionCode.get()) )
	{
	//ZeusMLK CQ377321 2013/01/17 shobuke End.
		// �����������݂���Ă��邩�ǂ����̃`�F�b�N 
		if(p_Enabler->isExtendedMemory() == False)
		{
			e.setKind(OAPE_Fault_faultcode_Server);		// Donau ����No302543 kobayashi 2008/4/30 �o�O�Ή�. 
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralPartsNotInstalled , "Memory is short");
			return false;
		}
	}
	//MinervaZeus3rd CQ382787 Sela 2013/09/18 Modified End. 

// Donau ����No302603 kobayasi 2008/4/28 start. 
	// �@�\��Ԏ擾�J�n. 
	uchar uc_TempFunctionCode[OAPD_FEKCODEMAX];
	uchar uc_TempWaitReboot[OAPD_FEKCODEMAX];
	
	p_Enabler->getFunctionEnablerStatus(uc_TempFunctionCode , uc_TempWaitReboot);

	// �@�\�d��OFF/ON�҂��`�F�b�N. 
	for(int i=0; i<OAPD_FEKCODEMAX; i++)
	{
		if( uc_TempWaitReboot[i] > 0 )
		{
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralWaitRebootConflict, "Must restart");
			return false;
		}
	}
// Donau ����No302603 kobayashi 2008/4/28 end. 

	// ���C�Z���X�Ǘ��ُ��ԃ`�F�b�N 
	if(p_Enabler->isLicenseManagementAbnormal() == True)
	{
		e.setKind( OAPE_Fault_faultcode_Server );
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Abnormal State");
		INC_ERROR_COUNT(SetActivateCode2_LicenseManagementAbnormal_AbnormalError);	// ZeusS_ZX0 ����\���ύX_No.76-2 Sahana 2015/11/06 Added.  
		return false;
	}

	// �A�N�e�B�x�[�V�����R�[�h�̃`�F�b�N�I�� 
	
	// �A�N�e�B�x�[�V�����R�[�h�̏������݊J�n 
	OAPC_CallbackObserver obs( _slock );
	
	OAPC_CallbackObserverMgr<TYPE_EnablerResult, 1211>::getInstance().addList( &e_CallbackResult , &obs );
	// Helios CQ514059 Palani 2015/06/04 Modified Start.
	unsigned char destBitArray[OAPD_FUNCTIONCODE2_MAXSTRING];
	ChgBase32toBin(p_req->s_FunctionStatus.sc_FunctionCode.get(), destBitArray, OAPD_FUNCTIONCODE2_MAXSTRING);
	// Poseidon CQ505898 Sela 2014/10/24 Added Start. 
	//if(strcmp(p_req->s_FunctionStatus.sc_FunctionCode.get(),"B") == 0) {
	if( destBitArray[0] == '1' ) {
		// �@�\�L���A�� �ݒ�.
		pc_EnablerSetting->setInterlock(True);
	}
	// Poseidon CQ505898 Sela 2014/10/24 Added End. 
	// Helios CQ514059 Palani 2015/06/04 Modified End.

	// �@�\�L�����v�� 
	p_Enabler->req_startEnabler(
		(unsigned char *)p_req->s_FunctionStatus.sc_FunctionCode.get(),
		(unsigned char *)p_req->s_FunctionStatus.sc_ActivateCode.get(),
		func_reqActivateCode
	);


	// Call Back�҂�..... 
	_slock.wait();

// Donau ����No302603 kobayasi 2008/4/28 start. 
	switch(e_CallbackResult)
	{
		// �p�����[�^�G���[�̏ꍇ. 
		case TYPE_EnablerResult_InspectFailed:				// ���؎��s. 
			p_res->e_WriteResult = OAPE_WriteResult_CodeError;
			break;
		// �������ݎ��s�̏ꍇ. 
		case TYPE_EnablerResult_WriteFailed:					// PRT�ւ̏������ݎ��s. 
			p_res->e_WriteResult = OAPE_WriteResult_WriteNG;
			break;
		case TYPE_EnablerResult_ParamError:					// �p�����[�^�G���[. 
		case TYPE_EnablerResult_Initializing:				// �G���W�������������O�̗v��. 
		case TYPE_EnablerResult_VicePowerOff:				// ���d��OFF���̗v��. 
		case TYPE_EnablerResult_RequetAndVicePowerOff:		// �v�����̕��d��OFF. 
		case TYPE_EnablerResult_DuplicateRequest:			// �Q�d�v��. 
		case TYPE_EnablerResult_InternalError:				// ���������G���[(����/�ϊ����s). 
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Failed to execute");
			return false;
		// �������ݐ���. 
		case TYPE_EnablerResult_OK:
			p_res->e_WriteResult = OAPE_WriteResult_WriteOK;
			break;
		// ����`. 
		default:
			p_res->e_WriteResult = OAPE_WriteResult_Unidentified;
			break;
	}
// Donau ����No302603 kobayashi 2008/4/28 end. 
	// �A�N�e�B�x�[�V�����R�[�h�̏������ݏI�� 

	p_res->sc_DeviceSerialNumber = p_req->sc_DeviceSerialNumber;
	
	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();
OAPD_END_TRANSACT_EXECUTE
// Donau �Ǘ�No219 akutaya 2008/02/26 END 

// ================================================================.
//�T�v�@�@�F�A�N�e�B�x�[�V�����R�[�h������.
//���l�@�@�F
//�쐬�ҁ@�F
//���r���[�F
//�ύX�����F
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqDisableActivateCode> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqDisableActivateCode , OAPE_Result_FaultRequest_AppReqDisableActivateCode > 
{
friend class OAPC_TransactImp<OAPS_AppReqDisableActivateCode>;
private:
	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
	
	static TYPE_EnablerResult e_CallbackResult;
	static uchar puc_CallbackDisablerFinishLicenseCode[OAPD_DISABLERCODE_MAXSTRING];
	
	static void func_reqstartDisabler( TYPE_EnablerResult us_Result, uchar *puc_DisablerFinishLicenseCode )
	{
		e_CallbackResult = us_Result;
		strncpy((char*)puc_CallbackDisablerFinishLicenseCode,(char*)puc_DisablerFinishLicenseCode,(OAPD_DISABLERCODE_MAXSTRING -1));
		OAPC_CallbackObserverMgr<TYPE_EnablerResult , 1>::getInstance().notify( &e_CallbackResult );
	}
};
TYPE_EnablerResult __OAPC_TransactImp<OAPS_AppReqDisableActivateCode>::e_CallbackResult = TYPE_EnablerResult_ParamError;
uchar __OAPC_TransactImp<OAPS_AppReqDisableActivateCode>::puc_CallbackDisablerFinishLicenseCode[OAPD_DISABLERCODE_MAXSTRING] = {0,};
#if (__GNUC__ < 4)
OAPC_CallbackObserverMgr<TYPE_EnablerResult, 1>		OAPC_CallbackObserverMgr<TYPE_EnablerResult, 1>::_c_theInstance;
#else
template OAPC_CallbackObserverMgr<TYPE_EnablerResult, 1>		OAPC_CallbackObserverMgr<TYPE_EnablerResult, 1>::_c_theInstance;
#endif

OAPD_TRANSACT_HANDLING(AppReqDisableActivateCode)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqDisableActivateCode)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (p_req->sc_DeviceSerialNumber.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "DeviceSerialNumber");
		return false;
	}
	if (p_req->s_FunctionStatus.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "FunctionStatus");
		return false;
	}
	if (p_req->s_FunctionStatus.sc_FunctionCode.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "FunctionCode");
		return false;
	}
	// ZeusMLK CQ372336 kiriike 2012/9/20 START.
	else if (!OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V52) && p_req->s_FunctionStatus.sc_FunctionCode.size() > OAPD_FUNCTIONCODE_MAX_UNDER_V51) {
		//MLK�ȑO�͍ő�4����.
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "FunctionCode");
		return false;
	}
	// ZeusMLK CQ372336 kiriike 2012/9/20 END.
	
	// �@�\Code=�@��i���x�P�j�A�@��i���x�Q�j�A�@��i���x�R�j�ȊO�̓G���[�iGeneralIllegalValue�j��Ԃ�.
	//MinervaBK2nd CQ380289 Bairavi 2013/06/04 Modified Start. 
	if( False == checkFunctionCodeValue(p_req->s_FunctionStatus.sc_FunctionCode.get()) )
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "FunctionCode");
		return false;
	}
	//MinervaBK2nd CQ380289 Bairavi 2013/06/04 Modified End. 
	
	if (p_req->s_FunctionStatus.sc_DisablerCode.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "DisablerCode");
		return false;
	}
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqDisableActivateCode)

	int authority = OAPE_UserType_Admin;

	////////////////////////////////////.
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e))
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqDisableActivateCode, AppResDisableActivateCode)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("AppReqDisableActivateCode");

	// �V���A���ԍ��̎擾�J�n.
	// APIC_SystemInfo �C���X�^���X�̎擾.
	OAPC_ApiLock<APIC_SystemInfo> p_SystemInfo(APIC_SystemInfo::newInstanceAdmin() , &_slock);
	APIC_Enabler* p_Enabler = APIC_Enabler::newInstanceAdmin();
	if(!p_SystemInfo || !p_Enabler)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	char sc_SerialNumber[OAPD_DEVICEINFODETAIL_SYSTEM_SERIALNUMBER_MAXSTRING] = {0 , };
	// SerialNumber�̐������`�F�b�N.
	p_SystemInfo->getSerialNoPrinter(sc_SerialNumber);
	
	if(strcmp(p_req->sc_DeviceSerialNumber.get(),sc_SerialNumber) != 0)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "SerialNumber is not correct");
		return false;
	}
	// �V���A���ԍ��̎擾�I��.

	//ZeusMLK CQ377321 2013/01/17 shobuke Start.
	//���x�ύX�̏ꍇ�́AHDD�A�g���������̃`�F�b�N�͂��Ȃ��B
	//PreCheck�ŁA�ȉ��̏����ŃG���[�ɂ��Ă���̂ŁA�����ňȉ��̏�����TRUE�ɂȂ�Ȃ��B DeadCode�ׁ̈ACQ380289�ő΍􂵂Ȃ��B//MinervaBK2nd CQ380289 Bairavi 2013/06/06 Added Comment. 
	if( False == checkFunctionNGCode(p_req->s_FunctionStatus.sc_FunctionCode.get()) ) {
	//ZeusMLK CQ377321 2013/01/17 shobuke End.

		// �����������݂���Ă��邩�ǂ����̃`�F�b�N.
		if(p_Enabler->isExtendedMemory() == False)
		{
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralPartsNotInstalled , "Memory is short");
			return false;
		}
	}

	// ���C�Z���X�Ǘ��ُ��ԃ`�F�b�N.
	if(p_Enabler->isLicenseManagementAbnormal() == True)
	{
		e.setKind( OAPE_Fault_faultcode_Server );
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Abnormal State");
		INC_ERROR_COUNT(DisableActivateCode_LicenseManagementAbnormal_AbnormalError);	// ZeusS_ZX0 ����\���ύX_No.76-2 Sahana 2015/11/06 Added. 
		return false;
	}

	// �A�N�e�B�x�[�V�����R�[�h�������J�n.
	OAPC_CallbackObserver obs( _slock );

	OAPC_CallbackObserverMgr<TYPE_EnablerResult, 1>::getInstance().addList( &e_CallbackResult , &obs );

	// �@�\�L�����v��.
	p_Enabler->req_startDisabler(
		( uchar *)p_req->s_FunctionStatus.sc_FunctionCode.get(),
		( uchar *)p_req->s_FunctionStatus.sc_DisablerCode.get(),
		func_reqstartDisabler
	);


	// Call Back�҂�......
	_slock.wait();

	switch(e_CallbackResult)
	{
		// �p�����[�^�G���[�̏ꍇ.
		case TYPE_EnablerResult_InspectFailed:				// ���؎��s.
			p_res->e_WriteResult = OAPE_WriteResult2_CodeError;
			break;
		// �������ݎ��s�̏ꍇ.
		case TYPE_EnablerResult_WriteFailed:				// PRT�ւ̏������ݎ��s.
		case TYPE_EnablerResult_ParamError:					// �p�����[�^�G���[.
		case TYPE_EnablerResult_Initializing:				// �G���W�������������O�̗v��.
		case TYPE_EnablerResult_VicePowerOff:				// ���d��OFF���̗v��.
		case TYPE_EnablerResult_RequetAndVicePowerOff:		// �v�����̕��d��OFF.
		case TYPE_EnablerResult_DuplicateRequest:			// �Q�d�v��.
		case TYPE_EnablerResult_InternalError:				// ���������G���[(����/�ϊ����s).
			p_res->e_WriteResult = OAPE_WriteResult2_WriteNg;
			break;
		// �������ݐ���.
		case TYPE_EnablerResult_OK:
			p_res->e_WriteResult = OAPE_WriteResult2_WriteOk;
			break;
		// ����`.
		default:
			p_res->e_WriteResult = OAPE_WriteResult2_Unidentified;
			break;
	}
	// �A�N�e�B�x�[�V�����R�[�h�������I��.

	p_res->sc_DeviceSerialNumber = p_req->sc_DeviceSerialNumber;
	if(p_res->e_WriteResult == OAPE_WriteResult_WriteOK) p_res->sc_DisablerFinishLicenseCode = puc_CallbackDisablerFinishLicenseCode;
	
	////////////////////////////////////.
	// ���ʒʒm���ʍ\���̍쐬.
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// ZeusMLK UV-01023 heima 2012/2/21 end.

// ================================================================.
//�T�v�@�@�F���C�Z���X�L����.
//���l�@�@�F.
//�쐬�ҁ@�Fmatsuda.
//�ύX�����F2010.07.22:matsuda.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqSetTokenCode> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqSetTokenCode , OAPE_Result_FaultRequest_AppReqSetTokenCode > 
{
friend class OAPC_TransactImp<OAPS_AppReqSetTokenCode>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqSetTokenCode)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqSetTokenCode)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) 
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) == false )
	{
		return false;
	}
	
	if(p_req->s_TokenCodeList.ss_ArraySize.empty())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "ss_ArraySize");
		return false;
	}
	if(!p_req->s_TokenCodeList.ss_ArraySize.range())
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralRangeIllegal, "ss_ArraySize");
		return false;
	}
	if(emptyArray( p_req->s_TokenCodeList.sc_TokenCode, OAPD_TOKENCODE_MAXLIST ))
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "sc_TokenCode");
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqSetTokenCode)

	int authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e))
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqSetTokenCode, AppResSetTokenCode)

	OAPD_TRACE_SCOPE("OAPS_AppReqSetTokenCode");
	
	APIC_Enabler* pc_Enabler = APIC_Enabler::newInstanceAdmin();
	OAPC_ApiLock<APIC_EnablerSetting> pc_EnablerSetting(APIC_EnablerSetting::newInstanceAdmin(), &_slock);
	OAPC_ApiLock<APIC_Lca> pc_Lca(APIC_Lca::newInstanceAdmin(), &_slock);		// Minerva���� UV-00683 matsuda 2011/01/25 �ǉ�.

	if(!pc_Enabler				// Helios CQ510774�Ή� 2015/04/17 HCL-Kavitha Modified.
	|| !pc_EnablerSetting
	|| !pc_Lca)					// Minerva���� UV-00683 matsuda 2011/01/25 �ǉ�.
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	// �@�\��Ԏ擾�J�n. 
	uchar uc_TempFunctionCode[OAPD_FEKCODEMAX];
	uchar uc_TempWaitReboot[OAPD_FEKCODEMAX];
	
	pc_Enabler->getFunctionEnablerStatus(uc_TempFunctionCode , uc_TempWaitReboot);

	// �@�\�d��OFF/ON�҂��`�F�b�N. 
	for(ushort i=0; i<OAPD_FEKCODEMAX; i++)
	{
		if( uc_TempWaitReboot[i] > 0 )
		{
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralWaitRebootConflict, "Must restart");
			return false;
		}
	}

	// ���C�Z���X�Ǘ��ُ��ԃ`�F�b�N.
	if(pc_Enabler->isLicenseManagementAbnormal() == True)
	{
		e.setKind( OAPE_Fault_faultcode_Server );
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Abnormal State");
		INC_ERROR_COUNT(SetTokenCode_LicenseManagementAbnormal_AbnormalError);	// ZeusS_ZX0 ����\���ύX_No.76-2 Sahana 2015/11/06 Added.
		return false;
	}
	
	OAPC_EnablerSettingObserver& pc_EnablerSettingObserver =  OAPC_EnablerSettingObserver::getInstance();
	pc_EnablerSettingObserver.setLock(_slock);
	LCAS_LcaTokenCode s_LcaTokenCode = { {{0,0}} };

	for( i = 0; i < p_req->s_TokenCodeList.ss_ArraySize.get(); i++ )
	{
		if( !p_req->s_TokenCodeList.sc_TokenCode[i].empty() )
		{
			strncpy( s_LcaTokenCode.sc_TokenCode[i],p_req->s_TokenCodeList.sc_TokenCode[i].get(),sizeof(s_LcaTokenCode.sc_TokenCode[i]) );
		}
	}

	// IWSGen2�g��FUM RQ797�̒ǉ��Ή� 2020.09.03
	TYPE_LcaTrgKind e_LcaTrgKind = TYPE_LcaTrgKind_Activation;		// �^�O�ȗ��̏ꍇ�́u�L�����v�Ƃ���.
	if( !p_req->e_Type.empty() )
	{
		if( !getCommAPIEnum( p_req->e_Type, e_LcaTrgKind ) )
        {
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Failed to execute");
			return false;
        }
	}

	pc_EnablerSettingObserver.attach();
	pc_EnablerSetting->indTrg( e_LcaTrgKind, &s_LcaTokenCode );
	
	_slock.wait();
	pc_EnablerSettingObserver.detach();
	ushort us_Count = 0;
// Minerva���� UV-00683 matsuda 2011/01/25 START.	
	switch(pc_EnablerSettingObserver.getLcaDispCode())
	{
		case TYPE_LcaDispCode_NormalEnd:							// ����I��.
			p_res->e_WriteResult = OAPE_WriteResult_WriteOK;
			break;
		case TYPE_LcaDispCode_FalseEnd:						// �z�X�g�Ƃ̒ʐM�ُ�(�ʐM�G���[).
		case TYPE_LcaDispCode_TimeOutError:					// �����t�@�C����M�s�\�i�^�C���A�E�g�j.
		case TYPE_LcaDispCode_SerialNumberError:			// �V���A���i���o�[NG�G���[.
		case TYPE_LcaDispCode_ReceiveFileError:				// �t�@�C����̓G���[.
		case TYPE_LcaDispCode_PutFileError:					// �t�@�C�����u���Ȃ��G���[.
		case TYPE_LcaDispCode_RequestCodeError:				// ���N�G�X�g�R�[�hNG�G���[.
		case TYPE_LcaDispCode_LMSError:						// LMS�����G���[.
			getOpenAPIEnum( pc_EnablerSettingObserver.getLcaDispCode(), p_res->s_ErrorDetail.e_Error );
			p_res->e_WriteResult = OAPE_WriteResult_WriteNG;
			pc_Lca.get_str(p_res->s_ErrorDetail.sc_ErrorCode, &APIC_Lca::getErrorCodeResult);
			break;
		case TYPE_LcaDispCode_TokenCodeError:						// �g�[�N���R�[�h�G���[.
			getOpenAPIEnum( pc_EnablerSettingObserver.getLcaDispCode(), p_res->s_ErrorDetail.e_Error );
			p_res->e_WriteResult = OAPE_WriteResult_WriteNG;
			
			LCAS_LcaTokenCode s_LcaErrorTokenCode;
			pc_EnablerSetting->getErrorTokenCodeList(&s_LcaErrorTokenCode);
			for( i = 0; i < OAPD_TOKENCODE_MAXLIST; i++ )
			{
				if( s_LcaErrorTokenCode.sc_TokenCode[i][0] != '\0' )
				{
					p_res->s_ErrorDetail.s_ErrorTokenCodeList.sc_TokenCode[us_Count] = s_LcaErrorTokenCode.sc_TokenCode[i];
					us_Count++;
				}
			}
			p_res->s_ErrorDetail.s_ErrorTokenCodeList.ss_ArraySize = us_Count;
			break;
		default:
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Failed to execute");
			return false;
			break;
	}
// Minerva���� UV-00683 matsuda 2011/01/25 END.	

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬.
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// Minerva���� UV-00683 matsuda 2010/07/22 END.

// ================================================================ 
//�T�v�@�@�F���u�[�g 
//���l�@�@�F
//�쐬�ҁ@�F
//���r���[�F�� 
//�ύX�����F2007.04.06:Kanazawa 
// ================================================================ 
// Amur_GCC4.1�Ή�_ #TODO
template <> class __OAPC_TransactImp<OAPS_AppReqReboot> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqReboot , OAPE_Result_FaultRequest_AppReqReboot > 
{
friend class OAPC_TransactImp<OAPS_AppReqReboot>;
private:
	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqReboot)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqReboot)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
	// LockKey 
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqReboot)

	int authority = OAPE_UserType_Admin;

// 2023/01/16 [IT6-117(�@��}�[�W)] Sky�O�c Add Start FleetRMM�𗘗p���ĉ��u����CE�p�X���[�h���ꊇ�ŕύX�\�ɂ���v�].
	OAPC_ApiLock<APIC_SoftDipSw> pc_SoftDipSw(APIC_SoftDipSw::newInstanceAdmin(), &_slock);
	if( pc_SoftDipSw ) {
		if ( True == pc_SoftDipSw->getSoftDipSwBitForPanelSpecNo(244, 4) ){
			// CE�����ǉ�.
			authority |= OAPE_UserType_CE;
		} else {
			// �����Ȃ�.
		}
	} else {
		// �����Ȃ�.
	}
// 2023/01/16 [IT6-117(�@��}�[�W)] Sky�O�c Add End FleetRMM�𗘗p���ĉ��u����CE�p�X���[�h���ꊇ�ŕύX�\�ɂ���v�].

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C�� 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqReboot, AppResReboot)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqReboot");
	
	/* ���u�[�g */ 
	// DonauDS CQNo.320957 2009/9/29 Sone START.
	// �C���X�^���X�̐����{lock���C���X�^���X�̐����݂̂ɕύX.
	APIC_SystemServiceFunction *p_SystemServiceFunction = APIC_SystemServiceFunction::newInstanceAdmin();
	// DonauDS CQNo.320957 2009/9/29 Sone END.
	
	if(!p_SystemServiceFunction)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	p_SystemServiceFunction->reboot();

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// ================================================================ 
// IEEE802.1x�F�؊J�n
// ================================================================ 
// Amur_GCC4.1�Ή�_ #TODO
template <> class __OAPC_TransactImp<OAPS_AppReq8021xCompleteConfig> :
	public OAPC_TransactImpBaseInquiry<OAPS_AppReq8021xCompleteConfig, OAPE_Result_FaultRequest_AppReq8021xCompleteConfig> 
{
friend class OAPC_TransactImp<OAPS_AppReq8021xCompleteConfig>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[���� 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check( const OAPC_Memory& , OAPC_Error& );
	inline bool _authorize( const OAPC_Memory& , OAPC_Error& );
	inline bool _execute( const OAPC_Memory& , OAPC_Memory& , OAPC_Error& );
};

OAPD_TRANSACT_HANDLING(AppReq8021xCompleteConfig);

OAPD_BEGIN_TRANSACT_PRECHECK(AppReq8021xCompleteConfig)

	// LockKey 
	if (!DEVICE_LOCKKEY_PASS_CHECK(p_req, _slock, e, true)) {
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReq8021xCompleteConfig)

	int authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C�� 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReq8021xCompleteConfig, AppRes8021xCompleteConfig)

	OAPD_TRACE_SCOPE( "AppReq8021xCompleteConfig" );

	// CommonApi����I�u�W�F�N�g�擾
	OAPC_ApiLock<APIC_IEEE802Setting> pc_IEEE802Setting(APIC_IEEE802Setting::newInstanceAdmin(), &_slock);

	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ��Fault��Ԃ� 
	if(!pc_IEEE802Setting) {
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}

	// �F�ؓ���J�n . 
	if(ERROR == pc_IEEE802Setting->getCompleteConfig()) {
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_Device8021XCompleteConfigFailure, "getCompleteConfig() returned the ERROR.");
		return false;
	}

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// Minerva���� �Ǘ�No320 matsuda 2010/06/17 START.
// ================================================================.
//�T�v�@�@�F�g���u�����Z�b�g.
//���l�@�@�F.
//�쐬�ҁ@�Fmatsuda.
//�ύX�����F2010.06.17:matsuda.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqTroubleReset> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqTroubleReset , OAPE_Result_FaultRequest_AppReqTroubleReset > 
{
friend class OAPC_TransactImp<OAPS_AppReqTroubleReset>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqTroubleReset)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqTroubleReset)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqTroubleReset)

	int authority = 0;
	OAPC_ApiLock<OAPC_AuthManager> p_authmanager(&_authmanager, &_slock);
	OAPC_AuthManager::OAPE_State e_state = p_authmanager->getStatus(p_req->e_NetworkType.get());	//IT6_Eagle AR1058015 Hcl-Palani 2018/09/04 Modified.
	if (OAPC_AuthManager::OAPE_State_Auth        ==e_state ||
		OAPC_AuthManager::OAPE_State_AuthAndTrack==e_state ||
		OAPC_AuthManager::OAPE_State_Track==e_state) 
	{	// �F��ON �̏ꍇ.
		authority = OAPE_UserType_User|OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
	}
	else
	{
		authority = OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
	}

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqTroubleReset, AppResTroubleReset)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqTroubleReset");
	
	//IT6_Eagle AR1068377 2018/11/30 HCL-Kailash Added Start.
	TYPE_NetworkSpecific e_NetworkSpecific = TYPE_NetworkSpecific_NW1;
	if((!p_req->e_NetworkType.empty()) && (OAPE_NetworkType_NW2 == p_req->e_NetworkType.get())){
		if(true == checkVLANSetting(e)){
			getCommAPIEnum( p_req->e_NetworkType, e_NetworkSpecific );
		}
			else{
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "VLAN setting is disabled");
				return false;
			}
	}
	//IT6_Eagle AR1068377 2018/11/30 HCL-Kailash Added End.
	APIC_SystemStatus *p_SystemStatus = APIC_SystemStatus::newInstanceAdmin();
	
	if(!p_SystemStatus)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	// �g���u�����Z�b�g.
	// OpenAPI����̗v���ŁA�G���[�����N�Ɋւ��Ă�B�܂ŉ���.
	if( False == p_SystemStatus->req_FatalCancellation( TYPE_FatalCancelRequestModuleOpenAPI, TYPE_FatalRankB ) )
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "FatalCancelNG");
		return false;
	}
	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// Minerva���� �Ǘ�No320 matsuda 2010/06/17 END.
// Minerva��s�J�� UV-00740 okabe 2010/11/5 START.
// ================================================================.
// �ڑ��m�F�v��Request.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqConnectionConfirmation> :
	public OAPC_TransactImpBaseInquiry<OAPS_AppReqConnectionConfirmation, OAPE_Result_FaultRequest_AppReqConnectionConfirmation> 
{
friend class OAPC_TransactImp<OAPS_AppReqConnectionConfirmation>;
private:
	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check( const OAPC_Memory& , OAPC_Error& );
	inline bool _authorize( const OAPC_Memory& , OAPC_Error& );
	inline bool _execute( const OAPC_Memory& , OAPC_Memory& , OAPC_Error& );
	
	static Bool b_Result;

	static void func_ans_ping( Bool b_CallbackResult)
	{
		b_Result = b_CallbackResult;
		OAPC_CallbackObserverMgr<Bool , 1211>::getInstance().notify( &b_Result );
	}

};
Bool __OAPC_TransactImp<OAPS_AppReqConnectionConfirmation>::b_Result = False;

OAPD_TRANSACT_HANDLING(AppReqConnectionConfirmation);

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqConnectionConfirmation)

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}

	// LockKey.
	if (!DEVICE_LOCKKEY_PASS_CHECK(p_req, _slock, e, true)) {
		return false;
	}
	
	if( p_req->sc_IpAddress.empty() ){
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "IpAddress");
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqConnectionConfirmation)

	int authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C�� 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqConnectionConfirmation, AppResConnectionConfirmation)

	OAPD_TRACE_SCOPE( "AppReqConnectionConfirmation" );

	// CommonApi����I�u�W�F�N�g�擾
	OAPC_ApiLock<APIC_TcpIpSetting> pc_TcpIpSetting(APIC_TcpIpSetting::newInstanceAdmin(), &_slock);
	//RQ-686 IT3 Hcl_Dinesh 2017/10/04 Modified Start.
	   TYPE_NetworkSpecific e_NetworkSpecific = TYPE_NetworkSpecific_NW1;
		if((!p_req->e_NetworkType.empty()) && ((OAPE_NetworkType_NW2 == p_req->e_NetworkType.get())||(OAPE_NetworkType_ALL == p_req->e_NetworkType.get()))){
			if(true == checkVLANSetting(e)){
				getCommAPIEnum( p_req->e_NetworkType, e_NetworkSpecific );
			}
			else{
				e.setKind(OAPE_Fault_faultcode_Client);
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "VLAN setting is disabled");
				return false;
			}
		}
	
     //RQ-686 IT3 Hcl_Dinesh 2017/10/04 Modified End.

	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ��Fault��Ԃ� 
	if(!pc_TcpIpSetting) {
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}

	OAPC_CallbackObserver obs( _slock );
	OAPC_CallbackObserverMgr<Bool, 1211>::getInstance().addList( &b_Result , &obs );
	
	pc_TcpIpSetting->req_ping((char*)p_req->sc_IpAddress.get(),1,func_ans_ping, e_NetworkSpecific);
	// Call Back�҂�.
	_slock.wait();

	if( b_Result != True){
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Failed to execute");
		return false;
	}
	
	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// Minerva��s�J�� UV-00740 okabe 2010/11/5 END.

// Minerva UV-00971 InternetISW�@�\���P nishida 2010/10/07 START.
// ================================================================.
//�T�v�@�@�F�t�@�[���E�F�A�_�E�����[�h.
//���l�@�@�F.
//�쐬�ҁ@�Fnishida.
//�ύX�����F2010.10.07:nishida.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqFwDownload> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqFwDownload , OAPE_Result_FaultRequest_AppReqFwDownload > 
{
friend class OAPC_TransactImp<OAPS_AppReqFwDownload>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqFwDownload)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqFwDownload)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqFwDownload)

	int32_t authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqFwDownload, AppResFwDownload)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqFwDownload");
	
	e.setKind(OAPE_Fault_faultcode_Server);	// Minerva CQ342671 nishida 2011/04/25 �ǉ�.
	
//#ifdef TORNADO // SimWin�r���h�Ή�.		//IT5_4.0 1008278 Sahana 2016/12/01 Commented.
	OAPC_ApiLock<APIC_InternetISW> pc_InternetISW( APIC_InternetISW::newInstanceAdmin() , &_slock );
	
	if(!pc_InternetISW)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}

	// Minerva CQ342671 nishida 2011/04/25 START.	
	// IISW�g�p�ݒ� False���̃G���[.
	if ( False == pc_InternetISW->getEnableInternetISW() ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "EnableInternetISW:False");
		INC_ERROR_COUNT(FwDownload_EnableInternetISWError);	// ZeusS_ZX0 ����\���ύX_No.76-2 Sahana 2015/11/06 Added.
		return false;
	}

	// �_�E�����[�hURL NULL���̃G���[.
	char uc_url[OAPD_DOWNLOADURL_MAXSTRING] = {'\0',};
	pc_InternetISW->getURL(uc_url);
	if ( '\0' == uc_url[0] ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "DownLoadUrl:Null");
		return false;
	}
	
	// �_�E�����[�h�t�@�C���� NULL���̃G���[.
	char uc_filename[OAPD_FWFILENANE_MAXSTRING] = {'\0',};
	pc_InternetISW->getDownloadRomParameter(uc_filename);
	if ( ( '\0' == uc_filename[0] )
	  || ( ( '\x0E' == uc_filename[0] )
	    && ( '\0'   == uc_filename[1] ) ) ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "DownLoadFileName:Null");
		return false;
	}
	// Minerva CQ342671 nishida 2011/04/25 END.

	
	// FW�_�E�����[�h �J�n�v��.
	// ZeusCD CQ384534 Sela 2014/02/19 Modified Start. 
	if ( False == pc_InternetISW->setInternetISWStart(TYPE_InternetIswKindDownLoad) ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Failed to start File Download");
		return false;
	}
	// ZeusCD CQ384534 Sela 2014/02/19 Modified End. 
//#endif // TORNADO SimWin�r���h�Ή�.		//IT5_4.0 1008278 Sahana 2016/12/01 Commented.
	
	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// ================================================================.
//�T�v�@�@�F�t�@�[���E�F�A�_�E�����[�h�L�����Z��.
//���l�@�@�F.
//�쐬�ҁ@�Fnishida.
//�ύX�����F2010.10.07:nishida.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqFwDownloadCancel> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqFwDownloadCancel , OAPE_Result_FaultRequest_AppReqFwDownloadCancel > 
{
friend class OAPC_TransactImp<OAPS_AppReqFwDownloadCancel>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqFwDownloadCancel)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqFwDownloadCancel)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqFwDownloadCancel)

	int32_t authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqFwDownloadCancel, AppResFwDownloadCancel)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqFwDownloadCancel");
	
//#ifdef TORNADO // SimWin�r���h�Ή�.		//IT5_4.0 1008278 Sahana 2016/12/01 Commented.
	OAPC_ApiLock<APIC_InternetISW> pc_InternetISW( APIC_InternetISW::newInstanceAdmin() , &_slock );
	
	if(!pc_InternetISW)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	// �_�E�����[�h���̏ꍇ�A�L�����Z��.
	// �_�E�����[�h���ȊO�̏ꍇ�AFW�폜.
	if ( pc_InternetISW->getFWDLStatus() == TYPD_FWDLStatus_DownLoad )
	{
		// FW�_�E�����[�h�L�����Z�� �v��.
		pc_InternetISW->setFirmwareDownLoadCancel();
	}
	else
	{
		// �_�E�����[�h�ς�FW�폜 �v��.
		pc_InternetISW->setFirmwareDownLoadDelete();
	}
//#endif // TORNADO SimWin�r���h�Ή�.		//IT5_4.0 1008278 Sahana 2016/12/01 Commented.
	
	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// ================================================================.
//�T�v�@�@�F�t�@�[���E�F�A�_�E�����[�h�X�e�[�^�X�擾.
//���l�@�@�F.
//�쐬�ҁ@�Fnishida.
//�ύX�����F2010.10.07:nishida.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqGetFwDownloadStatus> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqGetFwDownloadStatus , OAPE_Result_FaultRequest_AppReqGetFwDownloadStatus > 
{
friend class OAPC_TransactImp<OAPS_AppReqGetFwDownloadStatus>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
	inline bool _preparation(const OAPC_Memory& msg, OAPC_Memory& retres, int iRequestItem, OAPC_Error& e);
	inline bool _post_process(const OAPC_Memory& msg, OAPC_Memory& retres, int iRequestItem, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING_CUSTOMDATA(AppReqGetFwDownloadStatus)

// �p�����[�^�ݒ�.
OAPD_BEGIN_TRANSACT_PREPARATION(AppReqGetFwDownloadStatus)
	if( !p_req->s_OperatorInfo.empty()) {
		req->s_OperatorInfo = p_req->s_OperatorInfo;
	}

	retres = p_param;

OAPD_END_TRANSACT_PREPARATION

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetFwDownloadStatus)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqGetFwDownloadStatus)

	int32_t authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqGetFwDownloadStatus, AppResGetFwDownloadStatus)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqGetFwDownloadStatus");
	
//#ifdef TORNADO // SimWin�r���h�Ή�.		//IT5_4.0 1008278 Sahana 2016/12/01 Commented.
	OAPC_ApiLock<APIC_InternetISW> pc_InternetISW( APIC_InternetISW::newInstanceAdmin() , &_slock );
	
	if(!pc_InternetISW)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	getOpenAPIEnum(pc_InternetISW->getFWDLStatus(), p_res->e_Status);
//#endif // TORNADO SimWin�r���h�Ή�.		//IT5_4.0 1008278 Sahana 2016/12/01 Commented.

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// �����f�[�^�ݒ�.
OAPD_BEGIN_TRANSACT_POSTPROCESS(AppReqGetFwDownloadStatus, AppResGetFwDownloadStatus)

	p_res->s_CustomData.s_AppResGetFwDownloadStatus = *res;
	p_res->s_CustomData.s_AppResGetFwDownloadStatus.s_Result.e_ResultInfo.clean();

OAPD_END_TRANSACT_POSTPROCESS


// ================================================================.
//�T�v�@�@�F�t�@�[���E�F�A�X�V.
//���l�@�@�F.
//�쐬�ҁ@�Fnishida.
//�ύX�����F2010.10.07:nishida.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqFwUpdate> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqFwUpdate , OAPE_Result_FaultRequest_AppReqFwUpdate > 
{
friend class OAPC_TransactImp<OAPS_AppReqFwUpdate>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqFwUpdate)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqFwUpdate)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqFwUpdate)

	int32_t authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqFwUpdate, AppResFwUpdate)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqFwUpdate");
	
	e.setKind(OAPE_Fault_faultcode_Server);	// Minerva CQ342687 nishida 2011/04/25 �ǉ�.
	
//#ifdef TORNADO // SimWin�r���h�Ή�.		//IT5_4.0 1008278 Sahana 2016/12/01 Commented.
	OAPC_ApiLock<APIC_InternetISW> pc_InternetISW( APIC_InternetISW::newInstanceAdmin() , &_slock );
	
	if(!pc_InternetISW)
	{
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}

	// Minerva CQ342687 nishida 2011/04/25 START.
	// �_�E�����[�h�ς�(�X�e�[�^�X������)�łȂ��ꍇ�̓G���[.
	if ( TYPD_FWDLStatus_NormalEnd != pc_InternetISW->getFWDLStatus() ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "A file is not downloaded.");
		return false;
	}
	// Minerva CQ342687 nishida 2011/04/25 END.
	
	// FW�X�V �J�n�v��.
	// ZeusCD CQ384534 Sela 2014/02/19 Modified Start. 
	if ( False == pc_InternetISW->setInternetISWStart(TYPE_InternetIswKindUpdate) ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Failed to start FW Update");
		INC_ERROR_COUNT(FwUpdate_EnableInternetISWError);	// ZeusS_ZX0 ����\���ύX_No.76-2 Sahana 2015/11/06 Added.
		return false;
	}
	// ZeusCD CQ384534 Sela 2014/02/19 Modified End. 
//#endif // TORNADO SimWin�r���h�Ή�.		//IT5_4.0 1008278 Sahana 2016/12/01 Commented.

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// Minerva UV-00971 InternetISW�@�\���P nishida 2010/10/07 END.
// ZeusCD UV-1385 IISW�̉^�p�ۑ�̑Ή� 2013/11/21 Sela Added Start. 
// ================================================================.
//�T�v�@�@�F�t�@�[���E�F�A���[���o�b�N.
//���l�@�@�F.
//�쐬�ҁ@�FSela.
//�ύX�����F2013.11.22:Sela.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqFwRollback> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqFwRollback , OAPE_Result_FaultRequest_AppReqFwRollback > 
{
friend class OAPC_TransactImp<OAPS_AppReqFwRollback>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqFwRollback)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqFwRollback)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqFwRollback)

	int32_t authority = OAPE_UserType_Admin;

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqFwRollback, AppResFwRollback)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqFwRollback");
	
	e.setKind(OAPE_Fault_faultcode_Server);
	
	OAPC_ApiLock<APIC_InternetISW> pc_InternetISW( APIC_InternetISW::newInstanceAdmin() , &_slock );
	OAPC_ApiLock<APIC_SystemInfo>		pc_SystemInfo(APIC_SystemInfo::newInstanceAdmin(),&_slock);			// ZeusCD UV-1385_WP IISW�̉^�p�ۑ�̑Ή� 2013/12/13 Sela Added. 
	
	if( !pc_InternetISW
	 ||	!pc_SystemInfo ) {					// ZeusCD UV-1385_WP IISW�̉^�p�ۑ�̑Ή� 2013/12/13 Sela Added. 
	    e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	// ZeusCD UV-1385_WP IISW�̉^�p�ۑ�̑Ή� 2013/12/13 Sela Added Start. 
	// Check whether MFP Aral65 Configured or not. 
	if(False == pc_SystemInfo->isHeliosPFPart()) {	// Zeus5BK UV-1385_WP IISW�̉^�s�ۑ�̑Ή� 2014/05/28 Sundar Modified.
		OAPD_TRACE( "Rollback Operation Not Allowed: FwRollback is not Applicable." )
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "UV01385 is not Applicable. Rollback Not Allowed.");
		return false;
	}
	// ZeusCD UV-1385_WP IISW�̉^�p�ۑ�̑Ή� 2013/12/13 Sela Added End. 
	
	// Check whether Rollback is allowed or not.
	char temp[OAPD_VERSION_CODE_MAXSTRING] = {0, };
	if ( ( False == pc_InternetISW->getRollbackCardVersion(temp) )
	  || ( ( False == pc_InternetISW->getMakeBackUpFileOfFwUpdateFromUSB( ) ) 
	    && ( False == pc_InternetISW->getMakeBackUpFileOfFwUpdateFromIISW() ) )
	  || (False == pc_InternetISW->getFwRollBackAdminOpenMode( ) ) ) {
	  	OAPD_TRACE( "Rollback Operation Not Allowed" )
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Rollback Not Allowed.");
		return false;
	}
	
	// FW Rollback.
	if( TYPE_FwDataRollBackResult_NG == pc_InternetISW->req_FwDataRollBack() ) {
		OAPD_TRACE( "Roll Operation Failed to start" )
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure , "Failed to start Rollback");
		return false;
	}

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// ZeusCD UV-1385 IISW�̉^�p�ۑ�̑Ή� 2013/11/21 Sela Added End. 

// ZeusCD UV-01324 Gayathri 2013/12/30 Added Start. 
// ================================================================.
//�T�v�@�@�F���r�L�^�X�����S�폜.
//���l�@�@�F.
//�쐬�ҁ@�FGayathri.
//�ύX�����F2014.01.02:Gayathri.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqDeleteAllUbiquitousDoc> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqDeleteAllUbiquitousDoc , OAPE_Result_FaultRequest_AppReqDeleteAllUbiquitousDoc > 
{
friend class OAPC_TransactImp<OAPS_AppReqDeleteAllUbiquitousDoc>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
	
	static int32_t sl_LocalseqID;
	static int32_t sl_CallbackResult;
	static void pAns_deleteAllUbiquitousDoc(int32_t sl_SeqID, int32_t sl_Result) {
		if(sl_LocalseqID == sl_SeqID) {
			// �폜���s���ʂ̕ۑ�. 
			sl_CallbackResult = sl_Result;
		}
		
		// OpenAPI�����҂��̉���.
		OAPC_CallbackObserverMgr<int32_t, 0>::getInstance().notify( &sl_CallbackResult );
	}
	
};
int32_t __OAPC_TransactImp<OAPS_AppReqDeleteAllUbiquitousDoc>::sl_CallbackResult = 0;
int32_t __OAPC_TransactImp<OAPS_AppReqDeleteAllUbiquitousDoc>::sl_LocalseqID = 1;		// Set some const value. 
#if !(__GNUC__ < 4)
template 
#endif
OAPC_CallbackObserverMgr<int32_t, 0> OAPC_CallbackObserverMgr<int32_t, 0>::_c_theInstance;

OAPD_TRANSACT_HANDLING(AppReqDeleteAllUbiquitousDoc)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqDeleteAllUbiquitousDoc)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
	// LockKey.  
	if ( false == DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) ) {
		return false;
	}
	
OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqDeleteAllUbiquitousDoc)

	int32_t authority = OAPE_UserType_Admin;

	////////////////////////////////////. 
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqDeleteAllUbiquitousDoc, AppResDeleteAllUbiquitousDoc)

	OAPD_TRACE_SCOPE("OAPS_AppReqDeleteAllUbiquitousDoc");
	
	e.setKind(OAPE_Fault_faultcode_Server);
	

	OAPC_ApiWrapper<APIC_UbiquitousBox> pc_UbiquitousBox( APIC_UbiquitousBox::getInstance());
	// Zeus5BK ����\���ύXNo.70 PSWC����̃��r�L�^�X�v�����g�ݒ莞�̓���ύX�Ή� 2014/6/24 1OPS Ohno Start. 
//	OAPC_ApiLock<APIC_UbiquitousSetting>	pc_UbiquitousSetting(APIC_UbiquitousSetting::newInstance(), &_slock);
	OAPC_ApiLock<APIC_UbiquitousSetting>	pc_UbiquitousSetting(APIC_UbiquitousSetting::newInstanceAdmin(), &_slock);
	// Zeus5BK ����\���ύXNo.70 PSWC����̃��r�L�^�X�v�����g�ݒ莞�̓���ύX�Ή� 2014/6/24 1OPS Ohno End. 
	
	if( !pc_UbiquitousBox
	 || !pc_UbiquitousSetting) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}

    // Check for StorageFunction is Enable or not. 
	if(False == SYSF_getAppOptionStatus(TYPE_AppOptionUbiquitousStorage) // �X�g���[�W�@�\�I�v�V�������� Zeus5BK ����\���ύX No60. 
    || False == pc_UbiquitousSetting->getStorageOn()) { // Zeus5BK ����\���ύX No60. 
    	OAPD_TRACE( "Delete Not Allowed. The Storage Function Setting is Off." )
    	e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "Delete Not Allowed");
		return false;
	}
    
	// Delete All Ubiquitous Documents.
	OAPC_CallbackObserver c_DeleteAllUbiquitousDoc(_slock);
	OAPC_CallbackObserverMgr<int32_t, 0>::getInstance().addList( &sl_CallbackResult, &c_DeleteAllUbiquitousDoc );
	if( APID_UbqResultNG == pc_UbiquitousBox->req_delAll(sl_LocalseqID, pAns_deleteAllUbiquitousDoc) ) {
		OAPD_TRACE( "The Ubquitous Documents Delete Operation Failed to start." )
		// OpenAPI�����҂��̉���.
		OAPC_CallbackObserverMgr<int32_t, 0>::getInstance().notify( &sl_CallbackResult );
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "Failed to start Delete");	// ���s�Ɏ��s������.
		return false;
	}
	
	// Call Back�҂�.....
	_slock.wait();
	
	if(APID_UbqResultOK != sl_CallbackResult) {
		OAPD_TRACE( "The Ubquitous Documents Delete Operation Failed." )
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "Failed to Delete");	// ���s�Ɏ��s������.
		return false;
	}
	////////////////////////////////////. 
	// ���ʒʒm���ʍ\���̍쐬.  
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// ZeusCD UV-01324 Gayathri 2013/12/30 Added End. 
//2017-10-10 IT6�y�}�[�W�Ή��p�ۑ�z1030046 Hcl-Rajeshwari add start.
Bool bCallbackResult = False;

template OAPC_CallbackObserverMgr<Bool, 1242> OAPC_CallbackObserverMgr<Bool, 1242>::_c_theInstance;

static void ans_Callback(Bool b_result)
{
	bCallbackResult = b_result;
	OAPC_CallbackObserverMgr<Bool, 1242>::getInstance().notify( &bCallbackResult );
}
// ================================================================.
//�T�v�@�@	�FDeleteSMBFiles.
//���l�@�@	�F.
//�쐬�ҁ@	�FHCL-Neeraj.
//�ύX����	�F
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqDeleteSMBFiles> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqDeleteSMBFiles , OAPE_Result_FaultRequest_AppReqDeleteSMBFiles >
{
friend class OAPC_TransactImp<OAPS_AppReqDeleteSMBFiles>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};
	
OAPD_TRANSACT_HANDLING(AppReqDeleteSMBFiles)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqDeleteSMBFiles)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
	// LockKey Check(���b�N��) .
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, false ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqDeleteSMBFiles)

	long authority = OAPE_UserType_Admin;
	////////////////////////////////////.
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqDeleteSMBFiles, AppResDeleteSMBFiles)

	OAPD_TRACE_SCOPE("OAPS_AppReqDeleteSMBFiles");
	e.setKind(OAPE_Fault_faultcode_Server);
	
	OAPC_ApiWrapper<APIC_SMBCleaningSetting>	pc_SMBCleaningSetting( APIC_SMBCleaningSetting::newInstanceAdmin() );
	
	if ( !pc_SMBCleaningSetting ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}

	OAPC_CallbackObserver c_CallbackObs(_slock);
	OAPC_CallbackObserverMgr<Bool, 1242>::getInstance().addList( &bCallbackResult, &c_CallbackObs );

	if(!pc_SMBCleaningSetting->deleteAllSMBShareFile( ans_Callback )) {
		OAPD_TRACE( "The deleteAllSMBShareFile  Delete Operation Failed to Start.")
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "Failed to Start DeleteSMBShareFile ");		// ���s�Ɏ��s������.
		return false;
	}
	_slock.wait();
	
	if(!bCallbackResult) {
		OAPD_TRACE( "The bCallbackResult  Callback Function Call Failed.")
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "Callback Function Call Failed ");		// ���s�Ɏ��s������.
		return False;
	}
	else {
		OAPD_TRACE( "The bCallbackResult  Callback Function Call Success.")
		p_res->s_Result.set();
	}
	
OAPD_END_TRANSACT_EXECUTE	
//2017-10-10 IT6�y�}�[�W�Ή��p�ۑ�z1030046 Hcl-Rajeshwari add end.

//Zeus5BK UV.����\���ύX_No.19 Sundar 2014/06/16 Added Start.
//�R�[���o�b�N�֐� rebootSgw().
// CQ528002 �y�Ǘ�No.68�z�y����GW���P �G���[�R�[�h�\���z�Ή� Uma 2016/04/05 Modified Start.
TYPE_SGW_ERR_INFO e_CallbackResult = TYPE_SGW_ERR_INFO_OK;

template OAPC_CallbackObserverMgr<TYPE_SGW_ERR_INFO, 1241> OAPC_CallbackObserverMgr<TYPE_SGW_ERR_INFO, 1241>::_c_theInstance;

static void ans_GwBootCallback(TYPE_SGW_ERR_INFO e_result)
{
	e_CallbackResult = e_result;
	OAPC_CallbackObserverMgr<TYPE_SGW_ERR_INFO, 1241>::getInstance().notify( &e_CallbackResult );
}
// CQ528002 �y�Ǘ�No.68�z�y����GW���P �G���[�R�[�h�\���z�Ή� Uma 2016/04/05 Modified End.

// ================================================================.
//�T�v�@�@	�FKMSaasGatewayApp�ċN��.
//���l�@�@	�F.
//�쐬�ҁ@	�FSundar.
//�ύX����	�F
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqSaasGatewayAppRestart> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqSaasGatewayAppRestart , OAPE_Result_FaultRequest_AppReqSaasGatewayAppRestart >
{
friend class OAPC_TransactImp<OAPS_AppReqSaasGatewayAppRestart>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqSaasGatewayAppRestart)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqSaasGatewayAppRestart)

	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
	// LockKey Check(���b�N��) .
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, false ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqSaasGatewayAppRestart)

	int32_t authority = OAPE_UserType_Admin;

	////////////////////////////////////.
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqSaasGatewayAppRestart, AppResSaasGatewayAppRestart)
// MAv4 CQ529919 2016/06/10 mod end.

	OAPD_TRACE_SCOPE("OAPS_AppReqSaasGatewayAppRestart");
	
	e.setKind(OAPE_Fault_faultcode_Server);
	
	OAPC_ApiWrapper<APIC_SaaSGatewayInfo>	pc_SaaSGatewayInfo( APIC_SaaSGatewayInfo::newInstanceAdmin() );
	
	if ( !pc_SaaSGatewayInfo ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}

	// CQ528002 �y�Ǘ�No.68�z�y����GW���P �G���[�R�[�h�\���z�Ή� Uma 2016/04/05 Added Start.
	OAPC_CallbackObserver c_GWBootCallbackObs(_slock);
	OAPC_CallbackObserverMgr<TYPE_SGW_ERR_INFO, 1241>::getInstance().addList( &e_CallbackResult, &c_GWBootCallbackObs );

	pc_SaaSGatewayInfo->rebootSgw(ans_GwBootCallback);
	_slock.wait();
	
	bool b_Result = false;

	switch( e_CallbackResult )
	{
		case TYPE_SGW_ERR_INFO_OK:
			b_Result = true;
			break;
		case TYPE_SGW_ERR_INFO_ERROR:
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "SetSaaSGateway::Error");
			break;
		case TYPE_SGW_ERR_INFO_EINVAL:
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "SetSaaSGateway::ArgumentError");
			break;
		case TYPE_SGW_ERR_INFO_EBUSY:
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "SetSaaSGateway::Busy");
			break;
		case TYPE_SGW_ERR_INFO_ENOMEM:
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "SetSaaSGateway::InsufficientMemory");
			break;
		case TYPE_SGW_ERR_INFO_DISABLE:
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "SetSaaSGateway::OutOfService");
			break;
		default:
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralExecuteFailure, "SetSaaSGateway::UnknownError");
			break;
	}
	
	if ( b_Result == false ){
		return false;
	}
	//CQ528002 �y�Ǘ�No.68�z�y����GW���P �G���[�R�[�h�\���z�Ή� Uma 2016/04/05 Added End.
	
	////////////////////////////////////.
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();
	
OAPD_END_TRANSACT_EXECUTE
//Zeus5BK UV.����\���ύX_No.19 Sundar 2014/06/16 Added End.

// HeliosFUM(MAv2) UV-01378 SMB�ł̃f�[�^ExportImport�̉��P ���� �F�� 2013/10/01 �ǉ�Start .
Bool b_ExpImpCE = False;
// ================================================================ .
//�T�v�@�@�FImport/Export��Callback�p�N���X .
//���l�@�@�F .
//�쐬�ҁ@�F���� �F�� .
//�ύX�����F2013.10.01:�V�K�쐬 .
// ================================================================ .
class OAPC_ImportExportCallbackMgr
{
private:
	// pc_ImportExportObs����邽�߂̃Z�}�t�H .
	VR_SEM_ID _sem;

	// �G�N�X�|�[�g�C���|�[�g���s���t���O(�����l�FFalse) .
	Bool b_ImportExportExecutingFlag;

	// Import/Export����(�����l�FTYPE_UsbImportExportResult_None(�ΏۂȂ�)) .
	TYPE_UsbImportExportResult _e_UsbImportExportResult;
	TYPE_UsbImportExportResult2nd _e_UsbImportExportResult2nd;  // MinervaSBK CQ514822�Ή� 2015/07/09 HCL Pradeep Added.

	// �Ǘ��N���X�C���X�^���X��static�̈�Ɋm�ۂ��Ĉ�ӂƂ��� .
	static OAPC_ImportExportCallbackMgr _c_theInstanceImportExport;

	OAPC_ImportExportCallbackMgr():b_ImportExportExecutingFlag(False),_e_UsbImportExportResult(TYPE_UsbImportExportResult_None)
	                   ,_e_UsbImportExportResult2nd(TYPE_UsbImportExportResult2nd_None)//MinervaSBK CQ516896 HCL Rajarshi Added.
	{
		_sem = ::VR_semBCreate(VR_SEM_Q_FIFO, VR_SEM_FULL);		// �Z�}�t�H�쐬 .
	}

	// hidden .
	OAPC_ImportExportCallbackMgr(const OAPC_ImportExportCallbackMgr&);
	OAPC_ImportExportCallbackMgr& operator=(const OAPC_ImportExportCallbackMgr&);

public:
	// �N���X�C���X�^���X��static�Ŋm�ۂ��邽�߁ACall����Ȃ� .
	~OAPC_ImportExportCallbackMgr()
	{
		::VR_semDelete(_sem);									// �Z�}�t�H�폜 .
	}

	static OAPC_ImportExportCallbackMgr& getInstance() { return _c_theInstanceImportExport; }

	// b_ImportExportExecutingFlag����邽�߂̃Z�}�t�H�����֐� .
	void LockImportExportExecutingFlag()
	{
		::VR_semTake(_sem, VR_WAIT_FOREVER);
	}
	void UnLockImportExportExecutingFlag()
	{
		::VR_semGive(_sem);
	}

	// ���Y�֐���Call���鎞��LockObserver/UnLockObserver��b_ImportExportExecutingFlag����邱��!! .
	Bool getImportExportExecutingFlag()
	{
		return b_ImportExportExecutingFlag;
	}
	// ���Y�֐���Call���鎞��LockObserver/UnLockObserver��b_ImportExportExecutingFlag����邱��!! .
	void setImportExportExecutingFlag(Bool b_Flag)
	{
		b_ImportExportExecutingFlag = b_Flag;
	}

	TYPE_UsbImportExportResult getImportExportResult(TYPE_UsbImportExportResult2nd& e_Result2)	// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Modified.
	{
		e_Result2 = _e_UsbImportExportResult2nd;		// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Added.
		return _e_UsbImportExportResult;
	}

	void notify(TYPE_UsbImportExportResult e_UsbImportExportResult,TYPE_UsbImportExportResult2nd	e_UsbImportExportResult2nd)		// MinervaSBK CQ514822�Ή� 2015/07/09 HCL Pradeep Modified.
	{
		// �Z�}�t�H��b_ImportExportExecutingFlag�����!! .
		LockImportExportExecutingFlag();
		if (False != b_ImportExportExecutingFlag)
		{
			_e_UsbImportExportResult = e_UsbImportExportResult;
			_e_UsbImportExportResult2nd = e_UsbImportExportResult2nd;		// MinervaSBK CQ514822�Ή� 2015/07/09 HCL Pradeep Added.
			b_ImportExportExecutingFlag = False;	// CommonAPI����̃R�[���o�b�N��t��͏����� .
		}
		else
		{
			OAPD_TRACE("Error:not execute Import/Export")
		}
		// �Z�}�t�H��b_ImportExportExecutingFlag�����!! .
		UnLockImportExportExecutingFlag();
	}

	// CommonAPI����̊����ʒm��Kick����� .
	static void ImportExportCallbBack(TYPE_UsbImportExportResult e_UsbImportExportResult, TYPE_UsbImportExportResult2nd	e_UsbImportExportResult2nd)		// MinervaSBK CQ514822�Ή� 2015/07/09 HCL Pradeep Modified.
	{
		// CommonAPI����̊����ʒm��Kick����� .
		b_ExpImpCE = False;		// Export�������������߃t���OOff.
		OAPC_ImportExportCallbackMgr::getInstance().notify(e_UsbImportExportResult, e_UsbImportExportResult2nd);		// MinervaSBK CQ514822�Ή� 2015/07/09 HCL Pradeep Modified.
	}
};
OAPC_ImportExportCallbackMgr OAPC_ImportExportCallbackMgr::_c_theInstanceImportExport;

// ================================================================ .
//�T�v�@�@�FImport/Export�J�n .
//���l�@�@�F .
//�쐬�ҁ@�F���� �F�� .
//�ύX�����F2013.10.01:�V�K�쐬 .
// ================================================================ .
template <> class __OAPC_TransactImp<OAPS_AppReqStartImportExport> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqStartImportExport , OAPE_Result_FaultRequest_AppReqStartImportExport > 
{
friend class OAPC_TransactImp<OAPS_AppReqStartImportExport>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqStartImportExport)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqStartImportExport)

	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqStartImportExport)")

	e.setKind(OAPE_Fault_faultcode_Client);

	// ���ʍ\����Check(�^�O�L���E���[�U�[���) .
	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}

	// Import/Export���Check(�^�O�L��) .
	if (p_req->e_Kind.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Kind");
		return false;
	}

	// �Í����p�X���[�hCheck(�^�O�L��) .
	if (p_req->sc_Password.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Password");
		return false;
	}

	// LockKey Check(���b�N��) .
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, false ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqStartImportExport)

	// PSWC��CE��ʂ���̂ݎ��s .
	int32_t authority = OAPE_UserType_CE;

	// �I�y���[�^�[���O�C�� .
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
// 2022/12/19 MSCD2G-Sky [SecV6][RQ-904]�C���|�[�g�^�G�N�X�|�[�g�ʒm���̒ǉ��ireq_UsbImportExportStart�����ǉ��j.
// 2023/01/26 MSCD2G-Sky [SecV6][RQ-904]�C���|�[�g�^�G�N�X�|�[�g�ʒm�L���̒ǉ��ireq_UsbImportExportStart�����ǉ��j.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqStartImportExport, AppResStartImportExport)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqStartImportExport)")
// MAv4 CQ529919 2016/06/10 mod end.

	e.setKind(OAPE_Fault_faultcode_Server);

	APIC_UsbImportExportOperation* pc_UsbImportExportOperation = APIC_UsbImportExportOperation::newInstanceAdmin();
	
	OAPC_ApiLock<APIC_SystemInfo> pc_SystemInfo(APIC_SystemInfo::newInstanceAdmin() , &_slock);		// Eagle 1049929 ����\���ύX_No.118_WP Naveen 2018/09/29 Added.
	
	if (!pc_UsbImportExportOperation ||
		!pc_SystemInfo)		// Eagle 1049929 ����\���ύX_No.118_WP Naveen 2018/09/29 Added.
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	//TYPE_MachineType e_MachineType = pc_SystemInfo->getMachineType();		// Eagle 1049929 ����\���ύX_No.118_WP Naveen 2018/09/29 Added.

	// b_ImportExportExecutingFlag����邽�߂�LockImportExportExecutingFlag�����{ .
	OAPC_ImportExportCallbackMgr::getInstance().LockImportExportExecutingFlag();
	// b_ImportExportExecutingFlag��SET����Ă��邩�ۂ��ŃG�N�X�|�[�g���s�����ۂ��𔻒f���� .
	if (False == OAPC_ImportExportCallbackMgr::getInstance().getImportExportExecutingFlag())
	{
		OAPC_ImportExportCallbackMgr::getInstance().setImportExportExecutingFlag(True);
		// b_ImportExportExecutingFlag����邽�߂�LockImportExportExecutingFlag������ .
		OAPC_ImportExportCallbackMgr::getInstance().UnLockImportExportExecutingFlag();

		// �eTarget�^�O����Bit�l�쐬 .
		TYPE_UsbImportExportTarget e_Target = TYPE_UsbImportExportTarget_None;

		// �l�b�g���[�N�t�@�C�����Ώۂ��ۂ� .
		if (!p_req->e_TargetNetwork.empty())
		{
			if (OAPE_TargetOnOff_On == p_req->e_TargetNetwork.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Network;
			}
		}
		// CSRC�t�@�C�����Ώۂ��ۂ� .
		if (!p_req->e_TargetCsrc.empty())
		{
			if (OAPE_TargetOnOff_On == p_req->e_TargetCsrc.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Csrc;
			}
		}
		// �F�؃t�@�C�����Ώۂ��ۂ� .
		if (!p_req->e_TargetAuth.empty())
		{
			if (OAPE_TargetOnOff_On == p_req->e_TargetAuth.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Authentication;
			}
		}
		// ����t�@�C�����Ώۂ��ۂ� .
		if (!p_req->e_TargetAddr.empty())
		{
			if (OAPE_TargetOnOff_On == p_req->e_TargetAddr.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Address;
			}
		}
		// ���[�e�B���e�B�ݒ肪�Ώۂ��ۂ� .
		if (!p_req->e_TargetUtility.empty())
		{
			if (OAPE_TargetOnOff_On == p_req->e_TargetUtility.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Utility;
			}
		}
		// �Ǘ��Ґݒ肪�Ώۂ��ۂ� .
		if (!p_req->e_TargetAdmin.empty())
		{
			if (OAPE_TargetOnOff_On == p_req->e_TargetAdmin.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Admin;
			}
		}
		if (!p_req->e_TargetService.empty())
		{
			// �T�[�r�X�}���ݒ肪�Ώۂ��ۂ� .
			if (OAPE_TargetOnOff_On == p_req->e_TargetService.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Service;
			}
		}
// Zeus5BK ����\���ύXNo.59 Sky���J 2014/05/16 Start.
		if (!p_req->e_TargetTopmenu.empty())
		{
			// �T�[�r�X�}���ݒ肪�Ώۂ��ۂ� .
			if (OAPE_TargetOnOff_On == p_req->e_TargetTopmenu.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_TopMenuGadget;
			}
		}
// Zeus5BK ����\���ύXNo.59 Sky���J 2014/05/16 End.

//Zeus5BK UV.����\���ύX_No.19 Sundar 2014/06/16 Added Start.
		// �N���E�h�A�g���Ώۂ��ۂ� .
		if (!p_req->e_TargetCloud.empty())
		{
			if (OAPE_TargetOnOff_On == p_req->e_TargetCloud.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_CloudContact;
			}
		}
//Zeus5BK UV.����\���ύX_No.19 Sundar 2014/06/16 Added End.

		//MinervaSBK UV-1432 �u���E�U���u�ݒ�Ή� 08/06/2015 HCL-Sundar Added Start.
		// �O���ؖ����Ώ�.
		TYPE_UsbImportExportTarget2nd e_Target2 = TYPE_UsbImportExportTarget2nd_None;		// MinervaSBK CQ514822�Ή� 2015/07/09 HCL Pradeep Added.
		if (!p_req->e_TargetExtCertificates.empty())
		{
			if (OAPE_TargetOnOff_On == p_req->e_TargetExtCertificates.get())
			{
				e_Target2 |= TYPE_UsbImportExportTarget2nd_ExtCertificates;		// MinervaSBK CQ514822�Ή� 2015/07/09 HCL Pradeep Modified.
			}
		}
		//MinervaSBK UV-1432 �u���E�U���u�ݒ�Ή� 08/06/2015 HCL-Sundar Added End.
		
		// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Added Start.
		// �F�؃J�X�^�}�C�Y�f�[�^�Ώ�.
		if (!p_req->e_TargetCustomizeAuth.empty())
		{
			if (OAPE_TargetOnOff_On == p_req->e_TargetCustomizeAuth.get())
			{
				e_Target2 |= TYPE_UsbImportExportTarget2nd_MasterConfigSetting;
			}
		}
		// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Added End.

// 2014/11/18 [MAv3][RQ-251]�w���T�[�o�Ƃ̘A�g�ɂ��Z�b�g�A�b�v�����P  ���� ���� Start.
		// ���j�o�[�T���ݒ肪�Ώۂ��ۂ� .
		if (!p_req->e_TargetUniversal.empty()) {
			if (OAPE_TargetOnOff_On == p_req->e_TargetUniversal.get()) {
				e_Target |= TYPE_UsbImportExportTarget_Universal;
			}
		}
// 2014/11/18 [MAv3][RQ-251]�w���T�[�o�Ƃ̘A�g�ɂ��Z�b�g�A�b�v�����P  ���� ���� End.



		// Eagle 1049929 ����\���ύX_No.118_WP Naveen 2018/09/29 Added Start.
		if(!(OAPI_CheckIsSparrowSFPModel())) //IT6_SparrowBK ����\���ύX_No.36 HCL-Palani 2019/08/06 Modified.
		{	
			// �R�s�[�v���O�����f�[�^�Ώ�.
			if (!p_req->e_TargetCopyProgramData.empty())
			{
				if (OAPE_TargetOnOff_On == p_req->e_TargetCopyProgramData.get())
				{
					e_Target2 |= TYPE_UsbImportExportTarget2nd_CopyProgramSetting;
				}
			}
		}
		// Eagle 1049929 ����\���ύX_No.118_WP Naveen 2018/09/29 Added Added End.

		// �G�N�X�|�[�g��ʂ̌���.
		TYPE_UsbImportExportKind e_UsbImportExportKind = TYPE_UsbImportExportKind_Export;
		switch (p_req->e_Kind.get())
		{
			case OAPE_UsbImportExportKind_ExportSmb:
			{
				// SMB�G�N�X�|�[�g.
				e_UsbImportExportKind = TYPE_UsbImportExportKind_ExportSMB;
				break;
			}
			default:
			{
				// ���蓾�Ȃ��P�[�X(SMB�G�N�X�|�[�g�ȊO���w�肳����Message���̂��G���[�ƂȂ�).
				break;
			}
		}

		// AuthKey����A�J�E���g�����擾���A�č����O���c�����[�U�[�𔻒f���� .
		OAPE_UserType e_AccountUserType = OAPE_UserType_None;
		OAPS_AccountUser accountuser;
		if (OAPC_AccountMan::getInstance()->findAccount( p_req->s_OperatorInfo.sc_AuthKey.get(), accountuser))
		{
			e_AccountUserType = accountuser.e_UserType;
		}
		JLGE_InspectLogOperateNum e_InspectLogOperateNum = JLGE_InspectLogOperateIDL_Admin;
		switch (e_AccountUserType)
		{
			case OAPE_UserType_CE:
			{
				// �č����O ����Ҕԍ��FCE .
				e_InspectLogOperateNum = JLGE_InspectLogOperateIDL_CE;
				break;
			}
			default:
			{
				// �č����O ����Ҕԍ��F�Ǘ��� .
				// 2013/10���_�ł�CE�ȊO���蓾�Ȃ��B�����[�U�[�̏ꍇ��CommonAPI�̃f�t�H���g�l�ɍ��킹�ĊǗ��҂Ƃ��� .
				break;
			}
		}

		// Import/Export�v�� .
		b_ExpImpCE = True;		// Export���J�n����邽�߃t���OOn.
		// [RQ-698-37][JobLog�Ή�]2018.05.10 Sky start.
		Bool bl_IsWebUIFromPanel = OAPC_AccountMan::getInstance()->getIsWebUIFromPanel(p_req->s_OperatorInfo.sc_AuthKey.get());
		// [RQ-698-37][JobLog�Ή�]2018.05.10 Sky end.

		// MinervaSBK CQ514822�Ή� 2015/07/09 HCL Pradeep Modified Start.
		pc_UsbImportExportOperation->req_UsbImportExportStart(	e_UsbImportExportKind,
																e_Target,
																e_Target2,
																OAPC_ImportExportCallbackMgr::ImportExportCallbBack,
																(uchar*)p_req->sc_Password.get(),
																APIE_NotifyEmailImpExpDev_Smb,
																True,
																OAPD_JLGE_InspectLogIfISOpenAPI(bl_IsWebUIFromPanel),	// [RQ-698-37][JobLog�Ή�]2018.05.10 Sky add.
																False,		// �K���č����O���c�� .
																e_InspectLogOperateNum);
		// MinervaSBK CQ514822�Ή� 2015/07/09 HCL Pradeep Modified End.
		// ��������(OK)�����Ă���Response .
		p_res->e_RequestResult = OAPE_UsbImportExportRequestResult_Ok;
	}
	// 2�A���N�����ɂ͖{���[�g(else)�ɓ��� .
	// CE�ł̑���Ȃ̂�2�A���N���s�Ƃ���(2�x�ڂ̎w���́uReject(����)�v��Response) .
	// ��CE�̃E�B���h�E����Ă��܂���DeviceLock�^�C���A�E�g������A�Ăю��s�����ꍇ�̃K�[�h .
	else
	{
		// b_ImportExportExecutingFlag����邽�߂�LockImportExportExecutingFlag������ .
		OAPC_ImportExportCallbackMgr::getInstance().UnLockImportExportExecutingFlag();
		// ��������(����)�����Ă���Response .
		p_res->e_RequestResult = OAPE_UsbImportExportRequestResult_Reject;
	}

	//////////////////////////////////// .
	// ���̃��b�Z�[�W�ł́A����PSWC��Response��Ԃ��B .
	// PSWC�������I�Ƀ|�[�����O���A�G�N�X�|�[�g���ʂ��擾����B .
	// �G�N�X�|�[�g���s���́uReject(����)�v��ԋp����B .
	//////////////////////////////////// .

	// ���ʒʒm���ʍ\���̍쐬 .
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// ================================================================ .
//�T�v�@�@�FImport/Export���ʎ擾 .
//���l�@�@�F .
//�쐬�ҁ@�F���� �F�� .
//�ύX�����F2013.10.18:�V�K�쐬 .
// ================================================================ .
template <> class __OAPC_TransactImp<OAPS_AppReqGetImportExportResult> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqGetImportExportResult , OAPE_Result_FaultRequest_AppReqGetImportExportResult > 
{
friend class OAPC_TransactImp<OAPS_AppReqGetImportExportResult>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
	inline bool _preparation(const OAPC_Memory& msg, OAPC_Memory& retres, int iRequestItem, OAPC_Error& e);
	inline bool _post_process(const OAPC_Memory& msg, OAPC_Memory& retres, int iRequestItem, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING_CUSTOMDATA(AppReqGetImportExportResult)

// �p�����[�^�ݒ�.
OAPD_BEGIN_TRANSACT_PREPARATION(AppReqGetImportExportResult)
	if( !p_req->s_OperatorInfo.empty()) {
		req->s_OperatorInfo = p_req->s_OperatorInfo;
	}

	if( !p_req->sc_LockKey.empty()) {
		req->sc_LockKey = p_req->sc_LockKey;
	}

	retres = p_param;

OAPD_END_TRANSACT_PREPARATION

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetImportExportResult)

	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetImportExportResult)")

	e.setKind(OAPE_Fault_faultcode_Client);

	// ���ʍ\����Check(�^�O�L���E���[�U�[���) .
	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}

	// LockKey Check(���b�N��) .
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, false ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqGetImportExportResult)

	// PSWC��CE��ʂ���̂ݎ��s .
	int32_t authority = OAPE_UserType_CE;

	// �I�y���[�^�[���O�C�� .
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqGetImportExportResult, AppResGetImportExportResult)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqGetImportExportResult)")
// MAv4 CQ529919 2016/06/10 mod end.

	e.setKind(OAPE_Fault_faultcode_Server);
	
// Eagle 1049929 ����\���ύX_No.118_WP Naveen 2018/09/29 Added Start.
	OAPC_ApiLock<APIC_SystemInfo> pc_SystemInfo(APIC_SystemInfo::newInstanceAdmin() , &_slock);
	
	if (!pc_SystemInfo)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	//TYPE_MachineType e_MachineType = pc_SystemInfo->getMachineType();
// Eagle 1049929 ����\���ύX_No.118_WP Naveen 2018/09/29 Added End.

	// b_ImportExportExecutingFlag����邽�߂�LockImportExportExecutingFlag�����{ .
	OAPC_ImportExportCallbackMgr::getInstance().LockImportExportExecutingFlag();
	// b_ImportExportExecutingFlag��SET����Ă��邩�ۂ��ŃG�N�X�|�[�g���s�����ۂ��𔻒f���� .
	if (False == OAPC_ImportExportCallbackMgr::getInstance().getImportExportExecutingFlag())
	{
		// �ێ����Ă������ʂ��擾 .
		TYPE_UsbImportExportResult2nd e_Result2 = TYPE_UsbImportExportResult2nd_MasterConfigSettingOK ;		// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Added.
		TYPE_UsbImportExportResult e_Result
						= OAPC_ImportExportCallbackMgr::getInstance().getImportExportResult(e_Result2);		// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Modified.


		// b_ImportExportExecutingFlag����邽�߂�LockImportExportExecutingFlag�����{ .
		OAPC_ImportExportCallbackMgr::getInstance().UnLockImportExportExecutingFlag();

		// �l�b�g���[�N�t�@�C�� .
		if ( TYPE_UsbImportExportTarget_Network << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_Network << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult_NetOK != ( e_Result & TYPE_UsbImportExportResult_NetOK ) )
			{
				p_res->e_NetworkResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_NetworkResult = OAPE_UsbImportExportResult_Ok;
			}
		}

		// CSRC�t�@�C�� .
		if ( TYPE_UsbImportExportTarget_Csrc << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_Csrc << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult_CsrcOK != ( e_Result & TYPE_UsbImportExportResult_CsrcOK ) )
			{
				p_res->e_CsrcResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_CsrcResult = OAPE_UsbImportExportResult_Ok;
			}
		}

		// �F�؃t�@�C�� .
		if ( TYPE_UsbImportExportTarget_Authentication << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_Authentication << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult_AuthOK != ( e_Result & TYPE_UsbImportExportResult_AuthOK ) )
			{
				p_res->e_AuthResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_AuthResult = OAPE_UsbImportExportResult_Ok;
			}
		}

		// ����t�@�C�� .
		if ( TYPE_UsbImportExportTarget_Address << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_Address << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult_AddrOK != ( e_Result & TYPE_UsbImportExportResult_AddrOK ) )
			{
				p_res->e_AddrResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_AddrResult = OAPE_UsbImportExportResult_Ok;
			}
		}

		// ���[�e�B���e�B�ݒ� .
		if ( TYPE_UsbImportExportTarget_Utility << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_Utility << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult_UtilityOK != ( e_Result & TYPE_UsbImportExportResult_UtilityOK ) )
			{
				p_res->e_UtilityResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_UtilityResult = OAPE_UsbImportExportResult_Ok;
			}
		}

		// �Ǘ��Ґݒ� .
		if ( TYPE_UsbImportExportTarget_Admin << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_Admin << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult_AdminOK != ( e_Result & TYPE_UsbImportExportResult_AdminOK ) )
			{
				p_res->e_AdminResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_AdminResult = OAPE_UsbImportExportResult_Ok;
			}
		}

		// �T�[�r�X�}���ݒ��� .
		if ( TYPE_UsbImportExportTarget_Service << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_Service << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult_ServiceOK != ( e_Result & TYPE_UsbImportExportResult_ServiceOK ) )
			{
				p_res->e_ServiceResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_ServiceResult = OAPE_UsbImportExportResult_Ok;
			}
		}

// Zeus5BK ����\���ύXNo.59 Sky���J 2014/05/16 Start.
		// �g�b�v���j���[�e�[�}�ݒ��� .
		if ( TYPE_UsbImportExportTarget_TopMenuGadget << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_TopMenuGadget << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult_TopMenuGadgetOK != ( e_Result & TYPE_UsbImportExportResult_TopMenuGadgetOK ) )
			{
				p_res->e_TopmenuResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_TopmenuResult = OAPE_UsbImportExportResult_Ok;
			}
		}
// Zeus5BK ����\���ύXNo.59 Sky���J 2014/05/16 End.

//Zeus5BK UV.����\���ύX_No.19 Sundar 2014/06/16 Added Start.
		// �N���E�h�A�g .
		if ( TYPE_UsbImportExportTarget_CloudContact << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_CloudContact << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult_CloudContactOK != ( e_Result & TYPE_UsbImportExportResult_CloudContactOK ) )
			{
				p_res->e_CloudResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_CloudResult = OAPE_UsbImportExportResult_Ok;	// Poseidon CQ503202 Sahana 2014/09/30 Modified.
			}
		}
		//Zeus5BK UV.����\���ύX_No.19 Sundar 2014/06/16 Added End.

		//MinervaSBK UV-1432 �u���E�U���u�ݒ�Ή� 08/06/2015 HCL-Sundar Added Start.
		// �O���ؖ����Ώہ|����.
		if ( TYPE_UsbImportExportTarget2nd_ExtCertificates << 4 == ( e_Result2 & ( TYPE_UsbImportExportTarget2nd_ExtCertificates << 4 ) ) )		// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Modified.
		{
			// ���s.
			if ( TYPE_UsbImportExportResult2nd_ExtCertificatesOK != ( e_Result2 & TYPE_UsbImportExportResult2nd_ExtCertificatesOK ) )			// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Modified.
			{
				p_res->e_ExtCertificatesResult = OAPE_UsbImportExportResult_Ng;
			}
			// ����.
			else
			{
				p_res->e_ExtCertificatesResult = OAPE_UsbImportExportResult_Ok;
			}
		}
		//MinervaSBK UV-1432 �u���E�U���u�ݒ�Ή� 08/06/2015 HCL-Sundar Added End.
		
		// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Added Start.
		// �F�؃J�X�^�}�C�Y�f�[�^�Ώہ|����.
		if ( TYPE_UsbImportExportTarget2nd_MasterConfigSetting << 4 == ( e_Result2 & ( TYPE_UsbImportExportTarget2nd_MasterConfigSetting << 4 ) ) )
		{
			// ���s .
			if ( TYPE_UsbImportExportResult2nd_MasterConfigSettingOK != ( e_Result2 & TYPE_UsbImportExportResult2nd_MasterConfigSettingOK ) )
			{
				p_res->e_CustomizeAuthResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else
			{
				p_res->e_CustomizeAuthResult = OAPE_UsbImportExportResult_Ok;
			}
		}
		// ZeusS_ZX0 RQ-257 Naveen 2015/08/19 Added End.

// 2014/11/18 [MAv3][RQ-251]�w���T�[�o�Ƃ̘A�g�ɂ��Z�b�g�A�b�v�����P  ���� ���� Start.
		// ���j�o�[�T���ݒ��� .
		if ( TYPE_UsbImportExportTarget_Universal << 4 == ( e_Result & ( TYPE_UsbImportExportTarget_Universal << 4 ) ) ) {
			// ���s .
			if ( TYPE_UsbImportExportResult_UniversalOK != ( e_Result & TYPE_UsbImportExportResult_UniversalOK ) ) {
				p_res->e_UniversalResult = OAPE_UsbImportExportResult_Ng;
			}
			// ���� .
			else {
				p_res->e_UniversalResult = OAPE_UsbImportExportResult_Ok;
			}
		}
// 2014/11/18 [MAv3][RQ-251]�w���T�[�o�Ƃ̘A�g�ɂ��Z�b�g�A�b�v�����P  ���� ���� End.

		// Eagle 1049929 ����\���ύX_No.118_WP Naveen 2018/09/29 Added Start.
		if(!(OAPI_CheckIsSparrowSFPModel())) 	//IT6_SparrowBK ����\���ύX_No.36 HCL-Palani 2019/08/06 Modified.
		{	
			// �R�s�[�v���O�����f�[�^�Ώہ|����.
			if ( TYPE_UsbImportExportTarget2nd_CopyProgramSetting << 4 == ( e_Result2 & ( TYPE_UsbImportExportTarget2nd_CopyProgramSetting << 4 ) ) )
			{
				// ���s .
				if ( TYPE_UsbImportExportResult2nd_CopyProgramSettingOK != ( e_Result2 & TYPE_UsbImportExportResult2nd_CopyProgramSettingOK ) )
				{
					p_res->e_CopyProgramDataResult = OAPE_UsbImportExportResult_Ng;
				}
				// ���� .
				else
				{
					p_res->e_CopyProgramDataResult = OAPE_UsbImportExportResult_Ok;
				}
			}
		}
		// Eagle 1049929 ����\���ύX_No.118_WP Naveen 2018/09/29 Added Start.
		
		// �G�N�X�|�[�g���s���(�A�C�h��)�����Ă���Response .
		p_res->e_Status = OAPE_UsbImportExportStatus_Idle;
	}
	// �G�N�X�|�[�g���s���̎���else���[�g�ƂȂ�B .
	// PSWC����̌��ʎ擾(�|�[�����O)�ŁA���s���ł���Ύ��s����Ԃ�ʒm���� .
	else
	{
		// b_ImportExportExecutingFlag����邽�߂�LockImportExportExecutingFlag�����{ .
		OAPC_ImportExportCallbackMgr::getInstance().UnLockImportExportExecutingFlag();
		// �G�N�X�|�[�g���s���(���s��)�����Ă���Response .
		p_res->e_Status = OAPE_UsbImportExportStatus_Executing;
	}

	// ���ʒʒm���ʍ\���̍쐬 .
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// �����f�[�^�ݒ�.
OAPD_BEGIN_TRANSACT_POSTPROCESS(AppReqGetImportExportResult, AppResGetImportExportResult)

	p_res->s_CustomData.s_AppResGetImportExportResult = *res;
	p_res->s_CustomData.s_AppResGetImportExportResult.s_Result.e_ResultInfo.clean();

OAPD_END_TRANSACT_POSTPROCESS


//================================================================ .
//�T�v�@�@�F�t�@�[���E�F�A�X�V�J�n���ʒʒm�I�u�U�[�o .
//�߂�l�@�F .
//���l�@�@�F .
//�쐬�ҁ@�F���� �F�� .
//���r���[�F .
//�ύX�����F2013.10.01 ���� .
//================================================================ .
class OAPC_IISWClientObserver : public OAPC_Observer, public APIC_IISWClientObserver
{
friend class OAPC_Dummy;
private:
	static OAPC_IISWClientObserver _c_theInstance;
	OAPC_SyncLock _slock;
	TYPE_RemoteFWUpdateResult _e_RemoteFWUpdateResult;
	OAPC_IISWClientObserver()
	{ activate(); }

	// hidden .
	OAPC_IISWClientObserver(const OAPC_IISWClientObserver&);
	OAPC_IISWClientObserver& operator=(const OAPC_IISWClientObserver&);
public:
	~OAPC_IISWClientObserver()
	{ inactivate(); }

	// OpenAPI����p���\�b�h .
	static OAPC_IISWClientObserver& getInstance() { return _c_theInstance; }
	OAPE_ObserverName getName() const { return OAPE_ObserverName_IISWClient; }
	bool initial_attach() const { return false; }

	void setLock(OAPC_SyncLock slock) { _slock = slock; }
	TYPE_RemoteFWUpdateResult getRemoteFWUpdateResult() { return _e_RemoteFWUpdateResult; }

	// CommonAPI�ւ̃I�u�U�[�o�[�o�^ .
	void attach()
	{
		APIC_IISWClient* pc_IISWClient = APIC_IISWClient::newInstance();
		if (NULL != pc_IISWClient)
		{
			pc_IISWClient->attachObserver(this);
		}
	}
	// CommonAPI����̃I�u�U�[�o�[�폜 .
	void detach()
	{
		APIC_IISWClient* pc_IISWClient = APIC_IISWClient::newInstance();
		if (NULL != pc_IISWClient)
		{
			pc_IISWClient->detachObserver(this);
		}
	}

	//�T�v�@�@�F�t�@�[���E�F�A�X�V�J�n����(OK or ����)�ʒm .
	void notifyRemoteFWUpdateResult( TYPE_RemoteFWUpdateResult e_RemoteFWUpdateResult )
	{
		if (TYPE_RemoteFWUpdateResult_OK == e_RemoteFWUpdateResult)
		{
			// Import���J�n����邽�߃t���OOn.
			// ���{�@�\�ł͕K���ċN�����邽�߁A�t���O��Off�ɂ͂��Ȃ�.
			b_ExpImpCE = True;
		}
		_e_RemoteFWUpdateResult = e_RemoteFWUpdateResult;
		_slock.release();
		OAPD_TRACE("notifyRemoteFWUpdateResult=" << e_RemoteFWUpdateResult)
	}
};
OAPC_IISWClientObserver OAPC_IISWClientObserver::_c_theInstance;

// ================================================================ .
//�T�v�@�@�F�t�@�[���E�F�A�X�V�J�n .
//���l�@�@�F .
//�쐬�ҁ@�F���� �F�� .
//�ύX�����F2013.10.01:�V�K�쐬 .
// ================================================================ .
template <> class __OAPC_TransactImp<OAPS_AppReqStartFwUpdate> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqStartFwUpdate , OAPE_Result_FaultRequest_AppReqStartFwUpdate > 
{
friend class OAPC_TransactImp<OAPS_AppReqStartFwUpdate>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqStartFwUpdate)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqStartFwUpdate)

	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqStartFwUpdate)")

	e.setKind(OAPE_Fault_faultcode_Client);

	// ���ʍ\����Check(�^�O�L���E���[�U�[���) .
	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}

	// �������p�X���[�hCheck(�^�O�L��) .
	if (p_req->sc_Password.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Password");
		return false;
	}

	// LockKey Check .
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, false ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqStartFwUpdate)

	// PSWC��CE��ʂ���̂ݎ��s .
	int32_t authority = OAPE_UserType_CE;

	// �I�y���[�^�[���O�C�� .
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

// MAv4 CQ529919 2016/06/10 mod start.
OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqStartFwUpdate, AppResStartFwUpdate)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE_JOB_RUNNING(AppReqGetFwUpdateResult)")
// MAv4 CQ529919 2016/06/10 mod end.

	e.setKind(OAPE_Fault_faultcode_Server);

	APIC_IISWClient* pc_IISWClient = APIC_IISWClient::newInstance();
	if (!pc_IISWClient)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}

	// �I�u�U�[�o�[�N���X�ւ̃Z�}�t�HID�ݒ� .
	OAPC_IISWClientObserver& c_IISWClientObserver =  OAPC_IISWClientObserver::getInstance();
	c_IISWClientObserver.setLock(_slock);

	// CommonAPI�ւ̃I�u�U�[�o�[�o�^ .
	c_IISWClientObserver.attach();

	// FW�X�V�J�n�w�� .
	pc_IISWClient->startRemoteFWUpdate((char*)p_req->sc_Password.get());

	_slock.wait();						// �I�u�U�[�o�[�ʒm��҂� .
	c_IISWClientObserver.detach();		// �ʒm����M��A�I�u�U�[�o�[�폜 .

	// CommonAPI��`�l->OpenAPI��`�l�ϊ� .
	getOpenAPIEnum(c_IISWClientObserver.getRemoteFWUpdateResult(), p_res->e_FwUpdateResult);

	//////////////////////////////////// .
	// ���ʒʒm���ʍ\���̍쐬 .
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// HeliosFUM(MAv2) UV-01378 SMB�ł̃f�[�^ExportImport�̉��P ���� �F�� 2013/10/01 �ǉ�End.

// GaiaFUM 2009/07/10 sone START.
// ================================================================. 
// �Ǘ��Ҕ��MRequest.
// ================================================================.  
template <> class __OAPC_TransactImp<OAPS_AppReqAdminSend> :
	public OAPC_TransactImpBaseInquiry<OAPS_AppReqAdminSend, OAPE_Result_FaultRequest_AppReqAdminSend> 
{
friend class OAPC_TransactImp<OAPS_AppReqAdminSend>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[����. 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check( const OAPC_Memory& , OAPC_Error& );
	inline bool _authorize( const OAPC_Memory& , OAPC_Error& );
	inline bool _execute( const OAPC_Memory& , OAPC_Memory& , OAPC_Error& );
};
OAPD_TRANSACT_HANDLING(AppReqAdminSend);

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqAdminSend)
	
	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqAdminSend)")
	
	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
	// LockKey 
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqAdminSend)
	
	OAPD_TRACE_SCOPE( "OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqAdminSend)" )
	
	int authority = OAPE_UserType_Admin;

	////////////////////////////////////. 
	// �I�y���[�^�[���O�C��. 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
		return false;
	}
	
OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqAdminSend, AppResAdminSend)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqAdminSend)")
		
	// CommonApi����I�u�W�F�N�g�擾.
	OAPC_ApiLock<APIC_RdsSetting> pc_RdsSetting(APIC_RdsSetting::newInstanceAdmin(), &_slock);
	OAPC_ApiLock<APIC_Rds> pc_Rds(APIC_Rds::newInstanceAdmin(), &_slock);
	// �Ǘ��V�X�e���������J�� �v���d�l2-b  2021/03/02 Sky �勴 START.
	OAPC_ApiWrapper<APIC_CSRASetting> pc_CSRASetting( APIC_CSRASetting::newInstanceAdmin());	// CSRA�A�g�@�\�N���X.
	// �Ǘ��V�X�e���������J�� �v���d�l2-b  2021/03/02 Sky �勴 END.

	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ��Fault��Ԃ�.
	// �Ǘ��V�X�e���������J�� �v���d�l2-b  2021/03/02 Sky �勴 START.
	// if(!pc_RdsSetting || !pc_Rds)
	if(!pc_RdsSetting 
		|| !pc_Rds 
		|| !pc_CSRASetting )
	// �Ǘ��V�X�e���������J�� �v���d�l2-b  2021/03/02 Sky �勴 END.
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}
	
	// KMRDS�Z���^�ւ̌��݂̓o�^��Ԃ��擾����.
	TYPE_HostStat e_HostStat = pc_RdsSetting->getHostStat();
	// �Ǘ��V�X�e���������J�� �v���d�l2-b  2021/03/02 Sky �勴 START.
	// CSRA�f�[�^���t�ݒ�����擾����.
	// CSRA�o����.
	TYPS_CSRASetting s_CsraSetting = {};
	pc_CSRASetting->getCSRASetting( &s_CsraSetting );
	// CSRA�Е���.
	TYPS_CSRASetting s_OneWayCsraSetting = {};
	pc_CSRASetting->getCSRASetting( &s_OneWayCsraSetting, TYPE_CSRASettingComMode_OneWay );
	
	// �Z���^�o�^�ρA���A�Ǘ��Ҕ��M���łȂ��ꍇ�A�Ǘ��Ҕ��M���s��.
	//if( e_HostStat == TYPE_HostStatRgst && pc_Rds->isNowTrans( TYPE_RdsTrgKindManage ) == False ) 
	// �Z���^�o�^�ρA�܂��́ACSRA�L���A���A�Ǘ��Ҕ��M���łȂ��ꍇ�A�Ǘ��Ҕ��M���s��.
	if( ( ( e_HostStat == TYPE_HostStatRgst)
		|| ( True == s_CsraSetting.m_b_Enable )				// CSRA�o����.
		|| ( True == s_OneWayCsraSetting.m_b_Enable ) )		// CSRA�Е���.
		&& ( pc_Rds->isNowTrans( TYPE_RdsTrgKindManage ) == False ) ) 
	// �Ǘ��V�X�e���������J�� �v���d�l2-b  2021/03/02 Sky �勴 END.
	{
		pc_Rds->indTrg( TYPE_RdsTrgKindManage ); // �Ǘ��Ҕ��M���s.
	}
	
	////////////////////////////////////. 
	// ���ʒʒm���ʍ\���̍쐬. 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// GaiaFUM 2009/07/10 sone END.

// GaiaFUM 2009/07/14 sone START.
// ================================================================. 
// �Ǘ��Ҕ��M�ʐM�X�e�[�^�X�擾Request.
// ================================================================.  
template <> class __OAPC_TransactImp<OAPS_AppReqGetAdminSendStatus> :
	public OAPC_TransactImpBaseInquiry<OAPS_AppReqGetAdminSendStatus, OAPE_Result_FaultRequest_AppReqGetAdminSendStatus> 
{
friend class OAPC_TransactImp<OAPS_AppReqGetAdminSendStatus>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[����. 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check( const OAPC_Memory& , OAPC_Error& );
	inline bool _authorize( const OAPC_Memory& , OAPC_Error& );
	inline bool _execute( const OAPC_Memory& , OAPC_Memory& , OAPC_Error& );
	inline bool _preparation(const OAPC_Memory& msg, OAPC_Memory& retres, int iRequestItem, OAPC_Error& e);
	inline bool _post_process(const OAPC_Memory& msg, OAPC_Memory& retres, int iRequestItem, OAPC_Error& e);
};
OAPD_TRANSACT_HANDLING_CUSTOMDATA(AppReqGetAdminSendStatus);

// �p�����[�^�ݒ�.
OAPD_BEGIN_TRANSACT_PREPARATION(AppReqGetAdminSendStatus)

	if( !p_req->s_OperatorInfo.empty()) {
		req->s_OperatorInfo = p_req->s_OperatorInfo;
	}

	if( !p_req->sc_LockKey.empty()) {
		req->sc_LockKey = p_req->sc_LockKey;
	}
	retres = p_param;

OAPD_END_TRANSACT_PREPARATION

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetAdminSendStatus)
	
	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetAdminSendStatus)")
	
	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
	// LockKey. 
	if ( DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) == false )
	{
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqGetAdminSendStatus)
	
	OAPD_TRACE_SCOPE( "OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqGetAdminSendStatus)" )
	
	int authority = OAPE_UserType_Admin;

	////////////////////////////////////. 
	// �I�y���[�^�[���O�C��. 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
		return false;
	}
	
OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqGetAdminSendStatus, AppResGetAdminSendStatus)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqGetAdminSendStatus)")
		
	TYPS_RdsCommResult st_RdsCommResult;	// RDS�ʐM����(�\����).

	// CommonApi����I�u�W�F�N�g�擾.
	OAPC_ApiLock<APIC_Rds> pc_Rds(APIC_Rds::newInstanceAdmin(), &_slock);

	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ��Fault��Ԃ�.
	if(!pc_Rds)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}
	
	// �ʐM���ʂ��擾.
	pc_Rds->getRdsCommResult( &st_RdsCommResult.e_RdsDispCode, &st_RdsCommResult.ul_StatNo ); 
	
	getOpenAPIEnum(st_RdsCommResult.e_RdsDispCode, p_res->e_CommunicationStatus);
	
	////////////////////////////////////. 
	// ���ʒʒm���ʍ\���̍쐬. 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// GaiaFUM 2009/07/14 sone END.

// �����f�[�^�ݒ�.
OAPD_BEGIN_TRANSACT_POSTPROCESS(AppReqGetAdminSendStatus, AppResGetAdminSendStatus)

	p_res->s_CustomData.s_AppResGetAdminSendStatus = *res;
	p_res->s_CustomData.s_AppResGetAdminSendStatus.s_Result.e_ResultInfo.clean();

OAPD_END_TRANSACT_POSTPROCESS

// �l�b�g���[�N���Z�b�g XML��ՋZ�p�J��v2 2017/03/31 Pactera Added Start.
// ================================================================.
//�T�v�@�@   :AppReqResetNetwork.
//���l�@�@  �F.
//�쐬�ҁ@  �FPactera.
//�ύX����  : �V�K.
// ================================================================.
template <> class __OAPC_TransactImp<OAPS_AppReqResetNetwork> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqResetNetwork ,OAPE_Result_FaultRequest_AppReqResetNetwork >
{
friend class OAPC_TransactImp<OAPS_AppReqResetNetwork>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}

	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqResetNetwork)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqResetNetwork)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqResetNetwork)")

	if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V999) ) {
		e.setKind(OAPE_Fault_faultcode_Client);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "AppReqResetNetwork");
		return false;
	}

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	if (p_req->e_ResetMode.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "ResetMode");
		return false;
	}

	// LockKey Check(���b�N��) .
	if ( !DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) ) 	// �yIT6_Sparrow�zAR1056532 2018/08/13 HCL-Palani Modified.
	{
		return false;
	}
OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqResetNetwork)

	long authority = OAPE_UserType_Admin;

	////////////////////////////////////.
	// �I�y���[�^�[���O�C��.
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqResetNetwork, AppResResetNetwork)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqResetNetwork)")

	OAPC_ApiLock<APIC_NetworkDevice> pc_NetworkDevice(APIC_NetworkDevice::newInstanceAdmin(), &_slock);
	OAPC_ApiWrapper<APIC_SystemSetting> pc_SystemSetting(APIC_SystemSetting::newInstanceAdmin()); // �yIT6_1.0MR2�zAR1077044 2019/05/22 HCL-Palani Added.
	
	if ( !pc_NetworkDevice
		|| !pc_SystemSetting) {// �yIT6_1.0MR2�zAR1077044 2019/05/22 HCL-Palani Added.
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}

	TYPE_NetworkResetMode e_NetworkResetMode = TYPE_NetworkResetModeNoRemoteCare;
	getCommAPIEnum( p_req->e_ResetMode, e_NetworkResetMode );
	pc_NetworkDevice->resetNetworkSetting(e_NetworkResetMode);
	// �yIT6_1.0MR2�zAR1077044 2019/05/22 HCL-Palani Added Start.
	const char* sc_AuthKey = p_req->s_OperatorInfo.sc_AuthKey.get();
    callSetSecurityLevelUpOn(pc_SystemSetting, sc_AuthKey);
	// �yIT6_1.0MR2�zAR1077044 2019/05/22 HCL-Palani Added End.


	// ���ʒʒm���ʍ\���̍쐬.
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// �l�b�g���[�N���Z�b�g XML��ՋZ�p�J��v2 2017/03/31 Pactera Added End.

// IT5_4.0 RQ-421 2016/09/13 HCL-Naveen Added Start.

// ================================================================ .
//�T�v�@�@�FRDTFwUpdate .
//���l�@�@�F .
//�쐬�ҁ@�FNaveen Kanna.
//�ύX�����F2016.09.14.
// ================================================================ .
template <> class __OAPC_TransactImp<OAPS_AppReqStartRemoteFwUpdate> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqStartRemoteFwUpdate , OAPE_Result_FaultRequest_AppReqStartRemoteFwUpdate > 
{
friend class OAPC_TransactImp<OAPS_AppReqStartRemoteFwUpdate>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqStartRemoteFwUpdate)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqStartRemoteFwUpdate)

	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(OAPS_AppReqStartRemoteFwUpdate)")

	e.setKind(OAPE_Fault_faultcode_Client);
	
	APIC_RDTManager* pc_RDTManager = APIC_RDTManager::newInstanceAdmin();
	APIC_RDTSetting* pc_RDTSetting = APIC_RDTSetting::newInstanceAdmin();
	
	if (!pc_RDTManager
		|| !pc_RDTSetting)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	if( p_req->sc_LockKey.empty() ) 
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing , "LockKey" );
		return false;
	}

	// ���ʍ\����Check(�^�O�L���E���[�U�[���) .
	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
	if (p_req->s_Common.sc_Address.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Address");
		return false;
	} else {
	
		TYPS_RDTConnectInfo ps_ConnectInfo;
		::memset( &ps_ConnectInfo, 0, sizeof(ps_ConnectInfo) );	
		
		pc_RDTSetting->lock();
		pc_RDTSetting->getRDTConnectInfoSetting ( &ps_ConnectInfo);
		pc_RDTSetting->unlock();
	
		if( strcmp(p_req->s_Common.sc_Address.get(),ps_ConnectInfo.sc_IpAdress) != 0 )
		{
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "IpAddress");
			return false;
		}
	}
	
	if (p_req->s_Common.us_PortNo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "PortNo");
		return false;
	}

	// �������p�X���[�hCheck(�^�O�L��) .
	if (p_req->sc_Password.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Password");
		return false;
	}
	
	OAPC_SystemModeManager&	sysman = OAPC_SystemModeManager::getInstance();
	// �f�o�C�X���b�N��ԃ`�F�b�N 
	if ( sysman.checkMode( ( OAPE_SYSMODE_DevLockOap | OAPE_SYSMODE_DevLockOther ), _slock ) == OAPE_SYSMODE_None )
	{
		// ���b�N�L�[������ꍇ�ƕK�{���b�Z�[�W�̏ꍇ�̓G���[��Ԃ� 
		if ( ( p_req->sc_LockKey.empty() == false ) )
		{
			e.setKind           ( OAPE_Fault_faultcode_Client );
			e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralIllegalLockKey, "LockKey" );
			return false;
		}
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqStartRemoteFwUpdate)

// 2022/03/01 RQ-931 Sky Start.
//	// PSWC��CE��ʂ���̂ݎ��s .
//	int32_t authority = OAPE_UserType_CE;
	// CE�܂��́A�Ǘ��҂Ń��O�C���������Ɏ��s�\�Ƃ���B
	int32_t authority = OAPE_UserType_CE;
	if (true == OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_RQ931)) {
		authority = OAPE_UserType_CE | OAPE_UserType_Admin;
	}
// 2022/03/01 RQ-931 Sky End.

	// �I�y���[�^�[���O�C�� .
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqStartRemoteFwUpdate, AppResStartRemoteFwUpdate)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqStartRemoteFwUpdate)")

	e.setKind(OAPE_Fault_faultcode_Server);
	
	APIC_RDTManager* pc_RDTManager = APIC_RDTManager::newInstanceAdmin();
	if (!pc_RDTManager)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	

	// RDT�Ǘ��@�\ FW�X�V.
	getOpenAPIEnum( pc_RDTManager->requestStartFWUpdate((char*)p_req->sc_Password.get()), p_res->e_RemoteFwUpdateResult );

	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
	
// IT5_4.0 RQ-421 2016/09/13 HCL-Naveen Added End.

// IT5_4.0 RQ-421_Phase2 2016/10/04 HCL-Naveen Added Start.

// ================================================================ .
//�T�v�@�@�FStartRemoteBackup .
//���l�@�@�F .
//�쐬�ҁ@�FNaveen Kanna.
//�ύX�����F2016.10.04.
// ================================================================ .
template <> class __OAPC_TransactImp<OAPS_AppReqStartRemoteBackup> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqStartRemoteBackup , OAPE_Result_FaultRequest_AppReqStartRemoteBackup > 
{
friend class OAPC_TransactImp<OAPS_AppReqStartRemoteBackup>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqStartRemoteBackup)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqStartRemoteBackup)

	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqStartRemoteBackup)")

	e.setKind(OAPE_Fault_faultcode_Client);
	
	APIC_RDTManager* pc_RDTManager = APIC_RDTManager::newInstanceAdmin();
	APIC_RDTSetting* pc_RDTSetting = APIC_RDTSetting::newInstanceAdmin();
	
	if (!pc_RDTManager
		|| !pc_RDTSetting)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	if( p_req->sc_LockKey.empty() ) 
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing , "LockKey" );
		return false;
	}

	// ���ʍ\����Check(�^�O�L���E���[�U�[���) .
	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}
	
	if (p_req->s_Common.sc_Address.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Address");
		return false;
	} else {
	
		TYPS_RDTConnectInfo ps_ConnectInfo;
		::memset( &ps_ConnectInfo, 0, sizeof(ps_ConnectInfo) );	
		
		pc_RDTSetting->lock();
		pc_RDTSetting->getRDTConnectInfoSetting ( &ps_ConnectInfo);
		pc_RDTSetting->unlock();
	
		if( strcmp(p_req->s_Common.sc_Address.get(),ps_ConnectInfo.sc_IpAdress) != 0 )
		{
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "IpAddress");
			return false;
		}
	}
	
	if (p_req->s_Common.us_PortNo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "PortNo");
		return false;
	}

	// �������p�X���[�hCheck(�^�O�L��) .
	if (p_req->sc_Password.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Password");
		return false;
	}
	
	OAPC_SystemModeManager&	sysman = OAPC_SystemModeManager::getInstance();
	// �f�o�C�X���b�N��ԃ`�F�b�N 
	if ( sysman.checkMode( ( OAPE_SYSMODE_DevLockOap | OAPE_SYSMODE_DevLockOther ), _slock ) == OAPE_SYSMODE_None )
	{
		// ���b�N�L�[������ꍇ�ƕK�{���b�Z�[�W�̏ꍇ�̓G���[��Ԃ� 
		if ( ( p_req->sc_LockKey.empty() == false ) )
		{
			e.setKind           ( OAPE_Fault_faultcode_Client );
			e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralIllegalLockKey, "LockKey" );
			return false;
		}
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqStartRemoteBackup)

// 2022/03/01 RQ-931 Sky Start.
//	// PSWC��CE��ʂ���̂ݎ��s .
//	int32_t authority = OAPE_UserType_CE;
	// CE�܂��́A�Ǘ��҂Ń��O�C���������Ɏ��s�\�Ƃ���B
	int32_t authority = OAPE_UserType_CE;
	if (true == OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_RQ931)) {
		authority = OAPE_UserType_CE | OAPE_UserType_Admin;
	}
// 2022/03/01 RQ-931 Sky End.

	// �I�y���[�^�[���O�C�� .
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqStartRemoteBackup, AppResStartRemoteBackup)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqStartRemoteBackup)")

	e.setKind(OAPE_Fault_faultcode_Server);
	
	APIC_RDTManager* pc_RDTManager = APIC_RDTManager::newInstanceAdmin();
	if (!pc_RDTManager)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	// Backup Targets.
		
		// Argument 1.
		TYPE_UsbImportExportTarget e_Target = TYPE_UsbImportExportTarget_None;

		if (!p_req->s_BackupTarget.e_TargetNetwork.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetNetwork.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Network;
			}
		}
		if (!p_req->s_BackupTarget.e_TargetCsrc.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetCsrc.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Csrc;
			}
		}
		if (!p_req->s_BackupTarget.e_TargetAuthentication.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetAuthentication.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Authentication;
			}
		}
		if (!p_req->s_BackupTarget.e_TargetAddress.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetAddress.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Address;
			}
		}
		if (!p_req->s_BackupTarget.e_TargetUtility.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetUtility.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Utility;
			}
		}
		if (!p_req->s_BackupTarget.e_TargetAdmin.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetAdmin.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Admin;
			}
		}
		if (!p_req->s_BackupTarget.e_TargetService.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetService.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Service;
			}
		}

		if (!p_req->s_BackupTarget.e_TargetTopMenuGadget.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetTopMenuGadget.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_TopMenuGadget;
			}
		}

		if (!p_req->s_BackupTarget.e_TargetCloudContact.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetCloudContact.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_CloudContact;
			}
		}
		
		if (!p_req->s_BackupTarget.e_TargetUniversal.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetUniversal.get())
			{
				e_Target |= TYPE_UsbImportExportTarget_Universal;
			}
		}
		
		// Argument 2.
		TYPE_UsbImportExportTarget2nd e_Target2 = TYPE_UsbImportExportTarget2nd_None;
		
		if (!p_req->s_BackupTarget.e_TargetExtCertificates.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetExtCertificates.get())
			{
				e_Target2 |= TYPE_UsbImportExportTarget2nd_ExtCertificates;
			}
		}

		if (!p_req->s_BackupTarget.e_TargetMasterConfigSetting.empty())
		{
			if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetMasterConfigSetting.get())
			{
				e_Target2 |= TYPE_UsbImportExportTarget2nd_MasterConfigSetting;
			}
		}
// [MAv6] 2018/08/09 RQ-768 (Hitachi)K.Nishihara Add Start.
		if (true == OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V70)) {
			// �Z�L�����e�B�ݒ�.
			if (!p_req->s_BackupTarget.e_TargetSecurity.empty()) {
				if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetSecurity.get()) {
					e_Target2 |= TYPE_UsbImportExportTarget2nd_SecurityAutoSetting;
				}
			}

			// �\�t�g�E�F�ADipSW.
			if (!p_req->s_BackupTarget.e_TargetSoftwareDipSW.empty()) {
				if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetSoftwareDipSW.get()) {
					e_Target2 |= TYPE_UsbImportExportTarget2nd_SoftwareDipSW;
				}
			}

			// �G���W��DipSW.
			if (!p_req->s_BackupTarget.e_TargetEngineDipSW.empty()) {
				if (OAPE_Bool_true == p_req->s_BackupTarget.e_TargetEngineDipSW.get()) {
					e_Target2 |= TYPE_UsbImportExportTarget2nd_EngineDipSW;
				}
			}
		}
// [MAv6] 2018/08/09 RQ-768 (Hitachi)K.Nishihara Add End.

/////////////////////
// Main Operations
////////////////////

	
	OAPC_RDTManagerObserver& c_RDTManagerObserver =  OAPC_RDTManagerObserver::getInstance();

	
	// AuthKey Storage for Logout purpose.
	c_RDTManagerObserver.SetObserverAuthKey( const_cast<char*>(p_req->s_OperatorInfo.sc_AuthKey.get()) );	// IT5_4.0 RQ-421_Phase2 2016/10/04 HCL-Naveen Added.

	// RDT�ݒ�o�b�N�A�b�v�Ǘ��@�\ �v������.
	getOpenAPIEnum( pc_RDTManager->requestStartSettingBackup( e_Target, e_Target2, (char*)p_req->sc_Password.get()), p_res->e_RemoteBackupResult );

	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE


// ================================================================ .
//�T�v�@�@�FAppReqGetRemoteUpdateLog .
//���l�@�@�F .
//�쐬�ҁ@�FNaveen Kanna.
//�ύX�����F2016.10.04.
// ================================================================ .
template <> class __OAPC_TransactImp<OAPS_AppReqGetRemoteUpdateLog> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqGetRemoteUpdateLog , OAPE_Result_FaultRequest_AppReqGetRemoteUpdateLog > 
{
friend class OAPC_TransactImp<OAPS_AppReqGetRemoteUpdateLog>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqGetRemoteUpdateLog)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetRemoteUpdateLog)

	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetRemoteUpdateLog)")

	e.setKind(OAPE_Fault_faultcode_Client);
	
	// ���ʍ\����Check(�^�O�L���E���[�U�[���) .
	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqGetRemoteUpdateLog)

// 2022/03/01 RQ-931 Sky Start.
//	// PSWC��CE��ʂ���̂ݎ��s .
//	int32_t authority = OAPE_UserType_CE;
	// CE�܂��́A�Ǘ��҂Ń��O�C���������Ɏ��s�\�Ƃ���B
	int32_t authority = OAPE_UserType_CE;
	if (true == OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_RQ931)) {
		authority = OAPE_UserType_CE | OAPE_UserType_Admin;
	}
// 2022/03/01 RQ-931 Sky End.

	// �I�y���[�^�[���O�C�� .
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqGetRemoteUpdateLog, AppResGetRemoteUpdateLog)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqGetRemoteUpdateLog)")

	e.setKind(OAPE_Fault_faultcode_Server);
	
	APIC_RDTSetting* pc_RDTSetting = APIC_RDTSetting::newInstanceAdmin();
	
	if (!pc_RDTSetting)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	char psc_UpdateLog[OAPD_REMOTEUPDATELOG_MAXSTRING];

	pc_RDTSetting->lock();
	pc_RDTSetting->getRDTUpdateLog( psc_UpdateLog ) ;
	pc_RDTSetting->unlock();
	
	p_res->sc_RemoteUpdateLog = (const char *)psc_UpdateLog;

	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
	
// ================================================================ .
//�T�v�@�@�FAppReqGetRemoteBackupLog .
//���l�@�@�F .
//�쐬�ҁ@�FNaveen Kanna.
//�ύX�����F2016.10.04.
// ================================================================ .
template <> class __OAPC_TransactImp<OAPS_AppReqGetRemoteBackupLog> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqGetRemoteBackupLog , OAPE_Result_FaultRequest_AppReqGetRemoteBackupLog > 
{
friend class OAPC_TransactImp<OAPS_AppReqGetRemoteBackupLog>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqGetRemoteBackupLog)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetRemoteBackupLog)

	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetRemoteBackupLog)")

	e.setKind(OAPE_Fault_faultcode_Client);
	
	// ���ʍ\����Check(�^�O�L���E���[�U�[���) .
	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqGetRemoteBackupLog)

// 2022/03/01 RQ-931 Sky Start.
//	// PSWC��CE��ʂ���̂ݎ��s .
//	int32_t authority = OAPE_UserType_CE;
	// CE�܂��́A�Ǘ��҂Ń��O�C���������Ɏ��s�\�Ƃ���B
	int32_t authority = OAPE_UserType_CE;
	if (true == OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_RQ931)) {
		authority = OAPE_UserType_CE | OAPE_UserType_Admin;
	}
// 2022/03/01 RQ-931 Sky End.

	// �I�y���[�^�[���O�C�� .
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqGetRemoteBackupLog, AppResGetRemoteBackupLog)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqGetRemoteUpdateLog)")

	e.setKind(OAPE_Fault_faultcode_Server);
	
	APIC_RDTSetting* pc_RDTSetting = APIC_RDTSetting::newInstanceAdmin();
	
	if (!pc_RDTSetting)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	char psc_BackupLog[OAPD_REMOTEUPDATELOG_MAXSTRING];

	pc_RDTSetting->lock();
	pc_RDTSetting->getRDTBackupLog( psc_BackupLog ) ;
	pc_RDTSetting->unlock();
	
	p_res->sc_RemoteBackupLog = (const char *)psc_BackupLog;

	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
	
// ================================================================ .
//�T�v�@�@�FAppReqGetRemoteProcessState .
//���l�@�@�F .
//�쐬�ҁ@�FNaveen Kanna.
//�ύX�����F2016.10.04.
// ================================================================ .
template <> class __OAPC_TransactImp<OAPS_AppReqGetRemoteProcessState> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqGetRemoteProcessState , OAPE_Result_FaultRequest_AppReqGetRemoteProcessState > 
{
friend class OAPC_TransactImp<OAPS_AppReqGetRemoteProcessState>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqGetRemoteProcessState)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetRemoteProcessState)

	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetRemoteProcessState)")

	e.setKind(OAPE_Fault_faultcode_Client);
	
	// ���ʍ\����Check(�^�O�L���E���[�U�[���) .
	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqGetRemoteProcessState)

// 2022/03/01 RQ-931 Sky Start.
//	// PSWC��CE��ʂ���̂ݎ��s .
//	int32_t authority = OAPE_UserType_CE;
	// CE�܂��́A�Ǘ��҂Ń��O�C���������Ɏ��s�\�Ƃ���B
	int32_t authority = OAPE_UserType_CE;
	if (true == OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_RQ931)) {
		authority = OAPE_UserType_CE | OAPE_UserType_Admin;
	}
// 2022/03/01 RQ-931 Sky End.

	// �I�y���[�^�[���O�C�� .
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
	{
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqGetRemoteProcessState, AppResGetRemoteProcessState)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqGetRemoteProcessState)")

	e.setKind(OAPE_Fault_faultcode_Server);
	
	APIC_RDTManager* pc_RDTManager = APIC_RDTManager::newInstanceAdmin();
	
	if (!pc_RDTManager)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull , "Failed to get instance");
		return false;
	}
	
	getOpenAPIEnum( pc_RDTManager->getProcessState(), p_res->e_ProcessingState );

	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

// IT5_4.0 RQ-421_Phase2 2016/10/04 HCL-Naveen Added Start.

//2017/04/01 �ؖ����v��(CSR)_XML��ՋZ�p�J��v2 pactera add start.
template <> class __OAPC_TransactImp<OAPS_AppReqSslCSRCert> :
	public OAPC_TransactImpBaseInquiry< OAPS_AppReqSslCSRCert ,OAPE_Result_FaultRequest_AppReqSslCSRCert >
{
friend class OAPC_TransactImp<OAPS_AppReqSslCSRCert>;
private:

	OAPC_AuthManager _authmanager;

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}

	inline OAPE_Response _response() const;
	inline bool _pre_check(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _authorize(const OAPC_Memory& msg, OAPC_Error& e);
	inline bool _execute(const OAPC_Memory& msg, OAPC_Memory& retres, OAPC_Error& e);
};

OAPD_TRANSACT_HANDLING(AppReqSslCSRCert)

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqSslCSRCert)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqSslCSRCert)")

	if( !OAPD_VERSION_CHECK(p_req->getVersion(), OAPD_OVER_V999) )
	{
		e.setKind(OAPE_Fault_faultcode_Client);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralNotSupportedRequest, "AppReqSslCSRCert");
		return false;
	}

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}

	if ( strlen(p_req->sc_Organization.get()) > OAPD_SSLCSRCERT_MAXLENGTH ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "Organization");
		return false;
	}

	if ( strlen(p_req->sc_OrganizationUnit.get()) > OAPD_SSLCSRCERT_MAXLENGTH ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "OrganizationUnit");
		return false;
	}

	if ( strlen(p_req->sc_CityName.get()) > OAPD_SSLCSRCERT_NAME_MAXLENGTH ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "CityName");
		return false;
	}

	if ( strlen(p_req->sc_StateName.get()) > OAPD_SSLCSRCERT_NAME_MAXLENGTH ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "StateName");
		return false;
	}

	if ( strlen(p_req->sc_CountryCode.get()) > (OAPD_SSLCSRCERT_COUNTRYCODE - 1) ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "CountryCode");
		return false;
	}

	if ( strlen(p_req->sc_MailAddress.get()) > OAPD_SSLCSRCERT_NAME_MAXLENGTH ) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "MailAddress");
		return false;
	}

	// LockKey Check(���b�N��) .
	if ( !DEVICE_LOCKKEY_PASS_CHECK( p_req, _slock, e, true ) ) 	// �yIT6_Sparrow�zAR1056532 2018/08/13 HCL-Palani Modified.
	{
		return false;
	}

	// 2018/02/26 FVT 1038090 Pactera Added Start.
	if (p_req->sc_Organization.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "Organization");
		return false;
	}
	if (p_req->sc_OrganizationUnit.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OrganizationUnit");
		return false;
	}
	if (p_req->sc_CityName.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "CityName");
		return false;
	}
	if (p_req->sc_StateName.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "StateName");
		return false;
	}
	if (p_req->sc_CountryCode.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "CountryCode");
		return false;
	}
	if (p_req->e_SslPrivKeyType.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "SslPrivKeyType");
		return false;
	}
//IT6_EagleBK OP_BTS-8478 06/08/2019 HCL-Mangai Added Start.
	if( False == checkExpImpAccountCheck( p_req->s_OperatorInfo.sc_AuthKey.get() ) ){
		if (OAPE_SslPrivKeyType_Dsa_512 == p_req->e_SslPrivKeyType.get()
			||OAPE_SslPrivKeyType_Dsa_1024 == p_req->e_SslPrivKeyType.get() 
			||OAPE_SslPrivKeyType_Dsa_2048 == p_req->e_SslPrivKeyType.get() ) {
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue, "Not Support Enum for SslPrivKeyType");
				return false;
		}
	}
//IT6_EagleBK OP_BTS-8478 06/08/2019 HCL-Mangai Added End.
	
	if (p_req->sc_MailAddress.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "MailAddress");
		return false;
	}
	// 2018/02/26 FVT 1038090 Pactera Added End.
OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqSslCSRCert)

	long authority = OAPE_UserType_Admin; 

	////////////////////////////////////. 
	// �I�y���[�^�[���O�C��. 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e)) {
		return false;
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqSslCSRCert, AppResSslCSRCert)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqSslCSRCert)")

	// CommonApi����I�u�W�F�N�g�擾.
	OAPC_ApiLock<APIC_SslSetting> pc_SslSetting(APIC_SslSetting::newInstanceAdmin(), &_slock);

	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ��Fault��Ԃ�.
	if(!pc_SslSetting)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}

	// �r�r�k�Í������x.
	TYPE_SslPrivKeyType	type_SslPrivKeyType = TYPE_SslPrivKeyType_Rsa_1024;
	getCommAPIEnum( p_req->e_SslPrivKeyType, type_SslPrivKeyType );

	t_sMioSslCertInfo	setMioSslCertInfo;
	memset(&setMioSslCertInfo, 0, sizeof(t_sMioSslCertInfo));
	// �g�D��.
	memcpy(setMioSslCertInfo.szO, (const char*)p_req->sc_Organization.get(), 64);
	// ������.
	memcpy(setMioSslCertInfo.szOU, (const char*)p_req->sc_OrganizationUnit.get(), 64);
	// �s������.
	memcpy(setMioSslCertInfo.szL, (const char*)p_req->sc_CityName.get(), 128);
	// �s���{����.
	memcpy(setMioSslCertInfo.szST, (const char*)p_req->sc_StateName.get(), 128);
	// ����.
	strcpy((char*)setMioSslCertInfo.szC, (const char*)p_req->sc_CountryCode.get());
	// �Ǘ��҃��[���A�h���X.
	memcpy(setMioSslCertInfo.szE, (const char*)p_req->sc_MailAddress.get(), 128);

	TYPC_SslCertInfo	type_SslCertInfo;
	// CommonAPI.
	type_SslCertInfo = pc_SslSetting->setSSLCertReqCreate("", setMioSslCertInfo, type_SslPrivKeyType);

	// ���ʒʒm���ʍ\���̍쐬.
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
//2017/04/01 �ؖ����v��(CSR)_XML��ՋZ�p�J��v2 pactera add end.

// GaiaFUM 2009/07/03 sone START.
// ================================================================ 
// �ߓd���[�h�ڍs
// ================================================================  
// ZesuMLK ����\���ύX_�g�p���Ă��郁�����ʂ̍팸���s�� Senthil 2012/04/09 Commented START. 
/*
template <> class __OAPC_TransactImp<OAPS_AppReqPowerSave> :
	public OAPC_TransactImpBaseInquiry<OAPS_AppReqPowerSave, OAPE_Result_FaultRequest_AppReqPowerSave> 
{
friend class OAPC_TransactImp<OAPS_AppReqPowerSave>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[����. 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check( const OAPC_Memory& , OAPC_Error& );
	inline bool _authorize( const OAPC_Memory& , OAPC_Error& );
	inline bool _execute( const OAPC_Memory& , OAPC_Memory& , OAPC_Error& );
};
OAPD_TRANSACT_HANDLING(AppReqPowerSave);

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqPowerSave)
	
	OAPD_TRACE("OAPD_BEGIN_TRANSACT_PRECHECK(AppReqPowerSave)")
	
	e.setKind(OAPE_Fault_faultcode_Client);

	if (p_req->s_OperatorInfo.empty()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo");
		return false;
	}
	if (!p_req->s_OperatorInfo.check()) {
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo");
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqPowerSave)
	
	OAPD_TRACE_SCOPE( "OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqPowerSave)" )
	
	int authority = 0;
	{
		OAPC_ApiLock<OAPC_AuthManager> p_authmanager( &_authmanager, &_slock );
		OAPC_AuthManager::OAPE_State e_state = p_authmanager->getStatus();
		if ( OAPC_AuthManager::OAPE_State_Auth        ==e_state ||
			OAPC_AuthManager::OAPE_State_AuthAndTrack==e_state ) {
			authority = OAPE_UserType_User|OAPE_UserType_Public|OAPE_UserType_Admin;
		}
		else {
			authority = OAPE_UserType_Public|OAPE_UserType_Admin;
		}
	}

	//////////////////////////////////// 
	// �I�y���[�^�[���O�C��. 
	OAPC_User op(p_req->s_OperatorInfo, authority);
	if (!op.authCheck(TYPD_UserFunctionMask_None, e))
	{
		return false;
	}
	
OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqPowerSave, AppResPowerSave)

	OAPD_TRACE_SCOPE("OAPD_BEGIN_TRANSACT_EXECUTE(AppReqPowerSave)")
		

	// CommonApi����I�u�W�F�N�g�擾.
	OAPC_ApiLock<APIC_Power> pc_Power(APIC_Power::newInstanceAdmin(), &_slock);
	OAPC_ApiLock<APIC_SystemSetting> pc_SystemSetting(APIC_SystemSetting::newInstanceAdmin(), &_slock);
	OAPC_ApiLock<APIC_PrinterStatus> pc_prnst(APIC_PrinterStatus::newInstanceAdmin(), &_slock);


	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ��Fault��Ԃ�.
	if(!pc_Power || !pc_SystemSetting || !pc_prnst)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}
	

	///////////////////////	
	// ���݂̏�ԃ`�F�b�N//
	///////////////////////
 	
	// ���݂̏�Ԃ���d��/�X���[�v�̏ꍇ�A�G���[��Ԃ�.
	// �y���R�z.
	//  ��t�^�C�~���O�ł͒�d��/�X���[�v����GeneralOutOfTiming��ԋp���Ă��邪.
	//  SPD����GeneralOutOfTiming�ł͂Ȃ��A��d��/�X���[�v�����킩��G���[��ԋp���Ăق����Ƃ̂���.
	//  ��t�^�C�~���O���C������Ɖe���͈͂��傫�����߁AEXECUTE�Ŕ��肷��.
	
	// �d���Ǘ����ڍ׃X�e�[�^�X���擾����.
	TYPE_PowerSaveStatus e_PowerStatus = pc_Power->getPowerSaveStatus();
	
	
	
	if(e_PowerStatus == TYPE_PowerSaveStatusLowPowerIn			// ��d�͈ڍs��.
		|| e_PowerStatus == TYPE_PowerSaveStatusLowPower 		// ��d�͒�.
		|| e_PowerStatus == TYPE_PowerSaveStatusLowPowerOut		// ��d�͉�����.
		|| e_PowerStatus == TYPE_PowerSaveStatusSleepIn			// �X���[�v�ڍs��.
		|| e_PowerStatus == TYPE_PowerSaveStatusSleep			// �X���[�v��.
		|| e_PowerStatus == TYPE_PowerSaveStatusSleepOut)		// �X���[�v������.
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralDuringPowerSave, "GeneralDuringPowerSave");
		return false;
	}

	bool b_PowerSaveFlag = False;	// �ڍs���fFlag.

	// �ȓd�̓L�[�����̍ۂ́A��Ԏ擾.
	if(True == pc_SystemSetting->getLowPowerOrSleep())	// �X���[�v���[�h.
	{
		b_PowerSaveFlag = pc_Power->isPowerSaveShiftEnable( PWRE_PowerSaveShiftCheckSleepBySaveKey );	// �X���[�v���[�h�ڍs�`�F�b�N.
		if(!b_PowerSaveFlag)
		{
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "GeneralOutOfTiming");
			return false;
		}
		// �X���[�v���[�h�ڍs.
		pc_Power->changePowerMode( TYPE_PowerModePowerSaveKey );
	}
	else	// �ȓd��(��d��)���[�h.
	{
		b_PowerSaveFlag = pc_Power->isPowerSaveShiftEnable( PWRE_PowerSaveShiftCheckPreHeatBySaveKey );	// �ȓd��(��d��)���[�h�ڍs�`�F�b�N.
		if(!b_PowerSaveFlag)
		{
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "GeneralOutOfTiming");
			return false;
		}
		// �ȓd��(��d��)���[�h�ڍs.
		pc_Power->changePowerMode( TYPE_PowerModePowerSaveKey );
	}
	
	
	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬. 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
// GaiaFUM 2009/07/03 sone END.

// GaiaFUM LDAP���� matsuda 2009/07/24 START.
class OAPC_SearchLdap
{
private:
	OAPC_SyncLock _slock;					// Connect,Search�p.
	OAPC_SyncLock _slock2;					// Cancel�p.
	TYPE_LdapConnectError	e_ConnectError;	// Connect���G���[.
	TYPE_LdapSearchError e_SearchError;		// Search���G���[.
	TYPE_LdapCancelError e_CancelError;		// Cancel���G���[.
	short ss_TotalSearchCount;				// �������ʌ���.

	static OAPC_SearchLdap _c_theInstance;
	// �R���X�g���N�^.
	OAPC_SearchLdap():
		//Minerva�ÓI��� CID466415 matsuda 2011/2/22 START.
		e_ConnectError(TYPE_LdapConnectErrorOther),
		e_SearchError(TYPE_LdapSearchErrorOther),
		e_CancelError(TYPE_LdapCancelErrorOperationsError),
		//Minerva�ÓI��� CID466415 matsuda 2011/2/22 END.
		ss_TotalSearchCount(0),
		ss_BlockCount(0),
		b_SmimeSearch(False),
		b_Connect(False),
		b_Search(False),
		b_Active(False)
	{}
	
	OAPC_SearchLdap(const OAPC_SearchLdap&);
	OAPC_SearchLdap& operator=(const OAPC_SearchLdap&);

public:
	short ss_BlockCount;				// �������ʎ擾�J�E���^.
	
	Bool b_SmimeSearch;			// Smime�t���O.
	Bool b_Connect;				// Connect�t���O.
	Bool b_Search;				// Search�t���O.
	Bool b_Active;				// ���s���Ǘ��t���O.

	static OAPC_SearchLdap* getInstance() { return &_c_theInstance; }
	void setLock(OAPC_SyncLock slock) { _slock = slock; }
	void setLockCancel(OAPC_SyncLock slock) { _slock2 = slock; }

	// Connect.
	void setConnectResult( TYPE_LdapConnectError e_Result )
	{ 
		_slock.release();
		e_ConnectError = e_Result;
		b_Connect = False;
	}
	TYPE_LdapConnectError getConnectResult()
	{
		return e_ConnectError;
	}
	// Search.
	void setSearchResult( TYPE_LdapSearchError e_Result )
	{ 
		_slock.release();
		e_SearchError = e_Result;
		b_Search = False;
	}
	TYPE_LdapSearchError getSearchResult()
	{
		return e_SearchError;
	}
	// Cancel.
	void setCancelResult(TYPE_LdapCancelError e_Result)
	{
		_slock2.release();
		e_CancelError = e_Result;
		if( e_Result == TYPE_LdapCancelErrorOk )
		{
			if( b_Connect == True )
			{
				setConnectResult( TYPE_LdapConnectErrorUserCanceled );
			}
			else if( b_Search == True )
			{
				setSearchResult( TYPE_LdapSearchErrorUserCanceled );
			}
		}
	}
	void setDisconnectResult(TYPE_LdapDisconnectError e_Result)
	{	// �������Ȃ�.
		_slock.release();
		OAPD_TRACE( "TYPE_LdapDisconnectError:\t"<< (int)e_Result )
	}
	TYPE_LdapCancelError getCancelResult()
	{
		return e_CancelError;
	}

	// �������ʌ���.
	void SetTotalSearchCount( short newCount )
	{
		ss_TotalSearchCount = newCount;
	}
	short GetTotalSearchCount()
	{
		return ss_TotalSearchCount;
	}
	
	Bool CheckCount()
	{
		Bool ret = true;
		if( 
			ss_TotalSearchCount <= 0 										// �������ʂ�0���ȉ�.
			|| ( ss_BlockCount < 0)												// �J�E���g���}�C�i�X.
			|| ( ss_TotalSearchCount ) <= ( ( ss_BlockCount - 1 ) * 10 )  )		// �ő�J�E���g�𒴂���.
		{
			ret = false;
		}
		return ret;
	}
	
	// �R�[���o�b�N�֐�.
	// Connect.
	static void ans_connect( TYPE_LdapConnectError e_Result, int32_t sl_NICFUM_Result )
	{
		OAPD_TRACE( "ans_connect" )
		_c_theInstance.setConnectResult( e_Result );
	}
	// Search.
	static void ans_searchstart( TYPE_LdapSearchError e_Result, int32_t sl_NICFUM_Result )
	{
		OAPD_TRACE( "ans_searchstart" )
		_c_theInstance.setSearchResult( e_Result );
	}
	// Disconnect.
	static void ans_disconnect( TYPE_LdapDisconnectError e_Result, int32_t sl_NICFUM_Result )
	{
		OAPD_TRACE( "ans_disconnect" )
		_c_theInstance.setDisconnectResult( e_Result );
	}
	// Cancel.
	static void ans_cancel( TYPE_LdapCancelError e_Result)
	{
		OAPD_TRACE( "ans_cancel" )
		_c_theInstance.setCancelResult( e_Result );
	}
	// �����ʒu������.
	Bool ListNext ( APIC_LdapSearch* pc_LdapSearch )
	{
		if( ss_TotalSearchCount <= ( ss_BlockCount * 10 ) )
		{	// �����͈͊O.
			return False;
		}
		return True;
	}
	// �����ʒu��2��(�ő�10*20)�O��.
	Bool ListPrevious( APIC_LdapSearch* pc_LdapSearch )
	{
		LIBC_List<TYPS_LdapSearchResult> c_SearchResultList;
		if( ss_BlockCount < 11 )
		{	// �����͈͊O.
			return False;
		}
		int i = 0;
		if( ss_BlockCount % 10 != 0 )
		{
			while( ss_BlockCount % 10 != 0 )
			{
				pc_LdapSearch->getResultList( 10, TYPE_LdapSearchGetListTypePrevious, &c_SearchResultList );
				ss_BlockCount--;
			}
		}
		else
		{
			while( i < 10 )
			{
				 pc_LdapSearch->getResultList( 10, TYPE_LdapSearchGetListTypePrevious, &c_SearchResultList );
				i++;
				ss_BlockCount--;
			}
		}
		// �J�E���g���Z�b�g.
		i = 0;
		while( i < 10 )
		{
			 pc_LdapSearch->getResultList( 10, TYPE_LdapSearchGetListTypePrevious, &c_SearchResultList );
			i++;
			ss_BlockCount--;
		}
		return True;
	}
	// �����ʒu��1��(�ő�10*10)�O��.
	Bool ListCurrent( APIC_LdapSearch* pc_LdapSearch )
	{
		LIBC_List<TYPS_LdapSearchResult> c_SearchResultList;
		if( ss_BlockCount < 1 )
		{	// �����͈͊O.
			return False;
		}
		if( ss_BlockCount % 10 != 0 )
		{
			while( ss_BlockCount % 10 != 0 )
			{
				pc_LdapSearch->getResultList( 10, TYPE_LdapSearchGetListTypePrevious, &c_SearchResultList );
				ss_BlockCount--;
			}
		}
		else
		{
			int i = 0;
			while( i < 10 )
			{
				 pc_LdapSearch->getResultList( 10, TYPE_LdapSearchGetListTypePrevious, &c_SearchResultList );
				i++;
				ss_BlockCount--;
			}
		}
		return True;
	}

};
OAPC_SearchLdap OAPC_SearchLdap::_c_theInstance;

class OAPC_LdapActive
{
public:
	OAPC_LdapActive()
	{
		OAPC_SearchLdap* pc_SearchLdap = OAPC_SearchLdap::getInstance(); 
		pc_SearchLdap->b_Active = True;
	}
	~OAPC_LdapActive()
	{
		OAPC_SearchLdap* pc_SearchLdap = OAPC_SearchLdap::getInstance(); 
		pc_SearchLdap->b_Active = False;
	}
	
};
// Smime����.
void GetSearchLDAPResult( APIC_LdapSearch *pc_LdapSearch, TYPE_LdapSearchGetListType e_GetListType, OAPS_SearchResultList *s_SearchResultList,OAPC_SearchLdap *pc_SearchLdap )
{
	OAPD_TRACE_SCOPE( "LdapSearchResultGet" )
	LIBC_List<TYPS_LdapSearchResult> c_SearchResultList;
	TYPS_LdapSearchResult* ps_LdapSearchResult;
	short ss_Size = 0;
	
	// �������ʎ擾.
	// 100���܂킷�Ɨ�O���������邽��10*10��100���擾����.
	pc_LdapSearch->getResultList( 10, e_GetListType, &c_SearchResultList );
	pc_SearchLdap->ss_BlockCount++;
	// �������ʂ��\���̂ɑ��.
	ps_LdapSearchResult = c_SearchResultList.findFirst();
	
	int i = 0;	// ���[�v�J�E���^.
	// �������ʂ�������Ȃ��A�擾���ʂ�100���𒴂���A�擾�ʒu���������ʂ𒴂���̂����ꂩ�𖞂����܂Ń��[�v.
	while( NULL != ps_LdapSearchResult && ss_Size < OAPD_LDAPSEACHRESULT_MAXLIST && pc_SearchLdap->CheckCount() )
	{	// �l��������.
		s_SearchResultList->s_SearchResult[ss_Size].sc_Name = ps_LdapSearchResult->sc_SearchNameUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_MailAddress = ps_LdapSearchResult->sc_SearchMailAddress;
		s_SearchResultList->s_SearchResult[ss_Size].sc_TelNo = ps_LdapSearchResult->sc_SearchTelNoUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_FaxNo = ps_LdapSearchResult->sc_SearchFaxNoUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_LastName = ps_LdapSearchResult->sc_SearchLastNameUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_FirstName = ps_LdapSearchResult->sc_SearchFirstNameUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_CityName = ps_LdapSearchResult->sc_SearchCityNameUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_Organization = ps_LdapSearchResult->sc_OrganizationUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_OrganizationUnit = ps_LdapSearchResult->sc_OrganizationUnitUTF8;
		ss_Size++;
		i++;
		// 100���܂킷�Ɨ�O���������邽��10*10��100���擾����.
		if( i < 10 )
		{
			ps_LdapSearchResult = c_SearchResultList.findNext();
		}
		else
		{	// 100�������Ȃ玟�̌��ʂ��擾����.
			if( ss_Size < OAPD_LDAPSEACHRESULT_MAXLIST )
			{
				// �J�E���g���N���A.
				i = 0;
				// ���X�g���N���A.
				c_SearchResultList.delAll();
				// �����͈͓��Ȃ玟���擾����.
				if( pc_SearchLdap->CheckCount() )
				{
					pc_SearchLdap->ss_BlockCount++;
					pc_LdapSearch->getResultList( 10, OAPE_SearchListType_Next, &c_SearchResultList );
					ps_LdapSearchResult = c_SearchResultList.findFirst();
				}
				else
				{
					ps_LdapSearchResult = NULL;
					break;
				}
			}
			else
			{
				break;
			}
		}
	}
	s_SearchResultList->ss_ArraySize = ss_Size;
}

// Smime�L��.
void GetSearchLDAPResultSmime( APIC_LdapSearch *pc_LdapSearch, TYPE_LdapSearchGetListType e_GetListType, OAPS_SearchResultList *s_SearchResultList,OAPC_SearchLdap *pc_SearchLdap )
{
	LIBC_List<TYPS_LdapSearchResultSmime> c_SearchResultList;
	TYPS_LdapSearchResultSmime* ps_LdapSearchResultSmime;
	short ss_Size = 0;
	int i = 0;
	OAPD_TRACE( "LdapSearchResultGetSTART" )
	
	// �������ʎ擾.
	// 100���܂킷�Ɨ�O���������邽��10*10��100���擾����.
	pc_LdapSearch->getResultListSmime( 10, e_GetListType, &c_SearchResultList );
	pc_SearchLdap->ss_BlockCount++;
	// �������ʂ��\���̂ɑ��.
	ps_LdapSearchResultSmime = c_SearchResultList.findFirst();

	// �������ʂ�������Ȃ��A�擾���ʂ�100���𒴂���A�擾�ʒu���������ʂ𒴂���̂����ꂩ�𖞂����܂Ń��[�v.
	while( NULL != ps_LdapSearchResultSmime && ss_Size < OAPD_LDAPSEACHRESULT_MAXLIST && pc_SearchLdap->CheckCount() )
	{
		s_SearchResultList->s_SearchResult[ss_Size].sc_Name = ps_LdapSearchResultSmime->s_LdapSearchResult.sc_SearchNameUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_MailAddress = ps_LdapSearchResultSmime->s_LdapSearchResult.sc_SearchMailAddress;
		s_SearchResultList->s_SearchResult[ss_Size].sc_TelNo = ps_LdapSearchResultSmime->s_LdapSearchResult.sc_SearchTelNoUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_FaxNo = ps_LdapSearchResultSmime->s_LdapSearchResult.sc_SearchFaxNoUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_LastName = ps_LdapSearchResultSmime->s_LdapSearchResult.sc_SearchLastNameUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_FirstName = ps_LdapSearchResultSmime->s_LdapSearchResult.sc_SearchFirstNameUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_CityName = ps_LdapSearchResultSmime->s_LdapSearchResult.sc_SearchCityNameUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_Organization = ps_LdapSearchResultSmime->s_LdapSearchResult.sc_OrganizationUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].sc_OrganizationUnit = ps_LdapSearchResultSmime->s_LdapSearchResult.sc_OrganizationUnitUTF8;
		s_SearchResultList->s_SearchResult[ss_Size].s_Smime.ss_Size = ps_LdapSearchResultSmime->ss_x509size;
		char sc_data[OAPD_LDAPSMIME_MAXLEN];
		chgBintoBase64( (unsigned char*)ps_LdapSearchResultSmime->sc_x509, ps_LdapSearchResultSmime->ss_x509size, sc_data );
		s_SearchResultList->s_SearchResult[ss_Size].s_Smime.sc_Data = sc_data;
		ss_Size++;
		i++;
		// 100���܂킷�Ɨ�O���������邽��10*10��100���擾����.
		if( i < 10 )
		{
			ps_LdapSearchResultSmime = c_SearchResultList.findNext();
		}
		else
		{
			// 100�������Ȃ玟�̌��ʂ��擾����.
			if( ss_Size < OAPD_LDAPSEACHRESULT_MAXLIST )
			{
				// �J�E���g���N���A.
				i = 0;
				// ���X�g���N���A.
				c_SearchResultList.delAll();
				// �����͈͓��Ȃ玟���擾����.
				if( pc_SearchLdap->CheckCount() )
				{
					pc_SearchLdap->ss_BlockCount++;
					pc_LdapSearch->getResultListSmime( 10, OAPE_SearchListType_Next, &c_SearchResultList );
					ps_LdapSearchResultSmime = c_SearchResultList.findFirst();
				}
				else
				{
					ps_LdapSearchResultSmime = NULL;
					break;
				}
			}
			else
			{
				break;
			}
		}
	}
	s_SearchResultList->ss_ArraySize = ss_Size;
}

template <> class __OAPC_TransactImp<OAPS_AppReqSearchLdap> :
	public OAPC_TransactImpBaseInquiry<OAPS_AppReqSearchLdap, OAPE_Result_FaultRequest_AppReqSearchLdap> 
{
friend class OAPC_TransactImp<OAPS_AppReqSearchLdap>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[����.

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check( const OAPC_Memory& , OAPC_Error& );
	inline bool _authorize( const OAPC_Memory& , OAPC_Error& );
	inline bool _execute( const OAPC_Memory& , OAPC_Memory& , OAPC_Error& );
};

OAPD_TRANSACT_HANDLING( AppReqSearchLdap );

OAPD_BEGIN_TRANSACT_PRECHECK( AppReqSearchLdap )

	e.setKind(OAPE_Fault_faultcode_Client);

	if( p_req->s_OperatorInfo.empty() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo" );
		return false;
	}

	if( !p_req->s_OperatorInfo.check() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo" );
		return false;
	}

	if( p_req->s_ServerInfo.ss_ServerIndex.empty() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "ServerIndex" );
		return false;
	}
	
	if( !p_req->s_ServerInfo.ss_ServerIndex.range() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralIllegalValue, "ServerIndex" );
		return false;
	}
	if( !p_req->s_ServerInfo.s_UserInfo.empty() && ( p_req->s_ServerInfo.s_UserInfo.sc_UserName.empty() || p_req->s_ServerInfo.s_UserInfo.sc_Password.empty() ) )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "UserName or Password" );
		return false;
	}

	

	if( p_req->e_Smime.empty() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "Smime" );
		return false;
	}

	if( p_req->e_SearchAction.empty() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "SearchAction" );
		return false;
	}

	if( p_req->e_SearchAction == OAPE_SearchAction_Single )
	{	// �P����.
		if( p_req->s_SearchAttributeSingle.sc_SearchString.empty() )
		{
			e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "SearchString" );
			return false;
		}
	}
	else
	{	// ��������.
		if( p_req->s_SearchAttributeMulti.s_Name.empty() 
			&& p_req->s_SearchAttributeMulti.s_MailAddress.empty()
			&& p_req->s_SearchAttributeMulti.s_FaxNo.empty()
			&& p_req->s_SearchAttributeMulti.s_LastName.empty()
			&& p_req->s_SearchAttributeMulti.s_FirstName.empty()
			&& p_req->s_SearchAttributeMulti.s_CityName.empty()
			&& p_req->s_SearchAttributeMulti.s_Organization.empty()
			&& p_req->s_SearchAttributeMulti.s_OrganizationUnit.empty() )
		{
			e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "SearchAttribute" );
			return false;
		}
		
		if( !p_req->s_SearchAttributeMulti.s_Name.empty() && ( p_req->s_SearchAttributeMulti.s_Name.e_SearchCondition.empty() || p_req->s_SearchAttributeMulti.s_Name.sc_SearchString.empty() )
			|| !p_req->s_SearchAttributeMulti.s_MailAddress.empty() && ( p_req->s_SearchAttributeMulti.s_MailAddress.e_SearchCondition.empty() || p_req->s_SearchAttributeMulti.s_MailAddress.sc_SearchString.empty() )
			|| !p_req->s_SearchAttributeMulti.s_FaxNo.empty() && ( p_req->s_SearchAttributeMulti.s_FaxNo.e_SearchCondition.empty() || p_req->s_SearchAttributeMulti.s_FaxNo.sc_SearchString.empty() )
			|| !p_req->s_SearchAttributeMulti.s_LastName.empty() && ( p_req->s_SearchAttributeMulti.s_LastName.e_SearchCondition.empty() || p_req->s_SearchAttributeMulti.s_LastName.sc_SearchString.empty() )
			|| !p_req->s_SearchAttributeMulti.s_FirstName.empty() && ( p_req->s_SearchAttributeMulti.s_FirstName.e_SearchCondition.empty() || p_req->s_SearchAttributeMulti.s_FirstName.sc_SearchString.empty() )
			|| !p_req->s_SearchAttributeMulti.s_CityName.empty() && ( p_req->s_SearchAttributeMulti.s_CityName.e_SearchCondition.empty() || p_req->s_SearchAttributeMulti.s_CityName.sc_SearchString.empty() )
			|| !p_req->s_SearchAttributeMulti.s_Organization.empty() && ( p_req->s_SearchAttributeMulti.s_Organization.e_SearchCondition.empty() || p_req->s_SearchAttributeMulti.s_Organization.sc_SearchString.empty() )
			|| !p_req->s_SearchAttributeMulti.s_OrganizationUnit.empty() && ( p_req->s_SearchAttributeMulti.s_OrganizationUnit.e_SearchCondition.empty() || p_req->s_SearchAttributeMulti.s_OrganizationUnit.sc_SearchString.empty() ) )
		{
			e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "SearchCondition or SearchString" );
			return false;
		}
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqSearchLdap)

	if (!p_req->s_OperatorInfo.empty()) 
	{
		int authority = 0;
		OAPC_ApiLock<OAPC_AuthManager> p_authmanager( &_authmanager, &_slock );
		OAPC_AuthManager::OAPE_State e_state = p_authmanager->getStatus();
		if ( OAPC_AuthManager::OAPE_State_Auth        ==e_state ||
			OAPC_AuthManager::OAPE_State_AuthAndTrack==e_state ||
			OAPC_AuthManager::OAPE_State_Track==e_state) 
		{
			authority = OAPE_UserType_User|OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
		}
		else
		{
			authority = OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
		}

		////////////////////////////////////.
		// �I�y���[�^�[���O�C��.
		OAPC_User op(p_req->s_OperatorInfo, authority);
		if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
		{
			return false;
		}
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqSearchLdap, AppResSearchLdap)

	OAPD_TRACE_SCOPE( "OAPS_AppReqSearchLdap" );

	e.setKind(OAPE_Fault_faultcode_Client);

	// CommonApi����I�u�W�F�N�g�擾.
	OAPC_ApiLock<APIC_LdapSearch> pc_LdapSearch( APIC_LdapSearch::newInstanceAdmin(), &_slock );
	OAPC_ApiLock<APIC_LdapSetting> pc_LdapSetting( APIC_LdapSetting::newInstanceAdmin( (short)p_req->s_ServerInfo.ss_ServerIndex.get() ), &_slock );		// Minerva Warning Removal. Ravi Tej modified on 15-Feb-2011.

	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ��Fault��Ԃ�.
	if( !pc_LdapSearch
	|| !pc_LdapSetting )
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}
	// LDAP�@�\���L����.
	if( !pc_LdapSetting->getOn() )
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "Ldap isn't Enable");
		return false;
	}

	char sc_ServerAddress[64] = { 0, };
	pc_LdapSetting->getServerAddressUTF8( sc_ServerAddress );
	// �T�[�o���o�^����Ă��Ȃ�.
	if( strlen(sc_ServerAddress) <= 0 || strncmp(sc_ServerAddress, "0.0.0.0", sizeof(sc_ServerAddress)) == 0)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "LdapServer is not set");
		return false;
	}

	// LDAP�T�[�o�ڑ���Ԋm�F.
	if( True == pc_LdapSearch->isServerConnecting() )
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "Can not LdapSearch");
		return false;
	}

	// Ldap�Ǘ��p�N���X.
	OAPC_SearchLdap* pc_SearchLdap = OAPC_SearchLdap::getInstance(); 

	if( True == pc_SearchLdap->b_Active )
	{
		OAPD_TRACE("LDAPACTIVE")
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "LdapActive");
		return false;
	}
	
	OAPC_LdapActive Flg;

	// LDAP�ڑ��ݒ�.
	TYPC_LdapSetting  c_LdapSetting;
	// ����������.
	c_LdapSetting.uc_LdapSettingFlag = 0x00;														// �k�c�`�o�ݒ�t���O .
	c_LdapSetting.us_PortNumber = 0;																// �|�[�g�ԍ�.
	c_LdapSetting.ss_TimeOutSec = 0;																// �^�C���A�E�g����.
	c_LdapSetting.b_SslOn = False;																	// SSL.
	c_LdapSetting.e_LdapAuthentication = TYPE_LdapAuthenticationAnonymous;							// �F�؃^�C�v.
	memset( c_LdapSetting.sc_ServerAddressUTF8, 0, sizeof(c_LdapSetting.sc_ServerAddressUTF8) );	// �T�[�o�A�h���X.
	memset( c_LdapSetting.sc_LoginNameUTF8, 0, sizeof(c_LdapSetting.sc_LoginNameUTF8) );			// ���O�C����.
	memset( c_LdapSetting.sc_PasswordUTF8, 0, sizeof(c_LdapSetting.sc_PasswordUTF8) );				// �p�X���[�h.
	memset( c_LdapSetting.sc_DomainNameUTF8, 0, sizeof(c_LdapSetting.sc_DomainNameUTF8) );			// �h���C����.

	// LDAP�T�[�o�ݒ�p�����[�^�쐬.
	c_LdapSetting.uc_LdapSettingFlag = ( TYPD_LdapSettingFlagServerAddress | TYPD_LdapSettingFlagLoginName | TYPD_LdapSettingFlagPassword );
	// ServerAddress.
	pc_LdapSetting->getServerAddressUTF8( c_LdapSetting.sc_ServerAddressUTF8 );

	// �F�ؕ���.
	switch( pc_LdapSetting->getLdapUserAuthentication() ) 
	{
		case TYPE_LdapUserAuthenticationInput:		// �ݒ�l���g�p.
			// �ݒ�l���擾����.
			pc_LdapSetting->getLoginNameUTF8( c_LdapSetting.sc_LoginNameUTF8 );
			pc_LdapSetting->getPasswordUTF8( c_LdapSetting.sc_PasswordUTF8 );
			break;
			
		case TYPE_LdapUserAuthenticationUserAuthentication:		// ���[�U�[�F�؂��g�p.
			if( p_req->s_ServerInfo.s_UserInfo.empty() )
			{	// ���O�C�����[�U���𗘗p����.
				OAPS_AccountUser loginUser;	// �F�؍ς݃��[�U�[���.
				OAPC_AccountMan::getInstance()->findAccount( p_req->s_OperatorInfo.sc_AuthKey.get(), loginUser );
				strncpy( c_LdapSetting.sc_LoginNameUTF8,loginUser.sc_UserName, sizeof( c_LdapSetting.sc_LoginNameUTF8 ) );
				strncpy( c_LdapSetting.sc_PasswordUTF8,loginUser.sc_Password, sizeof( c_LdapSetting.sc_PasswordUTF8 ) );
			}
			else
			{	// ���[�U���ƃp�X���[�h�����݂���ꍇ�̓��b�Z�[�W�̒l��D��.
				strncpy( c_LdapSetting.sc_LoginNameUTF8, p_req->s_ServerInfo.s_UserInfo.sc_UserName.get(),  sizeof( c_LdapSetting.sc_LoginNameUTF8 ) );
				strncpy( c_LdapSetting.sc_PasswordUTF8, p_req->s_ServerInfo.s_UserInfo.sc_Password.get(), sizeof( c_LdapSetting.sc_PasswordUTF8 ) );
			}
			break;

		case TYPE_LdapUserAuthenticationDynamicAuthentication:		// �_�C�i�~�b�N�F��.
			if( p_req->s_ServerInfo.s_UserInfo.empty() )
			{	// ���[�U���ƃp�X���[�h���K�{�̂��߃G���[�Ƃ���.
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralTagMissing, "UserInfo");
				return false;
			}
			else
			{	// ���b�Z�[�W�̒l���g�p.
				strncpy( c_LdapSetting.sc_LoginNameUTF8, p_req->s_ServerInfo.s_UserInfo.sc_UserName.get(),  sizeof( c_LdapSetting.sc_LoginNameUTF8 ) );
				strncpy( c_LdapSetting.sc_PasswordUTF8, p_req->s_ServerInfo.s_UserInfo.sc_Password.get(), sizeof( c_LdapSetting.sc_PasswordUTF8 ) );
			}
			break;
		default:
			break;
	}

	pc_SearchLdap->setLock(_slock);
	pc_SearchLdap->b_Connect = True;

	// �����ڑ��𖳌��ɂ���.
	pc_LdapSearch->setAutoConnect( False );

	// LDAP�T�[�o�ڑ�.
	pc_LdapSearch->req_connect( &c_LdapSetting, pc_SearchLdap->ans_connect, (short)p_req->s_ServerInfo.ss_ServerIndex.get() );	// Minerva Warning Removal. Ravi Tej modified on 15-Feb-2011.
	//�R�[���o�b�N�҂�.
	_slock.wait();

	pc_SearchLdap->b_Connect = False;
	
	switch( pc_SearchLdap->getConnectResult() )
	{
		case TYPE_LdapConnectErrorOk:						// �ڑ�����.
			break;
		case TYPE_LdapConnectErrorInvalidCredentials:		// ���O�C���G���[.
			pc_LdapSearch->req_disconnect( pc_SearchLdap->ans_disconnect );
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_LdapLoginError, "ConnectError");
			return false;
			break;
		case TYPE_LdapConnectErrorUserCanceled:				// ���[�U�[�ɂ���ăL�����Z������܂���.
			pc_LdapSearch->req_disconnect( pc_SearchLdap->ans_disconnect );
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_LdapUserCanceled, "ConnectError");
			return false;
			break;
		default:
			pc_LdapSearch->req_disconnect( pc_SearchLdap->ans_disconnect );
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_LdapOtherError, "ConnectError");
			return false;
			break;
	}
	
	// LDAP�T�[�o�[�ؒf.
	pc_LdapSearch->req_disconnect( pc_SearchLdap->ans_disconnect );
	//�ؒf���Ɍ����������Ȃ��悤�ɃR�[���o�b�N�҂�.
	_slock.wait();

	// �����ڑ���L���ɂ���.
	pc_LdapSearch->setAutoConnect( True );


	// �����ݒ�\����.
	TYPS_LdapSearchCondition s_LdapSearchCondition;
	// �f�t�H���g�l�擾.
	s_LdapSearchCondition = pc_LdapSetting->getDefaultSearchCondition();
	
	// ����������̏�����.
	memset( s_LdapSearchCondition.sc_SearchNameUTF8, '\0', sizeof( s_LdapSearchCondition.sc_SearchNameUTF8 ) );
	memset( s_LdapSearchCondition.sc_SearchMailAddress, '\0', sizeof( s_LdapSearchCondition.sc_SearchFirstNameUTF8 ) );
	memset( s_LdapSearchCondition.sc_SearchFirstNameUTF8, '\0', sizeof( s_LdapSearchCondition.sc_SearchFirstNameUTF8 ) );
	memset( s_LdapSearchCondition.sc_SearchLastNameUTF8, '\0', sizeof( s_LdapSearchCondition.sc_SearchLastNameUTF8 ) );
	memset( s_LdapSearchCondition.sc_SearchFaxNoUTF8, '\0', sizeof( s_LdapSearchCondition.sc_SearchFaxNoUTF8 ) );
	memset( s_LdapSearchCondition.sc_OrganizationUnitUTF8, '\0', sizeof( s_LdapSearchCondition.sc_OrganizationUnitUTF8 ) );
	memset( s_LdapSearchCondition.sc_OrganizationUTF8, '\0', sizeof( s_LdapSearchCondition.sc_OrganizationUTF8 ) );
	memset( s_LdapSearchCondition.sc_SearchCityNameUTF8, '\0', sizeof( s_LdapSearchCondition.sc_SearchCityNameUTF8 ) );
	memset( s_LdapSearchCondition.sc_SearchTelNoUTF8, '\0', sizeof( s_LdapSearchCondition.sc_SearchTelNoUTF8) );


	if( p_req->e_SearchAction.get() == OAPE_SearchAction_Single )
	{	// �P����.
		// �P�����̓���̓p�l���ƍ��킹��.
		// ������ʂ̐ݒ�.
		s_LdapSearchCondition.us_SearchType = TYPD_LdapSearchTypeName					// ����.
											| TYPD_LdapSearchTypeMailAddress			// ���[���A�h���X.
											| TYPD_LdapSearchTypeFirstName				// ��.
											| TYPD_LdapSearchTypeLastName				// ��.
											| TYPD_LdapSearchTypeFaxNo;					// �e�`�w�ԍ�.
		
		// ���������̐ݒ�( �u���́v�u���[���A�h���X�v�u���v�u���v�u�e�`�w�ԍ��v�ɑ΂��āu�O����v�v��ݒ� ).
		s_LdapSearchCondition.e_SearchNameCondition = TYPE_LdapSearchConditionFirst;				// ����.
		s_LdapSearchCondition.e_SearchMailAddressCondition = TYPE_LdapSearchConditionFirst;			// ���[���A�h���X.
		s_LdapSearchCondition.e_SearchFirstNameCondition = TYPE_LdapSearchConditionFirst;			// ��.
		s_LdapSearchCondition.e_SearchLastNameCondition = TYPE_LdapSearchConditionFirst;			// ��.
		s_LdapSearchCondition.e_SearchFaxNoCondition = TYPE_LdapSearchConditionFirst;				// �e�`�w�ԍ�.
		strncpy( s_LdapSearchCondition.sc_SearchNameUTF8, p_req->s_SearchAttributeSingle.sc_SearchString.get(), sizeof( s_LdapSearchCondition.sc_SearchNameUTF8 )-1 );			// ����.
		strncpy( s_LdapSearchCondition.sc_SearchMailAddress, p_req->s_SearchAttributeSingle.sc_SearchString.get(), sizeof( s_LdapSearchCondition.sc_SearchMailAddress )-1 );		// ���[���A�h���X.
		strncpy( s_LdapSearchCondition.sc_SearchFirstNameUTF8, p_req->s_SearchAttributeSingle.sc_SearchString.get(), sizeof( s_LdapSearchCondition.sc_SearchFirstNameUTF8 )-1 );		// ��.
		strncpy( s_LdapSearchCondition.sc_SearchLastNameUTF8, p_req->s_SearchAttributeSingle.sc_SearchString.get(), sizeof( s_LdapSearchCondition.sc_SearchLastNameUTF8 )-1 );		// ��.
		strncpy( s_LdapSearchCondition.sc_SearchFaxNoUTF8, p_req->s_SearchAttributeSingle.sc_SearchString.get(), sizeof( s_LdapSearchCondition.sc_SearchFaxNoUTF8 )-1 );			// �e�`�w�ԍ�.

		// ��������������Or��ݒ肷��.
		s_LdapSearchCondition.e_LdapSearchOption = TYPE_LdapSearchOptionOr;
	}
	else
	{	// ��������.
		// �������������ݒ�.
		if( !p_req->s_SearchAttributeMulti.e_ComplexCondition.empty() )
		{
			getCommAPIEnum( p_req->s_SearchAttributeMulti.e_ComplexCondition, s_LdapSearchCondition.e_LdapSearchOption );
		}
		else
		{	//�ȗ����ꂽ�ꍇ��And.
			s_LdapSearchCondition.e_LdapSearchOption = TYPE_LdapSearchOptionAnd;
		}
			
		// ����.
		if( !p_req->s_SearchAttributeMulti.s_Name.empty() )
		{
			s_LdapSearchCondition.us_SearchType |= TYPD_LdapSearchTypeName;
			getCommAPIEnum( p_req->s_SearchAttributeMulti.s_Name.e_SearchCondition, s_LdapSearchCondition.e_SearchNameCondition );
	 		strcpy( s_LdapSearchCondition.sc_SearchNameUTF8, p_req->s_SearchAttributeMulti.s_Name.sc_SearchString.get() );
		}
		// ���[���A�h���X.
		if( !p_req->s_SearchAttributeMulti.s_MailAddress.empty() )
		{
			s_LdapSearchCondition.us_SearchType |= TYPD_LdapSearchTypeMailAddress;
			getCommAPIEnum( p_req->s_SearchAttributeMulti.s_MailAddress.e_SearchCondition, s_LdapSearchCondition.e_SearchMailAddressCondition );
	 		strcpy( s_LdapSearchCondition.sc_SearchMailAddress, p_req->s_SearchAttributeMulti.s_MailAddress.sc_SearchString.get() );
		}
		// FaxNo.
		if( !p_req->s_SearchAttributeMulti.s_FaxNo.empty() )
		{
			s_LdapSearchCondition.us_SearchType |= TYPD_LdapSearchTypeFax;
			getCommAPIEnum( p_req->s_SearchAttributeMulti.s_FaxNo.e_SearchCondition, s_LdapSearchCondition.e_SearchFaxNoCondition );
	 		strcpy( s_LdapSearchCondition.sc_SearchFaxNoUTF8, p_req->s_SearchAttributeMulti.s_FaxNo.sc_SearchString.get() );
		}
		// ��.
		if( !p_req->s_SearchAttributeMulti.s_LastName.empty() )
		{
			s_LdapSearchCondition.us_SearchType |= TYPD_LdapSearchTypeLastName;
			getCommAPIEnum( p_req->s_SearchAttributeMulti.s_LastName.e_SearchCondition, s_LdapSearchCondition.e_SearchLastNameCondition );
	 		strcpy( s_LdapSearchCondition.sc_SearchLastNameUTF8, p_req->s_SearchAttributeMulti.s_LastName.sc_SearchString.get() );
		}
		// ��.
		if( !p_req->s_SearchAttributeMulti.s_FirstName.empty() )
		{
			s_LdapSearchCondition.us_SearchType |= TYPD_LdapSearchTypeFirstName;
			getCommAPIEnum( p_req->s_SearchAttributeMulti.s_FirstName.e_SearchCondition, s_LdapSearchCondition.e_SearchFirstNameCondition );
	 		strcpy( s_LdapSearchCondition.sc_SearchFirstNameUTF8, p_req->s_SearchAttributeMulti.s_FirstName.sc_SearchString.get() );
		}
		// �s�s��.
		if( !p_req->s_SearchAttributeMulti.s_CityName.empty() )
		{
			s_LdapSearchCondition.us_SearchType |= TYPD_LdapSearchTypeCityName;
			getCommAPIEnum( p_req->s_SearchAttributeMulti.s_CityName.e_SearchCondition, s_LdapSearchCondition.e_SearchCityNameCondition );
	 		strcpy( s_LdapSearchCondition.sc_SearchCityNameUTF8, p_req->s_SearchAttributeMulti.s_CityName.sc_SearchString.get() );
		}
		// �g�D.
		if( !p_req->s_SearchAttributeMulti.s_Organization.empty() )
		{
			s_LdapSearchCondition.us_SearchType |= TYPD_LdapSearchTypeOrganization;
			getCommAPIEnum( p_req->s_SearchAttributeMulti.s_Organization.e_SearchCondition, s_LdapSearchCondition.e_SearchOrganizationCondition );
	 		strcpy( s_LdapSearchCondition.sc_OrganizationUTF8, p_req->s_SearchAttributeMulti.s_Organization.sc_SearchString.get() );
		}
		// ����.
		if( !p_req->s_SearchAttributeMulti.s_OrganizationUnit.empty() )
		{
			s_LdapSearchCondition.us_SearchType |= TYPD_LdapSearchTypeOrganizationUnit;
			getCommAPIEnum( p_req->s_SearchAttributeMulti.s_OrganizationUnit.e_SearchCondition, s_LdapSearchCondition.e_SearchOrganizationUnitCondition );
	 		strcpy( s_LdapSearchCondition.sc_OrganizationUnitUTF8, p_req->s_SearchAttributeMulti.s_OrganizationUnit.sc_SearchString.get() );
		}
	}
	// Smime�t��������.
	if( p_req->e_Smime == OAPE_SmimeOnOff_On)
	{	// �������ڂ�SMIME��ǉ�.
		s_LdapSearchCondition.us_SearchType |= TYPD_LdapSearchTypeSmime;
		pc_SearchLdap->b_SmimeSearch = True;
	}
	else
	{
		pc_SearchLdap->b_SmimeSearch = False;
	}
	
	if( True == pc_LdapSearch->isServerConnecting() 
		|| True == pc_SearchLdap->b_Search )
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "Already LdapSearch2");
		return false;
	}
	// ���ꂩ��́ASearch�̗̈�.
	pc_SearchLdap->b_Search = True;
	// �����J�n.
		// �F�ؕ���.
	if( TYPE_LdapUserAuthenticationUserAuthentication == pc_LdapSetting->getLdapUserAuthentication()
		|| TYPE_LdapUserAuthenticationDynamicAuthentication == pc_LdapSetting->getLdapUserAuthentication() ) 
	{
		pc_LdapSearch->req_searchstart( &c_LdapSetting, &s_LdapSearchCondition, pc_SearchLdap->ans_searchstart, (short)p_req->s_ServerInfo.ss_ServerIndex.get() );	// Minerva Warning Removal. Ravi Tej modified on 15-Feb-2011.
	}
	else
	{
		pc_LdapSearch->req_searchstart( 0, &s_LdapSearchCondition, pc_SearchLdap->ans_searchstart, (short)p_req->s_ServerInfo.ss_ServerIndex.get() );	// Minerva Warning Removal. Ravi Tej modified on 15-Feb-2011.
	}
	//�R�[���o�b�N�҂�.
	_slock.wait();

	// LDAP�T�[�o�[�ؒf.
	pc_LdapSearch->req_disconnect( pc_SearchLdap->ans_disconnect );
	
	pc_SearchLdap->b_Search = False;
	
	switch( pc_SearchLdap->getSearchResult() )
	{	// ����I��.
		case TYPE_LdapSearchErrorOk:														// �ڑ�����.
			p_res->e_SearchStatus = OAPE_SearchStatus_Success;
			break;
		case TYPE_LdapSearchErrorSizeLimitExceeded:											// �������ʂ��ő�l�𒴂��܂���.
			p_res->e_SearchStatus = OAPE_SearchStatus_SizeLimitExceeded;
			break;
		case TYPE_LdapSearchErrorReferral:													// �T�[�o�[��Referral�@�\��ݒ肵�Ă��܂�.
			p_res->e_SearchStatus = OAPE_SearchStatus_Referral;
			break;
		// �ُ�I��.
		case TYPE_LdapSearchErrorInvalidCredentials:										// ���O�C���G���[.
			e.setKind(OAPE_Fault_faultcode_Client);
			e.setCodeDescription(OAPE_Result_ErrorDetails_LdapLoginError, "SearchError");
			return false;
			break;
		case TYPE_LdapSearchErrorUserCanceled:												// ���[�U�[�ɂ���ăL�����Z������܂���.
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_LdapUserCanceled, "SearchError");
			return false;
			break;
		default:
			e.setKind(OAPE_Fault_faultcode_Server);
			e.setCodeDescription(OAPE_Result_ErrorDetails_LdapOtherError, "SearchError");
			return false;
			break;
	}
	
	// �J�E���g�̃N���A.
	pc_SearchLdap->ss_BlockCount = 0;
	pc_SearchLdap->SetTotalSearchCount( pc_LdapSearch->getTotalSearchCount() );
	p_res->ss_ResultTotalNumber = pc_LdapSearch->getTotalSearchCount();
	
	if( pc_SearchLdap->b_SmimeSearch == False )
	{	// Smime����.
		GetSearchLDAPResult( pc_LdapSearch, TYPE_LdapSearchGetListTypeFirst, &(p_res->s_SearchResultList), pc_SearchLdap );
	}
	else
	{	// Sime�L��.
		GetSearchLDAPResultSmime( pc_LdapSearch, TYPE_LdapSearchGetListTypeFirst, &(p_res->s_SearchResultList), pc_SearchLdap );
	}

	//////////////////////////////////// 
	// ���ʒʒm���ʍ\���̍쐬 
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

template <> class __OAPC_TransactImp<OAPS_AppReqSearchLdapCancel> :
	public OAPC_TransactImpBaseInquiry<OAPS_AppReqSearchLdapCancel, OAPE_Result_FaultRequest_AppReqSearchLdapCancel> 
{
friend class OAPC_TransactImp<OAPS_AppReqSearchLdapCancel>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[���� 

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check( const OAPC_Memory& , OAPC_Error& );
	inline bool _authorize( const OAPC_Memory& , OAPC_Error& );
	inline bool _execute( const OAPC_Memory& , OAPC_Memory& , OAPC_Error& );
};

OAPD_TRANSACT_HANDLING(AppReqSearchLdapCancel);

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqSearchLdapCancel)

	e.setKind(OAPE_Fault_faultcode_Client);

	if( p_req->s_OperatorInfo.empty() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo" );
		return false;
	}

	if( !p_req->s_OperatorInfo.check() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo" );
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqSearchLdapCancel)

	if (!p_req->s_OperatorInfo.empty()) 
	{
		int authority = 0;
		OAPC_ApiLock<OAPC_AuthManager> p_authmanager( &_authmanager, &_slock );
		OAPC_AuthManager::OAPE_State e_state = p_authmanager->getStatus();
		if ( OAPC_AuthManager::OAPE_State_Auth        ==e_state ||
			OAPC_AuthManager::OAPE_State_AuthAndTrack==e_state ||
			OAPC_AuthManager::OAPE_State_Track==e_state) 
		{
			authority = OAPE_UserType_User|OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
		}
		else
		{
			authority = OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
		}

		//////////////////////////////////// 
		// �I�y���[�^�[���O�C��.
		OAPC_User op(p_req->s_OperatorInfo, authority);
		if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
		{
			return false;
		}
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqSearchLdapCancel, AppResSearchLdapCancel)

	OAPD_TRACE_SCOPE( "AppReqSearchLdapCancel" );

	///////////////////.
	//IF Lock.
	OAPC_ApiLock<APIC_LdapSearch> pc_LdapSearch( APIC_LdapSearch::newInstanceAdmin(), &_slock );

	OAPC_SearchLdap* pc_SearchLdap = OAPC_SearchLdap::getInstance(); 

	// �C���X�^���X�`�F�b�N
	if(!pc_LdapSearch || !pc_SearchLdap)
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}
	
	// LDAP�T�[�o�ڑ���Ԋm�F.
	if( True != pc_LdapSearch->isServerConnecting())
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "No LdapSearch");
		return false;
	}
	
	pc_SearchLdap->setLockCancel(_slock);
	// Cancel�v��.
	pc_LdapSearch->req_cancel(pc_SearchLdap->ans_cancel);
	
	//�R�[���o�b�N�҂�. 
	_slock.wait();
	
	TYPE_LdapCancelError ret = pc_SearchLdap->getCancelResult();

	if( ret != TYPE_LdapCancelErrorOk )
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralOutOfTiming, "CancelError");
		return false;
	}
	
	////////////////////////////////////.
	// ���ʒʒm���ʍ\���̍쐬.
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE

template <> class __OAPC_TransactImp<OAPS_AppReqGetLdapResultList> :
	public OAPC_TransactImpBaseInquiry<OAPS_AppReqGetLdapResultList, OAPE_Result_FaultRequest_AppReqGetLdapResultList> 
{
friend class OAPC_TransactImp<OAPS_AppReqGetLdapResultList>;
private:
	OAPC_AuthManager _authmanager;	// �F�؃}�l�[�W���[����.

	__OAPC_TransactImp() {}
	~__OAPC_TransactImp() {}
	
	inline OAPE_Response _response() const;
	inline bool _pre_check( const OAPC_Memory& , OAPC_Error& );
	inline bool _authorize( const OAPC_Memory& , OAPC_Error& );
	inline bool _execute( const OAPC_Memory& , OAPC_Memory& , OAPC_Error& );
};

OAPD_TRANSACT_HANDLING(AppReqGetLdapResultList);

OAPD_BEGIN_TRANSACT_PRECHECK(AppReqGetLdapResultList)

	e.setKind(OAPE_Fault_faultcode_Client);

	if( p_req->s_OperatorInfo.empty() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "OperatorInfo" );
		return false;
	}

	if( !p_req->s_OperatorInfo.check() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralCombinationUnmatch, "OperatorInfo" );
		return false;
	}

	if( p_req->e_ListType.empty() )
	{
		e.setCodeDescription( OAPE_Result_ErrorDetails_GeneralTagMissing, "ListType" );
		return false;
	}

OAPD_END_TRANSACT_PRECHECK

OAPD_BEGIN_TRANSACT_AUTHORIZE(AppReqGetLdapResultList)

	if (!p_req->s_OperatorInfo.empty()) 
	{
		int authority = 0;
		OAPC_ApiLock<OAPC_AuthManager> p_authmanager( &_authmanager, &_slock );
		OAPC_AuthManager::OAPE_State e_state = p_authmanager->getStatus();
		if ( OAPC_AuthManager::OAPE_State_Auth        ==e_state ||
			OAPC_AuthManager::OAPE_State_AuthAndTrack==e_state ||
			OAPC_AuthManager::OAPE_State_Track==e_state) 
		{
			authority = OAPE_UserType_User|OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
		}
		else
		{
			authority = OAPE_UserType_Public|OAPE_UserType_Admin|OAPE_UserType_BoxAdmin|OAPE_UserType_System;
		}

		//////////////////////////////////// 
		// �I�y���[�^�[���O�C��.
		OAPC_User op(p_req->s_OperatorInfo, authority);
		if (!op.authCheck(TYPD_UserFunctionMask_None, e)) 
		{
			return false;
		}
	}

OAPD_END_TRANSACT_AUTHORIZE

OAPD_BEGIN_TRANSACT_EXECUTE(AppReqGetLdapResultList, AppResGetLdapResultList)

	OAPD_TRACE_SCOPE( "AppReqGetLdapResultList" );

	// CommonApi����I�u�W�F�N�g�擾.
	OAPC_ApiLock<APIC_LdapSearch> pc_LdapSearch( APIC_LdapSearch::newInstanceAdmin(), &_slock );

	// �C���X�^���X�̎擾���ł��Ȃ������ꍇ��Fault��Ԃ�.
	if( !pc_LdapSearch ) 
	{
		e.setKind(OAPE_Fault_faultcode_Server);
		e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralAllocateBufferFull, "Failed to get instance");
		return false;
	}
	OAPC_SearchLdap* pc_SearchLdap = OAPC_SearchLdap::getInstance(); 

	switch( p_req->e_ListType.get() )
	{
		case OAPE_SearchListType_Next:
			// ���X�g���I�[�o�[���Ȃ��悤�Ɋm�F.
			if( !pc_SearchLdap->ListNext( pc_LdapSearch ) )
			{
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "ListType");
				return false;
			}
			break;
		case OAPE_SearchListType_Previous:
			// �ő�200���O�ɖ߂�.
			if( !pc_SearchLdap->ListPrevious( pc_LdapSearch ) )
			{
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "ListType");
				return false;
			}
			break;
		case OAPE_SearchListType_Current:
			// �ő�100���O�ɖ߂�.
			if( !pc_SearchLdap->ListCurrent( pc_LdapSearch ) )
			{
				e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "ListType");
				return false;
			}
			break;
		case OAPE_SearchListType_First:
		default:
			e.setCodeDescription(OAPE_Result_ErrorDetails_GeneralIllegalValue , "ListType");
			return false;
			break;
	}

	if( pc_SearchLdap->b_SmimeSearch == False )
	{	// Smime����.
		GetSearchLDAPResult( pc_LdapSearch, TYPE_LdapSearchGetListTypeNext, &(p_res->s_SearchResultList), pc_SearchLdap );
	}
	else
	{	// Sime�L��.
		GetSearchLDAPResultSmime( pc_LdapSearch, TYPE_LdapSearchGetListTypeNext, &(p_res->s_SearchResultList), pc_SearchLdap );
	}
	////////////////////////////////////.
	// ���ʒʒm���ʍ\���̍쐬.
	p_res->s_Result.set();

OAPD_END_TRANSACT_EXECUTE
*/
// ZesuMLK ����\���ύX_�g�p���Ă��郁�����ʂ̍팸���s�� Senthil 2012/04/09 Commented END. 
// GaiaFUM LDAP���� matsuda 2009/07/24 END.
