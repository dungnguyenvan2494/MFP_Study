//�N���X-----------------------------------------------------------------------------------------------------------------.
// �t�@�C�� : CHOP_A0R2220110_EXT_Web�u���E�U�[�X�L�����A�g_���M_�����F���ݒ�.
// Version  : PD ver.012.
//-----------------------------------------------------------------------------------------------------------------------.
#define	SIZE( table )	( sizeof( table ) / sizeof( PDisplayParts* ) )
#include <panel/plibh/plibh_CLCD2/PNLC_StackManJobSpec.h>
#include <panel/plibh/plibhg/pdpcomb.h>
#include <panel/ppcg/ppcg_PD/ppcg_PD.h>
#include <panel/plibh/plibh_CLCD2/PNLC_BoxDataKeyControlLib.h>
#include <panel/pcgact/pcgact_CLCD2/pigact_pA070500.h>
#include <panel/pcgbox/pcgbox_CLCD2/pigbox_base.h>
#include <panel/pcgbrowser_ext/pcgbrowser_ext_PD/pcgbrowser_A0R2220110_EXT.h>
#ifdef DEF_LCD_7INCH
#include "PD/A0R2220110_EXT_7inch.cpp"
#else
#include "PD/A0R2220110_EXT.cpp"
#endif // DEF_LCD_7INCH.
//PanelDesigner�Ή�------------------------------------------------------------------------------------------------------.
// ��ʊJ�n����.
void PA0R2220110_EXT::startGamen()
{
	bl_PanelDesigner = True;																										// PanelDesigner�Ή�.
	PCGC_ScanFaxReadSetDetailComLib::startGamen();																					// �e�N���X�ďo��(������s��Ȃ���PopupWindow���\�����Ȃ�).
// �R�[���o�b�N�֐��̓o�^.
	ATTACH_OBSERVER( PA0R2220110_EXT, gp_A0R2220110_EXT, PA0R2220110_EXT::prOnOff, A0R2220110_EXT_Rbt1001, Bool, short );			// ON/OFF.
	ATTACH_OBSERVER( PA0R2220110_EXT, gp_A0R2220110_EXT, PA0R2220110_EXT::prLanguage, A0R2220110_EXT_Rbt1002, Bool, short );		// ����I��.
	ATTACH_OBSERVER( PA0R2220110_EXT, gp_A0R2220110_EXT, PA0R2220110_EXT::prOutputKindDOCX, A0R2220110_EXT_Rbt1003, Bool, short );	// �o�͌`��(DOCX).
	ATTACH_OBSERVER( PA0R2220110_EXT, gp_A0R2220110_EXT, PA0R2220110_EXT::prOutputKindXLSX, A0R2220110_EXT_Rbt1004, Bool, short );	// �o�͌`��(XLSX).
	ATTACH_OBSERVER( PA0R2220110_EXT, gp_A0R2220110_EXT, PA0R2220110_EXT::prRotationCorrect, A0R2220110_EXT_Btn0009, Bool, Bool );	// ��]�␳.
	ATTACH_OBSERVER( PA0R2220110_EXT, gp_A0R2220110_EXT, PA0R2220110_EXT::prOk, A0R2220110_EXT_Btn0007, Bool, Bool );				// OK.
	ATTACH_OBSERVER( PA0R2220110_EXT, gp_A0R2220110_EXT, PA0R2220110_EXT::prCancel, A0R2220110_EXT_Btn0005, Bool, Bool );			// �L�����Z��.
	setOkButtonForFunctionBadge( &A0R2220110_EXT_Btn0007 ); // �@�\�o�b�`�{�^���������ɑ�ւ��������s���n�j�L�[��o�^.
// �ϐ����̏������������L�ڂ���.
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	TYPE_LanguageOcr e_LanguageOcr[ TYPD_LanguageListNum ];																			//	�I���\����̎擾�̈�̏�����.
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {
		e_LanguageOcr[ i ] = TYPE_LanguageOcrNone;
	}
	PnlComGetSearchablePDFSetting()->getDownloadCompLangList( e_LanguageOcr );														//	�I���\����̎擾.
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {																					//	��ʑ��̈�e�[�u���̏�����.
		m_pst_LangTbl[ i ] = NULL;
	}
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {
		if ( e_LanguageOcr[ i ] == TYPE_LanguageOcrNone ) {
			continue;
		}
		for( short j = 0; j < us_SearchableLanguageIdSize; j++ ) {
			if( st_SearchableLanguageId[ j ].e_Language == e_LanguageOcr[ i ] ) {
				m_pst_LangTbl[ i ] = const_cast<struct PNLS_SearchableLanguage*>( &st_SearchableLanguageId[ j ] );
			}
		}
	}
	m_bl_Backup = False;
// �����ɍ\���ɂ��\���������L�ڂ���.
	static COnOffButtonObjectAdd* const tbl_LanguageButton[] = { &A0R2220110_EXT_Btn0017, &A0R2220110_EXT_Btn0019, &A0R2220110_EXT_Btn0021, &A0R2220110_EXT_Btn0023, &A0R2220110_EXT_Btn0025, &A0R2220110_EXT_Btn0027, &A0R2220110_EXT_Btn0029, &A0R2220110_EXT_Btn0031, &A0R2220110_EXT_Btn0033, };
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {																					//	����L�[�̕\��/��\��.
		if ( NULL == m_pst_LangTbl[ i ] ) {
			tbl_LanguageButton[ i ]->showEnable( False );
		} else {
			tbl_LanguageButton[ i ]->showEnable( True );
			tbl_LanguageButton[ i ]->changeText( m_pst_LangTbl[ i ]->us_TextId );
		}
	}
	Bool b_SelectionList = True;
	b_SelectionList = ScanOapExtSet.isEnableOCRLanguageType( TYPE_ExtLangJapanese );
	if( True != b_SelectionList ) {
		tbl_LanguageButton[ 5 ]->showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCRLanguageType( TYPE_ExtLangEnglish );
	if( True != b_SelectionList ) {
		tbl_LanguageButton[ 0 ]->showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCRLanguageType( TYPE_ExtLangFrench );
	if( True != b_SelectionList ) {
		tbl_LanguageButton[ 1 ]->showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCRLanguageType( TYPE_ExtLangItaly );
	if( True != b_SelectionList ) {
		tbl_LanguageButton[ 2 ]->showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCRLanguageType( TYPE_ExtLangGerman );
	if( True != b_SelectionList ) {
		tbl_LanguageButton[ 3 ]->showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCRLanguageType( TYPE_ExtLangSpanish );
	if( True != b_SelectionList ) {
		tbl_LanguageButton[ 4 ]->showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCRLanguageType( TYPE_ExtLangChinese );
	if( True != b_SelectionList ) {
		tbl_LanguageButton[ 6 ]->showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCRLanguageType( TYPE_ExtLangTaiwanese );
	if( True != b_SelectionList ) {
		tbl_LanguageButton[ 7 ]->showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCRLanguageType( TYPE_ExtLangKorean );
	if( True != b_SelectionList ) {
		tbl_LanguageButton[ 8 ]->showEnable( False );
	}
//comment2021/04/16 Sky���c[IT6_2.2][OP_BTS-30704]PPTX�I�����o�͌`����I���ł���悤�ɏC��.
	A0R2220110_EXT_Rbt1003.showEnable( False );																						// �o�͌`��(DOCX,PPTX).
	A0R2220110_EXT_Rbt1004.showEnable( False );																						// �o�͌`��(XLSX).
	A0R2220110_EXT_Gra0004.showEnable( True );	A0R2220110_EXT_Txt0045.showEnable( True );
	switch( pc_Send->c_ComSend.getFileFormat() ) {
		case TYPE_FileFormatDOCX:	A0R2220110_EXT_Rbt1003.showEnable( True );	break;												// �o�͌`��(DOCX).
		case TYPE_FileFormatXLSX:	A0R2220110_EXT_Rbt1004.showEnable( True );	break;												// �o�͌`��(XLSX).
//comment2021/04/16 Sky���c[IT6_2.2][OP_BTS-30704]PPTX�I�����o�͌`����I���ł���悤�ɏC��.
		case TYPE_FileFormatOfficeOpenXML:																							// �o�͌`��(PPTX).
			A0R2220110_EXT_Rbt1003.showEnable( True );
			A0R2220110_EXT_Btn0035.showEnable( False );
			break;
		default:					A0R2220110_EXT_Gra0004.showEnable( False );	A0R2220110_EXT_Txt0045.showEnable( False );	break;
	}
	b_SelectionList = ScanOapExtSet.isEnableOCROutputMethodType( TYPE_ExtOCRTextPriority );
	if( True != b_SelectionList ) {
		A0R2220110_EXT_Btn0035.showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCROutputMethodType( TYPE_ExtOCRImagePriority );
	if( True != b_SelectionList ) {
		A0R2220110_EXT_Btn0037.showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCROutputMethodType( TYPE_ExtImageAndText );
	if( True != b_SelectionList ) {
		A0R2220110_EXT_Btn0041.showEnable( False );
		A0R2220110_EXT_Btn0039.showEnable( False );
	}
	b_SelectionList = ScanOapExtSet.isEnableOCROutputMethodType( TYPE_ExtTextOnly );
	if( True != b_SelectionList ) {
		A0R2220110_EXT_Btn0043.showEnable( False );
	}
// �����ɉ�ʂ̏������������L�ڂ���.
	A0R2220110_EXT_Rbt1001.setN( ( True == c_OfficeOpenXml.getOcrOn() ) ? 0 : 1, True );
	A0R2220110_EXT_Cmp1000.setNowPopupGamen( PNLE_BoxCharacterRecognition );
	setupGamenAtButtonOn();																											// �{�^���n�m���̕\�����i�̃Z�b�g�A�b�v.
}
// �{�^���n�m���̕\�����i�̃Z�b�g�A�b�v.
void PA0R2220110_EXT::setupGamenAtButtonOn()
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	A0R2220110_EXT_Rbt1002.setN( -1 );																								// ����I��.
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {
		if( NULL == m_pst_LangTbl[ i ] ) {
			continue;
		}
		if( m_pst_LangTbl[ i ]->e_Language == c_OfficeOpenXml.getLanguage() ) {
			A0R2220110_EXT_Rbt1002.setN( i );																						// ����I��.
			break;
		}
	}
	switch( c_OfficeOpenXml.getOutPutFormat() ) {																					// �o�͌`���̑I��\��.
		case TYPE_OutPutFormat_Text_Priority:	A0R2220110_EXT_Rbt1003.setN( 0 );	A0R2220110_EXT_Rbt1004.setN( -1 );				//	�����D��.
//comment2021/04/16 Sky���c[IT6_2.2][OP_BTS-30704]PPTX�I�����o�͌`����I���ł���悤�ɏC��.
			if(TYPE_FileFormatOfficeOpenXML == pc_Send->c_ComSend.getFileFormat()){
				A0R2220110_EXT_Rbt1003.setN( -1 );
			}
			break;
		case TYPE_OutPutFormat_Image_Priority:	A0R2220110_EXT_Rbt1003.setN( 1 );	A0R2220110_EXT_Rbt1004.setN( -1 );	break;		//	�摜�D��.
		case TYPE_OutPutFormat_Image_Text:		A0R2220110_EXT_Rbt1003.setN( 2 );	A0R2220110_EXT_Rbt1004.setN( 0 );	break;		//	�摜�ƕ���.
		case TYPE_OutPutFormat_Text:			A0R2220110_EXT_Rbt1003.setN( -1 );	A0R2220110_EXT_Rbt1004.setN( 1 );	break;		//	�����̂�.
	}
	A0R2220110_EXT_Btn0009.setN( c_OfficeOpenXml.getRotationCorrection() );															//	�␳����E���Ȃ��L�[.
}
// ON/OFF.
Bool PA0R2220110_EXT::prOnOff( short n )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	if( n == 0 ) {
		if( False == setOfficeOpenXmlOn( pc_JobFax, m_pst_LangTbl, &m_c_OfficeOpenXml, m_bl_Backup ) ) {					// OCR�����F���̐ݒ��On�ɂ���.
			return	False;
		}
	} else {
		m_bl_Backup = True;																											// ��ʕ\������On����Off�ւ̐ؑւ����s��ꂽ�����L�^���Ă���.
		m_c_OfficeOpenXml = c_OfficeOpenXml;																						// �ݒ�On����OfficeOpenXML�f�[�^��ۑ�.
		cancel( CNK_OCRSetting, CNK_Size, pc_JobFax );																		// OCR�����F���ݒ��Off.
	}
	return	True;
}
// ����I��.
Bool PA0R2220110_EXT::prLanguage( short n )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	c_OfficeOpenXml.setLanguage( m_pst_LangTbl[ n ]->e_Language );
	pc_Send->setOfficeOpenXml( c_OfficeOpenXml );
	return	True;
}
// �o�͌`��(DOCX).
Bool PA0R2220110_EXT::prOutputKindDOCX( short n )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	switch( n ) {
		case 0:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Text_Priority );		break;										// �����D��.
		case 1:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Image_Priority );	break;										// �摜�D��.
		case 2:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Image_Text );		break;										// �摜�ƕ���.
	}
	pc_Send->setOfficeOpenXml( c_OfficeOpenXml );
	return	True;
}
// �o�͌`��(XLSX).
Bool PA0R2220110_EXT::prOutputKindXLSX( short n )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	switch( n ) {
		case 0:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Image_Text );	break;											//	�摜�ƕ���.
		case 1:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Text );			break;											//	����.
	}
	pc_Send->setOfficeOpenXml( c_OfficeOpenXml );
	return	True;
}
// ��]�␳.
Bool PA0R2220110_EXT::prRotationCorrect( Bool on )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	c_OfficeOpenXml.setRotationCorrection( on );
	pc_Send->setOfficeOpenXml( c_OfficeOpenXml );
	return	True;
}
// OK.
Bool PA0R2220110_EXT::prOk( Bool on )
{
	procOkSetup();																													//	�ݒ�I�����ʏ���.
	return	True;
}
// �L�����Z��.
Bool PA0R2220110_EXT::prCancel( Bool on )
{
	PNLC_StackManJobSpec::newInstance()->rollbackJobSpec();																			//	�ݒ�����ɖ߂�.
	return	True;
}
//�]������(��ʊO����)---------------------------------------------------------------------------------------------------.
//	�\�����i�̃Z�b�g�A�b�v.
void PA0R2220110_EXT::setupGamen( short option )
{
	PCGC_ScanFaxReadSetDetailComLib::setupGamen( option );
	printLEDControl( False );
}
//	�X�^�[�g.
void PA0R2220110_EXT::procStart( uchar option )
{
	const TYPS_ExtRegistration* pc_Application = ScanOapExtSet.getApplication();
	if( ( True == ScanOapExtSet.isActiveGeneralApplication() ) && ( NULL !=  pc_Application ) && ( TYPE_ExtTypeScanD == pc_Application->s_Version.e_Type ) ) {		// OpenAPI�X�L�����A�v��(Tyde-D)�g�p��.
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	}
	onlyPanel.checkWarningAdminMachineForBox( PnlComGetJobScan( PCGE_JobPutJBLBox ) );												// �����Ǘ����u�������x�����䏈��.
	if( True == printStartDisable() ) {																								//	�X�^�[�g�L�[�A���o�[�̎��͎󂯕t���Ȃ�.
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	}
	procOkSetup();																													//	�ݒ�I�����ʏ���.
	if( &gp_BoxDocKeepUSBMemory_box == PBasicMessageProc::getNowGamen() ) {															// �O���������ւ̕ۑ���.
		PNLC_BoxDataKeyControlLib::newInstance()->procStartBoxDocKeepUSBMemory();													// �O���������ւ̕ۑ��X�^�[�g.
	}else if( &gp_DocKeepUSBMemoryExport_box == PBasicMessageProc::getNowGamen() ) {												// �{�b�N�X����O����������.
		if( True == onlyPanel.isWarningOn( PnlComGetJobScan( PCGE_JobPutJBLBox ), PNL_ERROR_NoFrequency_Box ) || True == onlyPanel.isWarningOn( PnlComGetJobScan( PCGE_JobPutJBLBox ), PNL_ERROR_CardUnset_Box ) || True == onlyPanel.isWarningOn( PnlComGetJobScan( PCGE_JobPutJBLBox ), PNL_ERROR_AdminMachinePowerSupply_Box ) || True == onlyPanel.isWarningOn( PnlComGetJobScan( PCGE_JobPutJBLBox ), PNL_ERROR_AdminMachineRestrictedFunction_Box ) ) {		// �Ǘ����u�x���Ȃ��`�F�b�N.// �Ǘ��J�[�h���}���`�F�b�N.// �Ǘ����u�d���m�F�x���`�F�b�N.// �@�\���g�p�ݒ�F�g�p�֎~�`�F�b�N.
			return;																													//�����Ǘ����u�̌x�����������Ă���ꍇ�́A�֐��I��.
		}
		gp_USBMemoryExport_actExport.startWait();
		if( False == printStartDisable() ) {
			PNLC_PopupListControl::newInstance()->addPopup( &gp_USBMemoryExport_actExport, this, NULL, 360, 216, 80, 48 );			// ����ʂ��������g�ɐݒ肷��.
		} else {
			setBuzzerType( PCGE_BuzzerType_InputNg );																				// �J�n�s�\ �u�U�[��.
		}
	} else if( &gp_DocKeep_box == PBasicMessageProc::getNowGamen() ) {																// �{�b�N�X�֕ۑ�.
		PNLC_BoxDataKeyControlLib::newInstance()->procStartBoxDocKeep();															// �����ۑ�.
	} else {
		PNLC_BoxDataKeyControlLib::newInstance()->procStartDocNetSendNetSend( option );												// ���M�X�^�[�g.
	}
}
//��ʌŗL����-----------------------------------------------------------------------------------------------------------.
//	�ݒ�I�����ʓ����ݒ菈��.
void PA0R2220110_EXT::procOkSetup()
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	if( False == pc_Send->getOfficeOpenXml().getOcrOn() ) {
		cancel( CNK_OCRSetting, CNK_Size, pc_JobFax );
	}
}
