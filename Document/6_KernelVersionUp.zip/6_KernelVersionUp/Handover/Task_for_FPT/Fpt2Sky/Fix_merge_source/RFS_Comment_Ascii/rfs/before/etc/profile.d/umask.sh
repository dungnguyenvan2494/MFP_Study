umask 022
