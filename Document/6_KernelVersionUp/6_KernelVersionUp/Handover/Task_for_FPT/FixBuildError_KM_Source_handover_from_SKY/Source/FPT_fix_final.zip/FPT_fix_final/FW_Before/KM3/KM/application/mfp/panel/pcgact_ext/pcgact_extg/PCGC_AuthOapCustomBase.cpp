//------------------------------------------------------------------------------
/**
 * @file  : PCGC_AuthOapCustomBase.cpp.
 * @brief : ���ʃN���X��`.
 */
//------------------------------------------------------------------------------
#include "PCGC_AuthOapCustomBase.h"
#include <panel/pcgcom_ext/pcgcom_extg/PCGC_AuthOapCtrlCom.h>
#include <panel/pcgcom_ext/pcgcom_extg/PCGC_AuthOapCommonStaticLib.h>
#include <panel/pcgcom_ext/pcgcom_extg/PCGC_AuthOapCtrlMngLogin.h>
#include <panel/pcgcom_ext/pcgcom_extg/PCGC_AuthOapCtrlMngExtension.h>
#include <panel/pcgact_ext/pcgact_ext_CLCD2/pigact_pA070700.h>
#include <panel/pcgact_ext/pcgact_ext_CLCD2/pigact_pA070701_ext.h>
#include <panel/plibh/plibh_CLCD/plibh_CLCD1.h>
#include <panel/plibh/plibhg/plibh.h>
#include <panel/pcgcom/pcgcom_CLCD2/PNLC_PopupListControl.h>
// Old path for Dynamic control selection screens.
// These are not found in Overall control specifications.
#include <panel/pcgauthoap/pcgauthoap_CLCD/pigauthoap3_CLCD.h>
// comment 2020/07/14 SCD2-Sky �Ό� [IT6_2.0MR2][OP_BTS-25362] �t�b�^�[�G���A�Ή�.
#include <panel/plibh/plibh_CLCD2/plibh_CLCD2.h>

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�R���X�g���N�^.
// Return Value					: .
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
PCGC_AuthOapCustomBase::PCGC_AuthOapCustomBase( PDisplayParts** partsTable, short partsNumber, Bool isNoWarningGamen )	 // �R���X�g���N�^.
	: PCGC_AuthOapCommonBase( partsTable, partsNumber, isNoWarningGamen )
{
	for( uint CtrlSize=0; CtrlSize<sizeof( cControl ) / sizeof( PCGC_AuthOapAbstractControl* ); CtrlSize++ ) {
		cControl[CtrlSize] = NULL;
	}
	scActiveCtrlNo = -1;
	cCtrlMng = NULL;
	ucMaxInfo = 0;
	bDefaultSet = True;
	ucTopInfoNo = 0;
	bDirectInput = False;
	bErrInput = False;
	ucNowPage = 1;				// �\�����̃y�[�W�ԍ�.
	ucTotalPage = 1;			// �S�y�[�W��.
	bUpdateIcon = False;
	s_ctrlInfoBuf.dataType = 0;
	memset( s_ctrlInfoBuf.string, '\0', sizeof( s_ctrlInfoBuf.string ) );
	s_ctrlInfoBuf.numeric = 0;
	s_ctrlInfoBuf.select = False;
	s_ctrlInfoBuf.selList.num = 0;
	for( uchar i = 0; i < PNLD_AOSL_MaxListNum; i++ ) {
		memset( s_ctrlInfoBuf.selList.select[i].ID, '\0', sizeof( s_ctrlInfoBuf.selList.select[i].ID ) );
		memset( s_ctrlInfoBuf.selList.select[i].name, '\0', sizeof( s_ctrlInfoBuf.selList.select[i].name ) );
	}

	s_ctrlInfoBuf.dateTime.s_Value.ss_Year = 0;
	s_ctrlInfoBuf.dateTime.s_Value.sc_Month = 0;
	s_ctrlInfoBuf.dateTime.s_Value.sc_Day = 0;
	s_ctrlInfoBuf.dateTime.s_Value.sc_Hour = 0;
	s_ctrlInfoBuf.dateTime.s_Value.sc_Minute = 0;
	s_ctrlInfoBuf.dateTime.e_Display = TYPE_ExtDateTimeDisplayYMDHM;
	s_ctrlInfoBuf.dateTime.e_Default = TYPE_ExtDateTimeDefaultNone;
	s_ctrlInfoBuf.bDirectInput = False;
	memset( s_ScreenBuf.sc_ID, '\0', sizeof( s_ScreenBuf.sc_ID ) );
	memset( s_ScreenBuf.sc_Message, '\0', sizeof( s_ScreenBuf.sc_Message ) );
	s_ScreenBuf.e_Type = TYPE_ExtScreenTypeJobTicket;
	s_ScreenBuf.s_LinkButtonList.sc_Count = 0;
	for( i = 0; i < sizeof( s_ScreenBuf.s_LinkButtonList.s_LinkButton ) / sizeof( TYPS_ExtLinkButton ); i++ ) {
		memset( s_ScreenBuf.s_LinkButtonList.s_LinkButton[i].sc_ID, '\0', sizeof( s_ScreenBuf.s_LinkButtonList.s_LinkButton[i].sc_ID ) );
		memset( s_ScreenBuf.s_LinkButtonList.s_LinkButton[i].sc_Name, '\0', sizeof( s_ScreenBuf.s_LinkButtonList.s_LinkButton[i].sc_Name ) );
		s_ScreenBuf.s_LinkButtonList.s_LinkButton[i].e_Entry = TYPE_ExtLinkButtonDisable;
	}
	s_ScreenBuf.s_JobTicket.e_Type = TYPE_ExtListTypeLarge;
	s_ScreenBuf.s_Category.e_Type = TYPE_ExtListTypeLarge;
	s_ScreenBuf.s_Directory.e_Type = TYPE_ExtListTypeLarge;
	memset( s_ScreenBuf.s_Directory.s_DynamicLinkButton.sc_ID, '\0', sizeof( s_ScreenBuf.s_Directory.s_DynamicLinkButton.sc_ID ) );
	memset( s_ScreenBuf.s_Directory.s_DynamicLinkButton.sc_Name, '\0', sizeof( s_ScreenBuf.s_Directory.s_DynamicLinkButton.sc_Name ) );
	s_ScreenBuf.s_Directory.s_DynamicLinkButton.e_Entry = TYPE_ExtLinkButtonDisable;
	s_ScreenBuf.s_FileList.e_Type = TYPE_ExtListTypeLarge;
	memset( s_ScreenBuf.s_FileList.s_Custom.sc_ID, '\0', sizeof( s_ScreenBuf.s_FileList.s_Custom.sc_ID ) );
	s_ScreenBuf.s_FileList.s_Custom.e_ValidType = TYPE_ExtCustomValidTypeNone;
	memset( s_ScreenBuf.s_FileList.s_Custom.sc_ButtonName, '\0', sizeof( s_ScreenBuf.s_FileList.s_Custom.sc_ButtonName ) );
	s_ScreenBuf.s_FileList.s_Custom.e_InterLock = TYPE_ExtInterLockEnable;
	s_ScreenBuf.s_FileList.s_Custom.s_Icon.sc_No = 0;
	memset( s_ScreenBuf.s_FileList.s_DynamicLinkButton.sc_ID, '\0', sizeof( s_ScreenBuf.s_FileList.s_DynamicLinkButton.sc_ID ) );
	memset( s_ScreenBuf.s_FileList.s_DynamicLinkButton.sc_Name, '\0', sizeof( s_ScreenBuf.s_FileList.s_DynamicLinkButton.sc_Name ) );
	s_ScreenBuf.s_FileList.s_DynamicLinkButton.e_Entry = TYPE_ExtLinkButtonDisable;
	s_ScreenBuf.s_FileList.s_DeleteButton.e_Entry = TYPE_ExtButtonDisplayInvisible;
	s_ScreenBuf.s_FileList.s_SelectAllButton.e_Entry = TYPE_ExtLinkButtonDisable;
	s_ScreenBuf.s_FileList.s_FileLinkButton.e_Entry = TYPE_ExtLinkButtonDisable;
	s_ScreenBuf.s_PollingInfo.uc_Interval = 0;
	memset( s_ScreenBuf.s_Authentication.sc_Title, '\0', sizeof( s_ScreenBuf.s_Authentication.sc_Title ) );
	memset( s_ScreenBuf.s_Authentication.s_Custom.sc_ID, '\0', sizeof( s_ScreenBuf.s_Authentication.s_Custom.sc_ID ) );
	s_ScreenBuf.s_Authentication.s_Custom.e_ValidType = TYPE_ExtCustomValidTypeNone;
	memset( s_ScreenBuf.s_Authentication.s_Custom.sc_ButtonName, '\0', sizeof( s_ScreenBuf.s_Authentication.s_Custom.sc_ButtonName ) );
	s_ScreenBuf.s_Authentication.s_Custom.e_InterLock = TYPE_ExtInterLockEnable;
	s_ScreenBuf.s_Authentication.s_Custom.s_Icon.sc_No = 0;

	memset( s_CustomValueInfoBuf.sc_ID, '\0', sizeof( s_CustomValueInfoBuf.sc_ID ) );
	s_CustomValueInfoBuf.sc_ValueListList.sc_Count = 0;
	for( i = 0; i < sizeof( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList ) / sizeof( TYPS_ExtValueListFull ); i++ ) {
		memset( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].sc_ID, '\0', sizeof( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].sc_ID ) );
		s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].sc_Count = 0;
		for( uchar j = 0; j < sizeof( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].s_Value ) / sizeof( TYPS_ExtValue ) ; j++ ) {
			memset( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].s_Value[j].sc_Value, '\0', sizeof( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].s_Value[j].sc_Value ) );
		}
	}
	s_MultiStrResultBuf.num = 0;
	for( i = 0; i < PNLD_AOSL_MaxListNum; i++ ) {
		memset( s_MultiStrResultBuf.strList[i].str, '\0', sizeof( s_MultiStrResultBuf.strList[i].str ) );
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:��ʊJ�n����.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::startGamen()
{
	PCGC_AuthOapCommonBase::startGamen();

	// �L�����Z����t[�s��]�ݒ�.
	PCGC_AuthOapAPIAccess::getExtSettingAPI()->setCancelReceiveStatus( TYPE_ExtCancelReceiveStatusNG );

	// �R���g���[�����̏�����.
	clrControl();
	// ---------------------------------------------------------------------------
	// �S�y�[�W���Z�o.
	// ---------------------------------------------------------------------------
	char scCtrlNumBuf = cCtrlMng->getAuthControlNum();
	if( ( scCtrlNumBuf <= 0 ) || ( ucMaxInfo == 0 ) ) {
		ucTotalPage = 1;
	} else {
		ucTotalPage = ( uchar )( ( ( scCtrlNumBuf - 1 ) / ucMaxInfo ) + 1 );
	}
	// ---------------------------------------------------------------------------

	if( PNLE_MTUIMODE_V1 <= PLBC_MultiTouchFunction::getMultiTouchMode() ) {
		ucNowPage = 1;
	} else {
		// �R���g���[������5�ȏ�̏ꍇ.
		if( cCtrlMng->getControlNum() > PNLD_AOL_InfoNumPerPage ) {
			// �P�y�[�W�ɕ\�����郍�O�C����ʂ̏�񍀖ڐ���5�̏ꍇ.
			if( cCtrlMng->getDisplayControl() == PNLD_AOL_InfoNumPerPage && cCtrlMng->getDisplayFlg() == True ) {
				cCtrlMng->setDisplayFlg( False );
				ucNowPage = 1;																		// ���݂̃y�[�W��1�y�[�W�ڂ�ݒ�.
				TYPC_ExtCurrentInfo* pc_currInfo = PCGC_AuthOapAPIAccess::getCurrentInfoAPI();		// �J�����g���擾.
				if( pc_currInfo != NULL ) {
					TYPS_ExtControl* ps_Control = pc_currInfo->getDisplayControl();					// �\���R���g���[��ID�擾
					// �R���g���[��ID����������.
					uchar i;
					for( i=0; i<cCtrlMng->getControlNum(); i++ ) {
						if( strcmp( ps_Control->sc_ID, cCtrlMng->getControlID( i ) ) == 0 ) {		// �\���R���g���[��ID�Ɠ���ID������ꍇ
							if( i == PNLD_AOL_InfoNumPerPage ) {									// �R���g���[��ID��2�y�[�W�ڂɂ���ꍇ.
								ucNowPage = 2;														// ���݂̃y�[�W��2�y�[�W�ڂ�ݒ�.
							}
							break;
						}
					}
				}
			}
		} else {
			ucNowPage = 1;
		}
	}
	// ��ʏ��̍X�V.
	updateScreenInfo();
	// �f�t�H���g�擾�\���.
	bDefaultSet = False;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�\�����i�̃Z�b�g�A�b�v.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::setupGamen( short option )
{
	PCGC_AuthOapCommonBase::setupGamen( option );
	if( PCGC_AuthOapCommonStaticLib::cAppMng ) {
		// �A�C�R���f�[�^�ēǂݍ���.
		bUpdateIcon = PCGC_AuthOapCommonStaticLib::cAppMng->rereadIconData();
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: �K�{���ړ��̓`�F�b�N.
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::mandatoryOK()
{
	if( existExtAuthData() ) {
		// �O���F�؃f�[�^����.
		return mandatoryOKForExtAuth();
	}
	if( !cCtrlMng ) {
		LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		return False;
	}
	if( !( cCtrlMng->existData() ) ) { return False; }
	char scControlNumBuf = cCtrlMng->getControlNum();

	TYPS_ExtAuthControlList* ps_ExtAuthCtrlList = cCtrlMng->getAuthControlList();
	char scAuthControlNumBuf = 0; // �\�����̔F�؉�ʃR���g���[����

	if( ps_ExtAuthCtrlList == NULL ) {
		for( uchar i=0; i<scControlNumBuf; i++ ) {
			switch( cCtrlMng->getControlState( i ) ) {
				case PNLE_AOCM_ControlStateShowEnableMandatory:	// ���[�U����\�����͕K�{item.

					if( isNoInputControl( i ) ) {
						return False;	// �����͏��.
					}
					break;
				default: break;
			}
		}
	} else {
		scAuthControlNumBuf = (char)ps_ExtAuthCtrlList->ss_Count; // �\�����̔F�؉�ʃR���g���[����
		for( uchar i=0; i<scAuthControlNumBuf; i++ ) {
			for( uchar j=0; j<scControlNumBuf; j++ ) {
				if( strncmp( ps_ExtAuthCtrlList->s_Control[i].sc_ID, cCtrlMng->getControlID( j ), TYPD_ExtMaxID ) == 0 ) {
					if( cCtrlMng->getControlState( j ) == PNLE_AOCM_ControlStateShowEnableMandatory ) { // ���[�U����\�����͕K�{item.
						if( isNoInputControl( j ) ) { // �K�{���ږ����͏��.
							return False;
						}
					}
				}
			}
		}
	}
	return True;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�K�{���ړ��̓`�F�b�N�i�O���F�ؑ��u�p�j.
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::mandatoryOKForExtAuth()
{
	if( !cCtrlMng ) {
		LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		return False;
	}

	if( !( cCtrlMng->existData() ) ) { return False; }

	char scControlNumBuf = cCtrlMng->getControlNum();
	for( uchar i=0; i<scControlNumBuf; i++ ) {
		if( cCtrlMng->isMandatoryControlForExtAuth2( i ) ) {
			// �K�{�R���g���[��.
			if( isNoInputControl( i ) ) {
				return False;	// �����͏��.
			}
		}
	}
	return True;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�K�{���ړ��̓`�F�b�N�Q�i�O���F�ؑ��u�p�j.
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::mandatoryOKForExtAuth2()
{
	if( !cCtrlMng ) {
		LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		return False;
	}

	TYPS_ExtAuthControlList* ps_ExtAuthCtrlList = cCtrlMng->getAuthControlList();

	if( ps_ExtAuthCtrlList == NULL ) {return mandatoryOKForExtAuth();}

	char scAuthControlNumBuf = ( char )ps_ExtAuthCtrlList->ss_Count; // �F�؉�ʃR���g���[����
	char scControlNumBuf = cCtrlMng->getControlNum(); // �R���g���[����

	for( int i=0; i<scAuthControlNumBuf; i++ ) {
		for( uchar j=0; j<scControlNumBuf; j++ ) {
			if( strncmp( ps_ExtAuthCtrlList->s_Control[i].sc_ID, cCtrlMng->getControlID( j ), TYPD_ExtMaxID ) == 0 ) {
				if( cCtrlMng->isMandatoryControlForExtAuth2( j ) ) {
					if( isNoInputControl( j ) ) { return False; } // �K�{���ږ����͏��.
				}
			}
		}
	}
	return True;
}

// comment 2017.02.07 SCD2-Sky���� [IT5_3.4][���_No.1013222]
//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �F�ؑO�̕K�{���ڂ��O���F�ؑ��u�ɂ����͕s�v�ƂȂ��Ă��邩�`�F�b�N.
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: .
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::isMandatoryDisusedForExtAuth()
{
	if( !existExtAuthData() ) {			// �O�����u����̔F�؂łȂ��ꍇ�̓`�F�b�N���Ȃ�.
		return False;
	}
	if( !cCtrlMng ) {
		LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		return False;
	}
	if( !( cCtrlMng->existData() ) ) {
		return False;
	}

	char scControlNumBuf = cCtrlMng->getControlNum();
	for( int i = 0; i < scControlNumBuf; i++ ) {
		if( ( PNLE_AOCM_ControlStateShowEnableMandatory == cCtrlMng->getControlState( static_cast<uchar>( i ) ) )		// �O���F�ؑ��u�ŔF�؂���O�̕K�{���ڂ�.
		&&  ( False == cCtrlMng->isMaskControlForExtAuth( static_cast<uchar>( i ) ) ) ) {								// ��։\�ɂȂ��Ă��Ȃ��ꍇ.
			return False;	// ���͕s�v�ł͂Ȃ��K�{���ڂ�����.
		}
	}
	return True;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:Qt�\���R���g���[���ʒu����.
// Return Value					: short.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
short PCGC_AuthOapCustomBase::getAdjustControlPositionForQt()
{
	short ss_ret = 0 ;
	// �R���g���[������5�ȏ�̏ꍇ.
	if( cCtrlMng->getControlNum() > PNLD_AOL_InfoNumPerPage ) {
		// �P�y�[�W�ɕ\�����郍�O�C����ʂ̏�񍀖ڐ���5�̏ꍇ.
		if( cCtrlMng->getDisplayControl() == PNLD_AOL_InfoNumPerPage && cCtrlMng->getDisplayFlg() == True ) {
			cCtrlMng->setDisplayFlg( False );
			TYPC_ExtCurrentInfo* pc_currInfo = PCGC_AuthOapAPIAccess::getCurrentInfoAPI();		// �J�����g���擾.
			if( pc_currInfo != NULL ) {
				TYPS_ExtControl* ps_Control = pc_currInfo->getDisplayControl();					// �\���R���g���[��ID�擾
				// �R���g���[��ID����������.
				uchar i;
				for( i=0; i<cCtrlMng->getControlNum(); i++ ) {
					if( strcmp( ps_Control->sc_ID, cCtrlMng->getControlID( i ) ) == 0 ) {		// �\���R���g���[��ID�Ɠ���ID������ꍇ
						ss_ret = (short)i;
						break;
					}
				}
			}
		}
	}
	return ss_ret;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: ����̂ݎ��s.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::firstStart()
{
	ucNowPage = 1;
	PCGC_AuthOapCommonBase::firstStart();
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: : �O�y�[�W�ؑ�.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::changePrevPageLogin() {
	if( ucNowPage > 1 ) {
		ucNowPage--;
	}

	// �A�N�e�B�u����.
	setActiveCtrl( -1 );

	// ��ʏ��̍X�V.
	updateScreenInfo();
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: : ���y�[�W�ؑ�.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::changeNextPageLogin() {
	if( ucNowPage < ucTotalPage ) {
		ucNowPage++;
	}

	// �A�N�e�B�u����.
	setActiveCtrl( -1 );

	// ��ʏ��̍X�V.
	updateScreenInfo();

}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: �A�N�e�B�u�R���g���[���擾.
// Return Value					: PCGC_AuthOapAbstractControl*.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
PCGC_AuthOapAbstractControl* PCGC_AuthOapCustomBase::getActiveCtrl()
{
	if( ( scActiveCtrlNo < 0 )
	    || ( scActiveCtrlNo >= PNLD_AOC_ControlNum ) ) {
		return NULL;
	}
	return cControl[( uchar )scActiveCtrlNo];
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: �A�N�e�B�u�R���g���[���ݒ�.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::setActiveCtrl( char argCtrlNo )
{
	if( ( argCtrlNo < -1 )
	    || ( argCtrlNo >= PNLD_AOC_ControlNum ) ) {
		LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		return;
	}
	if( scActiveCtrlNo == argCtrlNo ) {
		// ���ɑI����Ԃ̂��ߖ���.
		return ;
	}
	if( getActiveCtrl() ) {
		// �I�𒆂̃R���g���[���𖢑I����.
		getActiveCtrl()->setActive( False );
	}
	scActiveCtrlNo = argCtrlNo;
	bDirectInput = True;
	if( argCtrlNo == -1 ) {
		// ���ׂĖ��I����Ԃ�.
		return;
	}
	// �A�N�e�B�u�ʒm.
	if( cControl[( uchar )argCtrlNo] ) {
		cControl[( uchar )argCtrlNo]->setActive( True );
		PNLS_AuthOapControlInfo ctrlInfoBuf;
		getControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ), ctrlInfoBuf );
		ctrlInfoBuf.bDirectInput = True;
		setControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ), ctrlInfoBuf );
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: �R���g���[���̖����͏�ԃ`�F�b�N.
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::isNoInputControl( uchar argCtrlNo )
{
	const PNLS_AuthOapControlInfo* ctrlInfoBuf = getControlInfo( argCtrlNo );
	if( !ctrlInfoBuf ) { return True; }
	switch( ctrlInfoBuf->dataType ) {
		case PNLE_AOC_DataTypeString:	// ������.
			if( ctrlInfoBuf->string[0] == 0 ) {
				// ������.
				return True;
			}
			break;
		case PNLE_AOC_DataTypeDateTime:	// ����.
			switch( ctrlInfoBuf->dateTime.e_Default ) {
				case TYPE_ExtDateTimeDefaultNone: return True; break;
				default: break;
			}
			break;
		case PNLE_AOC_DataTypeSelectList:	//�I�����X�g.
			if( ctrlInfoBuf->selList.num >= 1 ) {
				int i;
				for( i=0; i<ctrlInfoBuf->selList.num; i++ ) {
					if( ctrlInfoBuf->selList.select[i].name[0] != 0 ) {
						return False;
					}
				}
			}
			return True;
			break;
		default: break;
	}
	return False;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�R���g���[��No.�擾.
// Return Value					: uchar.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
uchar PCGC_AuthOapCustomBase::getControlNo( uchar ucAuthControlNo )
{
	return ucAuthControlNo;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�R���g���[������ID�擾.
// Return Value					: uchar.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
uchar PCGC_AuthOapCustomBase::getControlInfoNo( uchar uc_AuthControlNo, Bool b_isMaintenanceFlgOnListSearch )
{
	return uc_AuthControlNo;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: ��ʏ��̍X�V.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::updateScreenInfo()
{
	uchar i, j;
	// �J�X�^�}�C�Y�R���g���[�����\��.
	hideCustomizeControl();
	if( !cCtrlMng ) {
		LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		return;
	}
	// ---------------------------------------------------------------------------
	// �\���y�[�W�̐擪���ԍ��Z�o.
	// ---------------------------------------------------------------------------
	if( cCtrlMng->getAuthControlList() == NULL || onlyPanel.bl_ScreenInfoMaintenanceFlg == True ) {
		ucTopInfoNo = ( uchar )( ( ucNowPage - 1 ) * ucMaxInfo );
		// ��ʏ������ɃR���g���[�����쐬.
		for( i=0; i<ucMaxInfo; i++ ) {
			// �R���g���[����ގ擾.
			uchar ucType = cCtrlMng->getControlType( ( uchar )( i + ucTopInfoNo ) );
			if( PNLE_MTUIMODE_V1 <= PLBC_MultiTouchFunction::getMultiTouchMode() ) {
				// Qt�p��ʕ\���p�R���g���[���擾.
				cControl[i] = cCtrlMng->getControlQt( ucType,i );
			} else {
				// ��ʕ\���p�R���g���[���擾.
				cControl[i] = cCtrlMng->getControl( ucType,i );
			}
			if( cControl[i] ) {
				// ������.
				cControl[i]->init();
				// ��Ԑݒ�.
				cControl[i]->setState( cCtrlMng->getControlState( ( uchar )( i + ucTopInfoNo ) ) );
				// �O���F�؃f�[�^�L����Ԓʒm.
				cControl[i]->setValidExtAuth( existExtAuthData() );
				// �O���F�؎��̃}�X�N�w��.
				cControl[i]->setMaskForExtAuth( cCtrlMng->isMaskControlForExtAuth( ( uchar )( i + ucTopInfoNo ) ) );
				// �O���F�؎��̕K�{�w��.
				cControl[i]->setMandatoryForExtAuth( cCtrlMng->isMandatoryControlForExtAuth( ( uchar )( i + ucTopInfoNo ) ) );
				// �Œ�l�ݒ�.
				cControl[i]->setFixInfo( cCtrlMng->getAppFixInfo( ( uchar )( i + ucTopInfoNo ), i ) );
				// �����\���`���ݒ�.
				cControl[i]->setStrDispType( cCtrlMng->getControlDisplay( ( uchar )( i + ucTopInfoNo ) ) );
			}
		}
	} else if( cCtrlMng->getAuthControlList() != NULL ) {
		for( i=0; i<cCtrlMng->getAuthControlList()->ss_Count; i++ ) {
			for( j=0; j<cCtrlMng->getControlNum(); j++ ) {
				if( 0 == strncmp( cCtrlMng->getAuthControlList()->s_Control[i].sc_ID, cCtrlMng->getControlID( j ), sizeof( cCtrlMng->getAuthControlList()->s_Control[i].sc_ID ) ) ) {
					uchar ucType = cCtrlMng->getControlType( j );
					if( PNLE_MTUIMODE_V1 <= PLBC_MultiTouchFunction::getMultiTouchMode() ) {
						// Qt�p��ʕ\���p�R���g���[���擾.
						cControl[i] = cCtrlMng->getControlQt( ucType,i );
					} else {
						// ��ʕ\���p�R���g���[���擾.
						cControl[i] = cCtrlMng->getControl( ucType,i );
					}
					if( cControl[i] ) {
						cControl[i]->init();
						cControl[i]->setState( cCtrlMng->getControlState( j ) );
						cControl[i]->setValidExtAuth( existExtAuthData() );
						cControl[i]->setMaskForExtAuth( cCtrlMng->isMaskControlForExtAuth( j ) );
						cControl[i]->setMandatoryForExtAuth( cCtrlMng->isMandatoryControlForExtAuth( j ) );
						cControl[i]->setFixInfo( cCtrlMng->getAppFixInfo( j, i ) );
						cControl[i]->setStrDispType( cCtrlMng->getControlDisplay( j ) );
					}
				}
			}
		}
	}
	// �f�t�H���g�f�[�^�擾.
	if( bDefaultSet ) {
		defaultDataSet();
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�R���g���[�����̏�����.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::clrControl()
{
//	int i;
	uint i = 0;
	for( i=0; i<sizeof( cControl ) / sizeof( PCGC_AuthOapAbstractControl* ); i++ ) {
		cControl[i] = NULL;
	}
	setActiveCtrl( -1 );
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: �f�t�H���g�f�[�^�ݒ�.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::defaultDataSet()
{
	uchar i;

	uchar ucInfoNumBuf = getControlInfoNum();
	PNLS_AuthOapControlInfo ctrlInfoBuf;
	for( i=0; i<ucInfoNumBuf; i++ ) {
		if( cCtrlMng->getDefaultData( i,ctrlInfoBuf ) ) {
			setControlInfo( i,ctrlInfoBuf );
		}
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: �O�y�[�W�ؑ�.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::changePrevPage()
{
	if( ucNowPage <= 1 ) {
		ucNowPage = ucTotalPage;
	} else {
		ucNowPage--;
	}
	// �A�N�e�B�u����.
	setActiveCtrl( -1 );
	// ��ʏ��̍X�V.
	updateScreenInfo();
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�: ���y�[�W�ؑ�.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::changeNextPage()
{
	if( ucNowPage >= ucTotalPage ) {
		ucNowPage = 1;
	} else {
		ucNowPage++;
	}
	// �A�N�e�B�u����.
	setActiveCtrl( -1 );
	// ��ʏ��̍X�V.
	updateScreenInfo();
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�J�X�^����ʍX�V�`�F�b�N(String Control).
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::checkStringControl( char* psc_String )
{
	TYPS_ExtControlList* ps_ctrlListBuf = cCtrlMng->getControlList();			// �R���g���[�����X�g���擾.
	uchar uc_ControlInfoNo = getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) );	// �R���g���[�����̈��ID�擾.
	uchar uc_ControlNo = getControlNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) );			// �R���g���[��ID�擾.
	Bool bl_ret = getCurrentControlInfo( uc_ControlInfoNo, s_ctrlInfoBuf );		// ���[�J���̈�ɃR�s�[�����A�R���g���[�����擾.

	if( !ps_ctrlListBuf || bl_ret == False ) { return False; }

	if( ( strcmp( s_ctrlInfoBuf.string, "" ) == 0 ) && ( strcmp( s_ctrlInfoBuf.selList.select[0].name, "" ) != 0 ) ) {
		strncpy( s_ctrlInfoBuf.string, s_ctrlInfoBuf.selList.select[0].name, sizeof( s_ctrlInfoBuf.selList.select[0].name ) - 1 );
	}

	// �J�X�^����ʍX�V�L��ŁA�������񂪕ύX���ꂽ�ꍇ.
	if( ps_ctrlListBuf->s_Control[uc_ControlNo].s_CustomScreenUpdateSetting.e_Enable == TYPE_ExtCustomScreenUpdateSettingTypeEnable &&
	    strcmp( s_ctrlInfoBuf.string, psc_String ) != 0 ) {
		// �g���T�[�o�[�ғ����ŃA�v���ʐM�����Ώۉ�ʂłȂ��ꍇ.
		if( True == PNLC_MidAuthServerStatus::getServerStatus() || False == cControl[( uchar )scActiveCtrlNo]->getAppConnectRestriction() ) {
			memset( &s_ctrlInfoBuf,0,sizeof( s_ctrlInfoBuf ) );
			s_ctrlInfoBuf.dataType = PNLE_AOC_DataTypeString;
			// ���[�J���̈�ɕ������ۑ�.
			strncpy( s_ctrlInfoBuf.string, psc_String, sizeof( s_ctrlInfoBuf.string ) -1 );
			setCurrentControlInfo( uc_ControlInfoNo, s_ctrlInfoBuf );
			return True;
		}
	}
	return False;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�J�X�^����ʍX�V�`�F�b�N(Select Control).
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::checkSelectControl( PNLS_AuthOapSelectList& s_SelectList )
{
	TYPS_ExtControlList* ps_ctrlListBuf = cCtrlMng->getControlList();			// �R���g���[�����X�g���擾.
	uchar uc_ControlInfoNo = getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) );	// �R���g���[�����̈��ID�擾.
	uchar uc_ControlNo = getControlNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) );			// �R���g���[��No.�擾.
	Bool bl_ret = getCurrentControlInfo( uc_ControlInfoNo, s_ctrlInfoBuf );		// ���[�J���̈�ɃR�s�[�����A�R���g���[�����擾.

	if( !ps_ctrlListBuf || bl_ret == False ) { return False; }

	// Select Control�̒l��NULL�ŁAString Control�ɒl������ꍇ.
	if( ( strcmp( s_ctrlInfoBuf.string, "" ) != 0 ) && ( strcmp( s_ctrlInfoBuf.selList.select[0].name, "" ) == 0 ) ) {
		strncpy( s_ctrlInfoBuf.selList.select[0].name, s_ctrlInfoBuf.string, sizeof( s_ctrlInfoBuf.selList.select[0].name ) - 1 );
	}
	// �J�X�^����ʍX�V�L��̏ꍇ.
	if( ps_ctrlListBuf->s_Control[uc_ControlNo].s_CustomScreenUpdateSetting.e_Enable == TYPE_ExtCustomScreenUpdateSettingTypeEnable ) {
		// �ʏ�񂪕ύX����Ă���ꍇ.
		if( strcmp( s_ctrlInfoBuf.selList.select[0].name, s_SelectList.select[0].name ) != 0 ) {
			// �g���T�[�o�[�ғ����ŃA�v���ʐM�����Ώۉ�ʂłȂ��ꍇ.
			if( True == PNLC_MidAuthServerStatus::getServerStatus() || False == cControl[( uchar )scActiveCtrlNo]->getAppConnectRestriction() ) {
				// ���[�J���̈�ɑI�����X�g����ۑ�.
				memset( &s_ctrlInfoBuf,0,sizeof( s_ctrlInfoBuf ) );
				s_ctrlInfoBuf.dataType = PNLE_AOC_DataTypeSelectList;
				s_ctrlInfoBuf.selList = s_SelectList;
				setCurrentControlInfo( uc_ControlInfoNo, s_ctrlInfoBuf );
				return True;
			}
		}
	}
	return False;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�J�X�^����ʍX�V�`�F�b�N(DateAndTime Control).
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::checkDateTimeControl( PNLS_AuthOapDateTime& s_DateTimeInfo )
{
	TYPS_ExtControlList* ps_ctrlListBuf = cCtrlMng->getControlList();		// �R���g���[�����X�g���擾.
	uchar uc_ControlInfoNo = getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) );	// �R���g���[�����̈��ID�擾.
	uchar uc_ControlNo = getControlNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) );		// �R���g���[��No.�擾.
	Bool bl_ret = getCurrentControlInfo( uc_ControlInfoNo,s_ctrlInfoBuf );		// ���[�J���̈�ɃR�s�[�����A�R���g���[�����X�g���擾.

	if( !ps_ctrlListBuf || bl_ret == False ) { return False; }

	// �J�X�^����ʍX�V�L��ŁA����Date&Time���ύX���ꂽ�ꍇ.
	if( ps_ctrlListBuf->s_Control[uc_ControlNo].s_CustomScreenUpdateSetting.e_Enable == TYPE_ExtCustomScreenUpdateSettingTypeEnable			&&
	    ( s_ctrlInfoBuf.dateTime.s_Value.ss_Year != s_DateTimeInfo.s_Value.ss_Year																||
	      memcmp( &s_ctrlInfoBuf.dateTime.s_Value.sc_Month, &s_DateTimeInfo.s_Value.sc_Month, sizeof( char ) ) != 0								||
	      memcmp( &s_ctrlInfoBuf.dateTime.s_Value.sc_Day, &s_DateTimeInfo.s_Value.sc_Day, sizeof( char ) ) != 0									||
	      memcmp( &s_ctrlInfoBuf.dateTime.s_Value.sc_Hour, &s_DateTimeInfo.s_Value.sc_Hour, sizeof( char ) ) != 0								||
	      memcmp( &s_ctrlInfoBuf.dateTime.s_Value.sc_Minute, &s_DateTimeInfo.s_Value.sc_Minute, sizeof( char ) ) != 0							||
	      memcmp( &s_ctrlInfoBuf.dateTime.s_Value.s_TimeZone.sc_Hour, &s_DateTimeInfo.s_Value.s_TimeZone.sc_Hour, sizeof( char ) ) != 0			||
	      memcmp( &s_ctrlInfoBuf.dateTime.s_Value.s_TimeZone.sc_Minute, &s_DateTimeInfo.s_Value.s_TimeZone.sc_Minute, sizeof( char ) ) != 0		||
	      s_ctrlInfoBuf.dateTime.e_Display != s_DateTimeInfo.e_Display																			||
	      s_ctrlInfoBuf.dateTime.e_Default != s_DateTimeInfo.e_Default ) ) {
		// �g���T�[�o�[�ғ����ŃA�v���ʐM�����Ώۉ�ʂłȂ��ꍇ.
		if( True == PNLC_MidAuthServerStatus::getServerStatus() || False == cControl[( uchar )scActiveCtrlNo]->getAppConnectRestriction() ) {
			memset( &s_ctrlInfoBuf,0,sizeof( s_ctrlInfoBuf ) );
			s_ctrlInfoBuf.dataType = PNLE_AOC_DataTypeDateTime;
			// ���[�J���̈�ɓ�������ۑ�.
			s_ctrlInfoBuf.dateTime = s_DateTimeInfo;
			setCurrentControlInfo( uc_ControlInfoNo, s_ctrlInfoBuf );
			return True;
		}
	}
	return False;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�J�X�^����ʍX�V�`�F�b�N(Numeric Control).
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::checkNumericControl( int32_t i32_Numeric )
{
	TYPS_ExtControlList* ps_ctrlListBuf = cCtrlMng->getControlList();			// �R���g���[�����X�g���擾.
	uchar uc_ControlInfoNo = getControlInfoNo( ( uchar )( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ) );	// �R���g���[�����̈��ID�擾.
	uchar uc_ControlNo = getControlNo( ( uchar )( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ) );			// �R���g���[��No.�擾.
	Bool bl_ret = getCurrentControlInfo( uc_ControlInfoNo, s_ctrlInfoBuf );		// ���[�J���̈�ɃR�s�[�����A�R���g���[�����X�g���擾.

	if( !ps_ctrlListBuf || bl_ret == False ) { return False; }

	// �J�X�^����ʍX�V�L��ŁA�����l���ύX���ꂽ�ꍇ.
	if( ps_ctrlListBuf->s_Control[uc_ControlNo].s_CustomScreenUpdateSetting.e_Enable == TYPE_ExtCustomScreenUpdateSettingTypeEnable &&
	    s_ctrlInfoBuf.numeric != i32_Numeric ) {
		// �g���T�[�o�[�ғ����ŃA�v���ʐM�����Ώۉ�ʂłȂ��ꍇ.
		if( True == PNLC_MidAuthServerStatus::getServerStatus() || False == cControl[( uchar )scActiveCtrlNo]->getAppConnectRestriction() ) {
			// ���[�J���̈�ɐ��l��ۑ�.
			memset( &s_ctrlInfoBuf,0,sizeof( s_ctrlInfoBuf ) );
			s_ctrlInfoBuf.dataType = PNLE_AOC_DataTypeNumeric;
			s_ctrlInfoBuf.numeric = i32_Numeric;
			setCurrentControlInfo( uc_ControlInfoNo, s_ctrlInfoBuf );
			return True;
		}
	}
	return False;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:  ��ʏ��擾.
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::getScreenInfo( PBasicMessageProc* pc_backScreenInfo )
{
	uchar i; int j;
	memset( &s_ScreenBuf,0,sizeof( s_ScreenBuf ) );
	memset( &s_CustomValueInfoBuf,0,sizeof( s_CustomValueInfoBuf ) );

	// �C�x���g���.
	s_ScreenBuf.e_Type = cCtrlMng->getScreenType();
	if( s_ScreenBuf.e_Type == TYPE_ExtEventTypeOther ) {
		s_ScreenBuf.e_Type = TYPE_ExtScreenTypeAuthentication;
	}
	// ���ID.
	PNLS_AuthOapStrResult s_StrResultBuf;
	cCtrlMng->getScreenID( s_StrResultBuf );
	strncpy( s_ScreenBuf.sc_ID, s_StrResultBuf.str, sizeof( s_ScreenBuf.sc_ID ) - 1 );

	uchar uc_ControlNo = getControlNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) );			// �R���g���[��ID�擾.
	// ���̓R���g���[��ID�ݒ�.
	strncpy( s_CustomValueInfoBuf.sc_ID, cCtrlMng->getControlID( uc_ControlNo ), sizeof( s_CustomValueInfoBuf.sc_ID ) - 1 );

	// �R���g���[�����擾.
	s_CustomValueInfoBuf.sc_ValueListList.sc_Count = cCtrlMng->getAuthControlNum();

	// �R���g���[���l.
	for( i=0; i<s_CustomValueInfoBuf.sc_ValueListList.sc_Count; i++ ) {
		uc_ControlNo = getControlNo( i );
		// �R���g���[��ID�ݒ�.
		if( cCtrlMng->getControlID( uc_ControlNo ) ) {
			strncpy( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].sc_ID,
			         cCtrlMng->getControlID( uc_ControlNo ),
			         sizeof( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].sc_ID )-1 );
		}
		// �J�����g�̈�ݒ�p�̃R���g���[�����擾.
		uchar uc_ControlInfoNo = getControlInfoNo( i );	// �R���g���[�����̈��ID�擾.
		Bool b_ControlData = getCurrentControlInfo( uc_ControlInfoNo, s_ctrlInfoBuf );
		if( False == b_ControlData ) {
			LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		}
		// �R���g���[���f�[�^�𕶎���֕ϊ�.
		changeStringUTF8( s_ctrlInfoBuf,cCtrlMng->getControlType( uc_ControlNo ),s_MultiStrResultBuf );
		// �R���g���[�����̃f�[�^��.
		s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].sc_Count = s_MultiStrResultBuf.num;

		for( j=0; j<s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].sc_Count; j++ ) {
			strncpy( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].s_Value[j].sc_Value,
			         s_MultiStrResultBuf.strList[j].str,
			         sizeof( s_CustomValueInfoBuf.sc_ValueListList.s_ValueList[i].s_Value[j].sc_Value )-1 );
		}
	}
	// �J�����g�̈�ݒ�p�̃R���g���[���������Z�b�g.
	setCurrentControlInfoReset();
	// ---------------------------------------------------------------------------
	// �ؑ։�ʏ��ݒ�.
	// ---------------------------------------------------------------------------
	onlyPanel.bl_ScreenUpdateFlg = True;	// �X�V��ʗL��.
	PNLS_AuthOapChgGamen s_ChgGamenBuf = {
		this,pc_backScreenInfo
	};
	setChangeGamen( s_ChgGamenBuf );
	setRcvActionType( PNLE_AOC_RcvActionTypeChgScr );

	Bool bl_ret = PCGC_AuthOapCommonStaticLib::cSrvConnect->changeScreenData( s_ScreenBuf,s_CustomValueInfoBuf );
	if( bl_ret == True ) {
		// �X�V�҂���ʕ\��.
		PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapAppConnectExt_act, NULL, NULL, 0, 0, 424, 180 );
	}
	return bl_ret;
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:������ύX�ʒm.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::notifyStringChange( const char* argStr )
{
	PNLS_AuthOapControlInfo sCtrlInfoBuf;
	memset( &sCtrlInfoBuf,0,sizeof( sCtrlInfoBuf ) );
	sCtrlInfoBuf.dataType = PNLE_AOC_DataTypeString;
	if( argStr ) {
		strncpy( sCtrlInfoBuf.string,argStr,sizeof( sCtrlInfoBuf.string )-1 );
	}
	setControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ),sCtrlInfoBuf );																// �yOAPExFUM3�z�y�F�،�̃p�����[�^���́z�y13�J���x��z�y99034�z 2008/5/29 mod.
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�I��ύX�ʒm.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::notifySelectChange( PNLS_AuthOapSelectList& argSelectList )
{
	PNLS_AuthOapControlInfo sCtrlInfoBuf;
	memset( &sCtrlInfoBuf,0,sizeof( sCtrlInfoBuf ) );
	sCtrlInfoBuf.dataType = PNLE_AOC_DataTypeSelectList;
	sCtrlInfoBuf.selList = argSelectList;
	setControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ),sCtrlInfoBuf );																	// �yOAPExFUM3�z�y�F�،�̃p�����[�^���́z�y13�J���x��z�y99034�z 2008/5/29 mod.
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�����ύX�ʒm.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::notifyDateTimeChange( PNLS_AuthOapDateTime& argDateTime )
{
	PNLS_AuthOapControlInfo sCtrlInfoBuf;
	memset( &sCtrlInfoBuf,0,sizeof( sCtrlInfoBuf ) );
	sCtrlInfoBuf.dataType = PNLE_AOC_DataTypeDateTime;
	sCtrlInfoBuf.dateTime = argDateTime;
	setControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ),sCtrlInfoBuf );																	// �yOAPExFUM3�z�y�F�،�̃p�����[�^���́z�y13�J���x��z�y99034�z 2008/5/29 mod.
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:���l�ύX�ʒm.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::notifyNumericChange( int32_t argNumeric )
{
	PNLS_AuthOapControlInfo sCtrlInfoBuf;
	memset( &sCtrlInfoBuf,0,sizeof( sCtrlInfoBuf ) );
	sCtrlInfoBuf.dataType = PNLE_AOC_DataTypeNumeric;
	sCtrlInfoBuf.numeric = argNumeric;
	setControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ),sCtrlInfoBuf );																	// �yOAPExFUM3�z�y�F�،�̃p�����[�^���́z�y13�J���x��z�y99034�z 2008/5/29 mod.
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:��ʈړ�.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::procGoToPage( uchar option )
{
	uchar fieldNoBuf = ( uchar )( ( option / 10 ) - 1 );
	uchar btnOption = ( uchar )( option - ( fieldNoBuf + 1 )*10 );
	if( fieldNoBuf >= PNLD_AOC_ControlNum ) {
		// �s���l.
		LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		return;
	}
	if( cControl[fieldNoBuf] ) {
		// �A�N�e�B�u�R���g���[���ԍ��X�V.
		setActiveCtrl( fieldNoBuf );
		// �R���g���[����������.
		controlGoToPage( btnOption );
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�{�^���i�����ꂽ�j.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::procButtonOn( uchar option )
{
	uchar fieldNoBuf = ( uchar )( ( option / 10 ) - 1 );
	uchar btnOption = ( uchar )( option - ( fieldNoBuf + 1 )*10 );
	if( fieldNoBuf >= PNLD_AOC_ControlNum ) {
		// �s���l.
		LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		return;
	}
	if( cControl[fieldNoBuf] ) {
		// �A�N�e�B�u�R���g���[���ԍ��X�V.
		setActiveCtrl( fieldNoBuf );
		if( getActiveCtrl() ) {
			PNLS_AuthOapControlInfo sCtrlInfoBuf;
			// �������ʒm.
			if( getActiveCtrl()->procButtonOn( btnOption,sCtrlInfoBuf ) ) {
				// Toggle�̏ꍇ
				if( sCtrlInfoBuf.dataType & PNLE_AOC_DataTypeSelect ) {
					TYPS_ExtControlList* ps_ctrlListBuf = cCtrlMng->getControlList();		// �R���g���[�����X�g���擾.
					uchar uc_ControlInfoNo = getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) );	// �R���g���[�����̈��ID�擾.
					uchar uc_ControlNo = getControlNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) );			// �R���g���[��No.�擾.

					// �J�X�^����ʍX�V�L��̏ꍇ�A���g���T�[�o�[�ғ����ŃA�v���ʐM�����Ώۉ�ʂłȂ��ꍇ.
					if( ( ps_ctrlListBuf->s_Control[uc_ControlNo].s_CustomScreenUpdateSetting.e_Enable == TYPE_ExtCustomScreenUpdateSettingTypeEnable )
					    && ( True == PNLC_MidAuthServerStatus::getServerStatus() || False == cControl[fieldNoBuf]->getAppConnectRestriction() ) ) {
						setCurrentControlInfo( uc_ControlInfoNo,sCtrlInfoBuf );
						PBasicMessageProc* pc_backScreenInfo = this;
						Bool bl_ret = getScreenInfo( pc_backScreenInfo );
						if( bl_ret == False ) {
							onlyPanel.bl_ScreenUpdateFlg = False;
							return;
						}
					} else {

						// �R���g���[�����ύX����.
						setControlInfo( uc_ControlInfoNo,sCtrlInfoBuf );

						setupGamen();
					}
				} else {
					// �R���g���[�����ύX����.
					setControlInfo( getControlNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ),sCtrlInfoBuf );	// �y306258�z�y�F�،�̃p�����[�^���́z�y13�x��z 2008/7/4 mod.
					setupGamen();
				}
			}
		}
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�e���L�[.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::proc10Key( uchar option )
{
// comment 2015/12/01 OPS1-Sky�I�� [��ROM][MZV-143_�@��}�[�W]SafeQ���O�C���X�e�b�v���팸DipSW���Ή�.
	char _sc_Num[ PCGD_NumberKeyCode ];
	memset( _sc_Num, '\0', sizeof( _sc_Num ) );
	//1�Ԗڂ̃R���g���[�����擾.
	PNLS_AuthOapControlInfo ctrlInfoBuf0;
	getControlInfo(0, ctrlInfoBuf0);
	// �A�v���w����擾.
	TYPS_ExtControl sFixInfoBuf0;
	cCtrlMng->getAppFixInfo(0, sFixInfoBuf0);

	if( !getActiveCtrl() ) {
// comment 2015/12/01 OPS1-Sky�I�� [��ROM][MZV-143_�@��}�[�W]SafeQ���O�C���X�e�b�v���팸DipSW���Ή�.
//		setBuzzerType( PCGE_BuzzerType_InputNg );
		if ( True == APIC_SoftDipSw::newInstance()->getSoftDipSwBitForPanelSpecNo( DEFSOFTWARESW218, 6 ) ) {
			if(TYPE_ExtControlTypeString == sFixInfoBuf0.e_Type						// StringControl.
				&& strlen(ctrlInfoBuf0.string) < sFixInfoBuf0.s_String.uc_Max		// �A�v���w��ő�l�̏ꍇ.
				&& strlen(ctrlInfoBuf0.string) < PNLD_AO_MaxControlName	- 1			// �i�[�̈�ő�l�̏ꍇ.
				&& 9 >= option) {													// ���l�̏ꍇ.
// comment 2015/01/07 �yHCL-Rengaraaj�z�yCQ519679�z Klockwork Changes ID:33679 [ABV.GENERAL].
//				sprintf( _sc_Num,"%d", option );
				snprintf( _sc_Num, sizeof( _sc_Num ),"%d", option );
				strncat(ctrlInfoBuf0.string, _sc_Num, sizeof(ctrlInfoBuf0.string)-strlen(ctrlInfoBuf0.string)-1);
				setControlInfo(0, ctrlInfoBuf0);
				setupGamen();
			}
			else {
				setBuzzerType( PCGE_BuzzerType_InputNg );
			}
		} else {
			setBuzzerType( PCGE_BuzzerType_InputNg );
		}
		return;
	}
	// �A�N�e�B�u�R���g���[�����擾.
	PNLS_AuthOapControlInfo ctrlInfoBuf;
	getControlInfo( getControlNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ), ctrlInfoBuf );				// �y307783�z�y�l�b�g���[�N���O�C���@�\�z�y13����zmerge.
	getControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ), ctrlInfoBuf );
	if( ctrlInfoBuf.dataType != PNLE_AOC_DataTypeNumeric ) {
		// �ΏۊO.
// comment 2015/12/01 OPS1-Sky�I�� [��ROM][MZV-143_�@��}�[�W]SafeQ���O�C���X�e�b�v���팸DipSW���Ή�.
//		setBuzzerType( PCGE_BuzzerType_InputNg );
		if ( True == APIC_SoftDipSw::newInstance()->getSoftDipSwBitForPanelSpecNo( DEFSOFTWARESW218, 6 ) ) {
			if(TYPE_ExtControlTypeString == sFixInfoBuf0.e_Type						// StringControl.
				&& strlen(ctrlInfoBuf0.string) < sFixInfoBuf0.s_String.uc_Max		// �A�v���w��ő�l�̏ꍇ.
				&& strlen(ctrlInfoBuf0.string) < PNLD_AO_MaxControlName - 1			// �i�[�̈�ő�l�̏ꍇ.
				&& 9 >= option) {													// ���l�̏ꍇ.
// comment 2015/01/07 �yHCL-Rengaraaj�z�yCQ519679�z Klockwork Changes ID:33679 [ABV.GENERAL].
//				sprintf( _sc_Num,"%d", option );
				snprintf( _sc_Num, sizeof( _sc_Num ),"%d", option );
				strncat(ctrlInfoBuf0.string, _sc_Num, sizeof(ctrlInfoBuf0.string)-strlen(ctrlInfoBuf0.string)-1);
				setControlInfo(0, ctrlInfoBuf0);
				setupGamen();
			}
			else {
				// �ΏۊO.
				setBuzzerType( PCGE_BuzzerType_InputNg );
			}
		} else {
			setBuzzerType( PCGE_BuzzerType_InputNg );
		}
		return;
	}
	if( !( getActiveCtrl()->isValid10Key() ) ) {
		// ��t�s��.
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	}
	// �ő�l�擾.
	const TYPS_ExtControl* sFixInfoBuf = getActiveCtrl()->getFixInfo();
	if( !sFixInfoBuf ) {
		// �͈͕s���̂��߁A��t�s��.
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	}
	if( 214748364 < ctrlInfoBuf.numeric
	    ||( 214748364 == ctrlInfoBuf.numeric && 7 < option )
	    || -214748364 > ctrlInfoBuf.numeric
	    ||( -214748364 == ctrlInfoBuf.numeric && 8 < option ) ) {
		bErrInput = True;
	} else if( INT_MIN == sFixInfoBuf->s_Numeric.sl_Min ) {
		// �ŏ��l�� -2147483648 �̏ꍇ�A�����ɂ��悤�Ƃ���� int32_t �𒴂��Ă��܂����߁A�ʐ���ōs��.
		// �܂��A��L��ʂ��Ă鎞�_�ŁA���̓G���[�͂��肦�Ȃ�.
		bErrInput = False;
		if( True == bDirectInput ) {	// �_�C���N�g���͎�.
			if( option != 0 ) {			// 0�ȊO�̓��͎���t��.
				ctrlInfoBuf.numeric = option;
			}
		} else {
			if( 0 <= ctrlInfoBuf.numeric ) {
				ctrlInfoBuf.numeric = ctrlInfoBuf.numeric * 10 + option;
			} else {
				ctrlInfoBuf.numeric = ctrlInfoBuf.numeric * 10 - option;
			}
		}
	} else {
		int32_t i32_TempMax = sFixInfoBuf->s_Numeric.sl_Max;
		int32_t i32_TempValue = ctrlInfoBuf.numeric;
		Bool b_TempValue = False;
		if( 0 > i32_TempValue ) {
			i32_TempValue = i32_TempValue * -1;
			b_TempValue = True;
		}
		if( abs( sFixInfoBuf->s_Numeric.sl_Max ) < abs( sFixInfoBuf->s_Numeric.sl_Min ) ) {
			i32_TempMax = sFixInfoBuf->s_Numeric.sl_Min * -1;
		}
		ctrlInfoBuf.numeric = proc10KeyInput( i32_TempValue, i32_TempMax, option, bDirectInput, EP_InputMaxLimitPattern_Refuse, &bErrInput );
		if( True == b_TempValue ) {
			ctrlInfoBuf.numeric = ctrlInfoBuf.numeric * -1;
		}
	}
	// �R���g���[���փG���[�ʒm.
	getActiveCtrl()->setError( bErrInput );
	if( bErrInput ) {
		// �G���[��ԃZ�b�g.
		onlyPanel.setErrorNumberFieldPartsKind( EP_ErrorPartsKind_NumberField );
	}
	// ���͂��J�n���ꂽ���߁A�_�C���N�g���͉���.
	bDirectInput = False;
	ctrlInfoBuf.bDirectInput = False;
	// �R���g���[�����̐ݒ�.
	setControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ),ctrlInfoBuf );
	setupGamen();
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�A�X�^���X�N�L�[.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::procAster( uchar option )
{
	if( !getActiveCtrl() ) {
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	}
	// �A�N�e�B�u�R���g���[�����擾.
	PNLS_AuthOapControlInfo ctrlInfoBuf;
	getControlInfo( getControlNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ), ctrlInfoBuf );
	getControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ), ctrlInfoBuf );
	if( ctrlInfoBuf.dataType != PNLE_AOC_DataTypeNumeric ) {
		// �ΏۊO.
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	}
	if( !( getActiveCtrl()->isValid10Key() ) ) {
		// ��t�s��.
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	}
	// �ő�l�擾.
	const TYPS_ExtControl* sFixInfoBuf = getActiveCtrl()->getFixInfo();
	if( !sFixInfoBuf ) {
		// �͈͕s���̂��߁A��t�s��.
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	}
	if( INT_MIN == ctrlInfoBuf.numeric ) {
		// -2147483648��2147483648�֕ϊ�������ƃI�[�o�[�t���[����.
		bErrInput = True;
	} else {
		bErrInput = False;
		ctrlInfoBuf.numeric = ctrlInfoBuf.numeric * -1;
	}
	// �R���g���[���փG���[�ʒm.
	getActiveCtrl()->setError( bErrInput );
	if( bErrInput ) {
		// �G���[��ԃZ�b�g.
		onlyPanel.setErrorNumberFieldPartsKind( EP_ErrorPartsKind_NumberField );
	}
	// �R���g���[�����̐ݒ�.
	setControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ),ctrlInfoBuf );
	setupGamen();
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�N���A�[.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::procClear( uchar option )
{
// comment 2015/12/01 OPS1-Sky�I�� [��ROM][MZV-143_�@��}�[�W]SafeQ���O�C���X�e�b�v���팸DipSW���Ή�.
	//1�Ԗڂ̃R���g���[�����擾.
	PNLS_AuthOapControlInfo ctrlInfoBuf0;
	getControlInfo(0, ctrlInfoBuf0);
	// �A�v���w����擾.
	TYPS_ExtControl sFixInfoBuf0;
	cCtrlMng->getAppFixInfo(0, sFixInfoBuf0);

	if( !getActiveCtrl() ) {
// comment 2015/12/01 OPS1-Sky�I�� [��ROM][MZV-143_�@��}�[�W]SafeQ���O�C���X�e�b�v���팸DipSW���Ή�.
//		setBuzzerType( PCGE_BuzzerType_InputNg );
		if ( True == APIC_SoftDipSw::newInstance()->getSoftDipSwBitForPanelSpecNo( DEFSOFTWARESW218, 6 ) ) {
			if(TYPE_ExtControlTypeString == sFixInfoBuf0.e_Type) {
				memset(ctrlInfoBuf0.string, '\0', sizeof(ctrlInfoBuf0.string));
				setControlInfo(0, ctrlInfoBuf0);
				setupGamen();
			}
			else {
				setBuzzerType( PCGE_BuzzerType_InputNg );
			}
		} else {
			setBuzzerType( PCGE_BuzzerType_InputNg );
		}
		return;
	}
	// �A�N�e�B�u�R���g���[�����擾.
	PNLS_AuthOapControlInfo ctrlInfoBuf;
	getControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ), ctrlInfoBuf );
	if( ctrlInfoBuf.dataType != PNLE_AOC_DataTypeNumeric ) {
		// �ΏۊO.
// comment 2015/12/01 OPS1-Sky�I�� [��ROM][MZV-143_�@��}�[�W]SafeQ���O�C���X�e�b�v���팸DipSW���Ή�.
//		setBuzzerType( PCGE_BuzzerType_InputNg );
		if ( True == APIC_SoftDipSw::newInstance()->getSoftDipSwBitForPanelSpecNo( DEFSOFTWARESW218, 6 ) ) {
		if(TYPE_ExtControlTypeString == sFixInfoBuf0.e_Type) {
				memset(ctrlInfoBuf0.string, '\0', sizeof(ctrlInfoBuf0.string));
				setControlInfo(0, ctrlInfoBuf0);
				setupGamen();
			}
			else {
				// �ΏۊO.
				setBuzzerType( PCGE_BuzzerType_InputNg );
			}
		} else {
			setBuzzerType( PCGE_BuzzerType_InputNg );
		}
		return;
	}
	if( !( getActiveCtrl()->isValid10Key() ) ) {
		// ��t�s��.
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	}
	ctrlInfoBuf.numeric = 0;
	const TYPS_ExtControl* sFixInfoBuf = getActiveCtrl()->getFixInfo();
	if( !sFixInfoBuf ) {
		// �͈͕s���̂��߁A��t�s��.
		setBuzzerType( PCGE_BuzzerType_InputNg );
		return;
	} else if( 0 < sFixInfoBuf->s_Numeric.sl_Min ) {
		// �ŏ��l�����̏ꍇ�̃N���A���͍ŏ��l�\���Ƃ���.
		ctrlInfoBuf.numeric = sFixInfoBuf->s_Numeric.sl_Min;
	} else if( 0 > sFixInfoBuf->s_Numeric.sl_Max ) {
		// �ő�l�����̏ꍇ�̃N���A���͍ő�l�\���Ƃ���.
		ctrlInfoBuf.numeric = sFixInfoBuf->s_Numeric.sl_Max;
	}

	ctrlInfoBuf.bDirectInput = True;
	// �R���g���[�����̐ݒ�.
	setControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ),ctrlInfoBuf );
	// �_�C���N�g���͍ĊJ.
	bDirectInput = True;
	setupGamen();
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�p�l�����Z�b�g.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::procReset( uchar option )
{
	defaultDataSet();
	// �F�؃f�[�^�N���A.
	clearExtAuthData();
	onlyPanel.bl_NetworkExtAuthData = False;
	TYPS_ResExtParameter* ps_ResExtParameter = PCGC_AuthOapCommonStaticLib::getResExtParameter();
	memset( ps_ResExtParameter, 0, sizeof( TYPS_ResExtParameter ) );
	PCGC_AuthOapCommonStaticLib::m_b_OnLoginFlg = False; // �F�ؓr���t���O������.
	PCGC_AuthOapCommonStaticLib::m_b_ReqLoginByUseDevice = False; // �O���F�؋@��ɂ��F�ؗv����������.
}
// comment 2020/07/14 SCD2-Sky �Ό� [IT6_2.0MR2][OP_BTS-25362] �t�b�^�[�G���A�Ή�.
//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:�p�l�����Z�b�g�L�[�������.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::resetKeyActiveCheck()
{
	ACTIVEKEY_RET( True );
}
//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:��ʈړ�(�R���g���[��).
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::controlGoToPage( uchar option )
{
	if( !getActiveCtrl() ) { return; }
	// �������ʒm.
	getActiveCtrl()->procGoToPage( option );
	// ���ݒl�擾.
	const PNLS_AuthOapControlInfo* ctrlInfoBuf = getControlInfo( getControlInfoNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ) );
	if( !ctrlInfoBuf ) { return; }
	// ��ʃ^�C�g���擾.
	char scTitleBuf[( PNLD_AOL_ScreenTitleViewMax * 3 ) + 1];
	cCtrlMng->getScreenTitle( scTitleBuf,sizeof( scTitleBuf ) );
	// �Œ���擾(�ؑ֐�̉�ʂ�UTF��z�肵�Ă��邽��UTF�œn��).
	TYPS_ExtControl sControlBuf;
	cCtrlMng->getAppFixInfoUTF( getControlNo( ( uchar )( scActiveCtrlNo + ucTopInfoNo ) ),sControlBuf );
	// �ؑ֏��擾.
	PNLS_AuthOapChgScrType sChgScrTypeBuf;
	getActiveCtrl()->getChgScrType( sChgScrTypeBuf );
	switch( sChgScrTypeBuf.scrType ) {
		case PNLE_AOAC_ChgScrTypeString:	// ���������.
		{
			PNLS_AuthOapCtrlParamStrLib sCtrlParamStrBuf;
			memset( &sCtrlParamStrBuf,0,sizeof( sCtrlParamStrBuf ) );
			sCtrlParamStrBuf.paramCom.scrTitle = scTitleBuf;
			sCtrlParamStrBuf.paramCom.fixInfo = &sControlBuf;
			sCtrlParamStrBuf.paramCom.backScreenBase = this;
			if( ctrlInfoBuf->dataType & PNLE_AOC_DataTypeString ) {
				sCtrlParamStrBuf.nowStr = ctrlInfoBuf->string;
			} else if( ctrlInfoBuf->dataType & PNLE_AOC_DataTypeSelectList ) {
				if( ctrlInfoBuf->selList.num >= 1 ) {
					sCtrlParamStrBuf.nowStr = ctrlInfoBuf->selList.select[0].name;
				}
			}
			gp_AuthOapInputTextExt_act.setParam( &sCtrlParamStrBuf );
			// A070700700 - �g���T�[�o�[�F��_StringControl�L�[�{�[�h
			if( True == PLBC_FuncVersionCheck::isOK_Type1() ) {
				gp_AuthOapInputTextExt_act.setParam( &sCtrlParamStrBuf );
			}
			PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapInputTextExt_act, this, NULL );
		}
		break;
		case PNLE_AOAC_ChgScrTypeSelection:	// �P��I��.
		{
			PNLS_AuthOapCtrlParamSelLib sCtrlParamSelBuf;
			memset( &sCtrlParamSelBuf,0,sizeof( sCtrlParamSelBuf ) );
			sCtrlParamSelBuf.paramCom.scrTitle = scTitleBuf;
			sCtrlParamSelBuf.paramCom.fixInfo = &sControlBuf;
			sCtrlParamSelBuf.paramCom.backScreenBase = this;
			if( ctrlInfoBuf->dataType & PNLE_AOC_DataTypeSelectList ) {
				sCtrlParamSelBuf.selList = &( ctrlInfoBuf->selList );
			}
			switch( sChgScrTypeBuf.listType ) {
				case PNLE_AOAC_ListTypeMiddle:			// �~�h��.
					gp_AuthOapStSelectCtrlExtStaticTypeM_act.setParam( &sCtrlParamSelBuf );
					PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapStSelectCtrlExtStaticTypeM_act, this, NULL );
					break;
					break;
				case PNLE_AOAC_ListTypeSmall:			// �X���[��.
					gp_AuthOapStSelectCtrlExtStaticTypeS_act.setParam( &sCtrlParamSelBuf );
					PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapStSelectCtrlExtStaticTypeS_act, this, NULL );
					break;
					break;
				case PNLE_AOAC_ListTypeLarge:			// ���[�W.
				default:
					gp_AuthOapStSelectCtrlExtStaticTypeL_act.setParam( &sCtrlParamSelBuf );
					PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapStSelectCtrlExtStaticTypeL_act, this, NULL );
					break;
			}
		}
		break;
		case PNLE_AOAC_ChgScrTypeDynSelection:	// �P��I���i���I�j.
		{
			if( True == isServerInitializing() ) {
				// ���������͖���.
				setBuzzerType( PCGE_BuzzerType_InputNg );
				break;
			}

			// ---------------------------------------------------------------------------
			// �ؑ։�ʏ��ݒ�.
			// ---------------------------------------------------------------------------
			PNLS_AuthOapChgGamen sChgGamenBuf;
			memset( &sChgGamenBuf,0,sizeof( sChgGamenBuf ) );
			sChgGamenBuf.backward = this;
			switch( sChgScrTypeBuf.listType ) {
				case PNLE_AOAC_ListTypeMiddle: sChgGamenBuf.forward = &gp_AuthOapStSelectCtrlExtDynamicTypeM_act; break;	// �~�h��.
				case PNLE_AOAC_ListTypeSmall: sChgGamenBuf.forward = &gp_AuthOapStSelectCtrlExtDynamicTypeS_act; break;	// �X���[��.
				case PNLE_AOAC_ListTypeLarge:			// ���[�W.
				default: sChgGamenBuf.forward = &gp_AuthOapStSelectCtrlExtDynamicTypeL_act; break;
			}
			setChangeGamen( sChgGamenBuf );
			setRcvActionType( PNLE_AOC_RcvActionTypeChgScr );
			// ---------------------------------------------------------------------------
			// ---------------------------------------------------------------------------
			// �ؑ֐�ŕ\������R���g���[���f�[�^�X�V.
			// ---------------------------------------------------------------------------
			PNLS_AuthOapChgCtrlInfo sChgCtrlInfoBuf;
			memset( &sChgCtrlInfoBuf,0,sizeof( sChgCtrlInfoBuf ) );
			// ���ID.
			PNLS_AuthOapStrResult sStrResultBuf;
			cCtrlMng->getScreenID( sStrResultBuf );
			strncpy( sChgCtrlInfoBuf.screenID, sStrResultBuf.str, sizeof( sChgCtrlInfoBuf.screenID ) - 1 );

			// �R���g���[��ID.
			strncpy( sChgCtrlInfoBuf.controlID, sControlBuf.sc_ID, sizeof( sChgCtrlInfoBuf.controlID ) - 1 );

			// �J�n�ԍ�.
			sChgCtrlInfoBuf.us_Start = 1;
			// �v����.
			int32_t	i32_ListItemNum = ( ( PCPC_AuthOapStSelectCtrlExtDynamicCom_act* )sChgGamenBuf.forward )->getListItemNum();
			ushort us_PagePerBlockBuf = (ushort)(TYPD_ExtMaxSelectionData / i32_ListItemNum);
			sChgCtrlInfoBuf.uc_Length = (uchar)(us_PagePerBlockBuf * i32_ListItemNum);
			PCGC_AuthOapCommonStaticLib::cSrvConnect->changeControlData( sChgCtrlInfoBuf );
			// ---------------------------------------------------------------------------
			// �X�V�҂���ʕ\��.
			PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapAppConnectExt_act, NULL, NULL, 0, 0, 424, 180 );
			// ---------------------------------------------------------------------------
			// ������ؑ։�ʂ̃p�����[�^�ݒ�.
			// ---------------------------------------------------------------------------
			PNLS_AuthOapCtrlParamSelLib sCtrlParamSelBuf;
			memset( &sCtrlParamSelBuf,0,sizeof( sCtrlParamSelBuf ) );
			sCtrlParamSelBuf.paramCom.scrTitle = scTitleBuf;
			sCtrlParamSelBuf.paramCom.fixInfo = &sControlBuf;
			sCtrlParamSelBuf.paramCom.backScreenBase = this;
			if( ctrlInfoBuf->dataType & PNLE_AOC_DataTypeSelectList ) {
				sCtrlParamSelBuf.selList = &( ctrlInfoBuf->selList );
			} else {
				sCtrlParamSelBuf.selList = NULL;
			}
			switch( sChgScrTypeBuf.listType ) {
				case PNLE_AOAC_ListTypeMiddle:			// �~�h��.
					gp_AuthOapStSelectCtrlExtDynamicTypeM_act.setParam( &sCtrlParamSelBuf );
					gp_AuthOapStSelectCtrlExtDynamicTypeM_act.setDynamicParam( &sChgCtrlInfoBuf );
					break;
				case PNLE_AOAC_ListTypeSmall:			// �X���[��.
					gp_AuthOapStSelectCtrlExtDynamicTypeS_act.setParam( &sCtrlParamSelBuf );
					gp_AuthOapStSelectCtrlExtDynamicTypeS_act.setDynamicParam( &sChgCtrlInfoBuf );
					break;
				case PNLE_AOAC_ListTypeLarge:			// ���[�W.
				default:
					gp_AuthOapStSelectCtrlExtDynamicTypeL_act.setParam( &sCtrlParamSelBuf );
					gp_AuthOapStSelectCtrlExtDynamicTypeL_act.setDynamicParam( &sChgCtrlInfoBuf );
					break;
			}
			// ---------------------------------------------------------------------------.
		}
		break;
		case PNLE_AOAC_ChgScrTypeMultiSelection:	// �����I��.
		{
			PNLS_AuthOapCtrlParamSelLib sCtrlParamSelBuf;
			memset( &sCtrlParamSelBuf,0,sizeof( sCtrlParamSelBuf ) );
			sCtrlParamSelBuf.paramCom.scrTitle = scTitleBuf;
			sCtrlParamSelBuf.paramCom.fixInfo = &sControlBuf;
			sCtrlParamSelBuf.paramCom.backScreenBase = this;
			if( ctrlInfoBuf->dataType & PNLE_AOC_DataTypeSelectList ) {
				sCtrlParamSelBuf.selList = &( ctrlInfoBuf->selList );
			}
			switch( sChgScrTypeBuf.listType ) {
				case PNLE_AOAC_ListTypeMiddle: break;	// �~�h��.
				case PNLE_AOAC_ListTypeSmall: break;	// �X���[��.
				case PNLE_AOAC_ListTypeLarge:			// ���[�W.
				default:
					break;
			}
		}
		break;
		case PNLE_AOAC_ChgScrTypeDateTime:			// ���t����.
		{
			PNLS_AuthOapCtrlParamDateTimeLib sCtrlParamDateTimeBuf;
			memset( &sCtrlParamDateTimeBuf,0,sizeof( sCtrlParamDateTimeBuf ) );
			sCtrlParamDateTimeBuf.paramCom.scrTitle = scTitleBuf;
			sCtrlParamDateTimeBuf.paramCom.fixInfo = &sControlBuf;
			sCtrlParamDateTimeBuf.paramCom.backScreenBase = this;
			if( ctrlInfoBuf->dataType & PNLE_AOC_DataTypeDateTime ) {
				sCtrlParamDateTimeBuf.dateTime = ctrlInfoBuf->dateTime;
			}
			gp_AuthOapInputDateTimeExt_act.setParam( &sCtrlParamDateTimeBuf );
			PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapInputDateTimeExt_act, this, NULL );
		}
		break;
		case PNLE_AOAC_ChgScrTypeSearch: {			// ����.

			if( True == isServerInitializing() ) {
				// ���������͖���.
				setBuzzerType( PCGE_BuzzerType_InputNg );
				break;
			}

			PNLS_AuthOapCtrlParamStrLib sCtrlParamStrBuf;
			memset( &sCtrlParamStrBuf,0,sizeof( sCtrlParamStrBuf ) );
			sCtrlParamStrBuf.paramCom.scrTitle = scTitleBuf;
			sCtrlParamStrBuf.paramCom.fixInfo = &sControlBuf;
			sCtrlParamStrBuf.paramCom.backScreenBase = this;
			// ---------------------------------------------------------------------------
			// �ؑ֌�ɗ��p���铮�I�擾�p���.
			// ---------------------------------------------------------------------------
			PNLS_AuthOapChgCtrlInfo sChgCtrlInfoBuf;
			memset( &sChgCtrlInfoBuf,0,sizeof( sChgCtrlInfoBuf ) );
			// ���ID.
			PNLS_AuthOapStrResult sStrResultBuf;
			cCtrlMng->getScreenID( sStrResultBuf );
			strncpy( sChgCtrlInfoBuf.screenID,sStrResultBuf.str,sizeof( sChgCtrlInfoBuf.screenID )-1 );
			// �R���g���[��ID.
			strncpy( sChgCtrlInfoBuf.controlID,sControlBuf.sc_ID,sizeof( sChgCtrlInfoBuf.controlID )-1 );
			// ���̑����ڂ͕s�v.
			// ---------------------------------------------------------------------------
			// A070701000(�g���T�[�o�[�F��_SearchSelection).
			switch( sControlBuf.s_SearchString.e_ListType ) {
				case TYPE_ExtListTypeMiddle:			// �~�h��.
					gp_AuthOapStSelectCtrlExtSearchTypeM_act.setParam( &sCtrlParamStrBuf );
					gp_AuthOapStSelectCtrlExtSearchTypeM_act.setDynamicParam( &sChgCtrlInfoBuf );
					PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapStSelectCtrlExtSearchTypeM_act, this, NULL );
					break;
				case TYPE_ExtListTypeSmall:			// �X���[��.
					gp_AuthOapStSelectCtrlExtSearchTypeS_act.setParam( &sCtrlParamStrBuf );
					gp_AuthOapStSelectCtrlExtSearchTypeS_act.setDynamicParam( &sChgCtrlInfoBuf );
					PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapStSelectCtrlExtSearchTypeS_act, this, NULL );
					break;
				case TYPE_ExtListTypeLarge:			// ���[�W.
				default:
					gp_AuthOapStSelectCtrlExtSearchTypeL_act.setParam( &sCtrlParamStrBuf );
					gp_AuthOapStSelectCtrlExtSearchTypeL_act.setDynamicParam( &sChgCtrlInfoBuf );
					PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapStSelectCtrlExtSearchTypeL_act, this, NULL );
					break;
			}
		}
		break;
		case PNLE_AOAC_ChgScrTypeNumeric: {		// ���l����.
			PNLS_AuthOapCtrlParamNumLib sCtrlParamNumBuf;
			memset( &sCtrlParamNumBuf,0,sizeof( sCtrlParamNumBuf ) );
			sCtrlParamNumBuf.paramCom.scrTitle = scTitleBuf;
			sCtrlParamNumBuf.paramCom.fixInfo = &sControlBuf;
			sCtrlParamNumBuf.paramCom.backScreenBase = this;
			if( ctrlInfoBuf->dataType & PNLE_AOC_DataTypeNumeric ) {
				sCtrlParamNumBuf.numeric = ctrlInfoBuf->numeric;
			}
			gp_AuthOapInputNumExt_act.setParam( &sCtrlParamNumBuf );
			PNLC_PopupListControl::newInstance()->addPopup( &gp_AuthOapInputNumExt_act, this, NULL );
		}
		break;
		default: break;
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:������ϊ�.
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::changeString( const PNLS_AuthOapControlInfo& argInfo,
        PNLE_AOCM_ControlType argType,
        PNLS_AuthOapMultiStrResult& argResult )
{
	int i;

	memset( &argResult,0,sizeof( argResult ) );
	if( argInfo.dataType & PNLE_AOC_DataTypeString ) {
		// ������.
		argResult.num = 1;
		strncpy( argResult.strList[0].str,argInfo.string,sizeof( argResult.strList[0] )-1 );
	} else if( argInfo.dataType & PNLE_AOC_DataTypeNumeric ) {
		// ���l.
		argResult.num = 1;
		snprintf( argResult.strList[0].str, sizeof(argResult.strList[0].str), "%d",argInfo.numeric );
	} else if( argInfo.dataType & PNLE_AOC_DataTypeSelect ) {
		argResult.num = 1;
		// �I����ԁi�I�v�V�����{�^���j.
		if( argInfo.select ) {
			strncpy( argResult.strList[0].str,"true",sizeof( argResult.strList[0].str )-1 );
		} else {
			strncpy( argResult.strList[0].str,"false",sizeof( argResult.strList[0].str )-1 );
		}
	} else if( argInfo.dataType & PNLE_AOC_DataTypeSelectList ) {
		// �I�����X�g.
		argResult.num = (char)argInfo.selList.num;
		if( argResult.num > PNLD_AOSL_MaxListNum ) {
			argResult.num = PNLD_AOSL_MaxListNum;
		}
		if( argResult.num == 0 ) {
			switch( argType ) {
				case PNLE_AOCM_ControlTypeStringSelection:
				case PNLE_AOCM_ControlTypeSearchString:
					// �I�����X�g���Ȃ��Ă�Null��ݒ肷��.
					argResult.strList[0].str[0] = '\0';
					argResult.num = 1;
					break;
				default:
					break;
			}
		}

		for( i=0; i<argResult.num; i++ ) {
			switch( argType ) {
				case PNLE_AOCM_ControlTypeStringSelection:
				case PNLE_AOCM_ControlTypeSearchString:
					// ���O��Ԃ�.
					strncpy( argResult.strList[i].str,argInfo.selList.select[i].name,sizeof( argResult.strList[i].str )-1 );
					break;
				default:
					// ID��Ԃ�.
					strncpy( argResult.strList[i].str,argInfo.selList.select[i].ID,sizeof( argResult.strList[i].str )-1 );
					break;
			}
		}
	} else if( argInfo.dataType & PNLE_AOC_DataTypeDateTime ) {
		// ����.
		char strBuf[PNLD_AOC_StringTemp3];
		memset( strBuf,0,sizeof( strBuf ) );
		strncpy( strBuf,",,,,,,",sizeof( strBuf ) );
		if( argInfo.dateTime.e_Default == TYPE_ExtDateTimeDefaultSpecified ) {
			switch( argInfo.dateTime.e_Display ) {
				case TYPE_ExtDateTimeDisplayYMDHM:	// �N�������� .
					snprintf( strBuf, sizeof(strBuf), "%04d,%02d,%02d,%02d,%02d,,",
					         argInfo.dateTime.s_Value.ss_Year,
					         argInfo.dateTime.s_Value.sc_Month,argInfo.dateTime.s_Value.sc_Day,
					         argInfo.dateTime.s_Value.sc_Hour, argInfo.dateTime.s_Value.sc_Minute );
					break;
				case TYPE_ExtDateTimeDisplayYMD:	// �N���� .
					snprintf( strBuf, sizeof(strBuf), "%04d,%02d,%02d,,,,",
					         argInfo.dateTime.s_Value.ss_Year,
					         argInfo.dateTime.s_Value.sc_Month,argInfo.dateTime.s_Value.sc_Day );
					break;
				case TYPE_ExtDateTimeDisplayHM:		// ���� .
					snprintf( strBuf, sizeof(strBuf), ",,,%02d,%02d,,",
					         argInfo.dateTime.s_Value.sc_Hour, argInfo.dateTime.s_Value.sc_Minute );
					break;
				case TYPE_ExtDateTimeDisplayYMDHMZ:	// �N���������^�C���]�[�� .
					snprintf( strBuf, sizeof(strBuf), "%04d,%02d,%02d,%02d,%02d,%02d,%02d",
					         argInfo.dateTime.s_Value.ss_Year,
					         argInfo.dateTime.s_Value.sc_Month,argInfo.dateTime.s_Value.sc_Day,
					         argInfo.dateTime.s_Value.sc_Hour, argInfo.dateTime.s_Value.sc_Minute,
					         argInfo.dateTime.s_Value.s_TimeZone.sc_Hour,argInfo.dateTime.s_Value.s_TimeZone.sc_Minute );
					break;
				default: break;
			}
		}
		argResult.num = 1;
		strncpy( argResult.strList[0].str,strBuf,sizeof( argResult.strList[0].str )-1 );
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:������ϊ�(UTF8).
// Return Value					: void.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
void PCGC_AuthOapCustomBase::changeStringUTF8( const PNLS_AuthOapControlInfo& argInfo,
        PNLE_AOCM_ControlType argType,
        PNLS_AuthOapMultiStrResult& argResult )
{
	int i;
	memset( &argResult,0,sizeof( argResult ) );
	// ������ϊ�.
	changeString( argInfo,argType,argResult );
	// UTF8�ϊ�.
	char strBufUTF[PNLD_AOC_StringTemp];
	for( i=0; i<argResult.num; i++ ) {
		PnlComSetUTF8Str( ( const LIBE_CharSet )getCharSetForCAPI(),argResult.strList[i].str,strBufUTF,sizeof( strBufUTF ) - 1 );
		strncpy( argResult.strList[i].str,strBufUTF,sizeof( argResult.strList[i].str )-1 );
	}
}

//=================================================================================================================.
// Class					    : PCGC_AuthOapCustomBase.
// Overview						: �J�X�^����ʋ��ʕ�:������ϊ�(UTF8).
// ARG Value					: Bool True:�`�F�N�̂ݎ��{ False:�G���[���������{.
// Return Value					: Bool.
// Remarks						: .
// Reviews						: .
// Change History				: .
// History						: New class Implementation for (pcgauthoap1_CLCD.cpp - PCGC_AuthOapCustomBase).
//=================================================================================================================.
Bool PCGC_AuthOapCustomBase::checkErrInput( Bool bl_chk )
{
	uchar i;
	Bool bExist_err = False;

	for( i=0; i<ucMaxInfo; i++ ) {
		if( cControl[i] ) {
			const PNLS_AuthOapControlInfo* ctrlInfoBuf = getControlInfo( getControlInfoNo( ( uchar )( i + ucTopInfoNo ) ) );
			if( !ctrlInfoBuf ) { continue; }
			if( cControl[i]->checkErrInput( *ctrlInfoBuf ) ) {
				if( !bl_chk ) {
					// �R���g���[�����G���[��Ԃ�.
					cControl[i]->setError( True );
				}
				bExist_err = True;
			}
		}
	}
	if( bExist_err && !bl_chk ) {
		// �G���[��ԃZ�b�g.
		onlyPanel.setErrorNumberFieldPartsKind( EP_ErrorPartsKind_NumberField );
		bErrInput = True;
	}
	return bExist_err;
}




