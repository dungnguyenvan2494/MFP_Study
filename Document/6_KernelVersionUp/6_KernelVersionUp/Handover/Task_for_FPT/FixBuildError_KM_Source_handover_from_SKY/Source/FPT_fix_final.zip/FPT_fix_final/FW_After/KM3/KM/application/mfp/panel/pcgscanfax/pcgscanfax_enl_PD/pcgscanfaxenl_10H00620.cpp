//�N���X-----------------------------------------------------------------------------------------------------------------.
// �t�@�C�� : CHOP_10H00620_LDAP����_�������ʓo�^�m�F.
// Version  : PDV2 ver.004.
//-----------------------------------------------------------------------------------------------------------------------.
#define	SIZE( table )		( sizeof( table ) / sizeof( PDisplayParts* ) )
#include <panel/pcgscanfax/pcgscanfax_enl_CLCD2/pigscanfaxenl_p10H00.h>			//	PNLRFN_V2_ITEM_0001.
#include <panel/plibh/plibh_CLCD2/PNLC_EnlScanFax_VoiceDataLib.h>
#include <panel/plibh/plibh_CLCD2/PNLC_LdapSearchManager.h>
#include <panel/plibh/plibh_CLCD2/PNLC_FaxScanAddressSearchLib.h>
#include <panel/pcgcomponent/pcgcomponent_enl/PMessageAreaEnlComponent.h>
#include <panel/plibh/plibh_PD/plibh_PD.h>
#include <panel/ppcg/ppcg_PD/ppcg_PD.h>
#include <panel/pcgscanfax/pcgscanfax_enl_PD/pcgscanfaxenl_10H00550.h>
extern PPD_10H00550 gp_PD_10H00550;
#include <panel/pcgscanfax/pcgscanfax_enl_PD/pcgscanfaxenl_10H00620.h>
PNumberFieldEnl Num_EnlScanFax_LDAPSearchEntryResultPageNumberReal( sf_LDAPDetailDisplayPageReal, 640, 96, 24, 32, UC_GPARTS_COLOR_BLACK, "%3.0f", NULL, UC_FONT_SIZE_16, False, TYPE_LayoutFree, True, False, PNL_ENLARGE_X2xY2 );
static	PSinglePartsTextEnl Ktx_EnlScanFax_LDAPSearchEntryResultLDAPEntryResultPageSlash( s_Slash, 696, 96, 8, 16, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutFree, False, PNL_ENLARGE_X2xY2 );
PNumberFieldEnl Num_EnlScanFax_LDAPSearchEntryResultPageTotalCount( sf_LDAPDetailDisplayPageTotal, 712, 96, 24, 32, UC_GPARTS_COLOR_BLACK, "%3.0f", NULL, UC_FONT_SIZE_16, False, TYPE_LayoutFree, True, False, PNL_ENLARGE_X2xY2 );	// �y�[�W�����̐��l.
PSinglePartsResizableGraphic Btx_EnlScanFax_LDAPSearchEntryResultPageUpDown( tbl_ef00_013_000_X152_Y104, 624, 80,  TYPE_LayoutFree, False );	// �y�[�W�ԍ��Ɩ��w�i.
PButtonObject Key_EnlScanFax_LDAPSearchEntryResultPageUp( MSG_MSButton, BTNID_KEY_PREVPAGE_ENL, tbl_em30_005_000_X64_Y38, 704, 136,  NULL );	// ���L�[.
PButtonObject Key_EnlScanFax_LDAPSearchEntryResultPageDown( MSG_MSButton, BTNID_KEY_NEXTPAGE_ENL, tbl_em30_006_000_X64_Y38, 632, 136,  NULL );	// ���L�[.
static PSingleParts* const tbl_EnlScanFax_LDAPSearchEntryResultPageReal[] = {
	&Num_EnlScanFax_LDAPSearchEntryResultPageNumberReal,
	&Ktx_EnlScanFax_LDAPSearchEntryResultLDAPEntryResultPageSlash,
	&Num_EnlScanFax_LDAPSearchEntryResultPageTotalCount,
};
PObjectAdd Btx_EnlScanFax_LDAPSearchEntryResultPageReal( tbl_em00_005_002_X136_Y044, 632, 88, const_cast<PSingleParts**>( tbl_EnlScanFax_LDAPSearchEntryResultPageReal ), SIZE( tbl_EnlScanFax_LDAPSearchEntryResultPageReal ), True );
static PDisplayParts* const tbl_EnlScanFax_LDAPSearchEntryResultKeyScrollPage[] = {
	&Btx_EnlScanFax_LDAPSearchEntryResultPageUpDown,
	&Key_EnlScanFax_LDAPSearchEntryResultPageUp,
	&Key_EnlScanFax_LDAPSearchEntryResultPageDown,
	&Btx_EnlScanFax_LDAPSearchEntryResultPageReal,
};
PScrollPageEnlComponent Cmp_EnlScanFax_LDAPSearchEntryResultKeyScrollPage( const_cast<PDisplayParts**>( tbl_EnlScanFax_LDAPSearchEntryResultKeyScrollPage ), SIZE( tbl_EnlScanFax_LDAPSearchEntryResultKeyScrollPage ), 1, PNLE_ScrollPageEnl_DisplayType_NumberField );
#include "PD/PD_10H00620.cpp"
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageDown_Cur[] = { v_MSGPageDown_Cur };	//���@�L�[�I��.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageUp_Cur[] = { v_MSGPageUp_Cur };		//���@�L�[�I��.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultYes_Cur[] = { v_KEYYes_Cur };			//�͂��@�L�[�I��.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultNo_Cur[] = { v_KEYNo_Cur };				//�������@�L�[�I��.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultYes_Sel[] = { v_KEYYes_Sel };			//�͂��@�L�[�I������.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultNo_Sel[] = { v_KEYNo_Sel };				//�������@�L�[�I������.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageDown_Sel[] = { v_MSGPageDown_Sel };	//���@�L�[�I������.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageUp_Sel[] = { v_MSGPageUp_Sel };		//���@�L�[�I������.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultOk_Cur[] = { v_KEYOK_Cur };				//OK�L�[�@�L�[�I��.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchEntryResultOk_Sel[] = { v_KEYOK_Sel };				//OK�L�[�@�L�[�I������.
const ushort	tblVID_Exp_EnlScanFax_LDAPSearchEntryResult[] = { v_MSGRegisteredCheckOfAddress };	//�A�h���X��LDAP�����o�^�m�F���.
// ��ʂ��Ƃ̏��.
PNLS_VoiceCursorParts	tblVID_ScanFaxLDAPSearchEntryResult_Parts[] = {
	{ &Key_EnlScanFax_LDAPSearchEntryResultPageDown,	0,	{tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageDown_Cur,	tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageDown_Sel,NULL,NULL},
		{VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageDown_Cur ),VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageDown_Sel ),0,0}	, PNLE_VCDefaultCursor, PNLE_VCDefaultCursor},
	{ &Key_EnlScanFax_LDAPSearchEntryResultPageUp,	0,	{tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageUp_Cur,	tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageUp_Sel,NULL,NULL},
		{VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageUp_Cur ),VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultPageUp_Sel ),0,0}	, PNLE_VCDefaultCursor, PNLE_VCDefaultCursor},
	{ &PD_10H00620_Btn_SetYes,	0,	{tblVID_Key_EnlScanFax_LDAPSearchEntryResultYes_Cur,	tblVID_Key_EnlScanFax_LDAPSearchEntryResultYes_Sel,NULL,NULL},
		{VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultYes_Cur ),VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultYes_Sel ),0,0}	, PNLE_VCDefaultCursor, PNLE_VCDefaultCursor},
	{ &PD_10H00620_Btn_SetNo,	0,	{tblVID_Key_EnlScanFax_LDAPSearchEntryResultNo_Cur,	tblVID_Key_EnlScanFax_LDAPSearchEntryResultNo_Sel,NULL,NULL},
		{VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultNo_Cur ),VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultNo_Sel ),0,0}	, PNLE_VCDefaultCursor, PNLE_VCDefaultCursor},
	{ &PD_10H00620_Btn_OK,	0,	{tblVID_Key_EnlScanFax_LDAPSearchEntryResultOk_Cur,	tblVID_Key_EnlScanFax_LDAPSearchEntryResultOk_Sel,NULL,NULL},
		{VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultOk_Cur ),VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchEntryResultOk_Sel ),0,0}	, PNLE_VCDefaultCursor, PNLE_VCScanFaxLDAPSearchEntry},
};
PNLS_VoiceGamenInfo	 VGI_EnlScanFax_LDAPSearchEntryResult = { tblVID_ScanFaxLDAPSearchEntryResult_Parts,	VSTSZ( tblVID_ScanFaxLDAPSearchEntryResult_Parts ),
	tblVID_Exp_EnlScanFax_LDAPSearchEntryResult,	VIDSZ( tblVID_Exp_EnlScanFax_LDAPSearchEntryResult )};
// Component function mapping table.
PNLS_CompFuncMapping tblCompFunc_EnlScanFax_LDAPSearchEntryResult[] = {
	{ &Cmp_EnlScanFax_MessageArea, PNLE_EnlScanFax_FuncIDGetNone, PNLE_Key_EnlScanfax_None, 0 },
};
const short ss_CompFunc_EnlScanFax_LDAPSearchEntryResult = static_cast<short>(COMPFUNCTBL_SIZE( tblCompFunc_EnlScanFax_LDAPSearchEntryResult ));
static TYPC_ShorteningAddress c_NewRegistShorteningAddressLDAP;		// LDAP�������ʐV�K�o�^�p�Z�k����.
// �R���X�g���N�^.
PPD_10H00620::PPD_10H00620( PDisplayParts** partsTable, short partsNumber, Bool isNoWarningGamen, short ss_PosX, short ss_PosY, short ss_SizeX, short ss_SizeY )
	:PCGC_EnlScanFax_LDAPSearchCom( partsTable, partsNumber, isNoWarningGamen ), m_ss_Index( 0 ), m_ss_IndexOffset( 0 ), m_ss_IndexCounter( 0 ),
	m_ss_TotalSelectCounter( 0 ), m_i32_TotalPageNumber( 0 ), m_i32_NowPageNumber( 0 )
{
	memset( m_ss_EmptyIndex, 0, sizeof( m_ss_EmptyIndex ) );
	PNLC_EnlScanFax_VoiceDataLib* pc_ScanFaxVoiceLib = PNLC_EnlScanFax_VoiceDataLib::newInstance();
	if( NULL == pc_ScanFaxVoiceLib ) { return; }
	// Set parameters for voice guidance support.
	vgCtrl.setVoiceGuidance( this, pc_ScanFaxVoiceLib, tblCompFunc_EnlScanFax_LDAPSearchEntryResult,
							 ss_CompFunc_EnlScanFax_LDAPSearchEntryResult, NULL, 0, PNLE_EnlScanFax_LDAPSearchEntryResult );
}
// PanelDesigner�Ή�------------------------------------------------------------------------------------------------------.
// ��ʊJ�n����.
void PPD_10H00620::startGamen()
{
	bl_PanelDesigner = True;							// PanelDesigner�Ή�.
	PCGC_EnlScanFax_LDAPSearchCom::startGamen();		// �e�N���X�ďo��(������s��Ȃ���PopupWindow���\�����Ȃ�).
// �R�[���o�b�N�֐��̓o�^.
	ATTACH_OBSERVER( PPD_10H00620, gp_PD_10H00620, PPD_10H00620::prOk, PD_10H00620_Btn_OK, Bool, Bool );			//	OK.
	ATTACH_OBSERVER( PPD_10H00620, gp_PD_10H00620, PPD_10H00620::prYesNo, PD_10H00620_Rbt_YesNo, Bool, short );		//	YesNo.
// �ϐ����̏������������L�ڂ���.
	m_ss_IndexOffset = 0;
	m_ss_IndexCounter = 0;
	m_ss_TotalSelectCounter = 0;
	m_i32_TotalPageNumber = 0;
	m_i32_NowPageNumber = 0;
	m_ss_Index = 0;
	memset( m_ss_EmptyIndex, 0, sizeof( m_ss_EmptyIndex ) );
// �����ɍ\���ɂ��\���������L�ڂ���.
// �����ɉ�ʂ̏������������L�ڂ���.
	PD_10H00620_Bak_RegistNumberList1.showEnable( False );
	PD_10H00620_Bak_RegistNumberList2.showEnable( False );
	PD_10H00620_Bak_RegistNumberList3.showEnable( False );
	PD_10H00620_Bak_RegistNumberList4.showEnable( False );
	PD_10H00620_Bak_RegistNumberList5.showEnable( False );
	PD_10H00620_Bak_StorageNameList1.showEnable( False );
	PD_10H00620_Bak_StorageNameList2.showEnable( False );
	PD_10H00620_Bak_StorageNameList3.showEnable( False );
	PD_10H00620_Bak_StorageNameList4.showEnable( False );
	PD_10H00620_Bak_StorageNameList5.showEnable( False );
	PNLC_FaxScanAddressSearchLib::newInstance()->setupSearchResultLDAP( TYPE_LdapSearchGetListTypeFirst );
	PNLC_LdapSearchManager* c_FaxLdapSearchMgr = PNLC_LdapSearchManager::newInstance();
	for( short i = 1 ; i <= c_FaxLdapSearchMgr->getTotalSearchCount(); i++ ) {
		if( True == c_FaxLdapSearchMgr->getSelectAddressEnl( i ) ) {
			m_ss_TotalSelectCounter++;
		}
	}
	m_i32_TotalPageNumber = static_cast<int32_t>( m_ss_TotalSelectCounter / PCGD_EnlScanFaxLdapPageDataNum );
	if( ( m_ss_TotalSelectCounter % PCGD_EnlScanFaxLdapPageDataNum ) != 0 ) {
		m_i32_TotalPageNumber++;
	}
	Cmp_EnlScanFax_LDAPSearchEntryResultKeyScrollPage.setParent( this );							// Assign Screen instance to PScrollPageEnlComponent.
	Cmp_EnlScanFax_LDAPSearchEntryResultKeyScrollPage.setParentVoiceHandler( getVoiceHandler() );	//set voice handler into parent.
	Cmp_EnlScanFax_LDAPSearchEntryResultKeyScrollPage.setCallBackFunction( ans_ScrollPageKey );
	Cmp_EnlScanFax_LDAPSearchEntryResultKeyScrollPage.setMaxPage( static_cast<short>( m_i32_TotalPageNumber ) );
	Cmp_EnlScanFax_LDAPSearchEntryResultKeyScrollPage.setNowPage( 1 );
	getNextPage( True );
	PNLC_FaxScanAddressSearchLib::newInstance()->setAddressBookEntryStatus( False );
	PD_10H00620_Rbt_YesNo.setN( 0 );						//	������.
	setOkButtonForFunctionBadge( &PD_10H00620_Btn_OK );	// �@�\�o�b�`�{�^���������ɑ�ւ��������s���n�j�L�[��o�^.
}
// OK.
Bool PPD_10H00620::prOk( Bool on )
{
	if( 1 == PD_10H00620_Rbt_YesNo.getN() ) {
		pc_RegistrationLDAPCount.initSelectCount();																// �I������Ă��鈶�挏���ƃR�[���o�b�N�̉񐔂�������.
		pc_RegistrationLDAPCount.setSelectCount( m_ss_TotalSelectCounter );										// �I������Ă��鈶��̐����i�[.
		m_ss_Index = 0;
		m_ss_IndexOffset = 0;																					// ���̏�����.
		PNLC_FaxScanAddressSearchLib::newInstance()->setupSearchResultLDAP( TYPE_LdapSearchGetListTypeFirst );	// �擪�̃��X�g���擾.
		setAddressRegistration();																				// LDAP�������ʂ��A�h���X���ɓo�^����.
		// ���҂�����������ʂɑJ�ڂ���.// �����ݒ�.
		pc_ManageIGCWaitDisplay.initManageIGCWaitDisplay( PCGD_IGCDisplay_RegLDAP, &gp_PD_10H00620, getNowGamen() );
		nextWaitDisplay();
	} else {
		nextGamen = &gp_EnlScanFax_LDAPSearchEntry;																// 10H00610	  �X�L�����t�@�N�XLDAP����_�������ʓo�^.
	}
	return True;
}
// YesNo.
Bool PPD_10H00620::prYesNo( short n )
{
	switch( n ) {
		case 1:	PNLC_FaxScanAddressSearchLib::newInstance()->setAddressBookEntryStatus( True );		break;		// ����.
		case 0:	PNLC_FaxScanAddressSearchLib::newInstance()->setAddressBookEntryStatus( False );	break;		// ���Ȃ�.
		default:	break;
	}
	return True;
}
// �]������(��ʊO����)---------------------------------------------------------------------------------------------------.
// �R�[���o�b�N.
void PPD_10H00620::procCallBack( TYPE_PNL_CallBack option )
{
	PCGC_EnlScanFax_LDAPSearchCom::procCallBack( option );				// ��ʃN���X�̏���.
	if( option == TYPE_PNL_CallBack_ShorteningAddressRegistResult ) {	// �Z�k����o�^���ʂ̃R�[���o�b�N.
		if( c_ShorteningAddressRegistrationIGC.getRegistResult() == TYPE_COMMON_Result_SUC ) {		// �o�^���ʂ������̏ꍇ.
			pc_RegistrationLDAPCount.setCallbackCountUp();				// �R�[���o�b�N���Ԃ��Ă��������J�E���g.
			if( pc_RegistrationLDAPCount.getSelectCount() == pc_RegistrationLDAPCount.getCallbackCount() ) {	// �I�����ꂽ����̐��ƃR�[���o�b�N���Ԃ��Ă������������Ȃ�.
				pc_ManageIGCWaitDisplay.setDisplayFLGOff();				// ���҂�����������ʕ\���t���O�n�e�e.
				TYPS_SEARCH_ADDRESS_NUM_INFO s_SearchAddressNumInfo;	// �o�^�ς݈��挏���v�����w��.
				s_SearchAddressNumInfo.pC_user = PnlComGetUser();		// ���[�U�[���擾.
				s_SearchAddressNumInfo.e_InspectLogIF = TYPE_InspectLogIfOperationPanel;						// �v������ (�č����O I/F)�̓p�l��.
				s_SearchAddressNumInfo.e_addrDataKind = TYPE_AddressSearchDivisionShort;						// �A�h���X��ނ͒Z�k����.
				s_SearchAddressNumInfo.e_Owner = TYPE_ADDR_OWNER_KIND_PUBLIC;									// ���L�҂�Public.
				c_RegisteredAddressNumSearchIGC.requestRegisteredAddressNumSearch( &s_SearchAddressNumInfo );	// ����o�^�ς݈��挏���̌����J�n�v��.
				// ���҂�����������ʂɑJ�ڂ���.// �����ݒ�.
				pc_ManageIGCWaitDisplay.initManageIGCWaitDisplay( PCGD_IGCDisplayStandard, &gp_PD_10H00550, getNowGamen() );
				nextWaitDisplay();
				return;
			}
			setAddressRegistration();									// �A�h���X���ɒZ�k�����o�^.
		}
	} else if( option == TYPE_PNL_CallBack_ShorteningAddressRegistResultVoice ) {
		nextGamen = &gp_PD_10H00550;					// 10H00550	  �X�L�����t�@�N�XLDAP����_�F�ؐ���.
	}
}
// �X�N���[���o�[�̃R�[���o�b�N.
void PPD_10H00620::ans_ScrollPageKey( short ss_PageNo, uchar uc_Option )
{
	if( 1 == gp_PD_10H00620.m_i32_TotalPageNumber ) { return; }			// 1�y�[�W�������݂��Ȃ��ꍇ�ɂ̓y�[�W�X�V�͍s��Ȃ�.
	Bool b_IsNextPage = False;
	if( ss_PageNo < gp_PD_10H00620.m_i32_NowPageNumber ) {
		if( gp_PD_10H00620.m_i32_NowPageNumber== gp_PD_10H00620.m_i32_TotalPageNumber && gp_PD_10H00620.m_i32_NowPageNumber - 1 > ss_PageNo ) {
			b_IsNextPage = True;
		} else {
			b_IsNextPage = False;
		}
	} else if( ss_PageNo > gp_PD_10H00620.m_i32_NowPageNumber ) {
		if( gp_PD_10H00620.m_i32_NowPageNumber== 1 && gp_PD_10H00620.m_i32_NowPageNumber + 1 < ss_PageNo ) {
			b_IsNextPage = False;
		} else {
			b_IsNextPage = True;
		}
	}
	gp_PD_10H00620.getNextPage( b_IsNextPage );
}
// ��ʌŗL����-----------------------------------------------------------------------------------------------------------.
// ���̃A�h���X�擾.
void PPD_10H00620::getNextAddr( Bool b_Nextpage )
{
	short ss_PreIndex = m_ss_Index;	short ss_Index = 0;
	PNLC_LdapSearchManager* c_FaxLdapSearchMgr = PNLC_LdapSearchManager::newInstance();
	if( b_Nextpage == True ) {	// ������擾.
		ss_Index = ss_PreIndex;
		m_ss_IndexCounter = 0;
		for( short i = 1; i <= c_FaxLdapSearchMgr->getTotalSearchCount(); i++ ) {
			if( ss_Index == c_FaxLdapSearchMgr->getTotalSearchCount() ) {
				ss_Index = 1;
			} else {
				ss_Index++;
			}
			if( m_ss_Index != 0 ) {
				m_ss_IndexOffset++;
				if( 1 == ss_Index ) {
					m_ss_IndexCounter++;
					m_ss_IndexOffset = 0;
				}
			} else {
				m_ss_Index = 1;
			}
			if( PCGD_EnlScanFaxLdapPageDataNum == m_ss_IndexOffset ) {
				m_ss_IndexCounter++;
				m_ss_IndexOffset = 0;
			}
			if( True == c_FaxLdapSearchMgr->getSelectAddressEnl( ss_Index ) ) {
				m_ss_Index = ss_Index;
				while( 0 != m_ss_IndexCounter ) {
					PNLC_FaxScanAddressSearchLib::newInstance()->setupSearchResultLDAP( TYPE_LdapSearchGetListTypeNext );
					m_ss_IndexCounter--;
				}
				break;
			}
		}
	} else {	// �O����擾.
		ss_Index = ss_PreIndex;
		m_ss_IndexCounter = 0;
		for( short i = 1; i <= c_FaxLdapSearchMgr->getTotalSearchCount(); i++ ) {
			if( ss_Index == 1 ) {
				ss_Index = c_FaxLdapSearchMgr->getTotalSearchCount();
			} else {
				ss_Index--;
			}
			m_ss_IndexOffset--;
			if( c_FaxLdapSearchMgr->getTotalSearchCount() == ss_Index ) {
				short ss_OffsetWork = 0;
				m_ss_IndexCounter++;
				ss_OffsetWork = ss_Index / PCGD_EnlScanFaxLdapPageDataNum;
				if( ( ss_Index % PCGD_EnlScanFaxLdapPageDataNum ) != 0 ) {
					ss_OffsetWork++;
				}
				m_ss_IndexOffset = static_cast<short>( ( ss_Index - 1 ) - ( ( ss_OffsetWork - 1 ) * PCGD_EnlScanFaxLdapPageDataNum ) );
			}
			if( 0 > m_ss_IndexOffset ) {
				m_ss_IndexCounter++;
				m_ss_IndexOffset = PCGD_EnlScanFaxLdapPageDataNum - 1;
			}
			if( True == c_FaxLdapSearchMgr->getSelectAddressEnl( ss_Index ) ) {
				m_ss_Index = ss_Index;
				while( 0 != m_ss_IndexCounter ) {
					PNLC_FaxScanAddressSearchLib::newInstance()->setupSearchResultLDAP( TYPE_LdapSearchGetListTypePrevious );
					m_ss_IndexCounter--;
				}
				break;
			}
		}
	}
}
// ���̃y�[�W�擾.
void PPD_10H00620::getNextPage( Bool b_Nextpage )
{
	PObjectAdd* const pc_EntryNumTbl[] = {
		&PD_10H00620_Bak_RegistNumberList1, &PD_10H00620_Bak_RegistNumberList2, &PD_10H00620_Bak_RegistNumberList3, &PD_10H00620_Bak_RegistNumberList4, &PD_10H00620_Bak_RegistNumberList5,
	};
	PObjectAdd* const pc_EntryNameTbl[] = {
		&PD_10H00620_Bak_StorageNameList1, &PD_10H00620_Bak_StorageNameList2, &PD_10H00620_Bak_StorageNameList3, &PD_10H00620_Bak_StorageNameList4, &PD_10H00620_Bak_StorageNameList5,
	};
	const uchar uc_EntryNameTbl = static_cast<uchar>( sizeof( pc_EntryNameTbl ) / sizeof( PObjectAdd* ) );	short ss_LastOffset = 0;
	for( short i = 0; i < uc_EntryNameTbl; i++ ) {
		pc_EntryNumTbl[ i ]->showEnable( False );
		pc_EntryNameTbl[ i ]->showEnable( False );
	}
	if( b_Nextpage == True ) {	// ���y�[�W���擾.
		m_i32_NowPageNumber = ( m_i32_TotalPageNumber <= m_i32_NowPageNumber ) ? 1 : ( m_i32_NowPageNumber + 1 );
		getNextAddr( True );	// ������擾.
	} else {					// �O�y�[�W���擾.
		if( m_i32_TotalPageNumber == m_i32_NowPageNumber ) {			// �ŏI�y�[�W�̏ꍇ.
			ss_LastOffset = static_cast<short>( ( m_ss_TotalSelectCounter - 1 ) - ( ( m_i32_TotalPageNumber - 1 ) * PCGD_EnlScanFaxLdapPageDataNum ) );
		} else {													// �ŏI�y�[�W�ȊO�̏ꍇ.
			ss_LastOffset = PCGD_EnlScanFaxLdapPageDataNum - 1;
		}
		m_i32_NowPageNumber = ( 1 >= m_i32_NowPageNumber ) ? m_i32_TotalPageNumber : ( m_i32_NowPageNumber - 1 );		// �y�[�W�ԍ��ؑ�.
		short ss_DecCount;
		if( m_i32_TotalPageNumber == m_i32_NowPageNumber ) {			// �ŏI�y�[�W�̏ꍇ.
			ss_DecCount = static_cast<short>( ss_LastOffset + ( ( m_ss_TotalSelectCounter - 1 ) - ( ( m_i32_TotalPageNumber - 1 ) * PCGD_EnlScanFaxLdapPageDataNum ) ) + 1 );
		} else {													// �ŏI�y�[�W�ȊO�̏ꍇ.
			ss_DecCount = static_cast<short>( ss_LastOffset + PCGD_EnlScanFaxLdapPageDataNum );
		}
		for( short i = 0; i <ss_DecCount; i++ ) {
			getNextAddr( False );	// �O����擾.
		}
	}
	ss_LastOffset = static_cast<short>( ( m_ss_TotalSelectCounter - 1 ) - ( ( m_i32_NowPageNumber - 1 ) * PCGD_EnlScanFaxLdapPageDataNum ) );	//	�ŏI�y�[�W�̍ŏI����̃I�t�Z�b�g���擾.
	Bool b_Check = False;	short ss_DispIndex = 0;
	TYPE_CharSet e_CharSet = getCharSetForCAPI();	// UTF8�Ή��p�̃t�H���g�l���擾.
	EP_CharSet e_CharSetForPanel = getCharSetForPanel();
	LIBC_List<TYPS_LdapSearchResult>* c_ResultList = PNLC_FaxScanAddressSearchLib::newInstance()->getResultListLDAP();	//LDAP Search Result List.
	while( b_Check == False ) {
		TYPS_LdapSearchResult* ps_LdapSearchResult;	short ss_OffsetCount = 0;
		c_ResultList->Lock();
		ps_LdapSearchResult = c_ResultList->findFirst();
		while( NULL != ps_LdapSearchResult ) {
			if( ss_OffsetCount == m_ss_IndexOffset ) {
				break;
			}
			ss_OffsetCount++;
			ps_LdapSearchResult = c_ResultList->findNext();
		}
		c_ResultList->UnLock();
		if( ps_LdapSearchResult == NULL ) { return; }
		pc_EntryNumTbl[ ss_DispIndex ]->showEnable( True );
		pc_EntryNameTbl[ ss_DispIndex ]->showEnable( True );
		char sc_work[ 5 + 1 ];
		ushort us_strIndex = static_cast<ushort>(ss_DispIndex + ( m_i32_NowPageNumber - 1 ) * uc_EntryNameTbl + 1);	// �ʂ��ԍ�.
		snprintf( sc_work, sizeof( sc_work ), "%04d", us_strIndex );
		pc_EntryNumTbl[ ss_DispIndex ]->changeASCIIText( reinterpret_cast<uchar*>(sc_work), ( sizeof( sc_work )-1 ) );
		short ss_LDAPDispSelect = PNLC_FaxScanAddressSearchLib::newInstance()->getSelectedLDAPDispDestination();
		if( 0 < strlen( ps_LdapSearchResult->sc_SearchNameUTF8 ) ) {
			char sc_NameUTF8Temporary[ 255 + 1 ] = { 0 };
			PnlComGetUTF8Str( ps_LdapSearchResult->sc_SearchNameUTF8, static_cast<LIBE_CharSet>(e_CharSet), sc_NameUTF8Temporary, sizeof( sc_NameUTF8Temporary ) );
			pc_EntryNameTbl[ ss_DispIndex ]->changeExternalText( reinterpret_cast<uchar*>(SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max,
				sc_NameUTF8Temporary, static_cast<short>(0), e_CharSetForPanel )) );
		} else if( 0 < strlen( ps_LdapSearchResult->sc_SearchLastNameUTF8 ) ) {
			char sc_LastNameUTF8Temporary[ 63 + 1 ] = { 0 };
			PnlComGetUTF8Str( ps_LdapSearchResult->sc_SearchLastNameUTF8, static_cast<LIBE_CharSet>(e_CharSet), sc_LastNameUTF8Temporary, sizeof( sc_LastNameUTF8Temporary ) );
			SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max, sc_LastNameUTF8Temporary, static_cast<short>(0), e_CharSetForPanel );
			pc_EntryNameTbl[ ss_DispIndex ]->changeExternalText( reinterpret_cast<uchar*>(SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max,
				sc_LastNameUTF8Temporary, static_cast<short>(0), e_CharSetForPanel )) );
		} else if( 0 < strlen( ps_LdapSearchResult->sc_SearchFirstNameUTF8 ) ) {
			char sc_FirstNameUTF8Temporary[ 63 + 1 ] = { 0 };
			PnlComGetUTF8Str( ps_LdapSearchResult->sc_SearchFirstNameUTF8, static_cast<LIBE_CharSet>(e_CharSet), sc_FirstNameUTF8Temporary, sizeof( sc_FirstNameUTF8Temporary ) );
			pc_EntryNameTbl[ ss_DispIndex ]->changeExternalText( reinterpret_cast<uchar*>(SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max,
				sc_FirstNameUTF8Temporary, static_cast<short>(0), e_CharSetForPanel )) );
			// I-FAX��LDAP�������ʂ�E-mail�����I=FAX�Ƃ��ēo�^���邽�߁AE-mai,I-FAX�\������E-mail��o�^���Ƃ���.
			// I-FAX is registered name E-mail. So both are handled together.
		} else if( ( 0 < strlen( ps_LdapSearchResult->sc_SearchMailAddress ) ) && ( PNLD_ENLSCANFAX_LDAPSELECTFAX != ss_LDAPDispSelect ) ) {
			char sc_MailAddressTemporary[ TYPD_MaxMailAddress + 1 ] = { 0 };
			PnlComGetUTF8Str( ps_LdapSearchResult->sc_SearchMailAddress, static_cast<LIBE_CharSet>(e_CharSet), sc_MailAddressTemporary, sizeof( sc_MailAddressTemporary ) );
			SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max,sc_MailAddressTemporary, static_cast<short>(0), e_CharSetForPanel );
			pc_EntryNameTbl[ ss_DispIndex ]->changeExternalText( reinterpret_cast<uchar*>(SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max,
				sc_MailAddressTemporary, static_cast<short>(0), e_CharSetForPanel )) );
		} else if( ( 0 < strlen( ps_LdapSearchResult->sc_SearchFaxNoUTF8 ) ) && ( PNLD_ENLSCANFAX_LDAPSELECTFAX == ss_LDAPDispSelect ) ) {
			char sc_FaxNoUTF8Temporary[ 63 + 1 ] = { 0 };
			PnlComGetUTF8Str( ps_LdapSearchResult->sc_SearchFaxNoUTF8, static_cast<LIBE_CharSet>(e_CharSet), sc_FaxNoUTF8Temporary, sizeof( sc_FaxNoUTF8Temporary ) );
			pc_EntryNameTbl[ ss_DispIndex ]->changeExternalText( reinterpret_cast<uchar*>(SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max,
				sc_FaxNoUTF8Temporary, static_cast<short>(0), e_CharSetForPanel )) );
		} else {	// ��L�S�Ă̏�񂪑��݂��Ȃ��ꍇ.
			pc_EntryNameTbl[ ss_DispIndex ]->changeExternalText( reinterpret_cast<const uchar*>("") );
		}
		if( m_i32_TotalPageNumber == m_i32_NowPageNumber ) {			// �ŏI�y�[�W�̏ꍇ.
			ss_LastOffset = static_cast<short>( ( m_ss_TotalSelectCounter - 1 ) - ( ( m_i32_NowPageNumber - 1 ) * PCGD_EnlScanFaxLdapPageDataNum ) );
			if( ss_DispIndex == ss_LastOffset ) {
				b_Check = True;
			}
		} else {													// �ŏI�y�[�W�ȊO�̏ꍇ.
			if( ( PCGD_EnlScanFaxLdapPageDataNum - 1 ) == ss_DispIndex ) {
				b_Check = True;
			}
		}
		if( False == b_Check ) {
			ss_DispIndex++;
			getNextAddr( True );
		}
	}
}
// �A�h���X�o�^.
void PPD_10H00620::setAddressRegistration()
{
	PNLC_LdapSearchManager* c_FaxLdapSearchMgr = PNLC_LdapSearchManager::newInstance();
	TYPC_ShorteningAddress* pc_ShorteningAddress = &c_NewRegistShorteningAddressLDAP;													// LDAP�������ʐV�K�o�^.
	char sc_SetWork[ 73 ] = { 0 };
	LIBC_List<TYPS_LdapSearchResultSmime> c_ResultListSmime = PNLC_FaxScanAddressSearchLib::newInstance()->getResultListSmimeLDAP();	//Smime Result.
	LIBC_List<TYPS_LdapSearchResult>* c_ResultList = PNLC_FaxScanAddressSearchLib::newInstance()->getResultListLDAP();					//LDAP Search Result List.
	pc_ShorteningAddress->clearAddress();
	getNextAddr( True );
	TYPS_LdapSearchResult* ps_LdapSearchResultValue;	short ss_OffsetCount = 0;
	c_ResultList->Lock();
	ps_LdapSearchResultValue = c_ResultList->findFirst();
	while( NULL != ps_LdapSearchResultValue ) {
		if( ss_OffsetCount == m_ss_IndexOffset ) {
			break;
		}
		ss_OffsetCount++;
		ps_LdapSearchResultValue = c_ResultList->findNext();
	}
	c_ResultList->UnLock();
	if( ps_LdapSearchResultValue == NULL ) { return; }
	ps_LdapSearchResult s_LdapSearchResultString = c_FaxLdapSearchMgr->setupResultFromUTF8API( ps_LdapSearchResultValue );
	short ss_LDAPDispSelect = PNLC_FaxScanAddressSearchLib::newInstance()->getSelectedLDAPDispDestination();
	if( 0 < strlen( ps_LdapSearchResultValue->sc_SearchNameUTF8 ) ) {
		pc_ShorteningAddress->setAddressNameUTF8( SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max, s_LdapSearchResultString.sc_NameResultString,
			static_cast<short>(0), getCharSetForPanel() ), TYPE_CharSetUTF8 );
	} else if( 0 < strlen( ps_LdapSearchResultValue->sc_SearchLastNameUTF8 ) ) {
		pc_ShorteningAddress->setAddressNameUTF8( SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max, s_LdapSearchResultString.sc_LastNameResultString,
			static_cast<short>(0), getCharSetForPanel() ), TYPE_CharSetUTF8 );
	} else if( 0 < strlen( ps_LdapSearchResultValue->sc_SearchFirstNameUTF8 ) ) {
		pc_ShorteningAddress->setAddressNameUTF8( SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max, s_LdapSearchResultString.sc_FirstNameResultString,
			static_cast<short>(0), getCharSetForPanel() ), TYPE_CharSetUTF8 );
	} else if( ( 0 < strlen( ps_LdapSearchResultValue->sc_SearchMailAddress ) ) && ( PNLD_ENLSCANFAX_LDAPSELECTFAX != ss_LDAPDispSelect ) ) {
		pc_ShorteningAddress->setAddressNameUTF8( SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max, s_LdapSearchResultString.sc_MailAddressResultString,
			static_cast<short>(0), getCharSetForPanel() ), TYPE_CharSetUTF8 );
	} else if( ( 0 < strlen( ps_LdapSearchResultValue->sc_SearchFaxNoUTF8 ) ) && ( PNLD_ENLSCANFAX_LDAPSELECTFAX == ss_LDAPDispSelect ) ) {
		pc_ShorteningAddress->setAddressNameUTF8( SetupInputString( PCGD_SenderAddressLine1Max, PCGD_SenderAddressFont5Max, s_LdapSearchResultString.sc_FaxNoResultString,
			static_cast<short>(0), getCharSetForPanel() ), TYPE_CharSetUTF8 );
	} else {	// ��L�S�Ă̏�񂪑��݂��Ȃ��ꍇ.
		pc_ShorteningAddress->setAddressNameUTF8( "", TYPE_CharSetUTF8 );
	}
	switch( ss_LDAPDispSelect ) {
		case PNLD_ENLSCANFAX_LDAPSELECTFAX: {	// �t�@�N�X����\����.
			pc_ShorteningAddress->setSendMode( TYPE_SendModeFax );			// ��ʂ̐ݒ�(G3-FAX).
			TYPS_FaxAddress s_FaxAddress;	char sc_FaxNoResultString[ 63 + 1 ] = { 0 };
			strncpy( sc_FaxNoResultString, s_LdapSearchResultString.sc_FaxNoResultString, 38 );
			setupInputString( PCGD_SenderAddressLine1Max, ( 38 + 1 ), sc_FaxNoResultString, s_FaxAddress.sc_DialNo, static_cast<short>(0), getCharSetForPanel() );
			pc_ShorteningAddress->setFaxAddress( s_FaxAddress );
			TYPS_FaxSendInfo s_FaxSendInfo;
			s_FaxSendInfo.b_FaxSendInfoOn = True;																					// FAX����ʐݒ�L��/����.
			s_FaxSendInfo.b_EcmOff = c_JobSpecFaxDefult.pc_Fax->c_FaxCommon.getEcmModeOn();											// �d�b�l�I�t.
			s_FaxSendInfo.b_InternationalOn = c_JobSpecFaxDefult.pc_Fax->c_FaxCommon.getOverseasModeOn();							// �C�O�ʐM���[�h.
			s_FaxSendInfo.b_V34Off = c_JobSpecFaxDefult.pc_Fax->c_FaxCommon.getV34ModemModeOn();									// V34�I�t.
			s_FaxSendInfo.uc_CommunicationLine = static_cast<TYPE_CommunicationLine>(c_JobSpecFaxDefult.pc_Fax->c_FaxCommon.getCommLine());	// ����ݒ�.
			pc_ShorteningAddress->setFaxSendInfo( s_FaxSendInfo );
			break;
		}
		case PNLD_ENLSCANFAX_LDAPSELECTEMAIL: {	// E-Mail����\����.
			pc_ShorteningAddress->setSendMode( TYPE_SendModeEmail );
			TYPS_MailAddress s_MailAddress;
			setupInputString( PCGD_SenderAddressLine1Max, TYPD_MaxMailAddress, s_LdapSearchResultString.sc_MailAddressResultString, s_MailAddress.sc_MailToAddress,
				static_cast<short>(0), getCharSetForPanel() );
			pc_ShorteningAddress->setMailAddress( s_MailAddress );
			break;
		}
		case PNLD_ENLSCANFAX_LDAPSELECTIFAX: {	// I-Fax.
			pc_ShorteningAddress->setSendMode( TYPE_SendModeIfax );
			TYPS_MailAddress s_MailAddress;
			setupInputString( PCGD_SenderAddressLine1Max, TYPD_MaxMailAddress, s_LdapSearchResultString.sc_MailAddressResultString,
				s_MailAddress.sc_MailToAddress, static_cast<short>(0), getCharSetForPanel() );
			pc_ShorteningAddress->setIfaxAddress( s_MailAddress );										// I-Fax����.
			pc_ShorteningAddress->setIfaxSendInfo( c_JobControl.getDefaultIfaxPartnerReceptAbility() );	// ����@��M�\�͂��f�t�H���g�N���A.
			break;
		}
		default:	break;
	}
	pc_ShorteningAddress->setSearchKey( TYPE_SearchKeyNumOther );
	char sc_WorkText[ PCGD_SenderAddressFont5Max + 1 ];
	toUpperString( sc_SetWork, sc_WorkText );
	uchar us_startNum = ( PnlComGetMachineSetting()->getSystemType() == TYPE_SystemType_JP ) ? 0 : PCGD_ScanLdapSearchHiragana;
	for( short j = us_startNum; j < us_LDAPSearchCharTbl; j++ ) {
		char* psc_Result = strstr( sc_WorkText, s_LDAPSearchCharTbl[ j ].sc_SearchChar );
		if( sc_WorkText == psc_Result ) {
			pc_ShorteningAddress->setSearchKey( s_LDAPSearchCharTbl[ j ].e_SearchKey );
			break;
		}
	}
	pc_ShorteningAddress->setOftenUsed( False );
	APIC_Job* pc_Job = PnlComGetJobScanFax();
	if( NULL == pc_Job ) { return; }
	TYPC_JobSpec* pc_JobSpec = pc_Job->getJobSpec();
	if( NULL == pc_JobSpec ) { return; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { return; }
	if( ( PnlComGetCertificationState() == True ) && ( PnlComGetMyAddressFuncOnOffState() == True ) ) {
		TYPE_AddressKind e_AddressKind = PNLC_FaxScanAddressSearchLib::newInstance()->getAddressKind();
		if( e_AddressKind == TYPE_AddressKind_Common ) {								// �u���L�v�L�[���I������Ă����ꍇ.
			pc_ShorteningAddress->setOwnerKind( TYPE_ADDR_OWNER_KIND_PUBLIC );			// ���L�҂�Public.
		} else if( e_AddressKind == TYPE_AddressKind_Private ) {						// �u�l����v�L�[���I������Ă����ꍇ.
			pc_ShorteningAddress->setOwnerKind( TYPE_ADDR_OWNER_KIND_MY );				// ���L�҂�My.
		} else { }																		// ���̑�.
	} else {
		pc_ShorteningAddress->setOwnerKind( TYPE_ADDR_OWNER_KIND_PUBLIC );				// ���L�҂�Public.
	}
	pc_ShorteningAddress->setDisplayNo( 0 );											// �o�^�ԍ��́g0�h.
	TYPS_ShorteningAddress_Icon s_ShorteningAddress_Icon;								// �Z�k����A�C�R�����.
	s_ShorteningAddress_Icon.e_ImageType = TYPE_ADDRESS_ICON_TYPE_ICON;					// �A�C�R�����F�\���C���[�W��ʁF�o�^�A�C�R��.
	s_ShorteningAddress_Icon.us_IconID = PNLD_ShortAddressIconID01;						// �A�C�R�����F�A�C�R��ID�F�f�t�H���g�A�C�R��.
	for( ushort lcnt = 0; lcnt < TYPD_ADDR_PHOTO_SIZE; lcnt++ ) {
		s_ShorteningAddress_Icon.uc_PhotoData[ lcnt ] = 0x00;							// �A�C�R�����F�ʐ^�f�[�^�FNULL���.
	}
	pc_ShorteningAddress->setIcon( s_ShorteningAddress_Icon );							// �A�C�R������ݒ�.
	// �I�������Z�k���悪E-Mail���M���悩���[���Í���ON�̎�.
	if( PNLD_ENLSCANFAX_LDAPSELECTEMAIL == ss_LDAPDispSelect && True == pc_Send->c_MailSend.getSmimeEnableCrypt() ) {
		TYPS_LdapSearchResultSmime* ps_LdapSearchResultSmime;	TYPS_SmimeCertInfo ps_SmimeCertInfo;	TYPS_SmimeCert_REGIST_INFO ps_SmimeCert_REGIST_INFO;
		c_ResultListSmime.Lock();
		ps_LdapSearchResultSmime = c_ResultListSmime.findFirst();
		if( NULL == ps_LdapSearchResultSmime ) {
			c_ResultListSmime.UnLock();
			return;
		}
		for( short ss_i = 0; ss_i < ss_OffsetCount; ss_i++ ) {
			ps_LdapSearchResultSmime = c_ResultListSmime.findNext();
		}
		c_ResultListSmime.UnLock();
		if( NULL == ps_LdapSearchResultSmime ) { return; }
		if( 0 == ps_LdapSearchResultSmime->ss_x509size ) { return; }
		ps_SmimeCertInfo.ss_x509size = ps_LdapSearchResultSmime->ss_x509size;		// ���X�g���ێ�����ؖ�����NVRAM�ɐݒ肷��חp�̗̈�ɐ؂�ւ�.
		memcpy( ps_SmimeCertInfo.sc_x509, ps_LdapSearchResultSmime->sc_x509, TYPD_SmimeCert );
		ps_SmimeCert_REGIST_INFO.pC_user = PnlComGetUser();							// ���[�U���.
		ps_SmimeCert_REGIST_INFO.pC_track = PnlComGetTrack();						// ������.
		ps_SmimeCert_REGIST_INFO.e_InspectLogIF = JLGE_InspectLogIfOperationPanel;	// �v������ (�č����O I/F).
		ps_SmimeCert_REGIST_INFO.e_RegistrationType = TYPE_RegistrationTypeOnlyOne;	// �o�^����.
		pc_ShorteningAddress->setSmimeCertInfo( &ps_SmimeCertInfo, &ps_SmimeCert_REGIST_INFO );						// smime�ؖ�������ݒ�.
	}
	TYPS_ADDRESS_REQUEST_INFO s_AddressRequestInfo;									// ����v�����.
	s_AddressRequestInfo.pC_user = PnlComGetUser();									// ���[�U���.
	s_AddressRequestInfo.pC_track = PnlComGetTrack();								// ������.
	s_AddressRequestInfo.e_InspectLogIF = JLGE_InspectLogIfOperationPanel;			// �v������ (�č����O I/F).
	s_AddressRequestInfo.e_RegistrationType = TYPE_RegistrationTypeOnlyOne; 		// �o�^����.
	s_AddressRequestInfo.b_NoInspectionLog = False;									// �č����O�L�^.
	c_ShorteningAddressRegistrationIGC.requestAddressRegist( pc_ShorteningAddress, True, &s_AddressRequestInfo );	// �o�^�v��.
}
// �������ݒ�.
void PPD_10H00620::setVoiceGamenInfo()
{
	m_pstVoiceGamenInfo = &VGI_EnlScanFax_LDAPSearchEntryResult;
	PCGC_EnlScanFax_LDAPSearchCom::setVoiceGamenInfo();
}
