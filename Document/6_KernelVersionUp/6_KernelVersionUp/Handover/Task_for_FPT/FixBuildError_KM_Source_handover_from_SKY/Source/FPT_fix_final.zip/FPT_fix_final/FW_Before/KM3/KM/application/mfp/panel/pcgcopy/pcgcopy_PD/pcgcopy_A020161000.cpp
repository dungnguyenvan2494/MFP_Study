//�N���X-----------------------------------------------------------------------------------------------------------------.
// �t�@�C�� : CHOP_A020161000_OHP����.
// Version  : PD ver.016.
//-----------------------------------------------------------------------------------------------------------------------.
#include <panel/pddgrap/pddgrap_CLCD/pddgrapinclude_CLCD.h>
#include <panel/pddgrap/pddgrap_CLCD/pddgraptbl.h>
#include <panel/pddtext/pddtext_CLCD/pstr_CLCD.h>
#include <panel/pddtext/pddtext_CLCD/psstr_CLCD.h>
#include <panel/pddtext/pddtext_CLCD/pfstr_CLCD.h>
#include <panel/ppcg/ppcg_CLCD2/ppcgformsettingbutton_CLCD2.h>
#include <panel/pcgcomponent/pcgcomponentg/PSmallMachineComponent.h>
#include <panel/plibh/plibh_PD/PNLC_SelectPaperTray_PD.h>
#include <panel/plibh/plibh_CLCD2/plibh_CLCD2.h>
#include <panel/plibh/plibhg/pdpcomb.h>
#include <panel/plibh/plibh_CLCD2/PNLC_StackManJobSpec.h>
#include <panel/pcgwarn/pcgwarng/pctwarng.h>
#include <panel/pcgwarn/pcgwarn_CLCD2/pctwarn_CLCD2.h>
#include <panel/pcgcopy/pcgcopy_PD/pcgcopy_A020161000.h>
#define SIZE(table)	(sizeof(table) / sizeof(PDisplayParts*))
#define PNLD_Cmp_AuxilPageOHPIns_copy_SmallMachine	const_cast<PDisplayParts**>( tbl_SmallMachineParts ), static_cast<uchar>( ss_SmallMachinePars ), 20, 111
#define PNLD_Key_AuxilPageOHPIns_copy_Tray1	MSG_MSButton, 24, tbl_m30_075_000_X128_Y40, 180, 80, const_cast<PSingleParts**>( tbl_AuxilPageOHPIns_copy_Tray1 ), SIZE(tbl_AuxilPageOHPIns_copy_Tray1), True, PNLE_Shadow_Parts_2
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray1	s_pNOTTray1_W032H040A, 180, 80, 32, 40, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutCentering, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray1_FreeIcon	tbl_i00_275_000_X16_Y16, 180, 80, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray1_Sheet	s_pNOTA4SEF_W068H036A, 180, 80, 68, 36, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray1_X	s_pNOTXEdge_W016H016A, 180, 80, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray1_Y	s_pNOTXEdge_W016H016A, 180, 80, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Num_AuxilPageOHPIns_copy_Tray1_X_Num	SF_TEXT_DYNAMIC_ALLOC, 180, 80, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Num_AuxilPageOHPIns_copy_Tray1_Y_Num	SF_TEXT_DYNAMIC_ALLOC, 180, 80, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray1_Icon2	tbl_i00_270_000_X16_Y16, 180, 80, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray1_Icon1	tbl_i00_273_000_X16_Y16, 180, 80, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Key_AuxilPageOHPIns_copy_Tray2	MSG_MSButton, 19, tbl_m30_075_000_X128_Y40, 180, 128, const_cast<PSingleParts**>( tbl_AuxilPageOHPIns_copy_Tray2 ), SIZE(tbl_AuxilPageOHPIns_copy_Tray2), True, PNLE_Shadow_Parts_2
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray2	s_pNOTTray2_W032H040A, 180, 128, 32, 40, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutCentering, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray2_FreeIcon	tbl_i00_275_000_X16_Y16, 180, 128, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray2_Sheet	s_pNOTA4SEF_W068H036A, 180, 128, 68, 36, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray2_X	s_pNOTXEdge_W016H016A, 180, 128, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray2_Y	s_pNOTXEdge_W016H016A, 180, 128, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Num_AuxilPageOHPIns_copy_Tray2_X_Num	SF_TEXT_DYNAMIC_ALLOC, 180, 128, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Num_AuxilPageOHPIns_copy_Tray2_Y_Num	SF_TEXT_DYNAMIC_ALLOC, 180, 128, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray2_Icon2	tbl_i00_270_000_X16_Y16, 180, 128, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray2_Icon1	tbl_i00_273_000_X16_Y16, 180, 128, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Key_AuxilPageOHPIns_copy_Tray3	MSG_MSButton, 9, tbl_m30_075_000_X128_Y40, 180, 176, const_cast<PSingleParts**>( tbl_AuxilPageOHPIns_copy_Tray3 ), SIZE(tbl_AuxilPageOHPIns_copy_Tray3), True, PNLE_Shadow_Parts_2
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray3	s_pNOTTray3_W032H040A, 180, 176, 32, 40, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutCentering, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray3_FreeIcon	tbl_i00_275_000_X16_Y16, 180, 176, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray3_Sheet	s_pNOTA4SEF_W068H036A, 180, 176, 68, 36, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray3_X	s_pNOTXEdge_W016H016A, 180, 176, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray3_Y	s_pNOTXEdge_W016H016A, 180, 176, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Num_AuxilPageOHPIns_copy_Tray3_X_Num	SF_TEXT_DYNAMIC_ALLOC, 180, 176, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Num_AuxilPageOHPIns_copy_Tray3_Y_Num	SF_TEXT_DYNAMIC_ALLOC, 180, 176, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray3_Icon2	tbl_i00_270_000_X16_Y16, 180, 176, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray3_Icon1	tbl_i00_273_000_X16_Y16, 180, 176, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Key_AuxilPageOHPIns_copy_Tray4	MSG_MSButton, 14, tbl_m30_075_000_X128_Y40, 180, 224, const_cast<PSingleParts**>( tbl_AuxilPageOHPIns_copy_Tray4 ), SIZE(tbl_AuxilPageOHPIns_copy_Tray4), True, PNLE_Shadow_Parts_2
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray4	s_pNOTTray4_W032H040A, 180, 224, 32, 40, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutCentering, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray4_FreeIcon	tbl_i00_275_000_X16_Y16, 180, 224, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray4_Sheet	s_pNOTA4SEF_W068H036A, 180, 224, 68, 36, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray4_X	s_pNOTXEdge_W016H016A, 180, 224, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_Tray4_Y	s_pNOTXEdge_W016H016A, 180, 224, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Num_AuxilPageOHPIns_copy_Tray4_X_Num	SF_TEXT_DYNAMIC_ALLOC, 180, 224, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Num_AuxilPageOHPIns_copy_Tray4_Y_Num	SF_TEXT_DYNAMIC_ALLOC, 180, 224, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray4_Icon2	tbl_i00_270_000_X16_Y16, 180, 224, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Gra_AuxilPageOHPIns_copy_Tray4_Icon1	tbl_i00_273_000_X16_Y16, 180, 224, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Key_AuxilPageOHPIns_copy_TrayLct	MSG_MSButton, 27, tbl_m30_075_000_X128_Y40, 316, 224, const_cast<PSingleParts**>( tbl_AuxilPageOHPIns_copy_TrayLct ), SIZE(tbl_AuxilPageOHPIns_copy_TrayLct), True, PNLE_Shadow_Parts_2
// comment 2018/05/17 SCD2-Sky���� [DenebMLK][�@��\���ύXNo.7] 5�i���݃v�����g�@�\�ǉ��Ή�.
#ifdef DEF_DenebMLKCus
#define PNLD_Ktx_AuxilPageOHPIns_copy_TrayLct	s_pNOTTray5_W016H040A, 316, 224, 32, 40, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutCentering, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#else
#define PNLD_Ktx_AuxilPageOHPIns_copy_TrayLct	s_pNOTTrayLct_W032H040A, 316, 224, 32, 40, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutCentering, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#endif	// DEF_DenebMLKCus.
#define PNLD_Gra_AuxilPageOHPIns_copy_TrayLct_FreeIcon	tbl_i00_275_000_X16_Y16, 316, 224, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Ktx_AuxilPageOHPIns_copy_TrayLct_Sheet	s_pNOTA4SEF_W068H036A, 316, 224, 68, 36, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_TrayLct_X	s_pNOTXEdge_W016H016A, 316, 224, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Ktx_AuxilPageOHPIns_copy_TrayLct_Y	s_pNOTYEdge_W016H016A, 316, 224, 16, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, TYPE_LayoutFree, TYPE_VLayoutMiddle, PNLE_SELECT_FONT_A, 0
#define PNLD_Num_AuxilPageOHPIns_copy_TrayLct_X_Num	SF_TEXT_DYNAMIC_ALLOC, 316, 224, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Num_AuxilPageOHPIns_copy_TrayLct_Y_Num	SF_TEXT_DYNAMIC_ALLOC, 316, 224, 48, 16, UC_GPARTS_COLOR_BLACK, UC_GPARTS_COLOR_GRAY3, "%3.1f", "%2.2f", PNLE_SELECT_FONT_A, TYPE_LayoutFree, TYPE_VLayoutMiddle, 0
#define PNLD_Gra_AuxilPageOHPIns_copy_TrayLct_Icon2	tbl_i00_270_000_X16_Y16, 316, 224, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
#define PNLD_Gra_AuxilPageOHPIns_copy_TrayLct_Icon1	tbl_i00_273_000_X16_Y16, 316, 224, TYPE_LayoutFree, False, PNLE_Shadow_none, 16, 16
//  �g���C�P�{�^��.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray1( PNLD_Ktx_AuxilPageOHPIns_copy_Tray1 );		// 1.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray1_FreeIcon( PNLD_Gra_AuxilPageOHPIns_copy_Tray1_FreeIcon );		// �P�F�荷���}�[�N�i�ʏ�j.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray1_Sheet( PNLD_Ktx_AuxilPageOHPIns_copy_Tray1_Sheet );		// A4 _PT.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray1_X( PNLD_Ktx_AuxilPageOHPIns_copy_Tray1_X );		// �P�F�w.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray1_Y( PNLD_Ktx_AuxilPageOHPIns_copy_Tray1_Y );		// �P�F�x.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_Tray1_X_Num( PNLD_Num_AuxilPageOHPIns_copy_Tray1_X_Num );		// �P�F�w�l.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_Tray1_Y_Num( PNLD_Num_AuxilPageOHPIns_copy_Tray1_Y_Num );		// �P�F�x�l.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray1_Icon2( PNLD_Gra_AuxilPageOHPIns_copy_Tray1_Icon2 );		// �A�C�R���F���.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray1_Icon1( PNLD_Gra_AuxilPageOHPIns_copy_Tray1_Icon1 );		// �A�C�R���F�c��.
static PSingleParts* const tbl_AuxilPageOHPIns_copy_Tray1[] = {
	&Ktx_AuxilPageOHPIns_copy_Tray1,			// 1.
	&Gra_AuxilPageOHPIns_copy_Tray1_FreeIcon,	// �荷���}�[�N.
	&Ktx_AuxilPageOHPIns_copy_Tray1_Sheet,		// �{�^������.
	&Ktx_AuxilPageOHPIns_copy_Tray1_X,			// X.
	&Ktx_AuxilPageOHPIns_copy_Tray1_Y,			// Y.
	&Num_AuxilPageOHPIns_copy_Tray1_X_Num,		// X���l.
	&Num_AuxilPageOHPIns_copy_Tray1_Y_Num,		// Y���l.
	&Gra_AuxilPageOHPIns_copy_Tray1_Icon2,		// �p�����.
	&Gra_AuxilPageOHPIns_copy_Tray1_Icon1,		// �p���c��.
};
PFormSettingButton				Key_AuxilPageOHPIns_copy_Tray1( PNLD_Key_AuxilPageOHPIns_copy_Tray1 );		// 1.
//  �g���C�Q�{�^��.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray2( PNLD_Ktx_AuxilPageOHPIns_copy_Tray2 );		// 2.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray2_FreeIcon( PNLD_Gra_AuxilPageOHPIns_copy_Tray2_FreeIcon );		// �Q�F�荷���}�[�N�i�ʏ�j.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray2_Sheet( PNLD_Ktx_AuxilPageOHPIns_copy_Tray2_Sheet );		// A4 _PT.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray2_X( PNLD_Ktx_AuxilPageOHPIns_copy_Tray2_X );		// �Q�F�w.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray2_Y( PNLD_Ktx_AuxilPageOHPIns_copy_Tray2_Y );		// �Q�F�x.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_Tray2_X_Num( PNLD_Num_AuxilPageOHPIns_copy_Tray2_X_Num );		// �Q�F�w�l.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_Tray2_Y_Num( PNLD_Num_AuxilPageOHPIns_copy_Tray2_Y_Num );		// �Q�F�x�l.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray2_Icon2( PNLD_Gra_AuxilPageOHPIns_copy_Tray2_Icon2 );		// �A�C�R���F���.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray2_Icon1( PNLD_Gra_AuxilPageOHPIns_copy_Tray2_Icon1 );		// �A�C�R���F�c��.
static PSingleParts* const tbl_AuxilPageOHPIns_copy_Tray2[] = {
	&Ktx_AuxilPageOHPIns_copy_Tray2,
	&Gra_AuxilPageOHPIns_copy_Tray2_FreeIcon,
	&Ktx_AuxilPageOHPIns_copy_Tray2_Sheet,
	&Ktx_AuxilPageOHPIns_copy_Tray2_X,
	&Ktx_AuxilPageOHPIns_copy_Tray2_Y,
	&Num_AuxilPageOHPIns_copy_Tray2_X_Num,
	&Num_AuxilPageOHPIns_copy_Tray2_Y_Num,
	&Gra_AuxilPageOHPIns_copy_Tray2_Icon2,
	&Gra_AuxilPageOHPIns_copy_Tray2_Icon1,
};
PFormSettingButton				Key_AuxilPageOHPIns_copy_Tray2( PNLD_Key_AuxilPageOHPIns_copy_Tray2 );		// 2.
//  �g���C�R�{�^��.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray3( PNLD_Ktx_AuxilPageOHPIns_copy_Tray3 );		// 3.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray3_FreeIcon( PNLD_Gra_AuxilPageOHPIns_copy_Tray3_FreeIcon );		// �R�F�荷���}�[�N�i�ʏ�j.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray3_Sheet( PNLD_Ktx_AuxilPageOHPIns_copy_Tray3_Sheet );		// A4 _PT.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray3_X( PNLD_Ktx_AuxilPageOHPIns_copy_Tray3_X );		// �R�F�w.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray3_Y( PNLD_Ktx_AuxilPageOHPIns_copy_Tray3_Y );		// �R�F�x.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_Tray3_X_Num( PNLD_Num_AuxilPageOHPIns_copy_Tray3_X_Num );		// �R�F�w�l.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_Tray3_Y_Num( PNLD_Num_AuxilPageOHPIns_copy_Tray3_Y_Num );		// �R�F�x�l.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray3_Icon2( PNLD_Gra_AuxilPageOHPIns_copy_Tray3_Icon2 );		// �A�C�R���F���.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray3_Icon1( PNLD_Gra_AuxilPageOHPIns_copy_Tray3_Icon1 );		// �A�C�R���F�c��.
static PSingleParts* const tbl_AuxilPageOHPIns_copy_Tray3[] = {
	&Ktx_AuxilPageOHPIns_copy_Tray3,
	&Gra_AuxilPageOHPIns_copy_Tray3_FreeIcon,
	&Ktx_AuxilPageOHPIns_copy_Tray3_Sheet,
	&Ktx_AuxilPageOHPIns_copy_Tray3_X,
	&Ktx_AuxilPageOHPIns_copy_Tray3_Y,
	&Num_AuxilPageOHPIns_copy_Tray3_X_Num,
	&Num_AuxilPageOHPIns_copy_Tray3_Y_Num,
	&Gra_AuxilPageOHPIns_copy_Tray3_Icon2,
	&Gra_AuxilPageOHPIns_copy_Tray3_Icon1,
};
PFormSettingButton				Key_AuxilPageOHPIns_copy_Tray3( PNLD_Key_AuxilPageOHPIns_copy_Tray3 );		// 3.
//  �g���C�S�{�^��.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray4( PNLD_Ktx_AuxilPageOHPIns_copy_Tray4 );		// 4.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray4_FreeIcon( PNLD_Gra_AuxilPageOHPIns_copy_Tray4_FreeIcon );		// �S�F�荷���}�[�N�i�ʏ�j.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray4_Sheet( PNLD_Ktx_AuxilPageOHPIns_copy_Tray4_Sheet );		// A4 _PT.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray4_X( PNLD_Ktx_AuxilPageOHPIns_copy_Tray4_X );		// �S�F�w.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_Tray4_Y( PNLD_Ktx_AuxilPageOHPIns_copy_Tray4_Y );		// �S�F�x.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_Tray4_X_Num( PNLD_Num_AuxilPageOHPIns_copy_Tray4_X_Num );		// �S�F�w�l.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_Tray4_Y_Num( PNLD_Num_AuxilPageOHPIns_copy_Tray4_Y_Num );		// �S�F�x�l.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray4_Icon2( PNLD_Gra_AuxilPageOHPIns_copy_Tray4_Icon2 );		// �A�C�R���F���.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_Tray4_Icon1( PNLD_Gra_AuxilPageOHPIns_copy_Tray4_Icon1 );		// �A�C�R���F�c��.
static PSingleParts* const tbl_AuxilPageOHPIns_copy_Tray4[] = {
	&Ktx_AuxilPageOHPIns_copy_Tray4,
	&Gra_AuxilPageOHPIns_copy_Tray4_FreeIcon,
	&Ktx_AuxilPageOHPIns_copy_Tray4_Sheet,
	&Ktx_AuxilPageOHPIns_copy_Tray4_X,
	&Ktx_AuxilPageOHPIns_copy_Tray4_Y,
	&Num_AuxilPageOHPIns_copy_Tray4_X_Num,
	&Num_AuxilPageOHPIns_copy_Tray4_Y_Num,
	&Gra_AuxilPageOHPIns_copy_Tray4_Icon2,
	&Gra_AuxilPageOHPIns_copy_Tray4_Icon1,
};
PFormSettingButton				Key_AuxilPageOHPIns_copy_Tray4( PNLD_Key_AuxilPageOHPIns_copy_Tray4 );		// 4.
//  �g���C�k�b�s�{�^��.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_TrayLct( PNLD_Ktx_AuxilPageOHPIns_copy_TrayLct );		// L.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_TrayLct_FreeIcon( PNLD_Gra_AuxilPageOHPIns_copy_TrayLct_FreeIcon );		// �k�F�荷���}�[�N�i�ʏ�j.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_TrayLct_Sheet( PNLD_Ktx_AuxilPageOHPIns_copy_TrayLct_Sheet );		// A4 _PT.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_TrayLct_X( PNLD_Ktx_AuxilPageOHPIns_copy_TrayLct_X );		// �k�F�w.
PSinglePartsTextEx				Ktx_AuxilPageOHPIns_copy_TrayLct_Y( PNLD_Ktx_AuxilPageOHPIns_copy_TrayLct_Y );		// �k�F�x.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_TrayLct_X_Num( PNLD_Num_AuxilPageOHPIns_copy_TrayLct_X_Num );		// �k�F�w�l.
PNumberFieldEx					Num_AuxilPageOHPIns_copy_TrayLct_Y_Num( PNLD_Num_AuxilPageOHPIns_copy_TrayLct_Y_Num );		// �k�F�x�l.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_TrayLct_Icon2( PNLD_Gra_AuxilPageOHPIns_copy_TrayLct_Icon2 );		// �A�C�R���F���.
PSinglePartsResizableGraphic	Gra_AuxilPageOHPIns_copy_TrayLct_Icon1( PNLD_Gra_AuxilPageOHPIns_copy_TrayLct_Icon1 );		// �A�C�R���F�c��.
static PSingleParts* const tbl_AuxilPageOHPIns_copy_TrayLct[] = {
	&Ktx_AuxilPageOHPIns_copy_TrayLct,
	&Gra_AuxilPageOHPIns_copy_TrayLct_FreeIcon,
	&Ktx_AuxilPageOHPIns_copy_TrayLct_Sheet,
	&Ktx_AuxilPageOHPIns_copy_TrayLct_X,
	&Ktx_AuxilPageOHPIns_copy_TrayLct_Y,
	&Num_AuxilPageOHPIns_copy_TrayLct_X_Num,
	&Num_AuxilPageOHPIns_copy_TrayLct_Y_Num,
	&Gra_AuxilPageOHPIns_copy_TrayLct_Icon2,
	&Gra_AuxilPageOHPIns_copy_TrayLct_Icon1,
};
PFormSettingButton				Key_AuxilPageOHPIns_copy_TrayLct( PNLD_Key_AuxilPageOHPIns_copy_TrayLct );		// L.
//   ���}�V���}.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_1( PG_BPPPC_Do_X056Y086, 56, 32, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|�}�V���{�́j.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_2( PG_BPFS526_New_Do_X056Y096, 0, 24, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|�t�B�j�b�V���[).
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_3( PG_BPEDH_X048Y013, 56, 32, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|EDH�j.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_4( PG_BPDuplex_Do_X008Y022, 104, 56, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|Duplex�j.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_5( PG_BPManualTray_Do_X040Y011, 104, 78, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|�荷���g���C�j.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_6( PG_BP1stTray_Do_X040Y011, 56, 81, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|�g���C1�j.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_7( PG_BP2ndTray_Do_X040Y011, 56, 91, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|�g���C2�j.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_8( PG_BP3rdTray_Do_X040Y015, 56, 101, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|�g���C3�j.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_9( PG_BP4thTray_Do_X016Y012, 80, 104, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|�g���C4�j.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_10( PG_BPLCC_X040Y015, 56, 101, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|LCC�j.
PSinglePartsGraphic		Gra_AuxilPageOHPIns_copy_SmallMachine_11( PG_BPLCT_Do_X032Y030, 104, 88, 16, TYPE_LayoutFree, TYPE_VLayoutFree );		// �p���g���C�I���i���}�V���}�|LCT�j.
static PDisplayParts* const tbl_AuxilPageOHPIns_copy_SmallMachine[] = {
	&Gra_AuxilPageOHPIns_copy_SmallMachine_1,	// �{��.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_2,	// �t�B�j�b�V���[.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_3,	// EDH.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_4,	// Duplex.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_5,	// �荷��.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_6,	// �g���C1.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_7,	// �g���C�Q.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_8,	// �g���C�R.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_9,	// �g���C�S.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_10,	// LCC.
	&Gra_AuxilPageOHPIns_copy_SmallMachine_11,	// LCT.
};
static  PSmallMachineComponent	Cmp_AuxilPageOHPIns_copy_SmallMachine( PNLD_Cmp_AuxilPageOHPIns_copy_SmallMachine );	// �p���g���C�I���i���u�}).
#ifdef DEF_LCD_7INCH
#include "PD/A020161000_7inch.cpp"
#else
#include "PD/A020161000.cpp"
#endif
//================================================================================================.
//  �C���N���[�h�E�t�@�C��.
//================================================================================================.

/*================================================================================================
  �萔�E�^�̐錾.
================================================================================================*/

/*================================================================================================
  �񋓌^�ϐ��̃^�O�錾.
================================================================================================*/

/*================================================================================================
 �}�N���֐��̒�`.
================================================================================================*/

static PNLS_SelectPaperTrayCmnMndParts s_parts_tbl = {	// �K�{�p�[�c.
	A020161000_Txt0063,
	Cmp_AuxilPageOHPIns_copy_SmallMachine,
	A020161000_Rbt1001
};
static uchar uc_TrayPartsIdTbl[] = {
	PNLD_ID_SELECTPAPERTRAY1,
	PNLD_ID_SELECTPAPERTRAY2,
	PNLD_ID_SELECTPAPERTRAY3,
	PNLD_ID_SELECTPAPERTRAY4,
	PNLD_ID_SELECTPAPERTRAYLCT
};
//PanelDesigner�Ή�------------------------------------------------------------------------------------------------------.
// ��ʊJ�n����.
void PA020161000::startGamen()
{
	bl_PanelDesigner = True; // PanelDesigner�Ή�.
	PPopupDecisionButtonCom::startGamen();	// �e�N���X�R�[��.
// �R�[���o�b�N�֐��̓o�^.
	ATTACH_OBSERVER( PA020161000, gp_A020161000, PA020161000::prTray, A020161000_Rbt1001, Bool, short );	// �g���C.
	ATTACH_OBSERVER( PA020161000, gp_A020161000, PA020161000::prOnOff, A020161000_Rbt1003, Bool, short );	// ON/OFF.
	ATTACH_OBSERVER( PA020161000, gp_A020161000, PA020161000::prCancel, A020161000_Btn0032, Bool, Bool );	// �L�����Z��.
	setOkButtonForFunctionBadge( &A020161000_Btn0005 ); // �@�\�o�b�`�{�^���������ɑ�ւ��������s���n�j�L�[��o�^.
// �ϐ����̏������������L�ڂ���.
	short ss_StartPositionX = 0;	short ss_StartPositionY = 0;	// [AC]�p���g���C�I�������ݒ�.
// �����ɍ\���ɂ��\���������L�ڂ���.
	this->getPosition( &ss_StartPositionX, &ss_StartPositionY );
	PNLC_SelectPaperTrayOHPInsPaperSet_PD::newInstance()->Initialize(s_parts_tbl, uc_TrayPartsIdTbl, sizeof(uc_TrayPartsIdTbl)/sizeof(uchar), PnlComGetJobCopy(), PnlComGetFeedTray(), True, ss_StartPositionX, ss_StartPositionY );
	A020161000_Rbt1003.setN( isOn( CNK_OHP, PnlComGetJobCopy() ) ? 0 : 1, True );	// ON/OFF�{�^���ݒ�.
	if( ( onlyPanel.isWarning( PCAUTION_OHPPaperEmpty_S ) == True ) ) A020161000_Cmp1005.changeMainMessageText( s_pMSGOHPFilmEmpty_W448H034A );
	else A020161000_Cmp1005.changeMainMessageText( 0 );
// �����ɉ�ʂ̏������������L�ڂ���.
	A020161000_Txt0055.setCursorType(PNLD_CURSOR_TYPE_OFF);	// �p���T�C�YX �J�[�\���\�����Ȃ�.
	A020161000_Txt0053.setCursorType(PNLD_CURSOR_TYPE_OFF);	// �p���T�C�YY �J�[�\���\�����Ȃ�.
	A020161000_Cmp1005.setNowPopupGamen( PNLE_CopyOHPPaper );
}
// �g���C.
Bool PA020161000::prTray( short n )
{
	PNLC_SelectPaperTrayOHPInsPaperSet_PD::newInstance()->setSelectedTray( static_cast<uchar>( n ) );	// �e�������{�^������.
	return True;
}
// ON/OFF.
Bool PA020161000::prOnOff( short n )
{
	switch (n) {
		case 0:	// ���b�Z�[�W�G���A�A[ON]�{�^���̏ꍇ.
			if( -1 != m_ssJobSpecBackUpFlg ) {		// �o�b�N�A�b�v�ς݂̏ꍇ.
				PnlComGetCopyDataLib()->setJobSpecBackup( m_ssJobSpecBackUpFlg, PnlComGetJobCopy()->getJobSpec() );	// OFF�ɂ���O�̃W���u�X�y�b�N�����ɖ߂�.
				PnlComGetCopyDataLib()->JobSpecBackupClear( m_ssJobSpecBackUpFlg );	// �o�b�N�A�b�v�f�[�^�̏���.
				m_ssJobSpecBackUpFlg = -1;
// Comment 2016/09/08 HCLT-Venkataramesh [IT5_3.3][1003656] Handling "ON"," OFF "selection.
//			} else if( combinationCheck( CNK_OHP, PnlComGetJobCopy() ) == False ) return True;			// �o�b�N�A�b�v�����̏ꍇ, OHP �������[�h�̑g�����֎~�`�F�b�N.
			} else {
				if( combinationCheck( CNK_OHP, PnlComGetJobCopy() ) == False ) {
//comment 2018/8/2 SCD2-Sky��� [Sparrow][AR1050098]���͖�������2��Đ��������.
					A020161000_Rbt1003.setBuzzerOff( True );
					return False;					// �o�b�N�A�b�v�����̏ꍇ, OHP �������[�h�̑g�����֎~�`�F�b�N.
				}
				setOHPInsertionMode();				// OHP �������[�h��ݒ�.
			}
			break;
		case 1:	// ���b�Z�[�W�G���A�A[OFF]�{�^���̏ꍇ.
			m_ssJobSpecBackUpFlg = PnlComGetCopyDataLib()->saveJobSpecBackup( m_ssJobSpecBackUpFlg, PnlComGetJobCopy()->getJobSpec() );	// �W���u�X�y�b�N�̃o�b�N�A�b�v.
			PnlComGetJobCopy()->getJobSpec()->pc_Print->c_OhpInsertion.setFeedTray( TYPE_TrayTypeNon );	// �g���C�̑I����ԃN���A.
			cancel( CNK_OHP, CNK_Size, PnlComGetJobCopy() );	// OHP�̐ݒ��OFF�ɂ���.
			break;
	}
	return True;
}

// �L�����Z��.
Bool PA020161000::prCancel( Bool on )
{
	PNLC_StackManJobSpec::newInstance()->rollbackJobSpec();	// �ݒ�����ɖ߂�.
	return True;
}
//�]������(��ʊO����)---------------------------------------------------------------------------------------------------.
// �\�����i�̃Z�b�g�A�b�v.
void PA020161000::setupGamen( short option )
{
	PPopupDecisionButtonCom::setupGamen();	// �O����.
	PNLC_SelectPaperTrayOHPInsPaperSet_PD::newInstance()->update();
	PNLS_setOriginalSizeCLCD2Key s_parts = {&A020161000_Gra0052, &A020161000_Txt0057, NULL, &A020161000_Txt0054, &A020161000_Txt0056, &A020161000_Txt0055, &A020161000_Txt0053, NULL, NULL, NULL, &A020161000_Gra0059};
	PnlComsetPaperSizeCLCD2( &s_parts, PnlComGetJobCopy()->getJobSpec()->pc_Print->c_PaperTray.getFeedTray() );
	if( ( onlyPanel.isWarning( PCAUTION_OHPPaperEmpty_S ) == True ) ) A020161000_Cmp1005.changeMainMessageText( s_pMSGOHPFilmEmpty_W448H034A );
	else A020161000_Cmp1005.changeMainMessageText( 0 );
}
// �A�N�e�B�u��Ԃ̒ʒm.
void PA020161000::procActivate()
{
	if( gp_A0A3900000.getSettingOn() ) {	// �g�����֎~�i�ݒ�ύX�m�F�j��ʂ���̑J�ڎ�.
		gp_A0A3900000.initSettingOn();
// Comment 2016/09/08 HCLT-Venkataramesh [IT5_3.3][1003656] Handling default Tray selection.
		prOnOff( 0 );
	}
	short ss_TrayNum = -1;
	switch( PnlComGetJobCopy()->getJobSpec()->pc_Print->c_OhpInsertion.getFeedTray() ) {
		case TYPE_FeedTray1: ss_TrayNum = 0;	break;
		case TYPE_FeedTray2: ss_TrayNum = 1;	break;
		case TYPE_FeedTray3: ss_TrayNum = 2;	break;
		case TYPE_FeedTray4: ss_TrayNum = 3;	break;
		case TYPE_FeedTray5: ss_TrayNum = 4;	break;
	}
	A020161000_Rbt1001.setN( ss_TrayNum );		// �g���[�I���X�V.
	PPopupDecisionButtonCom::procActivate();	// �e�N���X����.
}
// ��ʏI������.
void PA020161000::endGamen()
{
	if( m_ssJobSpecBackUpFlg != -1 ) {
		PnlComGetCopyDataLib()->JobSpecBackupClear( m_ssJobSpecBackUpFlg );	// �o�b�N�A�b�v����JobSpec���N���A����.
		m_ssJobSpecBackUpFlg = -1;
	}
	PPopupDecisionButtonCom::endGamen();
}
// �g�݋֎��̐�ݒ�ύX���ʒm�n���h��.
void PA020161000::procChangePreSettingOk( uchar option )
{
	switch( sp_MessageWarningTable[ onlyPanel.us_NowMessageWarning ].ec_WarningName ) {
		case PNL_ERROR_Combination_ACS :
		case PNL_ERROR_Combination_FullColorMode :
		case PNL_ERROR_Combination_2Color:
		case PNL_ERROR_Combination_MonoColor:
			if( CNK_OHP == onlyPanel.ep_CombinationOrigin ) {
				PnlComGetJobCopy()->getJobSpec()->pc_Scan->setAcsOn( False );
				PnlComGetJobCopy()->getJobSpec()->pc_Common->setColorMode( TYPE_ColorModeBlack );
				PnlComGetJobCopy()->getJobSpec()->pc_Common->c_MonoColor.setMonoColorOn( False );
				PnlComGetJobCopy()->getJobSpec()->pc_Common->c_MonoColor.setMonoColor( TYPE_MonoColorRed );
				PnlComGetJobCopy()->getJobSpec()->pc_Common->c_2ColorMode.set2ColorOn( False );
				PnlComGetJobCopy()->getJobSpec()->pc_Common->c_2ColorMode.setMonoColor( TYPE_MonoColorRed );
			}
			break;
	}
	setOHPInsertionMode();
}
//��ʌŗL����-----------------------------------------------------------------------------------------------------------.
// �����ݒ菈��.
void PA020161000::setOHPInsertionMode()
{
	TYPE_FeedTray e_FeedTray = PnlComGetJobCopy()->getJobSpec()->pc_Print->c_PaperTray.getFeedTray();
	if( TYPE_TrayTypeMultiMan != PnlComGetFeedTray()->getTrayType( e_FeedTray ) || True == PnlComGetJobCopy()->getJobSpec()->pc_Print->c_PaperTray.getApsOn() ) {	// ���ݐݒ肳��Ă���g���C��MPC���𔻒�.
		TYPE_FeedTray e_FeedTrayOhp = TYPE_FeedTrayManual;
		TYPE_FeedTray e_FeedTrayOhpCandidate = TYPE_FeedTrayManual;
		Bool b_Discovery = False;
		for( uchar i = 0; uc_SizeShowFeedTrayTbl > i; ++i ) {
			if( TYPE_TrayTypeMultiMan == PnlComGetFeedTray()->getTrayType( e_AryShowFeedTrayTbl[i] ) ) {	// �}���`�荷���ł���ꍇ.
				if( False == b_Discovery ) {
					e_FeedTrayOhpCandidate = e_AryShowFeedTrayTbl[i];
					b_Discovery = True;
				}
				if( TYPE_PaperTypeOHP == PnlComGetFeedTray()->getPaperType( e_AryShowFeedTrayTbl[i] ).getPaperType() ) {	// �p����ނ��擾.
					e_FeedTrayOhp = e_AryShowFeedTrayTbl[i];	// OHP�p���̃g���C���擾.
					break;
				}
			}
		}
		if( uc_SizeShowFeedTrayTbl == i ) e_FeedTrayOhp = e_FeedTrayOhpCandidate;
		onlyPanel.setFeedMode( PnlComGetJobCopy(), e_FeedTrayOhp, False );
	}
	PnlComGetJobCopy()->getJobSpec()->pc_Print->c_OhpInsertion.setPaperInsertion( TYPE_PaperInsertionWithoutImage );
	if( combinationCheck( CNK_AMS, PnlComGetJobCopy(), True, False ) == True ) {	// �I�[�g�{���́A�g�ݍ��킹�\�ȏꍇ�̂ݐݒ肷�� .
		PnlComGetJobCopy()->getJobSpec()->pc_Common->c_Mag.setAmsOn( True );	// �I�[�g�{����ݒ�.
		PnlComGetJobCopy()->getJobSpec()->pc_Common->c_Mag.setAvailable( False );
		PnlComGetJobCopy()->getJobSpec()->pc_Common->c_Mag.setMagType( TYPE_MagTypeUnselect );
	}
	static const struct CheckFeedTrayTable_CLCD {
		TYPE_FeedTray				e_FeedTray;					// ������.
		TYPE_TemporaryRescueUnit	e_TemporaryRescueUnit;		// �ꎞ�؂藣���Ώ� .
	} checkFeedTrayTable_CLCD[] = {
		{ TYPE_FeedTray1,		TYPE_TemporaryRescueUnitTray1		},	// �g���C1.
		{ TYPE_FeedTray2,		TYPE_TemporaryRescueUnitTray2		},	// �g���C2.
		{ TYPE_FeedTray3,		TYPE_TemporaryRescueUnitTray3		},	// �g���C3.
		{ TYPE_FeedTray4,		TYPE_TemporaryRescueUnitTray4		},	// �g���C4.
// comment 2018/05/17 SCD2-Sky���� [DenebMLK][�@��\���ύXNo.7] 5�i���݃v�����g�@�\�ǉ��Ή�.
#ifdef DEF_DenebMLKCus
		{ TYPE_FeedTray5,		TYPE_TemporaryRescueUnitTray5		},	// �g���C5.
#else
		{ TYPE_FeedTray5,		TYPE_TemporaryRescueUnitTrayLCT		},	// LCT.
// comment 2018/05/17 SCD2-Sky���� [DenebMLK][�@��\���ύXNo.7] 5�i���݃v�����g�@�\�ǉ��Ή�.
#endif	// DEF_DenebMLKCus.
	};
	for( uchar i=0; i< static_cast<uchar>( sizeof( checkFeedTrayTable_CLCD )/sizeof( CheckFeedTrayTable_CLCD ) ); i++ ) {
		if( ppc_FeedTray->getTrayType( checkFeedTrayTable_CLCD[i].e_FeedTray ) != TYPE_TrayTypeNon && ppc_SystemStatus->getTemporaryRescueUserStatus( checkFeedTrayTable_CLCD[i].e_TemporaryRescueUnit ) == TYPE_TemporaryRescueStatusReset ) {
			PnlComGetJobCopy()->getJobSpec()->pc_Print->c_OhpInsertion.setFeedTray( checkFeedTrayTable_CLCD[i].e_FeedTray );	// OHP�����p���̃g���C��ݒ�.
			break;
		}
	}
	A020161000_Rbt1003.setN( True == isOn( CNK_OHP, PnlComGetJobCopy() ) ? 0 : 1, True );
	PnlComGetJobCopy()->getJobSpec()->pc_Print->setNumOfCopies( 1 );	// �u����1�ɐݒ�.
}
