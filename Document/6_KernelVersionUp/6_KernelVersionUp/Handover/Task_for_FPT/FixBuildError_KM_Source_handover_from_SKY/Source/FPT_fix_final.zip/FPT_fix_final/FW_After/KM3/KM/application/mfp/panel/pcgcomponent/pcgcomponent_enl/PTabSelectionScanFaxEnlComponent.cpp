//------------------------------------------------------------------------------.
/**
 *	@file	PTabSelectionScanFaxEnlComponent.cpp.
 *	@brief	Source file for PTabSelectionScanFaxEnlComponent component class.
 */
//------------------------------------------------------------------------------.

//------------------------------------------------------------------------------.
/**
 *	@brief	Include Files.
 */
//------------------------------------------------------------------------------.

#include <panel/pcgcomponent/pcgcomponent_enl/PTabSelectionScanFaxEnlComponent.h>

#include <panel/pdp/pdpg/pdpdefenl.h>
#include <panel/pddvoice/pddvoiceg/pvoice.h>
#include <panel/pcgcom/pcgcom_CLCD2/PBaseGamenCom.h>
#include <panel/pcgscanfax/pcgscanfax_enl_CLCD2/pipscanfaxdef_enl_CLCD2.h>
#include <panel/pddtext/pddtext_CLCD/pstr_CLCD.h>
#include <panel/plibh/plibh_CLCD/plibh_CLCD.h>
#include <panel/plibh/plibh_CLCD2/PNLC_ScanFaxDataLib.h>
#include <panel/pcgcom_ext/pcgcom_extg/PCGC_AplCommonSet.h>
// comment 2015/10/21 OPS1-Sky���� [MinervaSBK][CQ514983].
#include <panel/plibh/plibh_CLCD2/PNLC_ScanFaxDataChangeCheckLib.h> 
//Comment 2018/01/25 [HCL-Catherine] [IT5 4.2][RQ-686] AR1038621 To hide fax related bookmark and Title.
#include <panel/plibh/plibh_CLCD2/PNLC_NetworkLan.h>
//------------------------------------------------------------------------------.
/**
 *	@brief	Macro.
 */
//------------------------------------------------------------------------------.

#define  SIZE( table )  		( sizeof( table ) / sizeof( PDisplayParts* ) )	// ���i�o�^���𓾂�  

//------------------------------------------------------------------------------.
/**
 *	@brief	Component parts.
 */
//------------------------------------------------------------------------------.

static	PSinglePartsTextEnl				Ktx_EnlScanFax_LDAPSearchUnSelect( s_KEYLDAPSearch_b, 384, 72, 160, 32, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );												// LDAP�����^�u(��I��) .
PButtonObject					Key_EnlScanFax_LDAPSearchUnSelect( MSG_MSIndexButton, BTNID_KEY_LDAPSEARCHSELECT, tbl_ef30_007_000_X176_Y45, 376, 64,  &Ktx_EnlScanFax_LDAPSearchUnSelect );																	// LDAP�����^�u(��I��) .
static	PSinglePartsTextEnl				Ktx_EnlScanFax_LDAPSearchSelect( s_KEYLDAPSearch_b, 384, 80, 160, 32, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );								// LDAP���E�^�u(�I�E) .
PButtonObject					Key_EnlScanFax_LDAPSearchSelect( MSG_MSIndexButton, BTNID_KEY_LDAPSEARCHSELECT, tbl_ef30_006_000_X176_Y40, 376, 74,  &Ktx_EnlScanFax_LDAPSearchSelect );														// LDAP���E�^�u(�I�E) .

static	PSinglePartsTextEnl				Ktx_EnlScanFax_FromLogUnSelect( s_ENLKEYFromTheHistoryX10, 200, 72, 160, 32, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );												// ��������^�u(��I��) .
PButtonObject					Key_EnlScanFax_FromLogUnSelect( MSG_MSIndexButton, BTNID_KEY_FROMLOGSELECT, tbl_ef30_007_000_X176_Y45, 192, 64,  &Ktx_EnlScanFax_FromLogUnSelect );																			// ��������^�u(��I��) .
static	PSinglePartsTextEnl				Ktx_EnlScanFax_FromLogSelect( s_ENLKEYFromTheHistoryX10, 200, 80, 160, 32, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );		// ��������^�u(�I��) .
PButtonObject					Key_EnlScanFax_FromLogSelect( MSG_MSIndexButton, BTNID_KEY_FROMLOGSELECT, tbl_ef30_006_000_X176_Y40, 192, 74,  &Ktx_EnlScanFax_FromLogSelect );										// ��������^�u(�I��) .

static	PSinglePartsTextEnl				Ktx_EnlScanFax_FromRegAddressUnSelect( s_ENLKEYRegistrationAddressX10, 16, 72, 160, 32,  UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );					/// �o�^����.
PButtonObject					Key_EnlScanFax_FromRegAddressUnSelect( MSG_MSIndexButton, BTNID_KEY_FROMREGADDRESSSELECT, tbl_ef30_007_000_X176_Y45, 8, 64,  &Ktx_EnlScanFax_FromRegAddressUnSelect );						 			// �o�^����^�u(��I��) .
static	PSinglePartsTextEnl				Ktx_EnlScanFax_FromRegAddressSelect( s_ENLKEYRegistrationAddressX10, 16, 80, 160, 32, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );									// �o�^����.
PButtonObject					Key_EnlScanFax_FromRegAddressSelect( MSG_MSIndexButton, BTNID_KEY_FROMREGADDRESSSELECT, tbl_ef30_006_000_X176_Y40, 8, 74,  &Ktx_EnlScanFax_FromRegAddressSelect );																// �o�^����^�u(�I��) .

static	PSinglePartsTextEnl				Ktx_EnlScanFax_OffHookUnSelect( s_ENLKEYDirectInputScanFax, 384, 72, 160, 32, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );	// ���ړ���.
PButtonObject					Key_EnlScanFax_OffHookUnSelect( MSG_MSIndexButton, BTNID_KEY_DIRECTSELECT, tbl_ef30_007_000_X176_Y45, 376, 64,  &Ktx_EnlScanFax_OffHookUnSelect );						// ���ړ��̓^�u(��I��) .
static	PSinglePartsTextEnl				Ktx_EnlScanFax_OffHookSelect( s_ENLKEYDirectInputScanFax, 384, 80, 160, 32, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );		// ���ړ���.
PButtonObject					Key_EnlScanFax_OffHookSelect( MSG_MSIndexButton, BTNID_KEY_DIRECTSELECT, tbl_ef30_006_000_X176_Y40, 376, 74,  &Ktx_EnlScanFax_OffHookSelect );					// ���ړ��̓^�u(�I��) .

static	PSinglePartsTextEnl				Ktx_EnlScanFax_Offhook( s_ENLKEYOffHookX10, 616, 72, 160, 32, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );														// �I�t�t�b�N.
PButtonObject					Key_EnlScanFax_Offhook( MSG_MSGoToPage, BTNID_KEY_GOTOSCANFAXOFFHOOK, tbl_ef30_000_000_X176_Y48, 608, 64,  &Ktx_EnlScanFax_Offhook );																			// �I�t�t�b�N�L�[ .

static	PSinglePartsTextEnl				Ktx_EnlScanFax_Onhook( s_ENLKEYOnHookX10, 616, 72, 160, 32, UC_GPARTS_COLOR_BLACK, UC_FONT_SIZE_16, TYPE_LayoutCentering, True, PNL_ENLARGE_X2xY2 );		// �I���t�b�N�L�[ .
PButtonObject					Key_EnlScanFax_Onhook( MSG_MSGoToPage, BTNID_KEY_GOTOSCANFAXONHOOK, tbl_ef30_000_000_X176_Y48, 608, 64,  &Ktx_EnlScanFax_Onhook );	// �I���t�b�N�L�[ .

static PDisplayParts* const tbl_Cmp_Enl_TabSelection[] = {
	&Key_EnlScanFax_FromRegAddressUnSelect,
	&Key_EnlScanFax_FromRegAddressSelect,
	&Key_EnlScanFax_FromLogUnSelect,
	&Key_EnlScanFax_FromLogSelect,
	&Key_EnlScanFax_LDAPSearchUnSelect,
	&Key_EnlScanFax_LDAPSearchSelect,
	&Key_EnlScanFax_OffHookUnSelect,
	&Key_EnlScanFax_OffHookSelect,
	&Key_EnlScanFax_Offhook,
	&Key_EnlScanFax_Onhook,
};

PTabSelectionScanFaxEnlComponent  Cmp_Enl_TabSelection( ( PDisplayParts** )tbl_Cmp_Enl_TabSelection, SIZE( tbl_Cmp_Enl_TabSelection ) );


extern PCGC_AplCommonSet					AplCommonSet;

//------------------------------------------------------------------------------.
/**
 *	@brief	Voice table for voice guidance.
 */
//------------------------------------------------------------------------------.
const ushort	tblVID_Key_EnlScanFax_LDAPSearchUnSelect_Cur[] 		= { vm_000000006633 };	//LDAP�����^�u�@�L�[�I��.
const ushort	tblVID_Key_EnlScanFax_FromLogUnSelect_Cur[]			= { v_KEYFromHistory_Cur };	//��������^�u�@�L�[�I��.
const ushort 	tblVID_Key_EnlScanFax_FromRegAddressUnSelect_Cur[]  = { v_KEYRegisteredAddress_Cur }; // �o�^����^�u�@�L�[�I��.
const ushort	tblVID_Key_EnlScanFax_OffHookUnSelect_Cur[] 		= { v_KEYDirectInput_Cur };	//���ړ��� �L�[�I��.
const ushort 	tblVID_Key_EnlScanFax_Onhook_Cur[] 					= { v_KEYOnhook_Cur };
const ushort	tblVID_Key_EnlScanFax_Offhook_Cur[] 				= { v_KEYOffhook_Cur };	//�I�t�t�b�N�@�L�[�I��.

PNLS_VoiceCursorParts tblVID_TabSelectionEnl_Parts[] = {
	{ &Key_EnlScanFax_FromRegAddressUnSelect, 0, { tblVID_Key_EnlScanFax_FromRegAddressUnSelect_Cur, NULL, NULL, NULL },  { VIDSZ( tblVID_Key_EnlScanFax_FromRegAddressUnSelect_Cur ), 0, 0, 0 }, PNLE_VCDefaultCursor, PNLE_VCDefaultCursor },
	{ &Key_EnlScanFax_FromLogUnSelect,	0,	{tblVID_Key_EnlScanFax_FromLogUnSelect_Cur,NULL,NULL,NULL},	{VIDSZ( tblVID_Key_EnlScanFax_FromLogUnSelect_Cur ),0,0,0}	, PNLE_VCDefaultCursor, PNLE_VCDefaultCursor},
	{ &Key_EnlScanFax_LDAPSearchUnSelect,	0,	{tblVID_Key_EnlScanFax_LDAPSearchUnSelect_Cur,NULL,NULL,NULL},	{VIDSZ( tblVID_Key_EnlScanFax_LDAPSearchUnSelect_Cur ),0,0,0}	, PNLE_VCDefaultCursor, PNLE_VCDefaultCursor},
	{ &Key_EnlScanFax_OffHookUnSelect,	0,	{tblVID_Key_EnlScanFax_OffHookUnSelect_Cur,NULL,NULL,NULL},	{VIDSZ( tblVID_Key_EnlScanFax_OffHookUnSelect_Cur ),0,0,0}	, PNLE_VCDefaultCursor, PNLE_VCDefaultCursor},
	{ &Key_EnlScanFax_Onhook, 0, {tblVID_Key_EnlScanFax_Onhook_Cur,NULL,NULL,NULL}, {VIDSZ( tblVID_Key_EnlScanFax_Onhook_Cur ),0,0,0} , PNLE_VCDefaultCursor, PNLE_VCDefaultCursor},
	{ &Key_EnlScanFax_Offhook,	0,	{tblVID_Key_EnlScanFax_Offhook_Cur,NULL,NULL,NULL},	{VIDSZ( tblVID_Key_EnlScanFax_Offhook_Cur ),0,0,0}	, PNLE_VCDefaultCursor, PNLE_VCDefaultCursor},
};


//-------------------------------------------------------------------------------.
//	[Class] PTabSelectionScanFaxEnlComponent : Enlargment Scanfax Tab selection component.
//-------------------------------------------------------------------------------.

/**
* @brief	Constructor.Initialization of member variables is done.
* @note		None
* @param	[in]parts**				Parts Table.
* @param	[in]uc_PartsNumber		Parts table size.
* @return	None.
*/
PTabSelectionScanFaxEnlComponent::PTabSelectionScanFaxEnlComponent(
    PDisplayParts** parts,
    uchar uc_PartsNumber
): PEnlComponent( parts, uc_PartsNumber )
{
	m_voiceInfo.m_voiceTable = tblVID_TabSelectionEnl_Parts;
	m_voiceInfo.m_ss_voiceTableSize = ( short )VSTSZ( tblVID_TabSelectionEnl_Parts );
	m_voiceInfo.m_convertTable = NULL;
	m_voiceInfo.m_ss_convertTableSize= 0;
	m_voiceInfo.m_noeventTable_comp = NULL;
	m_voiceInfo.m_ss_notEventCompTableSize = 0;
	m_voiceInfo.m_compfuncTable = NULL;
	m_voiceInfo.m_ss_compFuncTableSize= 0;
}

/**
 * @brief   Hides job history tab when pincode display mask in ON.
 * @note    None.
 * @return  None
 */
void PTabSelectionScanFaxEnlComponent::hideJobHistoryTab()
{
	TYPE_UserType e_UserType = TYPE_UserTypeOther;
	if( NULL != PnlComGetUser() ) {
		e_UserType = PnlComGetUser()->getUserType(); // Get the User Type.
	}
	if( TYPE_UserTypeBoxAdmin != e_UserType ) { // Function version check & BoxAdmin permission check.
		APIC_FaxPanelSetting* pc_FaxPanelsetting = PnlComGetFaxPanelSetting();
		if( NULL != pc_FaxPanelsetting ) {
			if( True == pc_FaxPanelsetting->getPINNumNonDisplayOn() ) { // If Pincode Display Mask in ON.
				Key_EnlScanFax_FromLogUnSelect.showEnable( False ); // Hide the Job history Tab.
			}
		} else {
			LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" );
		}
	}
}

/**
* @brief	Component start function.
* @param	None.
* @return	None.
* @note		None.
*/
void PTabSelectionScanFaxEnlComponent::start()
{
	changeTabKeyPosition();
}

/**
* @brief	Handles the Tab Display and Positioning based on the current tab selection and job spec
* @param	None.
* @return	None.
* @note		None.
*/
void PTabSelectionScanFaxEnlComponent::changeTabKeyPosition()
{
	const Bool b_Regist = True;		// �o�^����͏�ɕ\�������
	Bool b_Direct = False;
	Bool b_History = False;
	Bool b_LDAP = False;

	// �^�u�L�[�\�����
	PNLS_BaseTabKeyStatus s_tabStatus[PNLD_ScanFaxBasicFunctionTabMax] = {
		{PNLE_EnlScanFaxBasicTabAddress, True},
		{PNLE_EnlScanFaxBasicTabDirect, True},
		{PNLE_EnlScanFaxBasicTabHistory, True},
		{PNLE_EnlScanFaxBasicTabLdap, True}
	};

	// �g�� ��I���^�u�L�[�z�u
	const PNLS_ScanFaxChangePosition	s_EnlTubKeyPos[PNLD_EnlScanFaxBasicFunctionTabMax] =
	{
		{8, 64},	{192, 64},	{376, 64}
	};
	// �g�� �I���^�u�L�[�z�u
	const PNLS_ScanFaxChangePosition	s_EnlSelectTubKeyPos[PNLD_EnlScanFaxBasicFunctionTabMax] =
	{
		{8, 74},	{192, 74},	{376, 74}
	};

// comment 2015/10/21 OPS1-Sky���� [MinervaSBK][CQ514983].
	// Fax���M�֎~�ݒ�`�F�b�N�����t���O�ݒ�
	// Fax���M�֎~���A�I�t�t�b�N���ړ��͉�ʂɑJ�ڂł��邪�A�^�u�؂�ւ��ɂ��A
	// �^�u��\���ɂ��J�ڕs�ƂȂ邽�߁A�`�F�b�N�����Ƃ���B
	// Fax���M�֎~���̓���ɂ��āA�^�u��\���Ȃǉ�ʎd�l�̌�����������ꍇ�͖{�Ή�������������.
	if( True == PNLC_ScanFaxDataChangeCheckLib::newInstance()->isNowFaxManualTxRxMode() ) {
		onlyPanel.setNoCheckEnableFaxSend( True );
	}

	// ���ړ��̓^�u�̕\�� or ��\���𔻒肷��
	if( isDisableAddressManualInput() == True ) {	// �֎~��.
		Key_EnlScanFax_OffHookUnSelect.showEnable( False );
		Key_EnlScanFax_OffHookSelect.showEnable( False );
		b_Direct = False;
	} else {
		//�g��̂Ƃ�����
		b_Direct = True;
	}

// comment 2015/10/21 OPS1-Sky���� [MinervaSBK][CQ514983].
	onlyPanel.setNoCheckEnableFaxSend( False );
	

	if( True == APIC_SoftDipSw::newInstance()->getSoftDipSwBitForPanelSpecNo( DEFSOFTWARESW42, 6 ) )		// DipSWNo.42 bit6.
	{
		Key_EnlScanFax_FromLogUnSelect.showEnable( False );
		Key_EnlScanFax_FromLogSelect.showEnable( False );
		b_History = False;
	}
	else
	{
		if( ( onlyPanel.isFaxFunctionUseCheck( PDPE_FaxFunctionCheckReDial ) == False ) ) // �֎~��
		{
			Key_EnlScanFax_FromLogUnSelect.showEnable( False );
			Key_EnlScanFax_FromLogSelect.showEnable( False );

			b_History = False;
		} else {
			b_History = True;
		}
	}

//comment 2020/02/04 [HCL-Madhavi] �yOP_BTS-19386_Reopen�zDisplaying the Address search based on the Dipswitch. 
	// LDAP�^�u�̕\�� or ��\���𔻒肷��
#ifndef DEF_HeliosMLKCus
	if( isEnableLDAP() == True ) {
#else
		if(( isEnableLDAP() == True ) && (False == APIC_SoftDipSw::newInstance()->getSoftDipSwBitForPanelSpecNo( 159, 4 ))){
#endif
		
		// �uLDAP�����v�L�[��\������
		b_LDAP = True;
	} else {

		// �uLDAP�����v�L�[��\�����Ȃ�
		Key_EnlScanFax_LDAPSearchUnSelect.showEnable( False );
		Key_EnlScanFax_LDAPSearchSelect.showEnable( False );
		// LDAP��\�����Ȃ��ꍇ��3�ԖڂɃ|�W�V�����ړ�.
		Key_EnlScanFax_OffHookSelect.changePosition( s_EnlSelectTubKeyPos[2].us_x, s_EnlSelectTubKeyPos[2].us_y, 0, 0 );
		Key_EnlScanFax_OffHookUnSelect.changePosition( s_EnlTubKeyPos[2].us_x, s_EnlTubKeyPos[2].us_y, 0, 0 );

		b_LDAP = False;
	}
// comment 2015.10.22 OPS1-Sky���� [MinervaSBk][CQ514983].
//	if ( True == PBasicMessageProc::b_isOffHookBtnOn)
	if ( True == PBasicMessageProc::b_isOffHookBtnOn || True == PBasicMessageProc::b_isFaxLine1OffHook )
	{
		b_LDAP = False;
		Key_EnlScanFax_LDAPSearchUnSelect.showEnable( False );
		Key_EnlScanFax_LDAPSearchSelect.showEnable( False );
		Key_EnlScanFax_Offhook.showEnable( False );
		Key_EnlScanFax_Onhook.showEnable( True );
	} else {
		b_Direct = False;
		Key_EnlScanFax_OffHookUnSelect.showEnable( False );
		Key_EnlScanFax_OffHookSelect.showEnable( False );
		Key_EnlScanFax_Onhook.showEnable( False );
		Key_EnlScanFax_Offhook.showEnable( checkShowFaxOption() );
	}

	// �s�����̒l���Q�Ƃ��A�\�����鏉����ʂ𔻒�
	switch( PnlComGetScanFaxMainDisp() ) {
		case TYPE_FaxMainDispProg:		// LDAP����
			s_tabStatus[0].m_e_BasicTab = PNLE_EnlScanFaxBasicTabLdap;
			s_tabStatus[1].m_e_BasicTab = PNLE_EnlScanFaxBasicTabAddress;
			s_tabStatus[2].m_e_BasicTab = PNLE_EnlScanFaxBasicTabDirect;
			s_tabStatus[3].m_e_BasicTab = PNLE_EnlScanFaxBasicTabHistory;
			s_tabStatus[0].m_b_DispStatus = b_LDAP;
			s_tabStatus[1].m_b_DispStatus = b_Regist;
			s_tabStatus[2].m_b_DispStatus = b_Direct;
			s_tabStatus[3].m_b_DispStatus = b_History;
			break;
		case TYPE_FaxMainDispGroup:		// ����
			s_tabStatus[0].m_e_BasicTab = PNLE_EnlScanFaxBasicTabHistory;
			s_tabStatus[1].m_e_BasicTab = PNLE_EnlScanFaxBasicTabAddress;
			s_tabStatus[2].m_e_BasicTab = PNLE_EnlScanFaxBasicTabDirect;
			s_tabStatus[3].m_e_BasicTab = PNLE_EnlScanFaxBasicTabLdap;
			s_tabStatus[0].m_b_DispStatus = b_History;
			s_tabStatus[1].m_b_DispStatus = b_Regist;
			s_tabStatus[2].m_b_DispStatus = b_Direct;
			s_tabStatus[3].m_b_DispStatus = b_LDAP;
			break;
		case TYPE_FaxMainDispTenKey:	// ���ړ���
			s_tabStatus[0].m_e_BasicTab = PNLE_EnlScanFaxBasicTabDirect;
			s_tabStatus[1].m_e_BasicTab = PNLE_EnlScanFaxBasicTabAddress;
			s_tabStatus[2].m_e_BasicTab = PNLE_EnlScanFaxBasicTabHistory;
			s_tabStatus[3].m_e_BasicTab = PNLE_EnlScanFaxBasicTabLdap;
			s_tabStatus[0].m_b_DispStatus = b_Direct;
			s_tabStatus[1].m_b_DispStatus = b_Regist;
			s_tabStatus[2].m_b_DispStatus = b_History;
			s_tabStatus[3].m_b_DispStatus = b_LDAP;
			break;
		case TYPE_FaxMainDispAbb:		// �o�^����
		default:
			s_tabStatus[0].m_e_BasicTab = PNLE_EnlScanFaxBasicTabAddress;
			s_tabStatus[1].m_e_BasicTab = PNLE_EnlScanFaxBasicTabDirect;
			s_tabStatus[2].m_e_BasicTab = PNLE_EnlScanFaxBasicTabHistory;
			s_tabStatus[3].m_e_BasicTab = PNLE_EnlScanFaxBasicTabLdap;
			s_tabStatus[0].m_b_DispStatus = b_Regist;
			s_tabStatus[1].m_b_DispStatus = b_Direct;
			s_tabStatus[2].m_b_DispStatus = b_History;
			s_tabStatus[3].m_b_DispStatus = b_LDAP;
			break;
	}
	for( int cnt = 0, chk = 0; cnt < PNLD_ScanFaxBasicFunctionTabMax; cnt++ ) {
		// �L�[�\������
		if( s_tabStatus[cnt].m_b_DispStatus == True ) {
			switch( s_tabStatus[cnt].m_e_BasicTab ) {
				case PNLE_EnlScanFaxBasicTabAddress:			// �o�^���悩��
					Key_EnlScanFax_FromRegAddressSelect.changePosition( s_EnlSelectTubKeyPos[chk].us_x, s_EnlSelectTubKeyPos[chk].us_y, 0, 0 );
					Key_EnlScanFax_FromRegAddressUnSelect.changePosition( s_EnlTubKeyPos[chk].us_x, s_EnlTubKeyPos[chk].us_y, 0, 0 );
					++chk;
					break;
				case PNLE_EnlScanFaxBasicTabDirect:			// ���ړ���
					break;
				case PNLE_EnlScanFaxBasicTabHistory:			// ��������
					Key_EnlScanFax_FromLogSelect.changePosition( s_EnlSelectTubKeyPos[chk].us_x, s_EnlSelectTubKeyPos[chk].us_y, 0, 0 );
					Key_EnlScanFax_FromLogUnSelect.changePosition( s_EnlTubKeyPos[chk].us_x, s_EnlTubKeyPos[chk].us_y, 0, 0 );
					++chk;
					break;
				case PNLE_EnlScanFaxBasicTabLdap:			// LDAP
					Key_EnlScanFax_LDAPSearchSelect.changePosition( s_EnlSelectTubKeyPos[chk].us_x, s_EnlSelectTubKeyPos[chk].us_y, 0, 0 );
					Key_EnlScanFax_LDAPSearchUnSelect.changePosition( s_EnlTubKeyPos[chk].us_x, s_EnlTubKeyPos[chk].us_y, 0, 0 );
					++chk;
					break;
				default: break;
			}
		}
	}

	PNLE_FaxTurnTopGamenBasic e_FaxTurnTopGamenBasic = PNLC_ScanFaxDataLib::newInstance()->getFaxTurnTopGamenBasic();

	// �^�u�\���p�[�c�ĕ`�揈��

	for( int cnt = 0; cnt < PNLD_ScanFaxBasicFunctionTabMax; cnt++ ) {
		if( s_tabStatus[cnt].m_b_DispStatus == True ) { // �L�[�\������
			switch( s_tabStatus[cnt].m_e_BasicTab ) {
				case PNLE_EnlScanFaxBasicTabAddress:	// �o�^���悩��
					if( ( PNLE_FaxTurnTopGamenBasicAddress == e_FaxTurnTopGamenBasic ) || ( PNLE_FaxTurnTopGamenBasicDefault == e_FaxTurnTopGamenBasic ) )
					{
						Key_EnlScanFax_FromRegAddressUnSelect.showEnable( False );
						Key_EnlScanFax_FromRegAddressSelect.showEnable( True );
					} else {
						Key_EnlScanFax_FromRegAddressUnSelect.showEnable( True );
						Key_EnlScanFax_FromRegAddressSelect.showEnable( False );
					}
					break;
				case PNLE_EnlScanFaxBasicTabDirect:			// ���ړ���
					if( PNLE_FaxTurnTopGamenBasicDirect == e_FaxTurnTopGamenBasic )
					{
						Key_EnlScanFax_OffHookSelect.showEnable( True );
						Key_EnlScanFax_OffHookUnSelect.showEnable( False );
					} else {
						Key_EnlScanFax_OffHookSelect.showEnable( False );
						Key_EnlScanFax_OffHookUnSelect.showEnable( True );
					}
					break;
				case PNLE_EnlScanFaxBasicTabHistory:			// ��������
					if( PNLE_FaxTurnTopGamenBasicRedial == e_FaxTurnTopGamenBasic )
					{
						Key_EnlScanFax_FromLogSelect.showEnable( True );
						Key_EnlScanFax_FromLogUnSelect.showEnable( False );
					} else {
						Key_EnlScanFax_FromLogSelect.showEnable( False );
						Key_EnlScanFax_FromLogUnSelect.showEnable( True );
					}
					break;
				case PNLE_EnlScanFaxBasicTabLdap:			// LDAP
					if( PNLE_FaxTurnTopGamenBasicLdap == e_FaxTurnTopGamenBasic )
					{
						Key_EnlScanFax_LDAPSearchSelect.showEnable( True );
						Key_EnlScanFax_LDAPSearchUnSelect.showEnable( False );
					} else {
						Key_EnlScanFax_LDAPSearchSelect.showEnable( False );
						Key_EnlScanFax_LDAPSearchUnSelect.showEnable( True );
					}
					break;
				default: break;
			}
		}
	}
}

/**
* @brief	Fax���MOption�ɂ��\���ݒ菈��
* @param	None.
* @return	Bool : Returns True if show fax option is enabled, else False.
* @note		None.
*/
Bool PTabSelectionScanFaxEnlComponent::checkShowFaxOption()
{
	// �N�C�b�N���������M�g�p�۔���
	Bool b_OffHookShow = onlyPanel.isFaxFunctionUseCheck( PDPE_FaxFunctionCheckQuickTx );
//Comment 2018/01/25 [HCL-Catherine] [IT5 4.2][RQ-686] AR1038621 To hide fax related bookmark and Title.
	if( b_OffHookShow == False || TYPE_NetworkSpecific_NW2 == PNLC_NetworkLan::getInstance()->getLine()) {
		return( False );
	}

// comment 2015.10.19 OPS1-Sky���� [MinervaSBk][CQ514983].
//	if(False == onlyPanel.isEnableSetFaxSend( PnlComGetJobScanFax(), PNELD_MSK_ISFAXMODE_FAX1 )) {
	if( False == onlyPanel.isEnableSetFaxSend( PnlComGetJobScanFax(), PNELD_MSK_ISFAXMODE_FAX1, False ) ) {
		// G3FAX�@�\�g�p�s�\�Ȃ�
		return( False );
	}
	// �摜���OOn���͋֎~.
	if( TYPE_ImageLogSendType2 == PnlComGetSystemSetting()->getImageLogSendEnabled() ) { return ( False ); }
	APIC_FaxJobSetting*			pc_FaxJobSetting = PnlComGetFaxJobSetting();
	if( pc_FaxJobSetting->getDoubleDialCallMode() == True ) {	// ���Ď��ē��͋@�\ON��
		return ( False );
	}
	if( PnlComGetOperationSetting()->getCopyGuardEnable()						// �R�s�[�K�[�h�L��.
	    || PnlComGetOperationSetting()->getPasswordCopyEnable() ) {					// �p�X���[�h�R�s�[�L��.
		return ( False );
	}
	// Prefix/Suffix���g�p����ꍇ�A�u�I�t�t�b�N�v�L�[���\���ɂ���.
	if( True == onlyPanel.isFaxServerEnable() ) {
		return ( False );
	}
	return( True );
}
