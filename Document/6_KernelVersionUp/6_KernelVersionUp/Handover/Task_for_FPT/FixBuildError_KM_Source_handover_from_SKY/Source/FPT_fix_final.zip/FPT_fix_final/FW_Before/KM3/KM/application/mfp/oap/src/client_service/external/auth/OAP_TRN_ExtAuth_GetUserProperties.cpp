// ===========================================================================================.
// File name		: ExtGetUserProperties.cpp
// Summary			: Auth Transaction
// Change History	: 2016.06.27: HCL_Divya: New Framework First edition  Corresponding.
// Device Info		: IT5-3.3 new feature added support.
// ===========================================================================================. 
#ifdef _MSC_VER
#pragma warning( disable : 4786 )
#endif // _MSC_VER
// ===========================================================================================. 
// Include file
// ===========================================================================================. 
#include "APIC_ExtSetting.h"
#include "OAP_COM_InternalApi_gene.h"
#include "OAP_COM_InternalApi_external.h"
#include "../../OAP_SVC_ExtFrameWork.h"
#include "../OAP_TRN_transactiondef.h"
#include "../OAP_TRN_transactiondef.h"
#include "../OAP_External_Library_V01.h"

#include "../OAP_External_Library_V02.h"
#include "../OAP_External_Library_V03.h"
// ===========================================================================================.
// Summary: DevReqExtGetUserProperties
// Creator: HCL_Divya
// ===========================================================================================.
// ===========================================================================================.
// DevReqExtGetUserProperties
// ===========================================================================================. 

/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : inquiry_impl.
 * @ Param [in]   : key.
 * @ Return processing results .
 */
template<> // Amur_GCC4.1�Ή�_No035
bool OAPC_ExtGetUserProperties_4_13_Auth::inquiry_impl(const char* key)
{
	return false;
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : pre_check_impl.
 * @ Param [in]   : p_req message structure.
 * @ Param [out]  : p_res message structure.
 * @ Return processing results .
 */
template<> // Amur_GCC4.1�Ή�_No035
bool OAPC_ExtGetUserProperties_4_13_Auth::pre_check_impl(const OAPS_AppReqExtGetUserProperties* p_req, OAPS_AppResExtGetUserProperties* p_res)
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_ExtGetUserProperties_4_13_Auth::pre_check_impl()" );
	if( OAPE_ExtAcqInfoGetType_EachUser == p_req->uc_GetDetailType.get() )
	{
		//[Accu_ID:1002263][CC7_IT Bug Fix_ErrorCode Wrong] HCL-Divya 2016/07/14 Add Start.
		//if( p_req->s_EachUserAcquisitionDetail.empty() )
		if( p_req->s_EachUserAcquisitionDetail.empty() || p_req->s_EachUserAcquisitionDetail.s_UserList.ss_ArraySize.empty() )
		//[Accu_ID:1002263][CC7_IT Bug Fix_ErrorCode Wrong] HCL-Divya 2016/07/14 Add End.
		{
			p_res->s_Result.setfault( OAP_EX_Result_Error_IllegalValue, "EachUserAcquisitionDetail" );
			return false;
		}
		//[Accu_ID:1003211][����\���ύXNo.7_FVT1 Bug Fix_ErrorCode Not Valid ] HCL-Suresh 2016/09/09 Del Start.
		//for( int i=0;i< p_req->s_EachUserAcquisitionDetail.s_UserList.ss_ArraySize.get();i++ )
		//{
		//	if( p_req->s_EachUserAcquisitionDetail.s_UserList.ss_ArraySize.get() > 0  && p_req->s_EachUserAcquisitionDetail.s_UserList.s_User[i].sc_ID.empty() )
		//	{
		//		p_res->s_Result.setfault( OAP_EX_Result_Error_IllegalValue, "UserList.ID" );
		//		return false;
		//	}
		//}
		//[Accu_ID:1003211][����\���ύXNo.7_FVT1 Bug Fix_ErrorCode Not Valid] HCL-Suresh 2016/09/09 Del End.
	}
	return true;
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : executeInit_impl.
 * @ Param [in]   : p_req message structure.
 * @ Param [out]  : p_res message structure.
 * @ Return processing results .
 */
template<>
bool OAPC_ExtGetUserProperties_4_13_Auth::executeInit_impl(const OAPS_AppReqExtGetUserProperties* p_req, OAPS_AppResExtGetUserProperties* p_res)
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_ExtGetUserProperties_4_13_Auth::executeInit_impl()" );
	return true;
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : execute_impl.
 * @ Param [in]   : p_req message structure.
 * @ Param [out]  : p_res message structure.
 * @ Return processing results .
 */
template<> // Amur_GCC4.1�Ή�_No035
bool OAPC_ExtGetUserProperties_4_13_Auth::execute_impl(const OAPS_AppReqExtGetUserProperties* p_req, OAPS_AppResExtGetUserProperties* p_res)
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_ExtGetUserProperties_4_13_Auth::execute_impl()" );
	OAPC_ExtAccountMan::AuthKey temp_AuthKey;
//	[AR : 1026431] �y Eagle �z�y�ÓI��͑Ή��p�ۑ�z�yC01-09(00)�ł̐V�K�w�E���z 2017/11/23 [HCL_Prashant] Mod Start.
	::strncpy( temp_AuthKey.key , p_req->s_OperatorInfo.sc_AuthKey.get(), (sizeof( temp_AuthKey.key )-1) );
//	[AR : 1026431] �y Eagle �z�y�ÓI��͑Ή��p�ۑ�z�yC01-09(00)�ł̐V�K�w�E���z 2017/11/23 [HCL_Prashant] Mod End. 
	//Auth Key Certification
 	if( !OAPC_ExtAccountMan::getInstance().certify( temp_AuthKey ) )
	{
		//Accu_ID:1003096[CC7] HCL-Divya 2016/08/22 Mod Start. 
		//p_res->s_Result.setfault( OAP_EX_Result_Error_IllegalValue, "AuthKey" );
		p_res->s_Result.setfault( OAP_EX_Result_Error_IllegalAuthKey, "AuthKey" );
		//Accu_ID:1003096[CC7] HCL-Divya 2016/08/22 Mod End. 
		return false;
	}
	OAPC_ExtAccountMan::AccountInfo s_AccInfo; 
	if( !OAPC_ExtAccountMan::getInstance().find( temp_AuthKey, s_AccInfo ) )
	{
		//Accu_ID:1003096[CC7] HCL-Divya 2016/08/22 Mod Start. 
		//p_res->s_Result.setfault( OAP_EX_Result_Error_IllegalValue, "AuthKey" );
		p_res->s_Result.setfault( OAP_EX_Result_Error_IllegalAuthKey, "AuthKey" );
		//Accu_ID:1003096[CC7] HCL-Divya 2016/08/22 Mod End.
		return false;
	}
	//If the User is not Admin or BoxAdmin,Acquisition of Box attribute information is not possible.
	if( s_AccInfo.sysacc.user->getUserType() != TYPE_UserTypeAdmin && s_AccInfo.sysacc.user->getUserType() != TYPE_UserTypeBoxAdmin ) 
	{
		//[Accu_ID:1002263][CC7_IT Bug Fix_ErrorCode Wrong] HCL-Divya 2016/07/14 Add Start.
		//p_res->s_Result.setfault( OAP_EX_Result_Error_IllegalValue, "DuringUserLogin" );
		  p_res->s_Result.setfault( OAP_EX_Result_Error_IllegalAuthKey, "DuringUserLogin" );
		//[Accu_ID:1002263][CC7_IT Bug Fix_ErrorCode Wrong] HCL-Divya 2016/07/14 Add End.
		return false;
	}
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix] Mod Start.
	//bool i_AuthFlag = 0;
	bool b_AuthFlag = false;
	bool b_MidAuthFlag = false;
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix] Mod End.
	//Finding the registered application number.
	for(unsigned char uc_ApplicationNum = 1;uc_ApplicationNum <= TYPD_ExtMaxApplication; uc_ApplicationNum++)
	{
		OAPC_ApiLock<APIC_ExtSetting> pc_ExtSetting(APIC_ExtSetting::newInstance( uc_ApplicationNum ), 0); 
		if( NULL == pc_ExtSetting  )
		{
			p_res->s_Result.setfault( OAP_EX_Result_Error_AllocateBufferFull, "newInstance" );
			return false;
		}
		TYPS_ExtRegistration appRegist  = pc_ExtSetting->getApplication();
		//Authentication Enable Check
		if(TYPE_ExtTypeAuthentication == appRegist.s_Version.e_Type || TYPE_ExtTypeBrowserAuth ==appRegist.s_Version.e_Type )
		{
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix] Mod Start.
			//i_AuthFlag =1;
			b_AuthFlag = true;
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix] Mod End.

			OAPC_ApiLock<APIC_UserAuthentication> p_UserAuth(APIC_UserAuthentication::newInstanceAdmin(), 0); 
			if( NULL == p_UserAuth  )
			{
				p_res->s_Result.setfault( OAP_EX_Result_Error_AllocateBufferFull, "newInstance" );
				return false;
			}
			TYPE_UserAuthentication e_userAuth = TYPE_UserAuthenticationOff;
			e_userAuth = p_UserAuth->getUserAuthentication();
			//Mid Authentication Enable Check.
			if( TYPE_UserAuthenticationDeviceAndMidAuth == e_userAuth||TYPE_UserAuthenticationIntermeddiateServer == e_userAuth )
			{
				//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix]Add Start.
				b_MidAuthFlag = true;
				//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix] Add End.
				//Function Version Setting
				//�yAccu_ID:1004076�z�yIT5_3.3�z�yWarning �����Ή��zHCL_Santhosh 2016/10/05 Mod Start.
				//setExternalFunctionVersion( &p_req->s_FunctionVersion , &appRegist );
				OAPS_ExternalFunctionVersion s_ExternalFunctionVersion;
				OAPS_ExternalFunctionVersion *p_FuncVer = &s_ExternalFunctionVersion;
				::memset(p_FuncVer, 0x00, sizeof(OAPS_ExternalFunctionVersion));
				::memcpy(p_FuncVer, &p_req->s_FunctionVersion, sizeof(OAPS_ExternalFunctionVersion));
				setExternalFunctionVersion( p_FuncVer , &appRegist );
				//�yAccu_ID:1004076�z�yIT5_3.3�z�yWarning �����Ή��zHCL_Santhosh 2016/10/05 Mod End.
				switch( p_req->uc_GetDetailType.get() )
				{
					case OAPE_ExtAcqInfoGetType_EachUser:
					{
						OAPD_EXT_TRACE_INFO( "OAPE_ExtAcqInfoGetType_EachUser" );
						APIC_UserAttributesInfo *pc_UserAttributesInfo = APIC_UserAttributesInfo::newInstance( );
						if( NULL == pc_UserAttributesInfo  )
						{
							p_res->s_Result.setfault( OAP_EX_Result_Error_AllocateBufferFull, "newInstance" );
							return false;
						}
						TYPS_ExtAppReqGetUserProperties s_GetUserProp;
						s_GetUserProp.e_GetDetailType = TYPE_ExtGetDetailTypeEachUser;
						//Set the Array Size
						s_GetUserProp.s_EachUserAcquisitionDetail.s_AcquisitionDetailUserList.us_NoOfUser = p_req->s_EachUserAcquisitionDetail.s_UserList.ss_ArraySize.get();
						for( int i=0;i < s_GetUserProp.s_EachUserAcquisitionDetail.s_AcquisitionDetailUserList.us_NoOfUser;i++ )
						{
							//Set the User ID information
							s_GetUserProp.s_EachUserAcquisitionDetail.s_AcquisitionDetailUserList.s_UserDetails[i].ul_UserID = ( ::atol( ( char* )p_req->s_EachUserAcquisitionDetail.s_UserList.s_User[i].sc_ID.get() ) );
						}
						//Get the User attribute information
						TYPS_ExtAppResGetUserProperties *pc_GetUserProp = pc_UserAttributesInfo->getUserProperties( &s_GetUserProp,s_AccInfo.sysacc.user->getUserType() );
						if( NULL == pc_GetUserProp  )
						{
							p_res->s_Result.setfault( OAP_EX_Result_Error_AllocateBufferFull, "newInstance" );
							return false;
						}
						p_res->uc_GetDetailType = OAPE_ExtAcqInfoGetType_EachUser;
						//Set the Array Size to OAP
						p_res->s_EachUserAcquisitionDetail.ss_ArraySize = pc_GetUserProp->s_EachUserAcquisitionDetailResult.us_NoOfUser;
						char buff[8+1];
						for(i=0 ; i< p_res->s_EachUserAcquisitionDetail.ss_ArraySize.get() ;i++ )
						{
							memset(buff,0,sizeof(buff));
							sprintf( buff, "%ld", pc_GetUserProp->s_EachUserAcquisitionDetailResult.s_AttributeInfoExistenceResult[i].ul_UserID );
							//Set the UserID and Box Information.
							p_res->s_EachUserAcquisitionDetail.s_AttributeInfoExistenceResult[i].sc_ID = buff;
							p_res->s_EachUserAcquisitionDetail.s_AttributeInfoExistenceResult[i].us_BoxInformation = pc_GetUserProp->s_EachUserAcquisitionDetailResult.s_AttributeInfoExistenceResult[i].us_BoxInformation;
							//For User with Admin priveleges,set the Cache Information.
							if( s_AccInfo.sysacc.user->getUserType() == TYPE_UserTypeAdmin )
							{
								OAPD_EXT_TRACE_INFO( "TYPE_UserTypeAdmin" );
								p_res->s_EachUserAcquisitionDetail.s_AttributeInfoExistenceResult[i].us_CacheInformation = pc_GetUserProp->s_EachUserAcquisitionDetailResult.s_AttributeInfoExistenceResult[i].us_CacheInformation;
							}
						}
					}
					break;
				case OAPE_ExtAcqInfoGetType_EachAttributes:
				{
					OAPD_EXT_TRACE_INFO( "OAPE_ExtAcqInfoGetType_EachAttributes" );
					APIC_UserAttributesInfo *pc_UserAttributesInfo = APIC_UserAttributesInfo::newInstance( );
					if( NULL == pc_UserAttributesInfo  )
					{
						p_res->s_Result.setfault( OAP_EX_Result_Error_AllocateBufferFull, "newInstance" );
						return false;
					}
					TYPS_ExtAppReqGetUserProperties s_GetAttrProp;
					s_GetAttrProp.e_GetDetailType = TYPE_ExtGetDetailTypeEachAttributes;
					//Set the Box and Cache Information to System.
					s_GetAttrProp.s_EachAttributeAcquisitionDetail.e_BoxInfoGet = p_req->s_EachAttributeAcquisitionDetail.uc_BoxInformation.get();
					s_GetAttrProp.s_EachAttributeAcquisitionDetail.e_CacheInfoGet =p_req->s_EachAttributeAcquisitionDetail.uc_CacheInformation.get();
					TYPS_ExtAppResGetUserProperties *pc_GetAttrProp = pc_UserAttributesInfo->getUserProperties( &s_GetAttrProp,s_AccInfo.sysacc.user->getUserType() );
					if( NULL == pc_GetAttrProp  )
					{
						p_res->s_Result.setfault( OAP_EX_Result_Error_AllocateBufferFull, "newInstance" );
						return false;
					}
					p_res->uc_GetDetailType = OAPE_ExtAcqInfoGetType_EachAttributes;
					char buff[8+1];
					//If the Box Information is enabled,set the information to OAP
 					if( OAPE_ExtBoxInfoGetEnable == p_req->s_EachAttributeAcquisitionDetail.uc_BoxInformation.get())
					{
						OAPD_EXT_TRACE_INFO( "OAPE_ExtBoxInfoGetEnable" );
						p_res->s_EachAttributeAcquisitionDetail.s_BoxUserList.ss_ArraySize = pc_GetAttrProp->s_EachAttributeAcquisitionDetailResult.s_BoxUserList.us_NoOfUser;
						for( int i=0 ; i < p_res->s_EachAttributeAcquisitionDetail.s_BoxUserList.ss_ArraySize.get() ;i++ )
						{
							memset(buff,0,sizeof(buff));
							sprintf( buff, "%ld", pc_GetAttrProp->s_EachAttributeAcquisitionDetailResult.s_BoxUserList.ul_UserID[i] );
							p_res->s_EachAttributeAcquisitionDetail.s_BoxUserList.sc_ID[i] = buff;
						}
					}
					//If Cache information is enabled,set the information to OAP
					if( OAPE_ExtCacheInfoGetEnable == p_req->s_EachAttributeAcquisitionDetail.uc_CacheInformation.get() && s_AccInfo.sysacc.user->getUserType() != TYPE_UserTypeBoxAdmin )
					{
						OAPD_EXT_TRACE_INFO( "OAPE_ExtCacheInfoGetEnable" );
						//[Accu_ID:1002263][CC7_IT Bug Fix_System Variable Wrong] HCL-Divya 2016/07/14 Add Start.
						//p_res->s_EachAttributeAcquisitionDetail.s_CacheUserList.ss_ArraySize = pc_GetAttrProp->s_EachAttributeAcquisitionDetailResult.s_BoxUserList.us_NoOfUser;
						p_res->s_EachAttributeAcquisitionDetail.s_CacheUserList.ss_ArraySize = pc_GetAttrProp->s_EachAttributeAcquisitionDetailResult.s_CacheUserList.us_NoOfUser;
						//[Accu_ID:1002263][CC7_IT Bug Fix_System Variable Wrong] HCL-Divya 2016/07/14 Add End.
						for( int i=0 ; i < p_res->s_EachAttributeAcquisitionDetail.s_CacheUserList.ss_ArraySize.get() ;i++ )
						{
							memset(buff,0,sizeof(buff));
							sprintf( buff, "%ld", pc_GetAttrProp->s_EachAttributeAcquisitionDetailResult.s_CacheUserList.ul_UserID[i] );
							p_res->s_EachAttributeAcquisitionDetail.s_CacheUserList.sc_ID[i] = buff;
						}
					}
				}
				break;
				default:
					OAPD_EXT_TRACE_INFO( "default" );
				break;
			}
		//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix]  Del Start.
			//}else{
		//	p_res->s_Result.setfault( OAP_EX_Result_Error_InvalidState, "MiddleAuthServer is not connected  " );
		//	return false;
       //}
		//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix]  Del End
		break;
		}
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix]  Add Start.

	}
	}	
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix]  Add End.
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix] Mod Start.
		//if( i_AuthFlag == 0 )
	    if( false == b_AuthFlag )
		{
			p_res->s_Result.setfault( OAP_EX_Result_Error_OpenApiAuth, "NotExistAuthApplication" );
			return false;
		}else if( false == b_MidAuthFlag ){
			p_res->s_Result.setfault( OAP_EX_Result_Error_InvalidState, "MiddleAuthServer is not connected " );
			return false;
		}
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix] Mod End.
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix]  Del Start.
	//}
	//[Accu_ID:1000757] 2016.08.08 [HCL_Divya][CC7_Braces Issue Fix]  Del End.
	p_res->s_Result.set();
	return true;
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : executeFinish_impl.
 * @ Param [in]   : p_req message structure.
 * @ Param [out]  : p_res message structure.
 * @ Return processing results .
 */
template<>
bool OAPC_ExtGetUserProperties_4_13_Auth::executeFinish_impl(const OAPS_AppReqExtGetUserProperties* p_req, OAPS_AppResExtGetUserProperties* p_res)
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_ExtGetUserProperties_4_13_Auth::executeFinish_impl()" );
	return true;
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : mimeRcvStart_impl.
 * @ Param [in]   : p_req message structure.
 * @ Param [out]  : p_res message structure.
 * @ Return processing results .
 */
template<> // Amur_GCC4.1�Ή�_No035
bool OAPC_ExtGetUserProperties_4_13_Auth::mimeRcvStart_impl(const OAPS_AppReqExtGetUserProperties* p_req, OAPS_AppResExtGetUserProperties* p_res)
{
	return(false);
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : mimeRcvEndInit_impl.
 * @ Param [in]   : MimeData message structure.
 * @ Param [in]   : p_req message structure.
 * @ Param [out]  : p_res message structure.
 * @ Return processing results .
 */
template<>
bool OAPC_ExtGetUserProperties_4_13_Auth::mimeRcvEndInit_impl(const OAPS_MimeData& dat,const OAPS_AppReqExtGetUserProperties* p_req, OAPS_AppResExtGetUserProperties* p_res)
{
	return(true);
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : mimeRcvEnd_impl.
 * @ Param [in]   : MimeData message structure.
 * @ Param [in]   : p_req message structure.
 * @ Param [out]  : p_res message structure.
 * @ Return processing results .
 */
template<> // Amur_GCC4.1�Ή�_No035
bool OAPC_ExtGetUserProperties_4_13_Auth::mimeRcvEnd_impl(const OAPS_MimeData& dat,const OAPS_AppReqExtGetUserProperties* p_req, OAPS_AppResExtGetUserProperties* p_res)
{
	return(false);
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : mimeRcvEndFinish_impl.
 * @ Param [in]   : MimeData message structure.
 * @ Param [in]   : p_req message structure.
 * @ Param [out]  : p_res message structure.
 * @ Return processing results .
 */
template<>
bool OAPC_ExtGetUserProperties_4_13_Auth::mimeRcvEndFinish_impl(const OAPS_MimeData& dat,const OAPS_AppReqExtGetUserProperties* p_req, OAPS_AppResExtGetUserProperties* p_res)
{
	return(true);
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : mimeSndStart_impl.
 * @ Param [in]   : MimeData message structure.
 * @ Param [in]   : p_req message structure.
 * @ Param [out]  : p_res message structure.
 * @ Return processing results .
 */
template<> // Amur_GCC4.1�Ή�_No035
bool OAPC_ExtGetUserProperties_4_13_Auth::mimeSndStart_impl(OAPC_ExtMimeData& dat,const OAPS_AppReqExtGetUserProperties* p_req, OAPS_AppResExtGetUserProperties* p_res)
{
	return(false);
}
/* @ brief OAPC_ExtGetUserProperties_4_13_Auth processing.
 * @ FunctionName : isAppResMime_impl.
 * @ Param [in]   : p_req message structure.
 * @ Return processing results .
 */
template<> // Amur_GCC4.1�Ή�_No035
bool OAPC_ExtGetUserProperties_4_13_Auth::isAppResMime_impl(const OAPS_AppReqExtGetUserProperties* p_req)
{
	return(false);
}
