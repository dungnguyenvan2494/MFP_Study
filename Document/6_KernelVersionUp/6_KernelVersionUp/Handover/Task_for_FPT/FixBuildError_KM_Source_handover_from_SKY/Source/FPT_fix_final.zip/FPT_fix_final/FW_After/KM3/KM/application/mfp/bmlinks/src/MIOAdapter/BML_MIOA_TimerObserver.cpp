//  $Id: BML_MIOA_TimerObserver.cpp,v 1.3 2007/07/31 08:19:57 terazono Exp $
// ****************************************************************************
// �t�@�C����: BML_MIOA_TimerObserver.cpp
// �T�v: 
// $Author: terazono $
// $Date: 2007/07/31 08:19:57 $
// $Revision: 1.3 $
// ****************************************************************************

#include "BML_MIOA_TimerObserver.h"
#include "BML_CMMN_Messages.h"
#include "BML_UTIL_InlineFunctions.h"

// *****************************************************************************
// BMLC_MIOA_TimerObserver::BMLC_MIOA_TimerObserver
// *****************************************************************************
// �T�v     : 
// �߂�l   : const 
// ���l     : 
// �쐬��   : terazono
// ���r���[ : 
// �ύX���� : 2007-07-06 ����.
// *****************************************************************************
BMLC_MIOA_TimerObserver::BMLC_MIOA_TimerObserver(const BMLS_SWAP_MSG_Q_ID  & rmsgqId)
    : _rmsgqId( rmsgqId )
    , _timId( 0 )
{
}

// *****************************************************************************
// BMLC_MIOA_TimerObserver::~BMLC_MIOA_TimerObserver
// *****************************************************************************
// �T�v     : 
// ���l     : 
// �쐬��   : terazono
// ���r���[ : 
// �ύX���� : 2007-07-06 ����.
// *****************************************************************************
BMLC_MIOA_TimerObserver::~BMLC_MIOA_TimerObserver()
{
    detach();
}

// *****************************************************************************
// BMLC_MIOA_TimerObserver::expire
// *****************************************************************************
// �T�v     : 
// �߂�l   : void
// ���l     : 
// �쐬��   : terazono
// ���r���[ : 
// �ύX���� : 2007-07-06 ����.
// *****************************************************************************
void BMLC_MIOA_TimerObserver::expire(BMLD_SWAP_TIM_ID timId)
{
    BMLS_CMMN_MsgQParam sQParam;

    sQParam.eMsgId     = BMLE_CMMN_MsgIdExpiryTimer;
    sQParam.pvShare    = reinterpret_cast< void* >( timId );
    sQParam.pvMsgParam = NULL;
    sQParam.pvReserve  = NULL;

    // �҂��Ȃ��œ�����.
    BMLF_UTIL_SendMsgToBMLinkSTask
        ( _rmsgqId, sQParam, BMLD_SWAP_NO_WAIT, BMLD_SWAP_MSG_PRI_NORMAL );
}

// *****************************************************************************
// BMLC_MIOA_TimerObserver::attach
// *****************************************************************************
// �T�v     : 
// �߂�l   : void
// ���l     : 
// �쐬��   : terazono
// ���r���[ : 
// �ύX���� : 2007-07-06 ����.
// *****************************************************************************
void BMLC_MIOA_TimerObserver::attach()
{
    BMLC_SWAP_Timer * pcTimer = BMLC_SWAP_Timer::newInstance();
    if ( 0 == this->_timId )
    {
        this->_timId = pcTimer->attachObserver( this );
        // printf( "attach_Timer_Observer timId=%d.\n", this->_timId );
    }
}

// *****************************************************************************
// BMLC_MIOA_TimerObserver::detach
// *****************************************************************************
// �T�v     : 
// �߂�l   : void
// ���l     : 
// �쐬��   : terazono
// ���r���[ : 
// �ύX���� : 2007-07-06 ����.
// *****************************************************************************
void BMLC_MIOA_TimerObserver::detach()
{
    if ( 0 != this->_timId )
    {
        BMLC_SWAP_Timer * pcTimer = BMLC_SWAP_Timer::newInstance();
        // printf( "detach_Timer_Observer timId=%d.\n", this->_timId );
        pcTimer->detachObserver( this->_timId );
        this->_timId = 0;
    }
}

// *****************************************************************************
// BMLC_MIOA_TimerObserver::start
// *****************************************************************************
// �T�v     : 
// �߂�l   : void
// ���l     : 
// �쐬��   : terazono
// ���r���[ : 
// �ύX���� : 2007-07-31 ����.
// *****************************************************************************
void BMLC_MIOA_TimerObserver::start(uint32_t ulTimout)
{
    if ( 0 != this->_timId )
    {
        // �^�C�}�쐬(�N��).
        // printf( "req_notifyWhen timId=%d, ulTimout=%d.\n", this->_timId, ulTimout );
        BMLC_SWAP_Timer * pcTimer = BMLC_SWAP_Timer::newInstance();
        BMLS_SWAP_ReqTime sReqTime;    
        sReqTime.eTimerType = BMLE_SWAP_CYCLE;
        sReqTime.RelTime    = ulTimout;
        pcTimer->req_notifyWhen( &sReqTime, this->_timId );
    }
}

// *****************************************************************************
// BMLC_MIOA_TimerObserver::cancel
// *****************************************************************************
// �T�v     : 
// �߂�l   : void
// ���l     : 
// �쐬��   : terazono
// ���r���[ : 
// �ύX���� : 2007-07-06 ����.
// *****************************************************************************
void BMLC_MIOA_TimerObserver::cancel()
{
    if ( 0 != this->_timId )
    {
        BMLC_SWAP_Timer * pcTimer = BMLC_SWAP_Timer::newInstance();
        pcTimer->cancel( this->_timId );
    }
}

/******************************************************************************
    $Log: BML_MIOA_TimerObserver.cpp,v $
    Revision 1.3  2007/07/31 08:19:57  terazono
    �C��:�^�C�}�o�^��,�^�C�}�J�n�̃��\�b�h�𕪂���.

    Revision 1.2  2007/07/17 00:58:25  terazono
    �C��:NICFUM5.15�Ή�.7/17�܂ł̏C����.

    Revision 1.1  2007/07/09 03:39:58  terazono
    �V�K�ǉ�:MIOAdapter�Ŏg�p����^�C�}�I�u�U�[�o.
   
 ******************************************************************************/
