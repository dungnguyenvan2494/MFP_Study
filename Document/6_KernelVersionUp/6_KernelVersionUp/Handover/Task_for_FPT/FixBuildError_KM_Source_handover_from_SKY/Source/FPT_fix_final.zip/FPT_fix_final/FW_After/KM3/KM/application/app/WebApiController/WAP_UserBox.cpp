#include <iostream>
#include <NIF_defs.h>
#include <NIF_SystemInfo.h>
#include "WAP_MainController.h"
#include "WAP_plugintrace.h"
#include "WAP_UserBox.h"
#include "WAP_AsyncResponder.h"
#include "WAP_CommonTables.h"
#include "WAP_Power.h"

#define	WAPD_NoSetting	(2)			// �Y���̃L�[���[�h���ݒ肳��Ă��Ȃ�.

static const int32_t WAPD_GetListMinOffset		= 1;
static const int32_t WAPD_GetListMaxOffset		= 1000;
static const int32_t WAPD_GetListMinNum			= 1;
static const int32_t WAPD_GetListMaxNum			= 1000;
static const int32_t WAPD_GetListInitNum		= 10;			// �{�b�N�X���X�g�ő�擾�� �����l.
static const char    WAPD_SelectNoSetting 		= -1;			// �e�W��M�@�\�� �����l.

// �������.
enum WAPE_FuncKind {
	WAPE_FuncKindNone = 0,
	WAPE_FuncKindCreateUserBox,
	WAPE_FuncKindGetUserBoxList,
	WAPE_FuncKindDeleteUserBox,
	WAPE_FuncKindGetUserBoxInformation,
	WAPE_FuncKindOpenUserBox,
	WAPE_FuncKindSetUserBoxInformation
};

// �����ϊ��p�e�[�u��.
static const struct{
	int32_t			si32_BoxReq;	// WebAPI���.
	uint32_t		ui32_Method;	// ���\�b�h.
	int32_t			si32_Funckind;	// �����^�C�v.
} g_s_ConvertTable[]={
	{	WAPE_BoxReqUriBoxes,		WAPD_HTTP_POST,		WAPE_FuncKindCreateUserBox			},
	{	WAPE_BoxReqUriBoxes,		WAPD_HTTP_GET,		WAPE_FuncKindGetUserBoxList			},
	{	WAPE_BoxReqUriBoxesNo,		WAPD_HTTP_DELETE,	WAPE_FuncKindDeleteUserBox			},
	{	WAPE_BoxReqUriBoxesNoInfo,	WAPD_HTTP_GET,		WAPE_FuncKindGetUserBoxInformation	},
	{	WAPE_BoxReqUriBoxesNo,		WAPD_HTTP_PUT,		WAPE_FuncKindOpenUserBox			},
	{	WAPE_BoxReqUriBoxesNoInfo,	WAPD_HTTP_PUT,		WAPE_FuncKindSetUserBoxInformation	}
};

// �R�[���o�b�N�֐�.
static void WAPC_UserBoxController_ans_deleteBox01( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox01) ); }
static void WAPC_UserBoxController_ans_deleteBox02( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox02) ); }
static void WAPC_UserBoxController_ans_deleteBox03( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox03) ); }
static void WAPC_UserBoxController_ans_deleteBox04( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox04) ); }
static void WAPC_UserBoxController_ans_deleteBox05( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox05) ); }
static void WAPC_UserBoxController_ans_deleteBox06( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox06) ); }
static void WAPC_UserBoxController_ans_deleteBox07( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox07) ); }
static void WAPC_UserBoxController_ans_deleteBox08( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox08) ); }
static void WAPC_UserBoxController_ans_deleteBox09( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox09) ); }
static void WAPC_UserBoxController_ans_deleteBox10( int32_t si32_BoxId, int32_t si32_Result ){ WAPC_UserBoxController::BoxDeleteCompleted( si32_BoxId, si32_Result, reinterpret_cast<uint64_t>(WAPC_UserBoxController_ans_deleteBox10) ); }

// �R�[���o�b�N�֐��e�[�u��.
static struct {
	FP_ANS_CHANGE_BOX_STATUS fp_Cb;
	Bool b_InUse;
} g_s_CbTable[] = {
	{	WAPC_UserBoxController_ans_deleteBox01,	False	},
	{	WAPC_UserBoxController_ans_deleteBox02,	False	},
	{	WAPC_UserBoxController_ans_deleteBox03,	False	},
	{	WAPC_UserBoxController_ans_deleteBox04,	False	},
	{	WAPC_UserBoxController_ans_deleteBox05,	False	},
	{	WAPC_UserBoxController_ans_deleteBox06,	False	},
	{	WAPC_UserBoxController_ans_deleteBox07,	False	},
	{	WAPC_UserBoxController_ans_deleteBox08,	False	},
	{	WAPC_UserBoxController_ans_deleteBox09,	False	},
	{	WAPC_UserBoxController_ans_deleteBox10,	False	}
};

// �{�b�N�X��ʁE���L�ҕύX����(�g��)�e�[�u��.
// �Y�������NG.
static struct {
	WAPE_BoxUserType e_OperatorType;
	WAPE_BoxUserType e_SrcBoxOwnerType;
	WAPE_BoxUserType e_DstBoxOwnerType;
	WAPE_PasswordRules e_PassWordRules;
	WAPE_UserAuthentication e_UserAuth;
} g_s_TypeAndOwnerValidate[] = {
	{	WAPE_BoxUserType_None,		WAPE_BoxUserType_None,		WAPE_BoxUserType_BoxAdmin,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},	// �{�b�N�X�Ǘ��҂ւ̏��L�ҕύX�͑S�ʓI�ɕs��.
	{	WAPE_BoxUserType_Public,	WAPE_BoxUserType_None,		WAPE_BoxUserType_None,		WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},	// �p�u���b�N���[�U�[�ɂ��ύX�͑S�ʓI�ɕs��.
	{	WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_Public,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_Track,		WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_Track,		WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Ext,	WAPE_BoxUserType_User_Ext,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Ext,	WAPE_BoxUserType_Track,		WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_Public,	WAPE_BoxUserType_User_Mfp,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_Public,	WAPE_BoxUserType_Track,		WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_User_Mfp,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_Track,		WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Track,		WAPE_BoxUserType_Track,		WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_Public,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_User_Ext,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_IntermeddiateServer	},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_Track,		WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_Track,		WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_Public,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_User_Mfp,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_User_Ext,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_IntermeddiateServer	},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_User_Mid,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_Track,		WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_Track,		WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_Public,	WAPE_PasswordRules_On_Invalid,	WAPE_UserAuthentication_None				},
	{	WAPE_BoxUserType_Admin,		WAPE_BoxUserType_BoxAdmin,	WAPE_BoxUserType_User_Mid,	WAPE_PasswordRules_None,		WAPE_UserAuthentication_None				},
};

/**
 * @brief �R���X�g���N�^
 * @return �Ȃ�
 */
WAPC_UserBoxController::WAPC_UserBoxController()
{
}

/**
 * @brief �R���X�g���N�^
 * @return �Ȃ�
 */
WAPC_UserBoxController::WAPC_UserBoxController( int32_t si32_BoxReq, int32_t si32_BoxNo, int32_t si32_DocNo )
{
	m_si32_BoxReq = si32_BoxReq;
	m_si32_BoxNo  = si32_BoxNo;
	m_si32_DocNo  = si32_DocNo;
}

/**
 * @brief �f�X�g���N�^
 * @return �Ȃ�
 */
WAPC_UserBoxController::~WAPC_UserBoxController()
{
}

/**
 * @brief HTTP���X�|���X�̐���
 * @param[in] params HTTP���N�G�X�g�w�b�_�A�{�f�B
 * @return �x�����擾�̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::ResponseGenerate(WAPS_SubController *params)
{
	int32_t si32_Ret = WAPD_AnyError;
	uint32_t ui32_funckind = WAPE_FuncKindNone;
	m_ResponseHeader->Status = WAPD_STATUS_OK;
	Bool b_SendBodyOnHttp20X = False;

	//�p�����[�^�`�F�b�N.
	if( NULL == params ){
		WAPG_API_trace("%s(%d) %s : params is NULL\n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		si32_Ret = WAPD_AnyError;
		goto LABEL_END;
	}

	for( uint32_t ui32_loop = 0; ui32_loop < (sizeof(g_s_ConvertTable) / sizeof(g_s_ConvertTable[0])); ui32_loop++ )
	{
		if( g_s_ConvertTable[ui32_loop].si32_BoxReq == m_si32_BoxReq )
		{
			if( g_s_ConvertTable[ui32_loop].ui32_Method == params->Method )
			{
				ui32_funckind = g_s_ConvertTable[ui32_loop].si32_Funckind;
			}
		}
	}

	// �@�\�����m�F.
	if ( WAPE_FuncKindNone != ui32_funckind ) {
		TYPS_FunctionLimitation s_FunctionLimitation;
		getFunctionLimitation( params, s_FunctionLimitation );

		// �{�b�N�X���삪�֎~�̏ꍇ��403��Ԃ�.
		if ( TYPE_FuncLimit_Disable == s_FunctionLimitation.e_EnableBoxOperation ) {
			WAPD_DEBUG1("WAPC_UserBoxController::%s Forbidden Disable\n", __FUNCTION__ );
			WAPG_API_trace("%s(%d) %s : Forbidden Disable.\n", __FILE__, __LINE__, __FUNCTION__);
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_ForbiddenFunctionLimitation );
			si32_Ret = WAPD_AnyError;
			goto LABEL_END;
		}
	}
	{
	// WebAPI�d���Ǘ�.
	WAPC_Power* pc_Power = WAPC_Power::newInstance();
	if ( NULL == pc_Power ) {
	    WAPG_API_trace("%s(%d) WAPC_Power::newInstance NULL 1\n", __FILE__, __LINE__);
	    LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, WAP_LOGF_LEVEL_FATAL, "WAPC_Power::newInstance NULL 1");
	}

	// HDD�f�[�^�A�N�Z�X�p�d���Ǘ��̏ȓd�͗}�~.
	int32_t si32_ret = pc_Power->waitStartAccessHDD();
	if( WAPD_AnyError == si32_ret ){
		WAPG_API_trace("%s(%d) WAPC_Power::waitStartAccessHDD Error\n", __FILE__, __LINE__);
	}

	switch(ui32_funckind){
		// �{�b�N�X����.
		case WAPE_FuncKindCreateUserBox:
			// Create user BOX.
			WAPD_DEBUG("Create user BOX start.\n");
			si32_Ret = createUserBox( params );
			b_SendBodyOnHttp20X = True;
			break;

		// �{�b�N�X���X�g�擾.
		case WAPE_FuncKindGetUserBoxList:
			// Get user BOX list.
			WAPD_DEBUG("Get user BOX list start.\n");
			si32_Ret = getUserBoxList( params );
			b_SendBodyOnHttp20X = True;
			break;

		// �{�b�N�X�A�N�Z�X���擾.
		case WAPE_FuncKindOpenUserBox:
			// Open user BOX.
			WAPD_DEBUG("Open user BOX start.\n");
			si32_Ret = openUserBox( params );
			break;

		// �{�b�N�X�폜(�񓯊�).
		case WAPE_FuncKindDeleteUserBox:
			// Delete user BOX.
			WAPD_DEBUG("Delete user BOX start.\n");
			si32_Ret = deleteUserBox( params );
			break;

		// �{�b�N�X���擾.
		case WAPE_FuncKindGetUserBoxInformation:
			// Get user BOX information.
			WAPD_DEBUG("Get user BOX information start.\n");
			si32_Ret = getUserBoxInformation( params );
			b_SendBodyOnHttp20X = True;
			break;

		// �{�b�N�X���ݒ�.
		case WAPE_FuncKindSetUserBoxInformation:
			// Set user BOX information.
			WAPD_DEBUG("Set user BOX information start.\n");
			si32_Ret = setUserBoxInformation( params );
			break;

		default:
			WAPG_API_trace("%s(%d) %s : Invalid Method.\n", __FILE__, __LINE__, __FUNCTION__);
			printf("405:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //405->ErrorStatus[WAPD_STATUS_METHOD_NOT_ALLOWED] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_METHOD_NOT_ALLOWED;
			generateErrorResponseBody( WAPE_BoxError_InvalidMethod );
			si32_Ret = WAPD_AnyError;
			break;
	}

	// HDD�f�[�^�A�N�Z�X�p�d���Ǘ��̏ȓd�͗}�~����.
	si32_ret = pc_Power->EndAccessHDD();
	if( WAPD_AnyError == si32_ret ){
		WAPG_API_trace("%s(%d) WAPC_Power::EndAccessHDD Error\n", __FILE__, __LINE__);
	}
	}
LABEL_END:
	switch( m_ResponseHeader->Status ) {
		// 200�n.
		case WAPD_STATUS_OK:
		case WAPD_STATUS_CREATED:
			if( True == b_SendBodyOnHttp20X ) {
				m_ResponseHeader->ContentType = const_cast<char*>("application/json");
				m_ResponseHeader->ContentTypeLength = sizeof("application/json") - 1;
			}
			break;

		// 400�n(���[�U�[�v��).
		case WAPD_STATUS_BAD_REQUEST:
		case WAPD_STATUS_FORBIDDEN:
		case WAPD_STATUS_NOT_FOUND:
		case WAPD_STATUS_METHOD_NOT_ALLOWED:
			m_ResponseHeader->ContentType = const_cast<char*>("application/json");
			m_ResponseHeader->ContentTypeLength = sizeof("application/json") - 1;
			break;

		// 500�n(�T�[�o�[�v��).
		default:
			break;
	}

	return si32_Ret;
}

/**
 * @brief �񓯊����X�|���X�̐���
 * @param[in] params HTTP���N�G�X�g�w�b�_�A�{�f�B
 * @retval WAPD_NoError(0) ����.
 * @retval WAPD_AnyError(1) ���s.
 */
int32_t WAPC_UserBoxController::AsyncResponseGenerate( WAPS_SubController *params )
{
	int32_t si32_Ret = WAPD_AnyError;
	int32_t si32_Funckind = WAPE_FuncKindNone;
	Bool b_SendBodyOnHttp20X = False;

	// �p�����[�^�`�F�b�N.
	if( NULL == params ) {
		WAPG_API_trace("%s(%d) %s : params is NULL\n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		si32_Ret = WAPD_AnyError;
		goto LABEL_END;
	}

	// �������.
	for( uint32_t ui32_Index = 0; ui32_Index < (sizeof(g_s_ConvertTable) / sizeof(g_s_ConvertTable[0])); ++ui32_Index ) {
		if( g_s_ConvertTable[ui32_Index].si32_BoxReq == m_si32_BoxReq ) {
			if( g_s_ConvertTable[ui32_Index].ui32_Method == params->Method ) {
				si32_Funckind = g_s_ConvertTable[ui32_Index].si32_Funckind;
				break;
			}
		}
	}
	switch( si32_Funckind ) {
		// �{�b�N�X�폜.
		case WAPE_FuncKindDeleteUserBox:
			WAPD_DEBUG("generateBoxDeleteResponse start.\n");
			si32_Ret = generateBoxDeleteResponse( params );
			b_SendBodyOnHttp20X = True;
			break;

		default:
			WAPG_API_trace("%s(%d) %s : Invalid Method.\n", __FILE__, __LINE__, __FUNCTION__);
			printf("405:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //405->ErrorStatus[WAPD_STATUS_METHOD_NOT_ALLOWED] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_METHOD_NOT_ALLOWED;
			generateErrorResponseBody( WAPE_BoxError_InvalidMethod );
			si32_Ret = WAPD_AnyError;
			break;
	}

LABEL_END:
	switch( m_ResponseHeader->Status ) {
		case WAPD_STATUS_OK:
			if( True == b_SendBodyOnHttp20X ) {
				m_ResponseHeader->ContentType = const_cast<char*>("application/json");
				m_ResponseHeader->ContentTypeLength = sizeof("application/json") - 1;
			}
			break;

		case WAPD_STATUS_BAD_REQUEST:
		case WAPD_STATUS_FORBIDDEN:
		case WAPD_STATUS_NOT_FOUND:
		case WAPD_STATUS_METHOD_NOT_ALLOWED:
			m_ResponseHeader->ContentType = const_cast<char*>("application/json");
			m_ResponseHeader->ContentTypeLength = sizeof("application/json") - 1;
			break;

		default:
			break;
	}
	return si32_Ret;
}

/**
 * @brief ���[�U�[�{�b�N�X����
 * @param[in] param �T�u�R���g���[���[
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::createUserBox( WAPS_SubController *params )
{
	int32_t si32_Ret = WAPD_AnyError;
	// �O������`�F�b�N.
	si32_Ret = checkBoxCreateReqStatus();
	if( WAPD_FatalError == si32_Ret ){
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	} else if( WAPD_AnyError == si32_Ret ){
		printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	} else {
		// �X�R�A�`�F�b�N�Ή�.
	}

	// �{�b�N�X�ԍ��擾.
	int32_t si32_BoxNo = 0;
	si32_Ret = getBoxNoFromBody( params, si32_BoxNo );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}

	// �{�b�N�X��ʎ擾.
	APIE_BoxOptionCreateInfo e_BoxType = APIE_BoxmakerAuto;
	si32_Ret = getBoxTypeFromBody( params, e_BoxType );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}

	// �{�b�N�X�p�X���[�h�擾.
	char sc_BoxPassword[WAPD_BoxPasswordMaxLength] = {0};
	si32_Ret = getBoxPasswordFromBody( params, sc_BoxPassword, e_BoxType );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}

	// �e�p�����[�^�쐬.
	// ���[�U�[�ԍ��̏����l�ݒ�.
	uint32_t ui32_UserNo = (uint32_t)params->UserNumber;
	// �Ǘ��ԍ��̏����l�ݒ�.
	uint32_t ui32_TrackNo = (uint32_t)params->TrackNumber;

	// ����F�؂̂ݗL.
	if( ( TYPD_IndexUserPublic == params->UserNumber ) && ( TYPD_NotSetting != params->TrackNumber ) ){
		if(e_BoxType == APIE_BoxmakerUser){
			WAPG_API_trace("%s(%d) %s : Illegal box type\n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
			return WAPD_AnyError;
        }

// ����Ǘ��̂ݗL�̏ꍇ��.
// params->UserNumber��TYPD_IndexUserPublic������d�l�ɕύX�ƂȂ�������.
// �ȉ��̏����͕s�v�B����ăR�����g�A�E�g����.
//		ui32_UserNo = TYPD_IndexUserPublic;

	// ���[�U�F�ؗL(Public�ȊO).
	} else if( ( 0 != params->UserNumber ) && ( TYPD_IndexUserPublic != params->UserNumber ) ) {
		if ( TYPD_NotSetting == params->TrackNumber) {
			if( APIE_BoxmakerGroup == e_BoxType ) {
				WAPG_API_trace("%s(%d) %s : Illegal box type\n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
				return WAPD_AnyError;
	        }
		}

	// ���F�؁A���̓��[�U�F�ؗL(Public).
	} else {
        if( ( APIE_BoxmakerGroup == e_BoxType ) || ( APIE_BoxmakerUser == e_BoxType ) ) {
			WAPG_API_trace("%s(%d) %s : Illegal box type\n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
			return WAPD_AnyError;
        }

// ���F�؁A���̓��[�U�F�ؗL(Public)�̏ꍇ��.
// params->UserNumber��TYPD_IndexUserPublic������d�l�ɕύX�ƂȂ�������.
// �ȉ��̏����͕s�v�B����ăR�����g�A�E�g����.
//		if( 0 == params->UserNumber ) {
//			// �p�l�������ɍ��킹���F�؎���Public��ݒ�.
//			ui32_UserNo = TYPD_IndexUserPublic;
//		}
	}

	uint32_t ui32_OwnerId = 0;
	int32_t si32_CreateOption = APID_CreateUserBox;
    // �{�b�N�X��ʂ����L.
    if( APIE_BoxmakerAuto == e_BoxType) {
		ui32_OwnerId = APID_BoxUserID_Public;

	// �{�b�N�X��ʂ��l.
	} else if( APIE_BoxmakerUser == e_BoxType ) {
		// Admin�͌l�{�b�N�X�����L�ł��Ȃ�.
		if( TYPD_IndexUserAdmin == params->UserNumber ) {
			WAPG_API_trace("%s(%d) %s : Illegal box type\n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
			return WAPD_AnyError;
		}
        ui32_TrackNo = 0;

	// �{�b�N�X��ʂ��O���[�v.
	} else if ( APIE_BoxmakerGroup == e_BoxType ) {
 		// Admin�̓O���[�v�{�b�N�X�����L�ł��Ȃ�.
 		// BoxAdmin�̓O���[�v�{�b�N�X�����L�ł��邪�A�쐬�͎�����������݂̂ŁAWebAPI����͕s�Ƃ���.
		if( ( TYPD_IndexUserAdmin == params->UserNumber ) || ( TYPD_IndexUserBoxAdmin == params->UserNumber ) ) {
			WAPG_API_trace("%s(%d) %s : Illegal box type\n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
			return WAPD_AnyError;
		}
		si32_CreateOption = APID_CreateGroupBox;
    	ui32_OwnerId = ui32_TrackNo;
	} else {
		// �X�R�A�`�F�b�N�Ή�.
	}

	// APIC_BoxRegistry�C���X�^���X�擾.
	APIC_BoxRegistry* pc_BoxRegistry = APIC_BoxRegistry::newInstance();
	if(NULL == pc_BoxRegistry){
		WAPG_API_trace("%s(%d) %s : APIC_BoxRegistry instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	// �A�N�Z�X�����ݒ�.
	APIC_AccessTokenManager* pc_AccessTokenManager = APIC_AccessTokenManager::newInstance();
	JLGE_InspectLogIF e_InspectLogIF = JLGE_InspectLogIfOperationPanel;
	if( NULL != pc_AccessTokenManager){
		pc_AccessTokenManager->getAppType(m_AccessToken, &e_InspectLogIF);
	}
	pc_BoxRegistry->setLogIFNo( e_InspectLogIF );

	// �{�b�N�X�쐬.
	int32_t si32_ReturnValue = APID_DocapiCommonErr;
    si32_ReturnValue = pc_BoxRegistry->createBox(
		ui32_UserNo,			// ���[�U�[�ԍ�.
		ui32_TrackNo,			// ����ԍ�.
		sc_BoxPassword,			// �{�b�N�X�p�X���[�h.
		si32_BoxNo,				// �{�b�N�X�ԍ�.
		TYPD_DefaultNonBox,		// �{�b�N�X���.
		si32_CreateOption,		// �{�b�N�X�쐬�I�v�V����.
		ui32_OwnerId,			// �쐬�O���[�v.
		TYPE_RegistrationTypeOnlyOne,			// �č����O�^�C�v.
		(short)params->AuthorityID,				// �F��ID.
		params->CostCenterID);	// CostCenterID	.
	WAPD_DEBUG1("createBox() si32_ReturnValue = %d\n", si32_ReturnValue);
	// APIC_BoxRegistry�C���X�^���X�폜.
	pc_BoxRegistry->deleteInstance();

	switch(si32_ReturnValue){
		case APID_DocapiMethodOk:
			si32_Ret = WAPD_NoError;

			m_Response = new Json::Value;
			(*m_Response)["box_no"] = si32_BoxNo;
			m_ResponseHeader->Status = WAPD_STATUS_CREATED;
			break;

		case APID_DocapiBoxidRegistErr:		// �w��Box�ԍ��o�^�ς݃G���[.
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_BoxNoAlreadyExist );
			break;

		case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			break;

		case APID_DocapiUserBoxOverErr:		// ���[�U�{�b�N�X������I�[�o�[.
		case APID_DocapiGroupBoxOverErr:	// �O���[�v�{�b�N�X������I�[�o�[.
		case APID_DocapiAllBoxOverErr:		// �S�{�b�N�X������I�[�o�[.
			printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
			generateErrorResponseBody( WAPE_BoxError_None );
			break;

		case APID_DocapiUnavailableBoxErr:	// �{�b�N�X�g�p�֎~�G���[.
		case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
		default:
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			break;
	}

	return si32_Ret;
}

/**
 * @brief �{�b�N�X���X�g�擾
 * @param[in] param �T�u�R���g���[���[
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getUserBoxList( WAPS_SubController *params )
{
	int32_t si32_Ret = WAPD_AnyError;
	// �O������`�F�b�N.
	si32_Ret = checkBoxInfoReqStatus();
	if( WAPD_AnyError == si32_Ret ){
		printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	// ���[�U�[�{�b�N�X�����l�擾.
	TYPE_SearchKey e_SearchKey = TYPE_SearchKeyAA;
	si32_Ret = getSearchKeyFromQuery( params, e_SearchKey );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}

	// ���X�g�擾�J�n�ʒu�擾.
	int32_t si32_Offset = 1;
	si32_Ret = getOffsetFromQuery( params, si32_Offset );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}

	// �ő�擾���擾.
	int32_t si32_Num = WAPD_GetListInitNum;
	si32_Ret = getNumFromQuery( params, si32_Num );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}

	// �e�p�����[�^�쐬.
	// ���[�U�[�A������擾.
	APIC_User* pc_User = NULL;
    APIC_Track* pc_Track = NULL;
	getUserTrackInformation( params, &pc_User, &pc_Track );

	const int32_t BOX_LIST_REQ_OPTION = 8;	// 8�F�����擾�v��(User�����偕Public).
	LIBC_List<APIC_BoxList> lst_BoxList;

	// APIC_BoxRegistry�C���X�^���X�擾.
	APIC_BoxRegistry* pc_BoxRegistry = APIC_BoxRegistry::newInstance();
	if(NULL == pc_BoxRegistry){
		WAPG_API_trace("%s(%d) %s : APIC_BoxRegistry instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	// �{�b�N�X�쐬.
	int32_t si32_ReturnValue = APID_DocapiCommonErr;
    si32_ReturnValue = pc_BoxRegistry->getBoxList(
		pc_User,				// ���[�U�[���.
		(si32_Offset - 1),		// ���X�g�擾�J�n�ʒu.
		si32_Num,				// �擾�ő吔.
		1,						// ���X�g�\�[�g(1:����).
		BOX_LIST_REQ_OPTION,	// �v���I�v�V����.
		e_SearchKey,			// ���[�U�[�{�b�N�X�����l.
		&lst_BoxList,			// �{�b�N�X�ꗗ���ʃ��X�g.
		False,					// �������̏�pBOX�w��.
		LIBE_CharSetUTF8,		// Box�������R�[�h�ϊ�����.
		pc_Track);				// ������.
	WAPD_DEBUG1("getBoxList() si32_ReturnValue = %d\n", si32_ReturnValue);
	// APIC_BoxRegistry�C���X�^���X�폜.
	pc_BoxRegistry->deleteInstance();

	std::list<int> lst_TempBoxlist;
	switch(si32_ReturnValue) {
		case APID_DocapiMethodOk:
			{
				lst_BoxList.Lock();
				APIC_BoxList *pc_boxlist = lst_BoxList.findFirst();

				if ( pc_boxlist == NULL ) {
					lst_BoxList.UnLock();
					// �����Ȃ��ꍇ�� 204 No Content.
					si32_Ret = WAPD_NoError;
					printf("204:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //204->ErrorStatus[WAPD_STATUS_NO_CONTENT] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_NO_CONTENT;
					break;
				}

				m_Response = new Json::Value;
				uint32_t ui32_Counter = 0;
				while( pc_boxlist != NULL )
				{
					(*m_Response)["list"][ui32_Counter++] = pc_boxlist->sl_BoxID;
					pc_boxlist = lst_BoxList.findNext();
				}
				lst_BoxList.UnLock();
				// ���X�g��Еt��(APIC_BoxRegistry�w�b�_�Q��).
				releaseBoxListFromBoxRegistry( lst_BoxList );

				si32_Ret = WAPD_NoError;
				m_ResponseHeader->Status = WAPD_STATUS_OK;
				break;
			}

		case APID_DocapiNoData:				// �擾�f�[�^�Ȃ�.
			si32_Ret = WAPD_NoError;
			m_ResponseHeader->Status = WAPD_STATUS_NO_CONTENT;
			break;

		case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			break;

		case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
		default:
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			break;
	}

	return si32_Ret;
}

/**
 * @brief �{�b�N�X�A�N�Z�X���擾
 * @param[in] param �T�u�R���g���[���[
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::openUserBox( WAPS_SubController *params )
{
	int32_t si32_Ret = WAPD_AnyError;
	
	// �O������`�F�b�N.
	si32_Ret = checkBoxOpenDelReqStatus();
	if( WAPD_FatalError == si32_Ret ){
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	} else if( WAPD_AnyError == si32_Ret ){
		printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	} else {
		// �X�R�A�`�F�b�N�Ή�.
	}

	// �{�b�N�X���݃`�F�b�N.
	Bool b_IsExist = False;
	si32_Ret = boxExists( m_si32_BoxNo, b_IsExist );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}
	if( False == b_IsExist ) {
		printf("404:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //404->ErrorStatus[WAPD_STATUS_NOT_FOUND] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_NOT_FOUND;
		generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
		return WAPD_AnyError;
	}
	
	// ���[�U�[�A������擾.
	APIC_User* pc_User = NULL;
    APIC_Track* pc_Track = NULL;
	getUserTrackInformation( params, &pc_User, &pc_Track );

	// �{�b�N�X���擾.
	// �{�b�N�X�I�v�V�������擾���邽��.
	APIC_Box* pc_Box = APIC_Box::newInstance();
	if(NULL == pc_Box){
		WAPG_API_trace("%s(%d) %s : APIC_Box instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	pc_Box->setBoxId( m_si32_BoxNo );

	int32_t si32_ReturnValue = APID_DocapiCommonErr;
	APIC_BoxInfo c_BoxInfo;       // �擾Info�l.
	si32_ReturnValue = pc_Box->getBoxInfo(
		pc_User,
		&c_BoxInfo,
		(LIBE_CharSet)APID_DefaultCharSet,
		pc_Track);

	switch(si32_ReturnValue) {
		case APID_DocapiMethodOk:
			break;

		case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
			WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiOwnerAccessErr \n", __FILE__, __LINE__, __FUNCTION__);
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			return WAPD_AnyError;

		case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
			WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiBoxidUnknownErr \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
			return WAPD_AnyError;

		case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
		default:
			WAPG_API_trace("%s(%d) %s : getBoxOption failed \n", __FILE__, __LINE__, __FUNCTION__);
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
	}

	// �{�b�N�X�I�v�V�����擾.
	// �{�b�N�X��ʂ��擾���邽��.
	APIC_BoxOption c_BoxOption;
	si32_ReturnValue = pc_Box->getBoxOption(
		pc_User,					// ���[�U�[���.
		c_BoxInfo.sc_BoxPassword,			// �{�b�N�X�p�X���[�h.
		&c_BoxOption,				// �{�b�N�X�I�v�V�������.
		pc_Track);					// ������.

	switch(si32_ReturnValue) {
		case APID_DocapiMethodOk:
			break;

		case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
			WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiOwnerAccessErr \n", __FILE__, __LINE__, __FUNCTION__);
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			return WAPD_AnyError;

		case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
			WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiBoxidUnknownErr \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
			return WAPD_AnyError;

		case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
		case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
		default:
			WAPG_API_trace("%s(%d) %s : getBoxOption failed \n", __FILE__, __LINE__, __FUNCTION__);
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
	}

	// �g���F�؎���BoxAdmin, Admin�͊g���F�؃��[�U�[���L�̃{�b�N�X�փA�N�Z�X�ł��Ȃ��i�{�́{�g���F�؎��̓A�N�Z�X�\�j.
	TYPE_UserAuthentication e_AuthType = APIC_UserAuthentication::newInstance()->getUserAuthentication();
	if( TYPE_UserAuthenticationIntermeddiateServer == e_AuthType ) {
		if( NULL == pc_User ) {
			WAPG_API_trace("%s(%d) %s : WAPC_UserBoxController::openUserBox pc_User is NULL\n", __FILE__, __LINE__, __FUNCTION__);
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}
		TYPE_UserType e_UserType = pc_User->getUserType();
		if( ( TYPE_UserTypeBoxAdmin == e_UserType ) || ( TYPE_UserTypeAdmin == e_UserType ) ) {
			// �g���F�ؕ����̏ꍇ�A���ꃆ�[�U�[�������A�l�{�b�N�X�̏��L�҂͑S�Ċg���F�؃��[�U�[.
			if( ( APIE_BoxmakerUser == c_BoxOption.sl_BoxCreateInfo ) &&
				( False == APIC_User::isSpecialUserNo( c_BoxInfo.ul_OwnUserID ) ) ) {
				WAPG_API_trace("%s(%d) %s : BoxAdmin and Admin is not permitted to access Mid-User's box. \n", __FILE__, __LINE__, __FUNCTION__);
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;
			}
		}
	}

	// �{�b�N�X�p�X���[�h�擾.
	char sc_BoxPassword[WAPD_BoxPasswordMaxLength] = {0};
	si32_Ret = getBoxPasswordFromBody( params, sc_BoxPassword, c_BoxOption.sl_BoxCreateInfo );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}

	// Box��ԕω��ʒm�I�u�U�[�o�[�o�^.
	si32_Ret = attachBoxObserver();
	if( WAPD_NoError != si32_Ret ) {
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	// APIC_BoxRegistry�C���X�^���X�擾.
	APIC_BoxRegistry* pc_BoxRegistry = APIC_BoxRegistry::newInstance();
	if(NULL == pc_BoxRegistry){
		WAPG_API_trace("%s(%d) %s : APIC_BoxRegistry instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	// �A�N�Z�X�����ݒ�.
	APIC_AccessTokenManager* pc_AccessTokenManager = APIC_AccessTokenManager::newInstance();
	JLGE_InspectLogIF e_InspectLogIF = JLGE_InspectLogIfOperationPanel;
	if( NULL != pc_AccessTokenManager){
		pc_AccessTokenManager->getAppType(m_AccessToken, &e_InspectLogIF);
	}
	pc_BoxRegistry->setLogIFNo( e_InspectLogIF );

	// �`�F�b�N���(�F�ؐ���(1)/���s(0)).
	int32_t si32_Check = 0;

	// �{�b�N�X�A�N�Z�X���擾.
    si32_ReturnValue = pc_BoxRegistry->BoxLogIn_Chk_ErrDetail(
		pc_User,			// ���[�U�[���.
		sc_BoxPassword,		// �{�b�N�X�p�X���[�h.
		m_si32_BoxNo,		// �{�b�N�X�ԍ�.
		&si32_Check,		// [out]�`�F�b�N���(�F�ؐ���(1)/���s(0)).
		e_InspectLogIF,	// �A�N�Z�X�����.
		pc_Track,			// ������.
		(short)params->AuthorityID );		// �F��ID.
	WAPD_DEBUG1("BoxLogIn_Chk_ErrDetail() si32_ReturnValue = %d\n", si32_ReturnValue);
	// APIC_BoxRegistry�C���X�^���X�폜.
	pc_BoxRegistry->deleteInstance();

	switch(si32_ReturnValue) {
		case APID_DocapiMethodOk:
			{
				if(1 != si32_Check){
					m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
					printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
					generateErrorResponseBody( WAPE_BoxError_None );
					return WAPD_AnyError;
				}

				// �p�X���[�h�ۑ�.
				TYPS_TokenBoxInfo st_TokenBoxInfo = {};		// �R���X�g���N�^��.
				st_TokenBoxInfo.m_i32BoxID = m_si32_BoxNo;
				strncpy(st_TokenBoxInfo.m_scBoxPassword, sc_BoxPassword, sizeof(st_TokenBoxInfo.m_scBoxPassword) - 1 );

				APIC_AccessTokenManager::newInstance()->setBoxIdPassword(
					params->AccessToken,
					st_TokenBoxInfo );

				si32_Ret = WAPD_NoError;
				m_ResponseHeader->Status = WAPD_STATUS_OK;
				break;
			}

		case APID_DocapiOwnerAccessErr:		// ���[�U�[�ԍ��s��v�܂���Box���������s��v�G���[.
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			break;

		case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��v�G���[.
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_PasswordAccessErr );
			break;

		case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
			break;

		case APID_DocapiLoginCntErr:		// ���O�C���񐔎��s�G���[.
			printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
			generateErrorResponseBody( WAPE_BoxError_None );
			break;

		case APID_DocapiParametaErr:		// �p�����[�^�G���[.
		case APID_DocapiCommonErr:			// ���������G���[.
		default:
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			break;
	}

	return si32_Ret;
}

/**
 * @brief ���[�U�[�{�b�N�X�폜
 * @param[in] param �T�u�R���g���[���[
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::deleteUserBox( WAPS_SubController *params )
{
	int32_t si32_Ret = WAPD_AnyError;
	
	// �O������`�F�b�N.
	si32_Ret = checkBoxOpenDelReqStatus();
	if( WAPD_FatalError == si32_Ret ){
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	} else if( WAPD_AnyError == si32_Ret ){
		printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	} else {
		// �X�R�A�`�F�b�N�Ή�.
	}

	// �{�b�N�X���݃`�F�b�N.
	Bool b_IsExist = False;
	si32_Ret = boxExists( m_si32_BoxNo, b_IsExist );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}
	if( False == b_IsExist ) {
		printf("404:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //404->ErrorStatus[WAPD_STATUS_NOT_FOUND] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_NOT_FOUND;
		generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
		return WAPD_AnyError;
	}
	
	// ���[�U�[�A������擾.
	APIC_User* pc_User = NULL;
    APIC_Track* pc_Track = NULL;
	getUserTrackInformation( params, &pc_User, &pc_Track );

	// �{�b�N�X�p�X���[�h�擾.
	Bool b_Rtn = False;
	char sc_BoxPassword[WAPD_BoxPasswordMaxLength] = {};
	char* psc_BoxPassword = NULL;
	b_Rtn = APIC_AccessTokenManager::newInstance()->getBoxPassword(
		params->AccessToken,
		m_si32_BoxNo,
		sc_BoxPassword );
	if( False == b_Rtn ) {
		printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
		generateErrorResponseBody( WAPE_BoxError_BoxNotOpened );
		return WAPD_AnyError;
	}

	ushort us_StringNum = 0;
	Bool b_CheckRet = getStringLengthUTF8(sc_BoxPassword, WAPE_CheckString_1String, us_StringNum);
	if(False  == b_CheckRet){
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	if( 0 < us_StringNum ) {
		psc_BoxPassword = sc_BoxPassword;
	}

	// �񓯊����ʃN���X����.
	WAPC_DeleteBoxResult* pc_AsyncResult = new WAPC_DeleteBoxResult();
	if( NULL == pc_AsyncResult ) {
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	pc_AsyncResult->setHandle( m_pv_Handle );

	// �R�[���o�b�N�֐��e�[�u�����A�g�p�\�Ȋ֐��|�C���^���擾.
	FP_ANS_CHANGE_BOX_STATUS fp_Cb = NULL;
	fp_Cb = getBoxDeleteCb();
	if( NULL == fp_Cb ) {
		delete pc_AsyncResult;
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	pc_AsyncResult->setReqId( reinterpret_cast<uint64_t>(fp_Cb) );

	// �񓯊����ʃN���X�i�[.
	si32_Ret = WAPC_AsyncResponseContainer::newInstance()->push( pc_AsyncResult );
	if( WAPD_NoError != si32_Ret ) {
		releaseBoxDeleteCb( fp_Cb );
		delete pc_AsyncResult;
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	// APIC_BoxRegistry�C���X�^���X�擾.
	APIC_BoxRegistry* pc_BoxRegistry = APIC_BoxRegistry::newInstance();
	if(NULL == pc_BoxRegistry){
		WAPG_API_trace("%s(%d) %s : APIC_BoxRegistry instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	// �A�N�Z�X�����ݒ�.
	APIC_AccessTokenManager* pc_AccessTokenManager = APIC_AccessTokenManager::newInstance();
	JLGE_InspectLogIF e_InspectLogIF = JLGE_InspectLogIfOperationPanel;
	if( NULL != pc_AccessTokenManager){
		pc_AccessTokenManager->getAppType(m_AccessToken, &e_InspectLogIF);
	}
	pc_BoxRegistry->setLogIFNo( e_InspectLogIF );

	// �{�b�N�X�쐬.
	int32_t si32_ReturnValue = APID_DocapiCommonErr;
	si32_ReturnValue = pc_BoxRegistry->req_deleteBox(
		pc_User,				// ���[�U�[���.
		psc_BoxPassword,		// �{�b�N�X�p�X���[�h.
		m_si32_BoxNo,			// �{�b�N�X�ԍ�.
		fp_Cb,					// �R�[���o�b�N�֐�.
		TYPD_DefaultNonBox,		// �{�b�N�X���.
		pc_Track,				// ������.
		TYPE_RegistrationTypeOnlyOne,	// �č����O�^�C�v.
		static_cast<short>( params->AuthorityID ) );	// �F��ID.
	pc_BoxRegistry->deleteInstance();

	if(APID_DocapiMethodOk != si32_ReturnValue ){
		switch(si32_ReturnValue) {
			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				break;

			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				break;
		}
		releaseBoxDeleteCb( fp_Cb );
		delete pc_AsyncResult;
		return WAPD_AnyError;
	}

	// �񓯊�API.
	// �񓯊����N�G�X�g������(WAPD_STATUS_OK/WAPD_NoError)���m�肵�Ă���t���O�𗧂Ă�.
	m_ResponseHeader->Async = WAPD_ASYNC_ENABLE;
	return WAPD_NoError;
}

/**
 * @brief ���[�U�[�{�b�N�X���擾
 * @param[in] param �T�u�R���g���[���[
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getUserBoxInformation( WAPS_SubController *params )
{
	int32_t si32_Ret = WAPD_AnyError;
	
	// �O������`�F�b�N.
	si32_Ret = checkBoxInfoReqStatus();
	if( WAPD_AnyError == si32_Ret ){
		printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	// �{�b�N�X���݃`�F�b�N.
	Bool b_IsExist = False;
	si32_Ret = boxExists( m_si32_BoxNo, b_IsExist );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}
	if( False == b_IsExist ) {
		printf("404:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //404->ErrorStatus[WAPD_STATUS_NOT_FOUND] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_NOT_FOUND;
		generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
		return WAPD_AnyError;
	}
	
	// ���[�U�[�A������擾.
	APIC_User* pc_User = NULL;
    APIC_Track* pc_Track = NULL;
	getUserTrackInformation( params, &pc_User, &pc_Track );

	// �{�b�N�X�ݒ�.
	APIC_Box* pc_Box = APIC_Box::newInstance();
	if(NULL == pc_Box){
		WAPG_API_trace("%s(%d) %s : APIC_Box instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	pc_Box->setBoxId( m_si32_BoxNo );

	m_Response = new Json::Value;
	APIC_BoxInfo c_BoxInfo;       /* �擾Info�l */

	// �{�b�N�X���擾.
	int32_t si32_ReturnValue = APID_DocapiCommonErr;
    si32_ReturnValue = pc_Box->getBoxInfo(
		pc_User,
		&c_BoxInfo,
		(LIBE_CharSet)APID_DefaultCharSet,
		pc_Track);
	// pc_Box->deleteInstance();.

	switch(si32_ReturnValue) {
		case APID_DocapiMethodOk:
			{
				// �� �{�b�N�X��.
				(*m_Response)["box_name"] = c_BoxInfo.sc_BoxName;

				// �� �{�b�N�X�쐬����.
				(*m_Response)["create_time"]["year"] = c_BoxInfo.c_CreateDate.ss_Year;
				(*m_Response)["create_time"]["month"] = c_BoxInfo.c_CreateDate.sc_Month;
				(*m_Response)["create_time"]["day"] = c_BoxInfo.c_CreateDate.sc_Day;
				(*m_Response)["create_time"]["hour"] = c_BoxInfo.c_CreateDate.sc_Hour;
				(*m_Response)["create_time"]["minute"] = c_BoxInfo.c_CreateDate.sc_Minute;
				(*m_Response)["create_time"]["second"] = c_BoxInfo.c_CreateDate.sc_Second;
				
				// �� �{�b�N�X�����L�[���.
				char sc_SearchKey[WAPD_MaxKeyLength] = {0};
				if(False == WAPS_CommonTableString<WAPE_SearchKey, TYPE_SearchKey>::CommonToWapString(
					c_BoxInfo.sc_searchKey, sc_SearchKey)){
					m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
					printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
					generateErrorResponseBody( WAPE_BoxError_None );
					return WAPD_AnyError;
				}
				(*m_Response)["index"] = sc_SearchKey;
				break;
			}

		case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			return WAPD_AnyError;

		case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
			return WAPD_AnyError;

		case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
		case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
		default:
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
	}	

	// APIC_BoxRegistry�C���X�^���X�擾.
	APIC_BoxRegistry* pc_BoxRegistry = APIC_BoxRegistry::newInstance();
	if(NULL == pc_BoxRegistry){
		WAPG_API_trace("%s(%d) %s : APIC_BoxRegistry instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	// �A�N�Z�X�����ݒ�.
	APIC_AccessTokenManager* pc_AccessTokenManager = APIC_AccessTokenManager::newInstance();
	JLGE_InspectLogIF e_InspectLogIF = JLGE_InspectLogIfOperationPanel;
	if( NULL != pc_AccessTokenManager){
		pc_AccessTokenManager->getAppType(m_AccessToken, &e_InspectLogIF);
	}
	pc_BoxRegistry->setLogIFNo( e_InspectLogIF );

	// �e�W��M���擾.
	APIS_ConfidentialBoxStruct s_Confidential = {};
	si32_ReturnValue = pc_BoxRegistry->ConfidentialInfoAction(
		m_si32_BoxNo, 				// �w��{�b�N�X�ԍ�.
		WAPD_BOX_CONFBOX_OPE_GET, 	// �A�N�Z�X���.
		&s_Confidential, 			// �e�W��M���.
		pc_User, 					// ���[�U�[���.
		pc_Track, 					// ������.
		TYPE_RegistrationTypeOnlyOne,	// �č����O�^�C�v.
		static_cast<short> ( params->AuthorityID ) );		// �F��ID.
	pc_BoxRegistry->deleteInstance();

	switch(si32_ReturnValue) {
		case APID_DocapiMethodOk:
			// �� �e�W��M�@�\�̗L���̓{�b�N�X�ԍ��̈�v�Ŕ��f����.
			if( m_si32_BoxNo == s_Confidential.sl_BoxNo ){
				(*m_Response)["confidential_rx"] = true;
			} else {
				(*m_Response)["confidential_rx"] = false; //NIF�̎����ɕ���āA�O�̂���.
			}
			break;

		case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
		default:
			//�uWAPD_BOX_CONFBOX_OPE_GET�ŃG���[���e�W��M�@�\���ݒ肳��Ă��Ȃ��v
			// �Ƃ���I/F�d�l�ł��邽�߁A�����ł͐e�W��M�@�\�����Ɣ��f���AWebAPI���s�G���[�Ƃ͂Ȃ�Ȃ�.
			(*m_Response)["confidential_rx"] = false;
			break;
	}

	// �� �{�b�N�X�p�X���[�h�̗L��.
	Bool b_Rtn = False;
	char sc_BoxPassword[WAPD_BoxPasswordMaxLength] = {0};
	char* psc_BoxPassword = NULL;
	b_Rtn = APIC_AccessTokenManager::newInstance()->getBoxPassword(
		params->AccessToken,
		m_si32_BoxNo,
		sc_BoxPassword );
	if( False == b_Rtn ) {
		printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
		generateErrorResponseBody( WAPE_BoxError_BoxNotOpened );
		return WAPD_AnyError;
	}

	ushort us_StringNum = 0;
	Bool b_CheckRet = getStringLengthUTF8(sc_BoxPassword, WAPE_CheckString_1String, us_StringNum);
	if(False  == b_CheckRet){
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	if( 0 < us_StringNum ) {
		(*m_Response)["is_box_password"] = true;
		psc_BoxPassword = sc_BoxPassword;
	} else {
		(*m_Response)["is_box_password"] = false;
	}

	// ���L�ҏ��擾.
	APIC_BoxOption c_BoxOption;
	si32_ReturnValue = pc_Box->getBoxOption(
		pc_User,					// ���[�U�[���.
		psc_BoxPassword,			// �{�b�N�X�p�X���[�h.
		&c_BoxOption,				// �{�b�N�X�I�v�V�������.
		pc_Track);					// ������.
	pc_Box->deleteInstance();

	switch(si32_ReturnValue) {
		case APID_DocapiMethodOk:
			{
				// �{�b�N�X��ʂ��V�X�e���̏ꍇ�̓G���[�I��.
				if( APIE_BoxmakerSystem == c_BoxOption.sl_BoxCreateInfo ) {
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
					return WAPD_AnyError;
				}

				// �{�b�N�X���.
				char sc_BoxType[WAPD_MaxKeyLength] = {0};
				if(False == WAPS_CommonTableString<WAPE_BoxType, APIE_BoxOptionCreateInfo>::CommonToWapString(
					c_BoxOption.sl_BoxCreateInfo, sc_BoxType)){
					m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
					printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
					generateErrorResponseBody( WAPE_BoxError_None );
					return WAPD_AnyError;
				}
				(*m_Response)["type"] = sc_BoxType;

				// �{�b�N�X���L��.
				char sc_BoxOwnerName[WAPD_BoxOwnerNameMaxLength] = {0};
				if( APIE_BoxmakerGroup == c_BoxOption.sl_BoxCreateInfo ){
					// �O���[�v�{�b�N�X�̏ꍇ.
					pc_Track = APIC_Track::newInstance(c_BoxInfo.ul_OwnUserID);
					if(NULL != pc_Track){
						pc_Track->getTrackName(sc_BoxOwnerName);
					}

					// ����Ǘ��p�X���[�h�݂̂̏ꍇ�AgetTrackName()�ł͕��喼����Ȃ̂ōĎ擾.
					ushort us_StringNum = 0;
					Bool b_CheckRet = getStringLengthUTF8(sc_BoxOwnerName, WAPE_CheckString_1String, us_StringNum);
					if(False  == b_CheckRet){
						m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
						printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
						generateErrorResponseBody( WAPE_BoxError_None );
						return WAPD_AnyError;
					}
					if( 0 >= us_StringNum ) {
						if(NULL != pc_Track){
							pc_Track->getTrackDispNameUTF8(sc_BoxOwnerName, TYPE_CharSetUTF8);
						}
					}
				}
				else if( APIE_BoxmakerUser == c_BoxOption.sl_BoxCreateInfo ){
					// �l�{�b�N�X�̏ꍇ.
					TYPE_UserAuthentication e_UserAuth = APIC_UserAuthentication::newInstance()->getUserAuthentication();
					WAPE_BoxUserType e_BoxOwnerType = getBoxOwnerType( APIE_BoxmakerUser, c_BoxInfo.ul_OwnUserID );
					WAPE_BoxUserType e_OperatorType = getBoxUserType( pc_User, pc_Track );

					// ���ԔF�؃��[�U�[�̃{�b�N�X�́A���g�ȊO�͏��L�Җ������邱�Ƃ͂ł��Ȃ��̂ŋ�ɐݒ�.
					if ( ( ( TYPE_UserAuthenticationIntermeddiateServer == e_UserAuth ) || 
					   ( TYPE_UserAuthenticationDeviceAndMidAuth == e_UserAuth ) ) && 
					   ( WAPE_BoxUserType_User_Mid != e_OperatorType ) &&
					   ( WAPE_BoxUserType_User_Mid == e_BoxOwnerType ) ) {
						sc_BoxOwnerName[0] = '\0';
					}
					else {
						pc_User = APIC_User::newInstance( c_BoxInfo.ul_OwnUserID );
						if(NULL != pc_User){
							pc_User->getUserNameUTF8( sc_BoxOwnerName );
						}
					}
				}
				else {
					// ���L�{�b�N�X�̏ꍇ.
					// ���L�Җ��͕\�����Ȃ�.
				}
				(*m_Response)["owner_info"]["owner_name"] = sc_BoxOwnerName;

				// ���L�҂̑�����O���T�[�o�[��.
				char sc_BoxServerName[WAPD_ServerNameMaxLength] = {0};
				if(APIE_BoxmakerUser == c_BoxOption.sl_BoxCreateInfo){
					// �l�{�b�N�X�̏ꍇ.
					APIC_User* pc_OwnerUser = APIC_User::newInstance(c_BoxInfo.ul_OwnUserID);
					if(pc_OwnerUser != NULL){
						// �F�ؕ�����"�{��+�O���T�[�o�["�ȊO�̏ꍇ�A����(V1.2.0)���������{.
						if(TYPE_UserAuthenticationDeviceAndServer != APIC_UserAuthentication::newInstance()->getUserAuthentication()) {
							pc_OwnerUser->getServerName(sc_BoxServerName);
						// �F�ؕ�����"�{��+�O���T�[�o�["�̏ꍇ�A�{�b�N�X���[�U�̃��O�C����ʂ���O���T�[�o�F�؃��[�U�����f.
						} else {
							if(TYPE_UserAuthenticationServer == pc_OwnerUser->getLoginUserAuthenticationType()){
								// �O���T�[�o�F�؃��[�U�̏ꍇ�A�F�؃T�[�o�����擾���ݒ�.
								pc_OwnerUser->getServerName(sc_BoxServerName);
							}
						}
					}
				}
				(*m_Response)["owner_info"]["server_name"] = sc_BoxServerName;

				// �h�L�������g�����폜����.
				int32_t si32_DeleteTime = 0;
				if(False == WAPS_CommonTable<WAPE_DelTime, APIE_BoxOptionDelTime>::CommonToWap(
					c_BoxOption.sl_AutoDeleteTime, si32_DeleteTime)){
					if ( ( APIE_5min > c_BoxOption.sl_AutoDeleteTime ) ||
						 ( APIE_12h  < c_BoxOption.sl_AutoDeleteTime ) ) {
						m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
						printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
						generateErrorResponseBody( WAPE_BoxError_None );
						return WAPD_AnyError;
					}
					si32_DeleteTime = static_cast<int32_t>(c_BoxOption.sl_AutoDeleteTime);
				}
				(*m_Response)["auto_document_delete_time"] = si32_DeleteTime;

				m_ResponseHeader->Status = WAPD_STATUS_OK;
				break;
			}

		case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			return WAPD_AnyError;

		case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
			return WAPD_AnyError;

		case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
		case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
		default:
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
	}	

	return WAPD_NoError;
}

/**
 * @brief ���[�U�[�{�b�N�X���ݒ�
 * @param[in] param �T�u�R���g���[���[
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::setUserBoxInformation( WAPS_SubController *params )
{
	int32_t si32_Ret = WAPD_AnyError;
	
	// �O������`�F�b�N.
	si32_Ret = checkSetBoxInfoReqStatus();
	if( WAPD_FatalError == si32_Ret ){
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	} else if( WAPD_AnyError == si32_Ret ){
		printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	} else {
		// �X�R�A�`�F�b�N�Ή�.
	}

	// �{�b�N�X���݃`�F�b�N.
	Bool b_IsExist = False;
	si32_Ret = boxExists( m_si32_BoxNo, b_IsExist );
	if( WAPD_NoError != si32_Ret ) {
		return WAPD_AnyError;
	}
	if( False == b_IsExist ) {
		printf("404:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //404->ErrorStatus[WAPD_STATUS_NOT_FOUND] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_NOT_FOUND;
		generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
		return WAPD_AnyError;
	}
	
	// ���[�U�[�A������擾.
	APIC_User* pc_User = NULL;
    APIC_Track* pc_Track = NULL;
	getUserTrackInformation( params, &pc_User, &pc_Track );

	// �{�b�N�X�p�X���[�h�擾.
	Bool b_Rtn = False;
	char sc_BoxPassword[WAPD_BoxPasswordMaxLength] = {};
	char* psc_BoxPassword = NULL;
	b_Rtn = APIC_AccessTokenManager::newInstance()->getBoxPassword(
		params->AccessToken,
		m_si32_BoxNo,
		sc_BoxPassword );
	if( False == b_Rtn ) {
		printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
		generateErrorResponseBody( WAPE_BoxError_BoxNotOpened );
		return WAPD_AnyError;
	}

	ushort us_StringNum = 0;
	Bool b_CheckRet = getStringLengthUTF8(sc_BoxPassword, WAPE_CheckString_1String, us_StringNum);
	if(False  == b_CheckRet){
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	if( 0 < us_StringNum ) {
		psc_BoxPassword = sc_BoxPassword;
	}

	// �{�b�N�X�C���X�^���X�擾.
	APIC_Box* pc_Box = APIC_Box::newInstance();
	if(NULL == pc_Box){
		WAPG_API_trace("%s(%d) %s : APIC_Box instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	pc_Box->setBoxId( m_si32_BoxNo );

	// 01.�{�b�N�X���ݒ�.
	si32_Ret = setBoxName( params, pc_Box, pc_User, pc_Track, psc_BoxPassword );
	if( WAPD_NoError != si32_Ret ) {
		WAPG_API_trace("%s(%d) %s : setBoxName failed \n", __FILE__, __LINE__, __FUNCTION__);
		pc_Box->deleteInstance();
		return WAPD_AnyError;
	}

	// 02.���������폜���Ԑݒ�.
	si32_Ret = setAutoDeleteTime( params, pc_Box, pc_User, pc_Track, psc_BoxPassword );
	if( WAPD_NoError != si32_Ret ) {
		WAPG_API_trace("%s(%d) %s : setAutoDeleteTime failed \n", __FILE__, __LINE__, __FUNCTION__);
		pc_Box->deleteInstance();
		return WAPD_AnyError;
	}

	// 03.�{�b�N�X��ʂ���я��L�Ґݒ�.
	si32_Ret = setBoxTypeAndOwner( params, pc_Box, pc_User, pc_Track, psc_BoxPassword );
	if( WAPD_NoError != si32_Ret ) {
		WAPG_API_trace("%s(%d) %s : setBoxTypeAndOwner failed \n", __FILE__, __LINE__, __FUNCTION__);
		pc_Box->deleteInstance();
		return WAPD_AnyError;
	}

	// 04.�{�b�N�X�����L�[��ʐݒ�.
	si32_Ret = setSearchKey( params, pc_Box, pc_User, pc_Track, psc_BoxPassword );
	if( WAPD_NoError != si32_Ret ) {
		WAPG_API_trace("%s(%d) %s : setSearchKey failed \n", __FILE__, __LINE__, __FUNCTION__);
		pc_Box->deleteInstance();
		return WAPD_AnyError;
	}

	// 05.�e�W��M�@�\���ݒ�.
	si32_Ret = setConfidentialRx( params, pc_Box, pc_User, pc_Track, psc_BoxPassword );
	if( WAPD_NoError != si32_Ret ) {
		WAPG_API_trace("%s(%d) %s : setConfidentialRx failed \n", __FILE__, __LINE__, __FUNCTION__);
		pc_Box->deleteInstance();
		return WAPD_AnyError;
	}

	// 06.�{�b�N�X�p�X���[�h�ݒ�.
	si32_Ret = setBoxPassword( params, pc_Box, pc_User, pc_Track, psc_BoxPassword );
	if( WAPD_NoError != si32_Ret ) {
		WAPG_API_trace("%s(%d) %s : setBoxPassword failed \n", __FILE__, __LINE__, __FUNCTION__);
		pc_Box->deleteInstance();
		return WAPD_AnyError;
	}

	pc_Box->deleteInstance();

	return WAPD_NoError;
}

/**
 * @brief ���N�G�X�g�{�f�B����{�b�N�X�ԍ����擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	si32_BoxNo �{�b�N�X�ԍ�
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getBoxNoFromBody( WAPS_SubController *params, int32_t& si32_BoxNo )
{
	int32_t si32_Ret = WAPD_AnyError;
	Bool	b_GetBoxNo = False;		// �{�b�N�X�ԍ��擾�t���O.

	if( NULL == params->Param ) {
		// �{�f�B�������ꍇ�͂ł��G���[�ɂ��Ȃ�.
		b_GetBoxNo = False;

	} else {
		if( !params->Param->isObject() ) {
			WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}

		if( params->Param->isMember("box_no") ) {
			Json::Value& box_no = (*params->Param)["box_no"];
			if( box_no.type() != Json::intValue ) {
				WAPG_API_trace("%s(%d) %s : Illegal json value type box_no \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
				return WAPD_AnyError;
			}

			si32_BoxNo = box_no.asInt();

			// �͈̓`�F�b�N.
			if( ( WAPD_BoxNoMin > si32_BoxNo ) || ( WAPD_BoxNoMax < si32_BoxNo ) ) {
				WAPG_API_trace("%s(%d) %s : Illegal json value : box_no \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidBoxNo );
				return WAPD_AnyError;
			}

			// �{�b�N�X�ԍ��擾.
			b_GetBoxNo = True;

		} else {
			// �{�b�N�X�ԍ��擾�o���Ȃ�.
			b_GetBoxNo = False;
		}
	}

	if ( False == b_GetBoxNo ) {
		// �{�b�N�X�ԍ��擾�o���Ȃ��Ƃ��͍ŏ��{�b�N�X�ԍ����擾.
		APIC_Box* pc_Box = APIC_Box::newInstance();
		if(NULL == pc_Box){
			WAPG_API_trace("%s(%d) %s : APIC_Box instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}

		int32_t ret = pc_Box->getNoUsedBoxID( &si32_BoxNo );
		pc_Box->deleteInstance();
		if(ret != APID_DocapiMethodOk) {
			WAPG_API_trace("%s(%d) %s : getNoUsedBoxID Faild \n", __FILE__, __LINE__, __FUNCTION__);
			printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}
	}

	WAPD_DEBUG1("si32_BoxNo = %d\n", si32_BoxNo);
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief ���N�G�X�g�{�f�B����{�b�N�X��ʂ��擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	sc_BoxType �{�b�N�X���
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getBoxTypeFromBody( WAPS_SubController *params, APIE_BoxOptionCreateInfo& e_BoxType )
{
	int32_t si32_Ret = WAPD_AnyError;
	if( NULL == params->Param ) {
		// �{�f�B�������ꍇ�͂ł��G���[�ɂ��Ȃ�.
	} else {
		if( !params->Param->isObject() ) {
			WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}

		if( params->Param->isMember("type") ) {
			Json::Value& type = (*params->Param)["type"];
			if( type.type() != Json::stringValue ) {
				WAPG_API_trace("%s(%d) %s : Illegal json value type : type \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
				return WAPD_AnyError;
			}
			if( WAPD_MaxKeyLength <= type.asString().length() ) {
				WAPG_API_trace("%s(%d) %s : Illegal sc_BoxType value \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
				return WAPD_AnyError;
			}

			char sc_BoxType[WAPD_MaxKeyLength] = {0};
			strncpy(sc_BoxType, type.asString().c_str(), sizeof(sc_BoxType) - 1 );
			if( False == WAPS_CommonTableString<WAPE_BoxType, APIE_BoxOptionCreateInfo>::WapStringToCommon(
				sc_BoxType, e_BoxType )){
				WAPG_API_trace("%s(%d) %s : Illegal sc_BoxType value \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
				return WAPD_AnyError;
			}
		} else {
			// �{�b�N�X��ʂ��ݒ肳��Ă��Ȃ��ꍇ�̓p�����[�^�̒l�͍X�V���Ȃ�.
		}
	}

	WAPD_DEBUG1("e_BoxType = %d\n", e_BoxType);
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief ���N�G�X�g�{�f�B����{�b�N�X�p�X���[�h���擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	sc_BoxPassword �{�b�N�X�p�X���[�h
 * @param[in]	e_BoxType �{�b�N�X���
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getBoxPasswordFromBody( WAPS_SubController *params, char (&sc_BoxPassword)[WAPD_BoxPasswordMaxLength], APIE_BoxOptionCreateInfo e_BoxType )
{
	if( NULL == params->Param ) {
		// �{�f�B�������ꍇ�ł��G���[�ɂ��Ȃ�.
	} else {
		if( !params->Param->isObject() ) {
			WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}

		if( params->Param->isMember("box_password") ) {
			Json::Value& box_password = (*params->Param)["box_password"];
			if( box_password.type() != Json::stringValue ) {
				WAPG_API_trace("%s(%d) %s : Illegal json value type : box_password \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
				return WAPD_AnyError;
			}

			std::string str_box_password = box_password.asString();
			// �o�C�g���`�F�b�N.
			if ( (WAPD_BoxPasswordMaxLength - 1) < str_box_password.length() ){
				WAPD_DEBUG("Illegal password length Byte \n");
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidPassword );
				return WAPD_AnyError;
			}

			// sc_BoxPassword ��������.
			memset(sc_BoxPassword, 0, sizeof(sc_BoxPassword));

			strncpy( sc_BoxPassword, box_password.asString().c_str(), sizeof(sc_BoxPassword) - 1 );

			// �{�b�N�X��ʂ����L�{�b�N�X�̏ꍇ�̂݃p�X���[�h�K��`�F�b�N.
			if( APIE_BoxmakerAuto == e_BoxType ) {
				if( WAPE_PasswordRules_On_Invalid == checkPasswordRules( sc_BoxPassword ) ) {
					WAPG_API_trace("%s(%d) %s : PasswordRulesOn check NG.\n", __FILE__, __LINE__, __FUNCTION__);
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidPassword );
					return WAPD_AnyError;
				}
			}
		} else {
			// �{�b�N�X�p�X���[�h���ݒ肳��Ă��Ȃ��ꍇ�̓p�����[�^�̒l�͍X�V���Ȃ�.
		}
	}

	WAPD_DEBUG1("sc_BoxPassword = %s\n", sc_BoxPassword);
	return WAPD_NoError;
}

/**
 * @brief �N�G���[�p�����[�^���烆�[�U�[�{�b�N�X�����l���擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	sc_SearchKey ���[�U�[�{�b�N�X�����l
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getSearchKeyFromQuery( WAPS_SubController *params, TYPE_SearchKey& e_SearchKey )
{
	int32_t si32_Ret = WAPD_AnyError;
	if( NULL == params->Search ) {
		WAPG_API_trace("%s(%d) %s : Body is NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	if( !params->Search->isObject() ) {
		WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	if( params->Search->isMember("search") ) {
		Json::Value& search = (*params->Search)["search"];
		if( search.type() != Json::stringValue ) {
			WAPG_API_trace("%s(%d) %s : Illegal json value type : search \n", __FILE__, __LINE__, __FUNCTION__);
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}
		if( WAPD_MaxKeyLength <= search.asString().length() ) {
			WAPG_API_trace("%s(%d) %s : Illegal search key value \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidSearchKey );
			return WAPD_AnyError;
		}

		char sc_Search[WAPD_MaxKeyLength] = {0};
		strncpy(sc_Search, search.asString().c_str(), sizeof(sc_Search) - 1 );
		if(False == WAPS_CommonTableString<WAPE_SearchKey, TYPE_SearchKey>::WapStringToCommon(
			sc_Search, e_SearchKey )){
			WAPG_API_trace("%s(%d) %s : Illegal search key value \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidSearchKey );
			return WAPD_AnyError;
		}
	} else {
		// �{�b�N�X��ʂ��ݒ肳��Ă��Ȃ��ꍇ�̓p�����[�^�̒l�͍X�V���Ȃ�.
	}

	WAPD_DEBUG1("e_SearchKey = %d\n", e_SearchKey);
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief �N�G���[�p�����[�^���烊�X�g�擾�J�n�ʒu���擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	si32_Offset ���X�g�擾�J�n�ʒu
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getOffsetFromQuery( WAPS_SubController *params, int32_t& si32_Offset )
{
	if( NULL == params->Search ) {
		WAPG_API_trace("%s(%d) %s : Query is NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	if( !params->Search->isObject() ) {
		WAPG_API_trace("%s(%d) %s : Query is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	int32_t si32_Ret = WAPD_AnyError;

	// �����l�ݒ�.
	si32_Offset = 1;

	if( params->Search->isMember("offset") ) {
		Json::Value& offset = (*params->Search)["offset"];
		if( offset.type() != Json::stringValue ) {
			WAPG_API_trace("%s(%d) %s : Illegal json value type : offset \n", __FILE__, __LINE__, __FUNCTION__);
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}

		const char* psc_String = offset.asString().c_str();
		int32_t si32_TempOffset = 0;
		uint32_t ui32_length = 0;
		if( WAPD_NoError != stoi(psc_String, si32_TempOffset, ui32_length) ) {
			WAPG_API_trace("%s(%d) %s : not string : offset \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidOffset );
			return WAPD_AnyError;
		}

		si32_Offset = si32_TempOffset;
		WAPD_DEBUG1("offset = %d\n", si32_Offset);

		// �͈̓`�F�b�N(1�`1000).
		if( ( WAPD_GetListMinOffset > si32_Offset ) || ( WAPD_GetListMaxOffset < si32_Offset ) ) {
			WAPG_API_trace("%s(%d) %s : Illegal offset value offset = %d\n", __FILE__, __LINE__, __FUNCTION__, si32_Offset);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidOffset );
			return WAPD_AnyError;
		}
	} else {
		// ���X�g�擾�J�n�ʒu���ݒ肳��Ă��Ȃ��ꍇ�̓p�����[�^�̒l�͍X�V���Ȃ�.
	}

	WAPD_DEBUG1("si32_Offset = %d\n", si32_Offset);
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief �N�G���[�p�����[�^����ő�擾�����擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	si32_Num �ő�擾��
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getNumFromQuery( WAPS_SubController *params, int32_t& si32_Num )
{
	if( NULL == params->Search ) {
		WAPG_API_trace("%s(%d) %s : Query is NULL \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}
	if( !params->Search->isObject() ) {
		WAPG_API_trace("%s(%d) %s : Query is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	int32_t si32_Ret = WAPD_AnyError;

	// �����l�ݒ�.
	si32_Num = WAPD_GetListInitNum;

	if( params->Search->isMember("num") ) {
		Json::Value& num = (*params->Search)["num"];
		if( num.type() != Json::stringValue ) {
			WAPG_API_trace("%s(%d) %s : Illegal json value type : num \n", __FILE__, __LINE__, __FUNCTION__);
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}

		const char* psc_String = num.asString().c_str();
		int32_t si32_TempNum = 0;
		uint32_t ui32_length = 0;
		if( WAPD_NoError != stoi(psc_String, si32_TempNum, ui32_length) ) {
			WAPG_API_trace("%s(%d) %s : not string : num \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidNum );
			return WAPD_AnyError;
		}

		si32_Num = si32_TempNum;
		WAPD_DEBUG1("num = %d\n", si32_Num);

		// �͈̓`�F�b�N(1�`1000).
		if( ( WAPD_GetListMinNum > si32_Num ) || ( WAPD_GetListMaxNum < si32_Num ) ) {
			WAPG_API_trace("%s(%d) %s : Illegal num value \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidNum );
			return WAPD_AnyError;
		}
	}

	WAPD_DEBUG1("si32_Num = %d\n", si32_Num);
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief ���N�G�X�g�{�f�B����{�b�N�X�����擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	sc_BoxName �{�b�N�X��
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getBoxNameFromBody( WAPS_SubController *params, char (&sc_BoxName)[WAPD_BoxNameMaxLength] )
{
	if( NULL == params->Param ) {
		WAPG_API_trace("%s(%d) %s : Body is NULL \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}
	if( !params->Param->isObject() ) {
		WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}

	int32_t si32_Ret = WAPD_AnyError;

	if( params->Param->isMember("box_name") ) {
		Json::Value& box_name = (*params->Param)["box_name"];
		if( box_name.type() != Json::stringValue ) {
			WAPG_API_trace("%s(%d) %s : Illegal json value type : box_name \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}

		memset( sc_BoxName, 0, WAPD_BoxNameMaxLength );
		strncpy( sc_BoxName, box_name.asString().c_str(), (WAPD_BoxNameMaxLength - 1) );
		std::string str_BoxName = sc_BoxName;
		// �o�C�g���`�F�b�N.
		if ( ( WAPD_BoxNameMinChar > str_BoxName.length() ) || ( (WAPD_BoxNameMaxLength - 1) < str_BoxName.length() ) ){
			WAPG_API_trace("%s(%d) %s : Illegal password length Byte\n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxName );
			return WAPD_AnyError;
		}
		
		ushort us_StringNum = 0;
		Bool b_CheckRet = getStringLengthUTF8(sc_BoxName, WAPE_CheckString_1String, us_StringNum);
		if(False  == b_CheckRet){
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}

		// 1�`20�����ȓ��ł��邱��.
		if ( ( WAPD_BoxNameMinChar > us_StringNum ) || ( WAPD_BoxNameMaxChar < us_StringNum ) ){
			WAPG_API_trace("%s(%d) %s : Illegal password length \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxName );
			return WAPD_AnyError;
		}
	}

	WAPD_DEBUG1("sc_BoxName = %s\n", sc_BoxName);
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief ���N�G�X�g�{�f�B���當���폜���Ԃ��擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	sc_BoxName �����폜����
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s�AWAPD_NoSetting(2)�F�ݒ�Ȃ�
 */
int32_t WAPC_UserBoxController::getAutoDeleteTimeFromBody( WAPS_SubController *params, int32_t& si32_DeleteTime)
{
	int32_t si32_Ret = WAPD_AnyError;
	if( NULL == params->Param ) {
		WAPG_API_trace("%s(%d) %s : Body is NULL \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}
	if( !params->Param->isObject() ) {
		WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}

	if( params->Param->isMember("auto_document_delete_time") ) {
		Json::Value& delete_time = (*params->Param)["auto_document_delete_time"];
		if( !delete_time.isObject() ) {
			WAPG_API_trace("%s(%d) %s : Illegal json type : auto_document_delete_time \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}

		if(delete_time.isMember("type")){
			Json::Value& type = delete_time["type"];

			if( type.type() != Json::stringValue ) {
				WAPG_API_trace("%s(%d) %s : Illegal json type : type \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
				return WAPD_AnyError;
			}
			if( WAPD_MaxKeyLength <= type.asString().length() ) {
				WAPG_API_trace("%s(%d) %s : Illegal auto_document_delete_time value \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidAutoDeleteTime );
				return WAPD_AnyError;
			}

			if( WAPD_BOX_STR_MIN == type.asString() ){
				// WAPD_BOX_MIN�̏ꍇ�Atime�̒l���擾.
				if(delete_time.isMember("time")){
					Json::Value& time = delete_time["time"];
					
					if(time.type() != Json::intValue){
						WAPG_API_trace("%s(%d) %s : Illegal auto_document_delete_time value \n", __FILE__, __LINE__, __FUNCTION__);
						printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
						m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
						generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
						return WAPD_AnyError;
					}

					si32_DeleteTime = time.asInt();

					// �͈̓`�F�b�N(5�`720).
					if( ( WAPD_BOX_5MIN > si32_DeleteTime ) || ( WAPD_BOX_12HOUR < si32_DeleteTime ) ) {
						WAPG_API_trace("%s(%d) %s : Illegal auto_document_delete_time value \n", __FILE__, __LINE__, __FUNCTION__);
						printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
						m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
						generateErrorResponseBody( WAPE_BoxError_InvalidAutoDeleteTime );
						return WAPD_AnyError;
					}

				} else {
					WAPG_API_trace("%s(%d) %s : Illegal auto_document_delete_time value \n", __FILE__, __LINE__, __FUNCTION__);
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidAutoDeleteTime );
					return WAPD_AnyError;
				}
			} else {
				char sc_DeleteType[WAPD_MaxKeyLength] = {0};
				APIE_BoxOptionDelTime e_DeleteTime = APIE_no_del;
				strncpy(sc_DeleteType, type.asString().c_str(), sizeof(sc_DeleteType) - 1 );
				if(False == WAPS_CommonTableString<WAPE_DelTimeStr, APIE_BoxOptionDelTime>::WapStringToCommon(
					sc_DeleteType, e_DeleteTime )){
					WAPG_API_trace("%s(%d) %s : Illegal auto_document_delete_time value \n", __FILE__, __LINE__, __FUNCTION__);
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidAutoDeleteTime );
					return WAPD_AnyError;
				}

				si32_DeleteTime = static_cast<int32_t>(e_DeleteTime);
			}
		} else {
			// type �ȗ�����NG.
			WAPG_API_trace("%s(%d) %s : Illegal json type : type is nothing \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}
	} else {
		return WAPD_NoSetting;
	}

	WAPD_DEBUG1("si32_DeleteTime = %d\n", si32_DeleteTime);
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief ���N�G�X�g�{�f�B���珊�L�Җ������擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	str_OwnerName ���L�Җ�
 * @param[out]	str_ServerName �T�[�o�[��
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getOwnerInformationFromBody( WAPS_SubController *params, std::string& str_OwnerName, std::string& str_ServerName )
{
	if( NULL == params->Param ) {
		WAPG_API_trace("%s(%d) %s : Body is NULL \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}
	if( !params->Param->isObject() ) {
		WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}
	Json::Value& val_Root = *params->Param;

	// ���L�Җ�.
	if( val_Root.isMember("owner_name") ) {
		Json::Value& owner = val_Root["owner_name"];

		if( owner.type() != Json::stringValue ) {
			WAPG_API_trace("%s(%d) %s : Illegal json type : owner_name \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}
		str_OwnerName = owner.asString();

		// �o�C�g���`�F�b�N.
		if ( ( WAPD_BoxOwnerNameMinChar > str_OwnerName.length() ) ||
				( (WAPD_BoxOwnerNameMaxLength - 1) < str_OwnerName.length() ) ){
			WAPG_API_trace("%s(%d) %s : Illegal BoxOwnerName length Byte\n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxOwnerName );
			return WAPD_AnyError;
		}

		ushort us_StringNum = 0;
		Bool b_CheckRet = getStringLengthUTF8(str_OwnerName.c_str(), WAPE_CheckString_1String, us_StringNum);
		if(False  == b_CheckRet){
			WAPG_API_trace("%s(%d) %s : getStringLengthUTF8 failed \n", __FILE__, __LINE__, __FUNCTION__);
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}

		// 1�`64�����ȓ��ł��邱��.
		if ( ( WAPD_BoxOwnerNameMinChar > us_StringNum ) ||
				( WAPD_BoxOwnerNameMaxChar < us_StringNum ) ){
			WAPG_API_trace("%s(%d) %s : Illegal BoxOwnerName length \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxOwnerName );
			return WAPD_AnyError;
		}
	}

	//�T�[�o�[��.
	if( val_Root.isMember("server_name") ) {
		Json::Value& server = val_Root["server_name"];

		if( server.type() != Json::stringValue ) {
			WAPG_API_trace("%s(%d) %s : Illegal json type : server_name \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}
		str_ServerName = server.asString();

		// �o�C�g���`�F�b�N.
		if ( ( WAPD_ServerNameMinChar > str_ServerName.length() ) || 
				( WAPD_ServerNameMaxChar < str_ServerName.length() ) ){
			WAPG_API_trace("%s(%d) %s : Illegal ServerName length Byte\n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidServerName );
			return WAPD_AnyError;
		}

		// �}���`�o�C�g�������܂܂��ꍇ�G���[.
		int32_t si32_Ret = WAPD_AnyError;
		Bool b_CheckRet = False;
		si32_Ret = containsMultiByteCharacterUTF8( str_ServerName.c_str(), b_CheckRet );
		if( WAPD_NoError != si32_Ret ) {
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}
		if( True == b_CheckRet ){
			WAPG_API_trace("%s(%d) %s : ServerName contains multi-byte character \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidServerName );
			return WAPD_AnyError;
		}

		// 1�`32�����ȓ��ł��邱��.
		if ( ( WAPD_ServerNameMinChar > str_ServerName.length() ) || 
				( WAPD_ServerNameMaxChar < str_ServerName.length() ) ){
			WAPG_API_trace("%s(%d) %s : Illegal ServerName length \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidServerName );
			return WAPD_AnyError;
		}
	}

	WAPD_DEBUG2("OwnerName = %s, ServerName = %s\n", str_OwnerName.c_str(), str_ServerName.c_str());
	return WAPD_NoError;
}

/**
 * @brief ���N�G�X�g�{�f�B����{�b�N�X��ʊ֘A�����擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	str_BoxType �{�b�N�X���
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getBoxTypeFromBody( WAPS_SubController *params, std::string& str_BoxType )
{
	if( NULL == params->Param ) {
		WAPG_API_trace("%s(%d) %s : Body is NULL \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}
	if( !params->Param->isObject() ) {
		WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}
	Json::Value& val_Root = *params->Param;

	// �{�b�N�X���.
	if( val_Root.isMember("type") ) {
		Json::Value& type = val_Root["type"];

		if( type.type() != Json::stringValue ) {
			WAPG_API_trace("%s(%d) %s : Illegal json type : type \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}

		str_BoxType = type.asString();

		if( ( str_BoxType != "PUBLIC" )
			&& ( str_BoxType != "PERSONAL" )
			&& ( str_BoxType != "GROUP" ) ) {
			WAPG_API_trace("%s(%d) %s : not supported box type\n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
			return WAPD_AnyError;
		}
	}

	WAPD_DEBUG1("BoxType = %s\n", str_BoxType.c_str());
	return WAPD_NoError;
}

/**
 * @brief ���N�G�X�g�{�f�B���猟���L�[��ʂ��擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	sc_str_SearchKey �����L�[���
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getSearchKeyFromBody( WAPS_SubController *params, string& str_SearchKey )
{
	int32_t si32_Ret = WAPD_AnyError;

	if( NULL == params->Param ) {
		WAPG_API_trace("%s(%d) %s : Body is NULL \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}
	if( !params->Param->isObject() ) {
		WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}

	if( params->Param->isMember("search_key") ) {
		Json::Value& search_key = (*params->Param)["search_key"];
		if( search_key.type() != Json::stringValue ) {
			WAPG_API_trace("%s(%d) %s : Illegal json value type : search_key \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}
		if( WAPD_MaxKeyLength <= search_key.asString().length() ) {
			WAPG_API_trace("%s(%d) %s : Too long : search_key \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidSearchKey );
			return WAPD_AnyError;
		}

		str_SearchKey = search_key.asString();
	}

	WAPD_DEBUG1("str_SearchKey = %s\n", str_SearchKey.c_str());
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief ���N�G�X�g�{�f�B����{�b�N�X�p�X���[�h�����擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[in]	pc_Box		�{�b�N�X�C���X�^���X
 * @param[in]	pc_User		���[�U�[�C���X�^���X
 * @param[in]	pc_Track	����C���X�^���X
 * @param[in]	psc_BoxPassword	�{�b�N�X�p�X���[�h
 * @param[out]	s_OwnerName �{�b�N�X�p�X���[�h�ݒ���
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getBoxPasswordInformationFromBody(
	WAPS_SubController *params,
	APIC_Box* pc_Box,
	APIC_User* pc_User,
	APIC_Track* pc_Track,
	char* psc_BoxPassword,
	WAPS_BoxPasswordInformation& s_BoxPassword
	)
{
	int32_t si32_Ret = WAPD_AnyError;

	if( NULL == params->Param ) {
		// �{�f�B�������ꍇ�ł��G���[�ɂ��Ȃ�.
	} else {
		if( !params->Param->isObject() ) {
			WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}

		if( params->Param->isMember("box_password_info") ) {
			Json::Value& box_password_info = (*params->Param)["box_password_info"];
			if( !box_password_info.isObject() ) {
				WAPG_API_trace("%s(%d) %s : Illegal json type : box_password_info \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
				return WAPD_AnyError;
			}

			// �����[�U�[�{�b�N�X�p�X���[�h.
			if( box_password_info.isMember("old_box_password") ) {
				Json::Value& oldPass = box_password_info["old_box_password"];

				if( oldPass.type() != Json::stringValue ) {
					WAPG_API_trace("%s(%d) %s : Illegal json type : oldPass \n", __FILE__, __LINE__, __FUNCTION__);
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
					return WAPD_AnyError;
				}
				s_BoxPassword.str_OldPassword = oldPass.asString();

				ushort us_StringNum = 0;

				// �o�C�g���`�F�b�N.
				if ( (WAPD_BoxPasswordMaxLength - 1) < s_BoxPassword.str_OldPassword.length() ){
					WAPG_API_trace("%s(%d) %s : Illegal password length Byte\n", __FILE__, __LINE__, __FUNCTION__);
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidPassword );
					return WAPD_AnyError;
				}

				// �������`�F�b�N.
				Bool b_CheckRet = False;
				b_CheckRet = getStringLengthUTF8(s_BoxPassword.str_OldPassword.c_str(), WAPE_CheckString_1String, us_StringNum);
				if(False  == b_CheckRet){
					m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
					printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
					generateErrorResponseBody( WAPE_BoxError_None );
					return WAPD_AnyError;
				}

				if ( ( WAPD_BoxPasswordMinChar > us_StringNum ) || ( WAPD_BoxPasswordMaxChar < us_StringNum ) ){
					WAPG_API_trace("%s(%d) %s : Illegal password length \n", __FILE__, __LINE__, __FUNCTION__);
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidPassword );
					return WAPD_AnyError;
				}
			}

			// �V���[�U�[�{�b�N�X�p�X���[�h.
			if( box_password_info.isMember("new_box_password") ) {
				Json::Value& newPass = box_password_info["new_box_password"];

				if( newPass.type() != Json::stringValue ) {
					WAPG_API_trace("%s(%d) %s : Illegal json type : newPass \n", __FILE__, __LINE__, __FUNCTION__);
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
					return WAPD_AnyError;
				}
				s_BoxPassword.str_NewPassword = newPass.asString();

				ushort us_StringNum = 0;

				// �o�C�g���`�F�b�N.
				if ( (WAPD_BoxPasswordMaxLength - 1) < s_BoxPassword.str_NewPassword.length() ){
					WAPG_API_trace("%s(%d) %s : Illegal password length Byte\n", __FILE__, __LINE__, __FUNCTION__);
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidPassword );
					return WAPD_AnyError;
				}

				// �������`�F�b�N.
				Bool b_CheckRet = False;
				b_CheckRet = getStringLengthUTF8(s_BoxPassword.str_NewPassword.c_str(), WAPE_CheckString_1String, us_StringNum);
				if(False  == b_CheckRet){
					m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
					printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
					generateErrorResponseBody( WAPE_BoxError_None );
					return WAPD_AnyError;
				}

				if ( ( WAPD_BoxPasswordMinChar > us_StringNum ) || ( WAPD_BoxPasswordMaxChar < us_StringNum ) ){
					WAPG_API_trace("%s(%d) %s : Illegal password length \n", __FILE__, __LINE__, __FUNCTION__);
					printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
					m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
					generateErrorResponseBody( WAPE_BoxError_InvalidPassword );
					return WAPD_AnyError;
				}

				// �{�b�N�X�I�v�V�����擾.
				APIC_BoxOption c_BoxOption;
				int32_t si32_ReturnValue = APID_DocapiCommonErr;
				si32_ReturnValue = pc_Box->getBoxOption(
					pc_User,					// ���[�U�[���.
					psc_BoxPassword,			// �{�b�N�X�p�X���[�h.
					&c_BoxOption,				// �{�b�N�X�I�v�V�������.
					pc_Track);					// ������.

				switch(si32_ReturnValue) {
					case APID_DocapiMethodOk:
						break;

					case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
						WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiOwnerAccessErr \n", __FILE__, __LINE__, __FUNCTION__);
						m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
						generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
						return WAPD_AnyError;

					case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
						WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiBoxidUnknownErr \n", __FILE__, __LINE__, __FUNCTION__);
						printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
						m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
						generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
						return WAPD_AnyError;

					case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
					case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
					default:
						WAPG_API_trace("%s(%d) %s : getBoxOption failed \n", __FILE__, __LINE__, __FUNCTION__);
						m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
						generateErrorResponseBody( WAPE_BoxError_None );
						printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
						return WAPD_AnyError;
				}

				// �p�X���[�h�K��`�F�b�N.
				// �{�b�N�X��ʂ����L�{�b�N�X�̏ꍇ�̂݃`�F�b�N.
				if( APIE_BoxmakerAuto == c_BoxOption.sl_BoxCreateInfo ) {
					if( WAPE_PasswordRules_On_Invalid == checkPasswordRules( s_BoxPassword.str_NewPassword.c_str() ) ) {
						WAPG_API_trace("%s(%d) %s : PasswordRulesOn check NG.\n", __FILE__, __LINE__, __FUNCTION__);
						printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
						m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
						generateErrorResponseBody( WAPE_BoxError_InvalidPassword );
						return WAPD_AnyError;
					}
				}
			}
		}
	}

	WAPD_DEBUG2("str_OldPassword = %s, str_NewPassword = %s\n", s_BoxPassword.str_OldPassword.c_str(), s_BoxPassword.str_NewPassword.c_str());
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief ���N�G�X�g�{�f�B����e�W��M�@�\�����擾����
 * @param[in]	param �T�u�R���g���[���[
 * @param[out]	s_OwnerName �e�W��M�@�\���
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getConfidentialRxFromBody( WAPS_SubController *params, WAPS_ConfidentialRx& s_ConfidentialRx)
{
	int32_t si32_Ret = WAPD_AnyError;
	s_ConfidentialRx.sc_Select = WAPD_SelectNoSetting;

	if( NULL == params->Param ) {
		WAPG_API_trace("%s(%d) %s : Body is NULL \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}
	if( !params->Param->isObject() ) {
		WAPG_API_trace("%s(%d) %s : Body is not Json Object \n", __FILE__, __LINE__, __FUNCTION__);
		printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
		m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
		generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
		return WAPD_AnyError;
	}

	if( params->Param->isMember("confidential_rx") ) {
		Json::Value& confidential_rx = (*params->Param)["confidential_rx"];
		if( !confidential_rx.isObject() ) {
			WAPG_API_trace("%s(%d) %s : Illegal json type : confidential_rx \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
			return WAPD_AnyError;
		}

		// �e�W��M�@�\��.
		if( confidential_rx.isMember("select") ) {
			Json::Value& select = confidential_rx["select"];

			if(!select.isBool()){
				WAPG_API_trace("%s(%d) %s : Illegal json type : select \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
				return WAPD_AnyError;
			}
			s_ConfidentialRx.sc_Select = static_cast<Bool>(select.asBool());
		} else {
			s_ConfidentialRx.sc_Select = WAPD_SelectNoSetting;
		}

		// ���e�W��M�p�X���[�h.
		if( confidential_rx.isMember("old_confidential_rx_password") ) {
			Json::Value& oldPass = confidential_rx["old_confidential_rx_password"];

			if( oldPass.type() != Json::stringValue ) {
				WAPG_API_trace("%s(%d) %s : Illegal json type : oldPass \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
				return WAPD_AnyError;
			}
			s_ConfidentialRx.str_OldPassword = oldPass.asString();

			// �o�C�g���`�F�b�N.
			if ( WAPD_ConfPasswordMaxChar < s_ConfidentialRx.str_OldPassword.length() ){
				WAPG_API_trace("%s(%d) %s : Illegal password length Byte\n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidConfidentialRxPassword );
				return WAPD_AnyError;
			}

			// �}���`�o�C�g�������܂܂��ꍇ�G���[.
			Bool b_CheckRet = False;
			si32_Ret = containsMultiByteCharacterUTF8( s_ConfidentialRx.str_OldPassword.c_str(), b_CheckRet );
			if( WAPD_NoError != si32_Ret ) {
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
			}
			if( True == b_CheckRet ){
				WAPG_API_trace("%s(%d) %s : password contains multi-byte character \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidConfidentialRxPassword );
				return WAPD_AnyError;
			}

			// �������`�F�b�N.
			ushort us_StringNum = 0;
			b_CheckRet = getStringLengthUTF8(s_ConfidentialRx.str_OldPassword.c_str(), WAPE_CheckString_1String, us_StringNum);
			if(False  == b_CheckRet){
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
			}

			if ( ( WAPD_ConfPasswordMinChar > us_StringNum ) || ( WAPD_ConfPasswordMaxChar < us_StringNum ) ){
				WAPG_API_trace("%s(%d) %s : Illegal password length \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidConfidentialRxPassword );
				return WAPD_AnyError;
			}
		}

		// �V�e�W��M�p�X���[�h.
		if( confidential_rx.isMember("new_confidential_rx_password") ) {
			Json::Value& newPass = confidential_rx["new_confidential_rx_password"];

			if( newPass.type() != Json::stringValue ) {
				WAPG_API_trace("%s(%d) %s : Illegal json type : newPass \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidJsonSyntax );
				return WAPD_AnyError;
			}
			s_ConfidentialRx.str_NewPassword = newPass.asString();

			// �o�C�g���`�F�b�N.
			if ( WAPD_ConfPasswordMaxChar < s_ConfidentialRx.str_NewPassword.length() ){
				WAPG_API_trace("%s(%d) %s : Illegal password length Byte\n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidConfidentialRxPassword );
				return WAPD_AnyError;
			}

			// �}���`�o�C�g�������܂܂��ꍇ�G���[.
			Bool b_CheckRet = False;
			si32_Ret = containsMultiByteCharacterUTF8( s_ConfidentialRx.str_NewPassword.c_str(), b_CheckRet );
			if( WAPD_NoError != si32_Ret ) {
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
			}
			if( True == b_CheckRet ){
				WAPG_API_trace("%s(%d) %s : password contains multi-byte character \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidConfidentialRxPassword );
				return WAPD_AnyError;
			}

			// �������`�F�b�N.
			ushort us_StringNum = 0;
			b_CheckRet = getStringLengthUTF8(s_ConfidentialRx.str_NewPassword.c_str(), WAPE_CheckString_1String, us_StringNum);
			if(False  == b_CheckRet){
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
			}

			if ( ( WAPD_ConfPasswordMinChar > us_StringNum ) || ( WAPD_ConfPasswordMaxChar < us_StringNum ) ){
				WAPG_API_trace("%s(%d) %s : Illegal password length \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidConfidentialRxPassword );
				return WAPD_AnyError;
			}
			
			// �p�X���[�h�K��`�F�b�N.
			if( WAPE_PasswordRules_On_Invalid == checkPasswordRules( s_ConfidentialRx.str_NewPassword.c_str() ) ) {
				WAPG_API_trace("%s(%d) %s : PasswordRulesOn check NG.\n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidConfidentialRxPassword );
				return WAPD_AnyError;
			}
		}

		if((0 < s_ConfidentialRx.str_OldPassword.length()) &&
		   (0 < s_ConfidentialRx.str_NewPassword.length())){

			// �V���p�X���[�h��������.
			if(s_ConfidentialRx.str_OldPassword == s_ConfidentialRx.str_NewPassword){
				WAPG_API_trace("%s(%d) %s : Illegal password\n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_InvalidConfidentialRxPassword );
				return WAPD_AnyError;
			}
		}
	}

	WAPD_DEBUG2("str_OldPassword = %s, str_NewPassword = %s\n", s_ConfidentialRx.str_OldPassword.c_str(), s_ConfidentialRx.str_NewPassword.c_str());
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief ���L�Ҕԍ����擾����i�{�b�N�X���/�{�b�N�X���L�ҕύX�p�j
 * @param[in]	pc_User	���s���[�U�[
 * @param[in]	pc_Track ���s���[�U�[��������
 * @param[in]	e_BoxCreateInfo	�{�b�N�X���
 * @param[in]	str_OwnerName	���L�Җ�
 * @param[in]	str_ServerName	�T�[�o�[��
 * @param[out]	si_OwnerNumber	���L�Ҕԍ�
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::getNewOwnerNumber(
	APIC_User* pc_User,
	APIC_Track* pc_Track,
	APIE_BoxOptionCreateInfo e_BoxCreateInfo,
	std::string& str_OwnerName,
	std::string& str_ServerName,
	int32_t& si32_OwnerNumber )
{
	int32_t si32_Ret = WAPD_AnyError;

	// �{�b�N�X��ʂ��l.
	if( APIE_BoxmakerUser == e_BoxCreateInfo ){
		if( ( TYPE_UserAuthenticationDeviceAndMidAuth == APIC_UserAuthentication::newInstance()->getUserAuthentication() ) &&
			( WAPE_BoxUserType_User_Mid == getBoxUserType( pc_User, pc_Track ) ) ) {
			// �{�́{�g���F�؎��ŁA���s���[�U�[���g�����[�U�[�̏ꍇ.
			si32_OwnerNumber = APIC_User::getUserNoSearchByUserName( str_OwnerName.c_str(), APID_MiddleAuthServerIndex );
		}
		else {
			si32_OwnerNumber = APIC_User::getUserNoSearchByServerName( str_OwnerName.c_str(), str_ServerName.c_str() );
		}

		if( ( si32_OwnerNumber == 0 ) || 
			( si32_OwnerNumber == TYPD_IndexUserAdmin ) ||
			( si32_OwnerNumber == TYPD_IndexUserCE ) || 
			( si32_OwnerNumber == TYPD_IndexUserOther ) || 
			( si32_OwnerNumber == TYPD_IndexUserLMU ) ) {
			// �{�b�N�X�����������Ȃ����[�U�[�ł���.
			WAPG_API_trace("%s(%d) %s : invalid user. si32_OwnerNumber=0x%08X, str_OwnerName=%s, str_ServerName=%s\n", __FILE__, __LINE__, __FUNCTION__, si32_OwnerNumber, str_OwnerName.c_str(), str_ServerName.c_str());
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			return WAPD_AnyError;
		}
	// �{�b�N�X��ʂ��O���[�v.
	} else if( APIE_BoxmakerGroup == e_BoxCreateInfo ) {
		si32_OwnerNumber = APIC_Track::getTrackNoSearchByTrackName(str_OwnerName.c_str());
		if( ( si32_OwnerNumber == 0 ) || 
			( si32_OwnerNumber == TYPD_IndexTrackBoxAdmin ) || 
			( si32_OwnerNumber == TYPD_IndexTrackAdmin ) ) {
			// �{�b�N�X�����������Ȃ�����ł���.
			WAPG_API_trace("%s(%d) %s : invalid track. si32_OwnerNumber=0x%08X, str_OwnerName=%s, str_ServerName=%s\n", __FILE__, __LINE__, __FUNCTION__, si32_OwnerNumber, str_OwnerName.c_str(), str_ServerName.c_str());
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			return WAPD_AnyError;
		}
	// �{�b�N�X��ʂ����L.
	} else {
		si32_OwnerNumber = APID_BoxUserID_Public;
	}

	WAPD_DEBUG2("si32_OwnerNumber = %d(0x%08X)\n", si32_OwnerNumber, si32_OwnerNumber);
	si32_Ret = WAPD_NoError;
	return si32_Ret;
}

/**
 * @brief �{�b�N�X����ݒ肷��
 * @param[in]	params�@�T�u�R���g���[���[
 * @param[in]	pc_Box	�{�b�N�X�C���X�^���X
 * @param[in]	pc_User		���[�U�[�C���X�^���X
 * @param[in]	pc_Track	����C���X�^���X
 * @param[in]	psc_BoxPassword	�{�b�N�X�p�X���[�h
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::setBoxName( WAPS_SubController* params, APIC_Box* pc_Box, APIC_User* pc_User, APIC_Track* pc_Track, char* psc_BoxPassword )
{
	int32_t si32_Ret = WAPD_AnyError;
	int32_t si32_ReturnValue = APID_DocapiCommonErr;

	// �� ���N�G�X�g�{�f�B�Ƀ��[�U�[�{�b�N�X�����ݒ肳��Ă���.
	char sc_BoxName[WAPD_BoxNameMaxLength] = {0};
	si32_Ret = getBoxNameFromBody( params, sc_BoxName );
	if(WAPD_NoError != si32_Ret){
		return WAPD_AnyError;
	}

	ushort us_BoxNameStringNum = 0;
	Bool b_CheckRet = False;
	b_CheckRet = getStringLengthUTF8(sc_BoxName, WAPE_CheckString_1String, us_BoxNameStringNum);
	if(False  == b_CheckRet){
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	if( 0 < us_BoxNameStringNum ) {
		// ���[�U�[�{�b�N�X���ݒ�.
		si32_ReturnValue = pc_Box->changeBoxName(
			pc_User,
			psc_BoxPassword,
			sc_BoxName,
			(LIBE_CharSet)APID_DefaultCharSet,
			pc_Track);
		
		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				m_ResponseHeader->Status = WAPD_STATUS_OK;
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s���G���[.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
			}	
	}

	return WAPD_NoError;
}

/**
 * @brief ���������폜���Ԃ�ݒ肷��
 * @param[in]	params�@�T�u�R���g���[���[
 * @param[in]	pc_Box	�{�b�N�X�C���X�^���X
 * @param[in]	pc_User		���[�U�[�C���X�^���X
 * @param[in]	pc_Track	����C���X�^���X
 * @param[in]	psc_BoxPassword	�{�b�N�X�p�X���[�h
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::setAutoDeleteTime( WAPS_SubController* params, APIC_Box* pc_Box, APIC_User* pc_User, APIC_Track* pc_Track, char* psc_BoxPassword )
{
	int32_t si32_Ret = WAPD_AnyError;
	int32_t si32_ReturnValue = APID_DocapiCommonErr;

	// �� ���N�G�X�g�{�f�B�ɕ����폜���Ԑݒ��񂪐ݒ肳��Ă���.
	int32_t si32_DeleteTime = 0;
	si32_Ret = getAutoDeleteTimeFromBody( params, si32_DeleteTime );
	if(WAPD_AnyError == si32_Ret){
		return WAPD_AnyError;
	} else if( WAPD_NoError == si32_Ret ){
		APIC_BoxOption c_BoxOption;
		si32_ReturnValue = pc_Box->getBoxOption(
			pc_User,					// ���[�U�[���.
			psc_BoxPassword,			// �{�b�N�X�p�X���[�h.
			&c_BoxOption,				// �{�b�N�X�I�v�V�������.
			pc_Track);					// ������.

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}

		c_BoxOption.sl_AutoDeleteTime = si32_DeleteTime;
		si32_ReturnValue = pc_Box->setBoxOption(
			pc_User,					// ���[�U�[���.
			psc_BoxPassword,			// �{�b�N�X�p�X���[�h.
			&c_BoxOption,				// �{�b�N�X�I�v�V�������.
			pc_Track,					// ������.
			TYPE_RegistrationTypeOnlyOne,
			static_cast<short> ( params->AuthorityID ) );

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				si32_Ret = WAPD_NoError;
				m_ResponseHeader->Status = WAPD_STATUS_OK;
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}
	} else {
		// WAPD_NoSetting�̏ꍇ�͉������Ȃ�
	}

	return WAPD_NoError;
}

/**
 * @brief �{�b�N�X��ʂ���я��L�҂�ݒ肷��
 * @param[in]	params		�T�u�R���g���[���[
 * @param[in]	pc_Box		�{�b�N�X�C���X�^���X
 * @param[in]	pc_User		���[�U�[�C���X�^���X
 * @param[in]	pc_Track	����C���X�^���X
 * @param[in]	psc_BoxPassword	�{�b�N�X�p�X���[�h
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::setBoxTypeAndOwner( WAPS_SubController* params, APIC_Box* pc_Box, APIC_User* pc_User, APIC_Track* pc_Track, char* psc_BoxPassword )
{
	int32_t si32_Ret = WAPD_AnyError;
	int32_t si32_ReturnValue = APID_DocapiCommonErr;

	// ���N�G�X�g�{�f�B���{�b�N�X��ʎ擾.
	std::string str_BoxType;
	si32_Ret = getBoxTypeFromBody( params, str_BoxType );
	if(WAPD_NoError != si32_Ret){
		WAPG_API_trace("%s(%d) %s : getBoxTypeFromBody failed \n", __FILE__, __LINE__, __FUNCTION__);
		return WAPD_AnyError;
	}

	// ���N�G�X�g�{�f�B���{�b�N�X���L�ҏ��擾.
	std::string str_OwnerName;
	std::string str_ServerName;
	si32_Ret = getOwnerInformationFromBody( params, str_OwnerName, str_ServerName );
	if(WAPD_NoError != si32_Ret){
		WAPG_API_trace("%s(%d) %s : getOwnerInformationFromBody failed \n", __FILE__, __LINE__, __FUNCTION__);
		return WAPD_AnyError;
	}

	// �� ���N�G�X�g�{�f�B�Ƀ{�b�N�X��ʏ�񂪐ݒ肳��Ă��邩.
	if(0 < str_BoxType.length()){
		// �p�u���b�N�ȊO�̃{�b�N�X��ʂɕύX����ꍇ�͏��L�Җ��K�{.
		if( ( str_BoxType != "PUBLIC" ) && ( 0 == str_OwnerName.length() ) ) {
			WAPG_API_trace("%s(%d) %s : owner_name empty.\n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxOwnerName );
			return WAPD_AnyError;
		}

		// �{�b�N�X�I�v�V�����擾.
		// �{�b�N�X��ʕύX(changeBoxKind)�̃p�����[�^�ɐݒ肷�邽��.
		APIC_BoxOption c_BoxOption;
		si32_ReturnValue = pc_Box->getBoxOption(
			pc_User,					// ���[�U�[���.
			psc_BoxPassword,			// �{�b�N�X�p�X���[�h.
			&c_BoxOption,				// �{�b�N�X�I�v�V�������.
			pc_Track);					// ������.

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiOwnerAccessErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiBoxidUnknownErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				WAPG_API_trace("%s(%d) %s : getBoxOption si32_ReturnValue=%d \n", __FILE__, __LINE__, __FUNCTION__, si32_ReturnValue);
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}

		// �{�b�N�X���擾.
		// �{�b�N�X��ʕύX(changeBoxKind)�̃p�����[�^�ɐݒ肷�邽��.
		APIC_BoxInfo c_BoxInfo;       // �擾Info�l.
		si32_ReturnValue = pc_Box->getBoxInfo(
			pc_User,
			&c_BoxInfo,
			(LIBE_CharSet)APID_DefaultCharSet,
			pc_Track);

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				WAPG_API_trace("%s(%d) %s : getBoxInfo APID_DocapiOwnerAccessErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				WAPG_API_trace("%s(%d) %s : getBoxInfo APID_DocapiBoxidUnknownErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				WAPG_API_trace("%s(%d) %s : getBoxInfo si32_ReturnValue=%d \n", __FILE__, __LINE__, __FUNCTION__, si32_ReturnValue);
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}

		char sc_BoxType[WAPD_MaxKeyLength] = {0};
		strncpy(sc_BoxType, str_BoxType.c_str(), sizeof(sc_BoxType) - 1 );
		APIE_BoxOptionCreateInfo e_NewBoxType = APIE_BoxmakerAuto;
		if(False == WAPS_CommonTableString<WAPE_BoxType, APIE_BoxOptionCreateInfo>::WapStringToCommon( sc_BoxType, e_NewBoxType )){
			WAPG_API_trace("%s(%d) %s : Illegal BoxType value \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidBoxKind );
			return WAPD_AnyError;
		}

		// ���L�Ҕԍ��ݒ�.
		int32_t si32_NewOwnerID = 0;
		si32_Ret = getNewOwnerNumber(pc_User, pc_Track, e_NewBoxType, str_OwnerName, str_ServerName, si32_NewOwnerID);
		if(WAPD_NoError != si32_Ret){
			WAPG_API_trace("%s(%d) %s : getNewOwnerNumber failed \n", __FILE__, __LINE__, __FUNCTION__);
			return WAPD_AnyError;
		}

		// �{�b�N�X���/���L�ҕύX�����`�F�b�N.
		if( False == validateChangingBoxTypeAndOwner( pc_User, pc_Track, c_BoxOption.sl_BoxCreateInfo, c_BoxInfo.ul_OwnUserID, e_NewBoxType, si32_NewOwnerID, psc_BoxPassword ) ) {
			WAPG_API_trace("%s(%d) %s : validateChangingBoxTypeAndOwner invalid \n", __FILE__, __LINE__, __FUNCTION__);
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			return WAPD_AnyError;
		}

		c_BoxOption.sl_BoxCreateInfo = e_NewBoxType;
		c_BoxInfo.ul_OwnUserID = static_cast<uint32_t>(si32_NewOwnerID);

		// �{�b�N�X��ʕύX.
		si32_ReturnValue = pc_Box->changeBoxKind(
			pc_User,				// ���[�U�[���.
			psc_BoxPassword,		// �{�b�N�X�p�X���[�h.
			&c_BoxInfo,				// �ݒ�C���t�H���[�V�����l.
			&c_BoxOption, 			// �ݒ�I�v�V�����w��l.
			(LIBE_CharSet)APID_DefaultCharSet,	// �{�b�N�X�������R�[�h�ϊ�����.
			pc_Track,				// ����Ǘ����.
			TYPE_RegistrationTypeOnlyOne,		// �č����O�^�C�v.
			pc_User,				// ���O�C�����[�U�[.
			pc_Track,				// ���O�C������.
			False,					//  �Ǘ��ґ��쎞�̃p�X���[�h�K��ۃt���O.
			static_cast<short> ( params->AuthorityID ),	// 	�F��ID.
			params->CostCenterID);	//CostCenterID.

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				WAPG_API_trace("%s(%d) %s : changeBoxKind APID_DocapiOwnerAccessErr\n", __FILE__, __LINE__, __FUNCTION__);
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				WAPG_API_trace("%s(%d) %s : changeBoxKind APID_DocapiOwnerAccessErr\n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiUserBoxOverErr:		// ���[�U�{�b�N�X������I�[�o�[.
			case APID_DocapiGroupBoxOverErr:	// �O���[�v�{�b�N�X������I�[�o�[.
			case APID_DocapiAllBoxOverErr:		// �S�{�b�N�X������I�[�o�[.
				WAPG_API_trace("%s(%d) %s : changeBoxKind si32_ReturnValue=%d\n", __FILE__, __LINE__, __FUNCTION__, si32_ReturnValue);
				printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				WAPG_API_trace("%s(%d) %s : changeBoxKind si32_ReturnValue=%d\n", __FILE__, __LINE__, __FUNCTION__, si32_ReturnValue);
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}
	}
	// �� ���N�G�X�g�{�f�B�Ƀ{�b�N�X���L�ҏ�񂪐ݒ肳��Ă��邩.
	else if((0 < str_OwnerName.length())
			|| (0 < str_ServerName.length())) {
		// �{�b�N�X��ʂ͎w�肳��Ă��Ȃ��̂ŁA���L�҂̂ݕύX����.

		// �{�b�N�X���擾.
		APIC_BoxInfo c_BoxInfo;       // �擾Info�l.
		si32_ReturnValue = pc_Box->getBoxInfo(
			pc_User,
			&c_BoxInfo,
			(LIBE_CharSet)APID_DefaultCharSet,
			pc_Track);

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				WAPG_API_trace("%s(%d) %s : getBoxInfo APID_DocapiOwnerAccessErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				WAPG_API_trace("%s(%d) %s : getBoxInfo APID_DocapiBoxidUnknownErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				WAPG_API_trace("%s(%d) %s : getBoxInfo si32_ReturnValue=%d \n", __FILE__, __LINE__, __FUNCTION__, si32_ReturnValue);
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}

		APIC_BoxOption c_BoxOption;
		si32_ReturnValue = pc_Box->getBoxOption(
			pc_User,					// ���[�U�[���.
			psc_BoxPassword,			// �{�b�N�X�p�X���[�h.
			&c_BoxOption,				// �{�b�N�X�I�v�V�������.
			pc_Track);					// ������.

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiOwnerAccessErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				WAPG_API_trace("%s(%d) %s : getBoxOption APID_DocapiBoxidUnknownErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				WAPG_API_trace("%s(%d) %s : getBoxOption si32_ReturnValue=%d \n", __FILE__, __LINE__, __FUNCTION__, si32_ReturnValue);
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}

		// ���L�Ҕԍ��ݒ�.
		int32_t si32_NewOwnerID = 0;
		si32_Ret = getNewOwnerNumber(pc_User, pc_Track, c_BoxOption.sl_BoxCreateInfo, str_OwnerName, str_ServerName, si32_NewOwnerID);
		if(WAPD_NoError != si32_Ret){
			WAPG_API_trace("%s(%d) %s : getNewOwnerNumber si32_ReturnValue=%d \n", __FILE__, __LINE__, __FUNCTION__, si32_ReturnValue);
			return WAPD_AnyError;
		}

		// �{�b�N�X���/���L�ҕύX�����`�F�b�N.
		if( False == validateChangingBoxTypeAndOwner( pc_User, pc_Track, c_BoxOption.sl_BoxCreateInfo, c_BoxInfo.ul_OwnUserID, c_BoxOption.sl_BoxCreateInfo, si32_NewOwnerID, psc_BoxPassword ) ) {
			WAPG_API_trace("%s(%d) %s : validateChangingBoxTypeAndOwner invalid \n", __FILE__, __LINE__, __FUNCTION__);
			printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
			generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
			return WAPD_AnyError;
		}

		// Box���L�Җ��ύX.
		si32_ReturnValue = pc_Box->changeOwner(
			pc_User,				// ���[�U�[���.
			psc_BoxPassword,		// �{�b�N�X�p�X���[�h.
			si32_NewOwnerID,		// �ݒ肵�������L�ҏ��.
			pc_Track,
			TYPE_RegistrationTypeOnlyOne,
			params->CostCenterID);

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				WAPG_API_trace("%s(%d) %s : changeOwner APID_DocapiOwnerAccessErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				WAPG_API_trace("%s(%d) %s : changeOwner APID_DocapiBoxidUnknownErr \n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiUserBoxOverErr:		// ���[�U�{�b�N�X������I�[�o�[.
			case APID_DocapiGroupBoxOverErr:	// �O���[�v�{�b�N�X������I�[�o�[.
			case APID_DocapiAllBoxOverErr:		// �S�{�b�N�X������I�[�o�[.
				WAPG_API_trace("%s(%d) %s : changeOwner si32_ReturnValue=%d\n", __FILE__, __LINE__, __FUNCTION__, si32_ReturnValue);
				printf("503:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //503->ErrorStatus[WAPD_STATUS_SERVICE_UNAVAILABLE] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_SERVICE_UNAVAILABLE;
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				WAPG_API_trace("%s(%d) %s : changeOwner si32_ReturnValue=%d\n", __FILE__, __LINE__, __FUNCTION__, si32_ReturnValue);
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}
	}
	else{
		// �������Ȃ�.
	}

	return WAPD_NoError;
}


/**
 * @brief �{�b�N�X�����L�[��ʂ�ݒ肷��
 * @param[in]	params		�T�u�R���g���[���[
 * @param[in]	pc_Box		�{�b�N�X�C���X�^���X
 * @param[in]	pc_User		���[�U�[�C���X�^���X
 * @param[in]	pc_Track	����C���X�^���X
 * @param[in]	psc_BoxPassword	�{�b�N�X�p�X���[�h
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::setSearchKey( WAPS_SubController* params, APIC_Box* pc_Box, APIC_User* pc_User, APIC_Track* pc_Track, char* psc_BoxPassword )
{
	int32_t si32_Ret = WAPD_AnyError;
	int32_t si32_ReturnValue = APID_DocapiCommonErr;

	// �� ���N�G�X�g�{�f�B�Ƀ{�b�N�X�����L�[��ʂ��ݒ肳��Ă���.
	string str_SearchKey;
	si32_Ret = getSearchKeyFromBody( params, str_SearchKey );
	if(WAPD_NoError != si32_Ret){
		return WAPD_AnyError;
	}
	if(0 < str_SearchKey.length()){
		char sc_SearchKey[WAPD_MaxKeyLength] = {0};
		TYPE_SearchKey e_SearchKey = TYPE_SearchKeyAA;
		strncpy(sc_SearchKey, str_SearchKey.c_str(), sizeof(sc_SearchKey) - 1 );
		if(False == WAPS_CommonTableString<WAPE_SearchKey, TYPE_SearchKey>::WapStringToCommon(
			sc_SearchKey, e_SearchKey )){
			WAPG_API_trace("%s(%d) %s : Illegal SearchKey value \n", __FILE__, __LINE__, __FUNCTION__);
			printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
			m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
			generateErrorResponseBody( WAPE_BoxError_InvalidSearchKey );
			return WAPD_AnyError;
		}

		// �{�b�N�X�����L�[��ʐݒ�.
		si32_ReturnValue = pc_Box->setBoxSearchKey(
			pc_User,				// ���[�U�[���.
			psc_BoxPassword,		// �{�b�N�X�p�X���[�h.
			e_SearchKey,			// �{�b�N�X�����L�[���.
			pc_Track);				// ����Ǘ����.

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}
	}

	return WAPD_NoError;
}

/**
 * @brief �e�W��M�@�\����ݒ肷��
 * @param[in]	params		�T�u�R���g���[���[
 * @param[in]	pc_Box		�{�b�N�X�C���X�^���X
 * @param[in]	pc_User		���[�U�[�C���X�^���X
 * @param[in]	pc_Track	����C���X�^���X
 * @param[in]	psc_BoxPassword	�{�b�N�X�p�X���[�h
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::setConfidentialRx( WAPS_SubController* params, APIC_Box* pc_Box, APIC_User* pc_User, APIC_Track* pc_Track, char* psc_BoxPassword )
{
	int32_t si32_Ret = WAPD_AnyError;
	int32_t si32_ReturnValue = APID_DocapiCommonErr;

	// �� ���N�G�X�g�{�f�B�ɐe�W��M�@�\��񂪐ݒ肳��Ă���.
	WAPS_ConfidentialRx s_ConfidentialRx = {};
	si32_Ret = getConfidentialRxFromBody( params, s_ConfidentialRx );
	if(WAPD_NoError != si32_Ret){
		WAPG_API_trace("%s(%d) %s : getConfidentialRxFromBody failed\n", __FILE__, __LINE__, __FUNCTION__);
		return WAPD_AnyError;
	}
	if( WAPD_SelectNoSetting != s_ConfidentialRx.sc_Select ) {

		Bool b_IsConfidentialReception = True;  //�e�W��M�ݒ��ON�ɂ���

		// APIC_BoxRegistry�C���X�^���X�擾.
		APIC_BoxRegistry* pc_BoxRegistry = APIC_BoxRegistry::newInstance();
		if(NULL == pc_BoxRegistry){
			WAPG_API_trace("%s(%d) %s : APIC_BoxRegistry instance NULL \n", __FILE__, __LINE__, __FUNCTION__);
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
		}
		// �A�N�Z�X�����ݒ�.
		APIC_AccessTokenManager* pc_AccessTokenManager = APIC_AccessTokenManager::newInstance();
		JLGE_InspectLogIF e_InspectLogIF = JLGE_InspectLogIfOperationPanel;
		if( NULL != pc_AccessTokenManager){
			pc_AccessTokenManager->getAppType(m_AccessToken, &e_InspectLogIF);
		}
		pc_BoxRegistry->setLogIFNo( e_InspectLogIF );

		// �e�W��M���擾.
		// �e�W��M���ݒ�/�폜�̃p�����[�^�ɐݒ肷�邽��.
		APIS_ConfidentialBoxStruct s_Confidential = {};
		si32_ReturnValue = pc_BoxRegistry->ConfidentialInfoAction(
			m_si32_BoxNo, 				// �w��{�b�N�X�ԍ�.
			WAPD_BOX_CONFBOX_OPE_GET, 	// �A�N�Z�X���(�擾).
			&s_Confidential, 			// �e�W��M���.
			pc_User, 					// ���[�U�[���.
			pc_Track, 					// ������.
			TYPE_RegistrationTypeOnlyOne,	// �č����O�^�C�v.
			static_cast<short> ( params->AuthorityID ) );		// �F��ID.

		switch(si32_ReturnValue) {
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				//�uWAPD_BOX_CONFBOX_OPE_GET�ŃG���[���e�W��M�@�\���ݒ肳��Ă��Ȃ��v.
				// �Ƃ���I/F�d�l�ł��邽�߁A�����ł͐e�W��M�@�\�����Ɣ��f���AWebAPI���s�G���[�Ƃ͂Ȃ�Ȃ�.
				b_IsConfidentialReception = False;  	// �e�W��M�ݒ肪OFF�ł���.
				// �V�K�ݒ�ƂȂ邽�߁AURI����w�肳�ꂽBoxNo���\���̂�BoxNo�ɑ��.
				s_Confidential.sl_BoxNo = m_si32_BoxNo;
				break;
		}

		// �ύX�O�ɐe�W��M�@�\���L���ł������ꍇ�A���p�X���[�h�̈�v�`�F�b�N.
		if( True == b_IsConfidentialReception ) {
			// ���p�X���[�h�ƈ�v���Ȃ��ꍇ.
			if( 0 != strncmp(s_Confidential.sc_CommPwd, s_ConfidentialRx.str_OldPassword.c_str(), sizeof(s_Confidential.sc_CommPwd)) ){
				WAPG_API_trace("%s(%d) %s : Illegal old Password\n", __FILE__, __LINE__, __FUNCTION__);
				pc_BoxRegistry->deleteInstance();
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_ConfidentialRxPasswordAccessErr );
				return WAPD_AnyError;
			}
		}

		int32_t si32_Operation = WAPD_BOX_CONFBOX_OPE_SET;
		if( True == s_ConfidentialRx.sc_Select ) {
			// �e�W��M�@�\�L�����iOFF��ON�j�܂��͐e�W�p�X���[�h�ύX�iON��ON�j.
			si32_Operation = WAPD_BOX_CONFBOX_OPE_SET;
			// �V�p�X���[�h��ݒ�\���̂ɃR�s�[.
			strncpy(s_Confidential.sc_CommPwd, s_ConfidentialRx.str_NewPassword.c_str(), sizeof(s_Confidential.sc_CommPwd) - 1 );
		}
		else {
			// �e�W��M�@�\�����iON��OFF�j.
			// ���̏ꍇ�A�ݒ�\���̂Ƀp�X���[�h�͓��ɕK�v�Ȃ�.
			si32_Operation = WAPD_BOX_CONFBOX_OPE_DEL;
		}

		// �e�W��M�ݒ�̖����iOFF�j���疳���iOFF�j�ւ̐ݒ�̓G���[�Ȃ̂ŁA����ȊO�̏ꍇ�̂݁A�e�W��M����ݒ肷��.
		if ((True == b_IsConfidentialReception) || (True == s_ConfidentialRx.sc_Select)) {
			// �e�W��M���ݒ�/�폜.
			si32_ReturnValue = pc_BoxRegistry->ConfidentialInfoAction(
				m_si32_BoxNo, 				// �w��{�b�N�X�ԍ�.
				si32_Operation, 			// �A�N�Z�X���(�ݒ� or �폜).
				&s_Confidential, 			// �e�W��M���.
				pc_User, 					// ���[�U�[���.
				pc_Track, 					// ������.
				TYPE_RegistrationTypeOnlyOne,	// �č����O�^�C�v.
				static_cast<short> ( params->AuthorityID ) );		// �F��ID.
			pc_BoxRegistry->deleteInstance();

			switch(si32_ReturnValue) {
				case APID_DocapiMethodOk:
					break;

				case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
				default:
					WAPG_API_trace("%s(%d) %s : APIC_BoxRegistry::ConfidentialInfoAction failed\n", __FILE__, __LINE__, __FUNCTION__);
					m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
					printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
					generateErrorResponseBody( WAPE_BoxError_None );
					return WAPD_AnyError;
				}
			}
	}

	return WAPD_NoError;
}

/**
 * @brief �{�b�N�X�p�X���[�h��ݒ肷��
 * @param[in]	params		�T�u�R���g���[���[
 * @param[in]	pc_Box		�{�b�N�X�C���X�^���X
 * @param[in]	pc_User		���[�U�[�C���X�^���X
 * @param[in]	pc_Track	����C���X�^���X
 * @param[in]	psc_BoxPassword	�{�b�N�X�p�X���[�h
 * @return �����̐���, WAPD_NoError(0)�F�����AWAPD_AnyError(1)�F���s
 */
int32_t WAPC_UserBoxController::setBoxPassword( WAPS_SubController* params, APIC_Box* pc_Box, APIC_User* pc_User, APIC_Track* pc_Track, char* psc_BoxPassword )
{
	int32_t si32_Ret = WAPD_AnyError;
	int32_t si32_ReturnValue = APID_DocapiCommonErr;

	// �� ���N�G�X�g�{�f�B�Ƀ{�b�N�X�p�X���[�h��񂪐ݒ肳��Ă���.
	WAPS_BoxPasswordInformation s_BoxPassword = {};
	si32_Ret = getBoxPasswordInformationFromBody( params, pc_Box, pc_User, pc_Track, psc_BoxPassword, s_BoxPassword );
	if(WAPD_NoError != si32_Ret){
		WAPG_API_trace("%s(%d) %s : getBoxPasswordInformationFromBody failed\n", __FILE__, __LINE__, __FUNCTION__);
		return WAPD_AnyError;
	}
	if( ( 0 < s_BoxPassword.str_OldPassword.length() ) ||
	    ( 0 < s_BoxPassword.str_NewPassword.length() ) ){

		si32_ReturnValue = pc_Box->changePassword(
			 pc_User,
			 s_BoxPassword.str_OldPassword.c_str(),
			 s_BoxPassword.str_NewPassword.c_str(),
			 pc_Track,
			 TYPE_RegistrationTypeOnlyOne,
			 static_cast<short> ( params->AuthorityID ) );

		switch(si32_ReturnValue){
			case APID_DocapiMethodOk:
				break;

			case APID_DocapiOwnerAccessErr:		// �I�[�i�[���s���G���[.
				WAPG_API_trace("%s(%d) %s : APIC_Box::changePassword APID_DocapiOwnerAccessErr\n", __FILE__, __LINE__, __FUNCTION__);
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_OwnerAccessErr );
				return WAPD_AnyError;

			case APID_DocapiBoxidUnknownErr:	// �w��ԍ���Box�Ȃ��G���[.
				WAPG_API_trace("%s(%d) %s : APIC_Box::changePassword APID_DocapiBoxidUnknownErr\n", __FILE__, __LINE__, __FUNCTION__);
				printf("400:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //400->ErrorStatus[WAPD_STATUS_BAD_REQUEST] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_BAD_REQUEST;
				generateErrorResponseBody( WAPE_BoxError_BoxNotExist );
				return WAPD_AnyError;

			case APID_DocapiPasswordAccessErr:	// �p�X���[�h�s��.
				WAPG_API_trace("%s(%d) %s : APIC_Box::changePassword APID_DocapiPasswordAccessErr\n", __FILE__, __LINE__, __FUNCTION__);
				printf("403:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //403->ErrorStatus[WAPD_STATUS_FORBIDDEN] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_FORBIDDEN;
				generateErrorResponseBody( WAPE_BoxError_PasswordAccessErr );
				return WAPD_AnyError;

			case APID_DocapiCommonErr:			// ���̑��̏������s�G���[.
			default:
				WAPG_API_trace("%s(%d) %s : APIC_Box::changePassword failed\n", __FILE__, __LINE__, __FUNCTION__);
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
		}
	}

	return WAPD_NoError;
}
/**
 * @brief �R�[���o�b�N�֐��|�C���^�擾.
 * @retval NULL�ȊO �R�[���o�b�N�֐��|�C���^.
 * @retval NULL �󂫊֐��Ȃ�.
 */
FP_ANS_CHANGE_BOX_STATUS WAPC_UserBoxController::getBoxDeleteCb()
{
	FP_ANS_CHANGE_BOX_STATUS fp_Cb = NULL;

	for( uint32_t ui32_loop = 0; ui32_loop < (sizeof(g_s_CbTable) / sizeof(g_s_CbTable[0])); ui32_loop++ ) {
		if( False == g_s_CbTable[ui32_loop].b_InUse ) {
			fp_Cb = g_s_CbTable[ui32_loop].fp_Cb;
			g_s_CbTable[ui32_loop].b_InUse = True;
			break;
		}
	}
	return fp_Cb;
}

/**
 * @brief �R�[���o�b�N�֐��|�C���^���.
 * @return �Ȃ�.
 */
void WAPC_UserBoxController::releaseBoxDeleteCb( FP_ANS_CHANGE_BOX_STATUS fp_Cb )
{
	for( uint32_t ui32_loop = 0; ui32_loop < (sizeof(g_s_CbTable) / sizeof(g_s_CbTable[0])); ui32_loop++ ) {
		if( fp_Cb == g_s_CbTable[ui32_loop].fp_Cb ) {
			g_s_CbTable[ui32_loop].b_InUse = False;
			break;
		}
	}
}

/**
 * @brief �{�b�N�X�폜���s���ʒʒm.
 * @param[in] si32_BoxId �폜���ꂽ�{�b�N�X�ԍ�
 * @param[in] si32_Result ��������
 * @param[in] ui64_ReqId �R�[���o�b�N�֐�ID
 * @return �Ȃ�.
 */
void WAPC_UserBoxController::BoxDeleteCompleted( int32_t si32_BoxId, int32_t si32_Result, uint64_t ui64_ReqId )
{
	void* vp_Handle = NULL;
	int32_t si32_cbStatus = WAPD_AnyError;

	// �񓯊����ʊi�[�N���X���o��.
	WAPC_DeleteBoxResult* pc_AsyncResult = NULL;
	pc_AsyncResult = dynamic_cast<WAPC_DeleteBoxResult*>(WAPC_AsyncResponseContainer::newInstance()->getById( ui64_ReqId ));
	if( NULL != pc_AsyncResult ) {
		pc_AsyncResult->setDeleteBoxId( si32_BoxId );
		pc_AsyncResult->setDeleteBoxResult( si32_Result );
		vp_Handle = pc_AsyncResult->getHandle();
		si32_cbStatus = WAPD_NoError;
	}

	// �񓯊����X�|���X�p�^�X�N�ɃX�C�b�`.
	WAPC_AsyncResponder::newInstance()->postMessage( vp_Handle, si32_cbStatus );
}

/**
 * @brief �{�b�N�X�폜 �񓯊����X�|���X����.
 * @param[in] ps_Params HTTP���N�G�X�g�w�b�_�A�{�f�B
 * @retval WAPD_NoError(0) ����.
 * @retval WAPD_AnyError(1) ���s.
 */
int32_t WAPC_UserBoxController::generateBoxDeleteResponse( WAPS_SubController *ps_Params )
{
	// �񓯊����ʃN���X���o��.
	WAPC_DeleteBoxResult* pc_AsyncResult = NULL;
	pc_AsyncResult = dynamic_cast<WAPC_DeleteBoxResult*>(WAPC_AsyncResponseContainer::newInstance()->getByHandle( m_pv_Handle ));
	if( NULL == pc_AsyncResult ) {
		m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
		printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
		generateErrorResponseBody( WAPE_BoxError_None );
		return WAPD_AnyError;
	}

	// ���ʎ擾.
	int32_t si32_BoxDeleteResult = APID_DocapiMethodOk;
	si32_BoxDeleteResult = pc_AsyncResult->getDeleteBoxResult();
	int32_t si32_DeleteBoxId = pc_AsyncResult->getDeleteBoxId();

	// �񓯊����ʃN���X�E�֐��|�C���^�Еt��.
	releaseBoxDeleteCb( reinterpret_cast<FP_ANS_CHANGE_BOX_STATUS>(pc_AsyncResult->getReqId()) );
	WAPC_AsyncResponseContainer::newInstance()->erase( pc_AsyncResult->getReqId() );
	delete pc_AsyncResult;

	// ���ʃ`�F�b�N.
	switch( si32_BoxDeleteResult ) {
		case APID_DocapiMethodOk:
			m_Response = new Json::Value;
			if( NULL == m_Response ) {
				m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
				printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
				generateErrorResponseBody( WAPE_BoxError_None );
				return WAPD_AnyError;
			}
			(*m_Response)["delete_box_no"] = si32_DeleteBoxId;
			m_ResponseHeader->Status = WAPD_STATUS_OK;
			break;

		default:
			m_ResponseHeader->Status = WAPD_STATUS_INTERNAL_SERVER_ERROR;
			printf("500:: File:%s, Line:%d, Function:%s \n",  __FILE__, __LINE__, __func__); //500->ErrorStatus[WAPD_STATUS_INTERNAL_SERVER_ERROR] in WAP_defs.h
			generateErrorResponseBody( WAPE_BoxError_None );
			return WAPD_AnyError;
	}
	return WAPD_NoError;
}

/**
 * @brief �{�b�N�X���/���L�ҕύX�����`�F�b�N.
 * @param[in] pc_User ���s���[�U�[�C���X�^���X. ���働�O�C���Ȃǃ��[�U�[�Ȃ��̏ꍇ��NULL.
 * @param[in] pc_Track ���s����C���X�^���X. �������Ă��Ȃ��ꍇ��NULL.
 * @param[in] e_BoxType ���{�b�N�X���.
 * @param[in] ui32_OwnUserID �����L��ID.
 * @param[in] e_NewBoxType �V�{�b�N�X���.
 * @param[in] ui32_NewOwnUserID �V���L��ID.
 * @param[in] psc_Password �{�b�N�X�p�X���[�h. NULL�͕s��.
 * @return ���茋��.
 */
Bool WAPC_UserBoxController::validateChangingBoxTypeAndOwner(
	APIC_User* pc_User,
	APIC_Track* pc_Track,
	APIE_BoxOptionCreateInfo e_BoxType,
	uint32_t ui32_OwnUserID,
	APIE_BoxOptionCreateInfo e_NewBoxType,
	uint32_t ui32_NewOwnUserID,
	char* psc_BoxPassword
	)
{
	// ���s���[�U�[���.
	WAPE_BoxUserType e_OperatorType = WAPE_BoxUserType_None;
	e_OperatorType = getBoxUserType( pc_User, pc_Track );
	if( WAPE_BoxUserType_None == e_OperatorType ) {
		return False;
	}
	// �{�b�N�X���L�Ҏ��.
	WAPE_BoxUserType e_SrcBoxOwnerType = WAPE_BoxUserType_None;
	e_SrcBoxOwnerType = getBoxOwnerType( e_BoxType, ui32_OwnUserID );
	if( WAPE_BoxUserType_None == e_SrcBoxOwnerType ) {
		return False;
	}
	// �{�b�N�X�V���L�Ҏ��.
	WAPE_BoxUserType e_DstBoxOwnerType = WAPE_BoxUserType_None;
	e_DstBoxOwnerType = getBoxOwnerType( e_NewBoxType, ui32_NewOwnUserID );
	if( WAPE_BoxUserType_None == e_DstBoxOwnerType ) {
		return False;
	}
	// �p�X���[�h�K����.
	WAPE_PasswordRules e_PassWordRules = WAPE_PasswordRules_None;
	e_PassWordRules = checkPasswordRules( psc_BoxPassword );
	// �F�ؕ���.
	WAPE_UserAuthentication e_UserAuth = WAPE_UserAuthentication_None;
	e_UserAuth = static_cast<WAPE_UserAuthentication>(APIC_UserAuthentication::newInstance()->getUserAuthentication());

	// �g�փe�[�u�����邮��.
	for( uint32_t si32_Index = 0; si32_Index < ( sizeof(g_s_TypeAndOwnerValidate) / sizeof(g_s_TypeAndOwnerValidate[0]) ); si32_Index++ ) {
		// None�܂��͈�v����Ȃ玟���ڂ̃`�F�b�N�ցA��v���Ȃ����continue.
		// ���s���[�U�[���.
		if( ( WAPE_BoxUserType_None != g_s_TypeAndOwnerValidate[si32_Index].e_OperatorType ) &&
			( e_OperatorType != g_s_TypeAndOwnerValidate[si32_Index].e_OperatorType ) ) {
				continue;
		}
		// �{�b�N�X���L�Ҏ��.
		if( ( WAPE_BoxUserType_None != g_s_TypeAndOwnerValidate[si32_Index].e_SrcBoxOwnerType ) &&
			( e_SrcBoxOwnerType != g_s_TypeAndOwnerValidate[si32_Index].e_SrcBoxOwnerType ) ) {
				continue;
		}
		// �{�b�N�X�V���L�Ҏ��.
		if( ( WAPE_BoxUserType_None != g_s_TypeAndOwnerValidate[si32_Index].e_DstBoxOwnerType ) &&
			( e_DstBoxOwnerType != g_s_TypeAndOwnerValidate[si32_Index].e_DstBoxOwnerType ) ) {
				continue;
		}
		// �p�X���[�h�K����.
		if( ( WAPE_PasswordRules_None != g_s_TypeAndOwnerValidate[si32_Index].e_PassWordRules ) &&
			( e_PassWordRules != g_s_TypeAndOwnerValidate[si32_Index].e_PassWordRules ) ) {
				continue;
		}
		// �F�ؕ���.
		if( ( WAPE_UserAuthentication_None != g_s_TypeAndOwnerValidate[si32_Index].e_UserAuth ) &&
			( e_UserAuth != g_s_TypeAndOwnerValidate[si32_Index].e_UserAuth ) ) {
				continue;
		}
		// �S�Ĉ�v�������ߑg�ւɒ�G���Ă���.
		return False;
	}

	// �g�ւɂ͒�G���Ȃ�����.
	return True;
}
