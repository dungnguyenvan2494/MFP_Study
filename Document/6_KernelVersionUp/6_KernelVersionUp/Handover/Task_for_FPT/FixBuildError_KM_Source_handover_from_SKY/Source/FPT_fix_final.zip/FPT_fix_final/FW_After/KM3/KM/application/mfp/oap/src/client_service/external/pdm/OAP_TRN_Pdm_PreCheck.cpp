// ========================================================================== 
// �t�@�C�����FOAP_TRN_Wsc_PreCheckServerInfo.cpp 
// �T�v�@�@�@�F
// �ύX�����@�F
// ========================================================================== 
// ========================================================================== 
//  �C���N���[�h�t�@�C�� 
// ========================================================================== 
#include "OAP_COM_InternalApi_gene.h"
#include "OAP_COM_InternalApi_external.h"
#include "../../OAP_SVC_ExtFrameWork.h"
#include "../OAP_TRN_transactiondef.h"

#include "OAP_TRN_External_Library_Pdm.h"
#include "APIC_SystemInfo.h"
#include "APIC_Setting_TcpIpSetting.h"
#include "APIC_Setting_SystemSetting.h"
#include "APIC_Setting_MailSendSetting.h"
#include "APIC_CSRASetting.h"
#include "APIC_CSRAControl.h"
#include "APIC_RdsApi.h"

// ========================================================================== 
//  ��`. 
// ========================================================================== 

// **************************************************************************************************************
// �G���[�R�[�h.
//
// �Q�l�d�l���F10.0002.CS Remote Analysis�G���[�R�[�h�ꗗ.docx.
// **************************************************************************************************************
// --------------------------------------------------------------------------------------------------------------
// ����.
// --------------------------------------------------------------------------------------------------------------
#define OAPD_PdmPreCheck_ErrorCode_Normal_None							0x00000000	//// �Ȃ�.
#define OAPD_PdmPreCheck_ErrorCode_Normal_SendNow						0x00000001	//// ����.
#define OAPD_PdmPreCheck_ErrorCode_Normal_SendSkip						0x00000002	//// �X�L�b�v.
#define OAPD_PdmPreCheck_ErrorCode_Normal_SendWait						0x00000003	//// ���Ԏw��.
// �Ǘ��V�X�e���������J��[RQ-811][�v���d�l1] 2020/07/15 Sky��m�� START.
#define OAPD_PdmPreCheck_ErrorCode_Normal_UnableSend					0x00000004	//// ���M�s��.
// �Ǘ��V�X�e���������J��[RQ-811][�v���d�l1] 2020/07/15 Sky��m�� END.


// --------------------------------------------------------------------------------------------------------------
// ��M�G���[.
// --------------------------------------------------------------------------------------------------------------
#define OAPD_PdmPreCheck_ErrorCode_Error_Timeout						0x00001001	//// �ʐM�^�C���A�E�g.
#define OAPD_PdmPreCheck_ErrorCode_Error_TagError						0x00001002	//// OpenAPI�^�O���e�̃G���[.

// --------------------------------------------------------------------------------------------------------------
// Mio�G���[.
// --------------------------------------------------------------------------------------------------------------
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR 							0x00002001	//// SOAPCMD_ERROR.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_PROXY_CONNECT_AUTH_FAILED	0x00002002	//// SOAPCMD_ERROR_PROXY_CONNECT_AUTH_FAILED.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_HTTP_VERSION_NOT_SUPPORTED	0x00002003	//// SOAPCMD_ERROR_HTTP_VERSION_NOT_SUPPORTED.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_FAILED_CONNECTION			0x00002004	//// SOAPCMD_ERROR_FAILED_CONNECTION.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_SEND						0x00002005	//// SOAPCMD_ERROR_SEND.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_SEND_TIMEOUT				0x00002006	//// SOAPCMD_ERROR_SEND_TIMEOUT.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INVALID_REQUEST_URL		0x00002007	//// SOAPCMD_ERROR_INVALID_REQUEST_URL.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INVALID_BODY_SIZE			0x00002008	//// SOAPCMD_ERROR_INVALID_BODY_SIZE.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_BODY_TOO_LARGE				0x00002009	//// SOAPCMD_ERROR_BODY_TOO_LARGE .
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_NOT_SET_PROXY_HOST			0x0000200A	//// SOAPCMD_ERROR_NOT_SET_PROXY_HOST.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_REJECT_CONNECT_METHOD		0x0000200B	//// SOAPCMD_ERROR_REJECT_CONNECT_METHOD.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_PROXY_STATUS				0x0000200C	//// SOAPCMD_ERROR_PROXY_STATUS.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_FAILED_PROXY_CONNECTION	0x0000200D	//// SOAPCMD_ERROR_FAILED_PROXY_CONNECTION.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_RESET						0x0000200E	//// SOAPCMD_ERROR_RESET.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INTERNAL_OTHER				0x0000200F	//// SOAPCMD_ERROR_INTERNAL_OTHER.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_NETDOWN					0x00002010	//// SOAPCMD_ERROR_NETDOWN.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INTERNAL_TASKSTART			0x00002011	//// SOAPCMD_ERROR_INTERNAL_TASKSTART.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INTERNAL_MSG				0x00002012	//// SOAPCMD_ERROR_INTERNAL_MSG.
#define OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INVALID_METHOD				0x00002013	//// SOAPCMD_ERROR_INVALID_METHOD.

// --------------------------------------------------------------------------------------------------------------
// ���N�G�X�g���ʈُ�.
// �Q�l�d�l���FMessage�d�l��(PDM).xls.
// sheet�u���ʍ\���́v<ErrorInfo><Code>�^�O ��0x00003000�̃r�b�g�𗧂Ă����.
// --------------------------------------------------------------------------------------------------------------
#define OAPD_PdmPreCheck_ErrorCode_Oap									0x00003000	//// OAP�G���[.

// --------------------------------------------------------------------------------------------------------------
// ��L�ȊO.
// --------------------------------------------------------------------------------------------------------------
#define OAPD_PdmPreCheck_ErrorCode_Other								0x00004000	//// �C���[�K���G���[.

// ========================================================================== 
//  ���[�J���ϐ�. 
// ========================================================================== 
// ���ԑѐݒ�l�e�[�u��.
static const struct OAPC_PrecheckTimeZone
{
	int32_t				si_NvdTimeZone;						// NVD�̎��ԑ�(�z��̓Y�����w��).
	unsigned char		uc_OapTimeZone;						// OAP�̎��ԑ�(bit�w��).
} s_PrecheckTimeZone [TYPD_CSRAPrecheck_TimePeriodNum] = {
	{ TYPD_CSRAPrecheck_TimePeriod_Index_00_03, (char)OAPD_EXTERNAL_TimeZone_00to03 },		//  0 -  3��.
	{ TYPD_CSRAPrecheck_TimePeriod_Index_04_07, (char)OAPD_EXTERNAL_TimeZone_04to07 },		//  4 -  7��.
	{ TYPD_CSRAPrecheck_TimePeriod_Index_08_11, (char)OAPD_EXTERNAL_TimeZone_08to11 },		//  8 - 11��.
	{ TYPD_CSRAPrecheck_TimePeriod_Index_12_15, (char)OAPD_EXTERNAL_TimeZone_12to15 },		// 12 - 15��.
	{ TYPD_CSRAPrecheck_TimePeriod_Index_16_19, (char)OAPD_EXTERNAL_TimeZone_16to19 },		// 16 - 19��.
	{ TYPD_CSRAPrecheck_TimePeriod_Index_20_23, (char)OAPD_EXTERNAL_TimeZone_20to23 },		// 20 - 23��.
};

// Mio�G���[�ϊ��e�[�u��.
static const struct OAPC_MioErrorTable
{
	int32_t				sl_Mio;
	uint32_t			ui_Oap;
} s_MioErrorTable [] = {
	{ SOAPCMD_ERROR,							OAPD_PdmPreCheck_ErrorCode_Mio_ERROR 							},
	{ SOAPCMD_ERROR_PROXY_CONNECT_AUTH_FAILED,	OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_PROXY_CONNECT_AUTH_FAILED	},
	{ SOAPCMD_ERROR_HTTP_VERSION_NOT_SUPPORTED,	OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_HTTP_VERSION_NOT_SUPPORTED	},
	{ SOAPCMD_ERROR_FAILED_CONNECTION,			OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_FAILED_CONNECTION			},
	{ SOAPCMD_ERROR_SEND,						OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_SEND						},
	{ SOAPCMD_ERROR_SEND_TIMEOUT,				OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_SEND_TIMEOUT				},
	{ SOAPCMD_ERROR_INVALID_REQUEST_URL,		OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INVALID_REQUEST_URL		},
	{ SOAPCMD_ERROR_INVALID_BODY_SIZE,			OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INVALID_BODY_SIZE			},
	{ SOAPCMD_ERROR_BODY_TOO_LARGE,				OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_BODY_TOO_LARGE				},
	{ SOAPCMD_ERROR_NOT_SET_PROXY_HOST,			OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_NOT_SET_PROXY_HOST			},
	{ SOAPCMD_ERROR_REJECT_CONNECT_METHOD,		OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_REJECT_CONNECT_METHOD		},
	{ SOAPCMD_ERROR_PROXY_STATUS,				OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_PROXY_STATUS				},
	{ SOAPCMD_ERROR_FAILED_PROXY_CONNECTION	,	OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_FAILED_PROXY_CONNECTION	},
	{ SOAPCMD_ERROR_RESET,						OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_RESET						},
	{ SOAPCMD_ERROR_INTERNAL_OTHER,				OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INTERNAL_OTHER				},
	{ SOAPCMD_ERROR_NETDOWN,					OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_NETDOWN					},
	{ SOAPCMD_ERROR_INTERNAL_TASKSTART,			OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INTERNAL_TASKSTART			},
	{ SOAPCMD_ERROR_INTERNAL_MSG,				OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INTERNAL_MSG				},
	{ SOAPCMD_ERROR_INVALID_METHOD,				OAPD_PdmPreCheck_ErrorCode_Mio_ERROR_INVALID_METHOD				},
};

// �Ǘ��V�X�e���������J��[RQ-811][�v���d�l1] 2020/07/15 Sky��m�� START.
// �ʐM��ʂ̕ϊ��e�[�u��.
static const struct OAPC_CommunicationType
{
	unsigned char		uc_Sys;						// Sys�̒ʐM���.
	uint32_t			ui_Oap;						// OAP�̒ʐM���.
} s_CommunicationType [] = {
	{ TYPE_PrecheckCommunicationType_Immediate, OAPE_External_PrecheckCommunicationType_Immediate },	//  �����v��.
	{ TYPE_PrecheckCommunicationType_Regular, OAPE_External_PrecheckCommunicationType_Regular },		//  ������CSRA�ڑ�.
	{ TYPE_PrecheckCommunicationType_Report, OAPE_External_PrecheckCommunicationType_Report },			//  ���|�[�g���M.
};
// �Ǘ��V�X�e���������J��[RQ-811][�v���d�l1] 2020/07/15 Sky��m�� END.

// ========================================================================== 
//  ������ 
// ========================================================================== 
	
/**
 * @brief PdmPreCheck��executeInit_impl(DevReq)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_notify	�C�x���g.
 * @param[out]p_req		DevReq���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::executeInit_impl( int appNo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_0::executeInit_impl()" );
	return true;
}

/**
 * @brief PdmPreCheck��execute_impl(DevReq)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_notify	�C�x���g.
 * @param[out]p_req		DevReq���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::execute_impl( int appNo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_0::execute_impl()" );
	
	if( NULL == p_notify || NULL == p_req ){
		OAPD_EXT_TRACE_FATAL("parameter error.");
		return false;
	}

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �ڑ��m�F.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == p_notify->uc_PrecheckType.get() ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}
	
	// system�̃C���X�^���X���擾.
	APIC_SystemInfo* pc_SystemInfo = APIC_SystemInfo::newInstance();
	APIC_SystemSetting* pc_SystemSetting = APIC_SystemSetting::newInstance();
	APIC_MailSendSetting* pc_MailSendSetting = APIC_MailSendSetting::newInstance();
	APIC_CSRASetting* pc_CSRASetting = APIC_CSRASetting::newInstance();
	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_SystemInfo
			|| NULL == pc_SystemSetting
			|| NULL == pc_MailSendSetting
			|| NULL == pc_CSRASetting
			|| NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("SystemIF::newInstance error.");
		return false;
	}
	// NVD����CSRA�̐ݒ�����擾.
	TYPS_CSRASetting s_CSRASetting = {};
	TYPS_CSRAPrecheckServerInfo s_CSRAPrecheckServerInfo = {};
	TYPS_CSRASendInfo s_CSRASendInfo = {};
	pc_CSRASetting->getCSRASetting( &s_CSRASetting );
	pc_CSRASetting->getCSRAPrecheckServerInfoSetting( &s_CSRAPrecheckServerInfo );
	pc_CSRASetting->getCSRASendInfo( &s_CSRASendInfo );

	// --------------------------------------------------------------------------------------------------.
	// �t�@���N�V�����o�[�W����.
	// --------------------------------------------------------------------------------------------------.
	p_req->s_FunctionVersion.uc_ApplicationType = p_notify->s_FunctionVersion.uc_ApplicationType;
	p_req->s_FunctionVersion.ss_Major = p_notify->s_FunctionVersion.ss_Major;
	p_req->s_FunctionVersion.ss_Minor = p_notify->s_FunctionVersion.ss_Minor;

	// --------------------------------------------------------------------------------------------------.
	// ���[�U�[���A�p�X���[�h.
	// --------------------------------------------------------------------------------------------------.
	// ���[�U�[��.
// MFP�Ǘ��Z�p�J��v5[KRQ-335][CSRA�ڑ�][AccuRev:1027084] start.
	p_req->sc_UserName = s_CSRAPrecheckServerInfo.m_sc_UserName;
// MFP�Ǘ��Z�p�J��v5[KRQ-335][CSRA�ڑ�][AccuRev:1027084] end.

	// �p�X���[�h.
	p_req->sc_Password = s_CSRAPrecheckServerInfo.m_sc_Password;

	// --------------------------------------------------------------------------------------------------.
	// MFP�̏��.
	// --------------------------------------------------------------------------------------------------.
	if( False == getPdmMfpInfo( &p_req->s_MfpInfo ) ){
		OAPD_EXT_TRACE_ERROR("getPdmMfpInfo error.");
		s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
		s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Other;
		pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
		return false;
	}
	
	// --------------------------------------------------------------------------------------------------.
	// �����ݒ�.
	// --------------------------------------------------------------------------------------------------.
	// �N��������.
	TYPC_Time c_time = pc_SystemSetting->getSystemTime();
	p_req->s_DateTimeSetting.ss_Year   = c_time.ss_Year;						// �N.
	p_req->s_DateTimeSetting.sc_Month  = c_time.sc_Month;						// ��.
	p_req->s_DateTimeSetting.sc_Day    = c_time.sc_Day;							// ��.
	p_req->s_DateTimeSetting.sc_Hour   = c_time.sc_Hour;						// ��.
	p_req->s_DateTimeSetting.sc_Minute = c_time.sc_Minute;						// ��.

	// �^�C���]�[��.
	TYPC_HourMinute c_HourMinute = pc_MailSendSetting->getTimeZone();
	p_req->s_DateTimeSetting.s_TimeZone.sc_Hour   = c_HourMinute.sc_Hour;		// �^�C���]�[��(��).
	p_req->s_DateTimeSetting.s_TimeZone.sc_Minute = c_HourMinute.sc_Minute;		// �^�C���]�[��(��).

	// --------------------------------------------------------------------------------------------------.
	// ��������(�O��). 
	// --------------------------------------------------------------------------------------------------.
	// ���ʂƃG���[�R�[�h.
	if( 0x00 == s_CSRASendInfo.m_us_PrecheckResult ){
		p_req->s_Result.uc_ResultInfo = OAPE_ExternalResult_ResultInfo_Ack;
	}else{
		p_req->s_Result.uc_ResultInfo = OAPE_ExternalResult_ResultInfo_Nack;
		p_req->s_Result.s_ErrorInfo.uc_Code  = s_CSRASendInfo.m_us_PrecheckResult;
	}

	// --------------------------------------------------------------------------------------------------.
	// �v���`�F�b�N���g���C��.
	// --------------------------------------------------------------------------------------------------.
	p_req->us_PreCheckRetryCnt = s_CSRASendInfo.m_uc_PrecheckRetryCnt;

	// --------------------------------------------------------------------------------------------------.
	// �f�[�^���M���g���C��.
	// --------------------------------------------------------------------------------------------------.
	p_req->us_SendDataRetryCnt = s_CSRASendInfo.m_uc_SendingRetryCnt;

	// --------------------------------------------------------------------------------------------------.
	// �T�[�o�[����̏㏑���֎~�ݒ�.
	// --------------------------------------------------------------------------------------------------.
	if( s_CSRASetting.m_b_SettingOverwrite ){
		// �㏑���\.
		p_req->uc_OverwriteProhibition = OAPE_ExternalPreCheckServerSettingOverwrite_Allow;
	}else{
		// �㏑���֎~.
		p_req->uc_OverwriteProhibition = OAPE_ExternalPreCheckServerSettingOverwrite_Prohibit;
	}

	// --------------------------------------------------------------------------------------------------.
	// �ڑ��m�F�t���O.
	// --------------------------------------------------------------------------------------------------.
	p_req->uc_CheckConnection = p_notify->uc_PrecheckType;

	// --------------------------------------------------------------------------------------------------.
	// �擾�R�}���h�ݒ�(��).
	// --------------------------------------------------------------------------------------------------.
	// ���Ԋu.
	p_req->s_DailyCycleSetting.uc_IntervalDate = s_CSRASetting.m_uc_CycleDay;
	// �R�}���h(��).
	p_req->s_DailyCycleSetting.sc_CsraCommandList = s_CSRASendInfo.m_sc_CommandDay;

	// --------------------------------------------------------------------------------------------------.
	// �擾�R�}���h�ݒ�(�T).
	// --------------------------------------------------------------------------------------------------.
	// �j��.
	switch( s_CSRASetting.m_e_CycleWday ){
		// ��.
		case TYPE_CSRAPrecheckCycleWdat_Sun:
			p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Sun;
			break;
		// ��.
		case TYPE_CSRAPrecheckCycleWdat_Mon:
			p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Mon;
			break;
		// ��.
		case TYPE_CSRAPrecheckCycleWdat_Tue:
			p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Tue;
			break;
		// ��.
		case TYPE_CSRAPrecheckCycleWdat_Wed:
			p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Wed;
			break;
		// ��.
		case TYPE_CSRAPrecheckCycleWdat_Thu:
			p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Thu;
			break;
		// ��.
		case TYPE_CSRAPrecheckCycleWdat_Fri:
			p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Fri;
			break;
		// �y.
		case TYPE_CSRAPrecheckCycleWdat_Sat:
			p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Sat;
			break;
		// ��L�ȊO.
		default:
			OAPD_EXT_TRACE_ERROR("s_CSRASetting.m_e_CycleWday error.");
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
			pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			return false;
	}
	// �R�}���h(�T).
	p_req->s_WeeklyCycleSetting.sc_CsraCommandList = s_CSRASendInfo.m_sc_CommandWday;

	// --------------------------------------------------------------------------------------------------.
	// �擾�R�}���h�ݒ�(��).
	// --------------------------------------------------------------------------------------------------.
	// ��.
	p_req->s_MonthlyCycleSetting.uc_DesignatedDay = s_CSRASetting.m_uc_CycleMonth;
	// �R�}���h(��).
	p_req->s_MonthlyCycleSetting.sc_CsraCommandList = s_CSRASendInfo.m_sc_CommandMonth;

	// --------------------------------------------------------------------------------------------------.
	// ���M����.
	// --------------------------------------------------------------------------------------------------.
	// �����w��/���ԑюw��.
	switch( s_CSRASetting.m_e_PrecheckPeriodSetting ){
		// �����w��.
		case TYPE_CSRAPrecheckPeriodSetting_Time:
			p_req->s_SendTimeSetting.uc_TimeSettingValid = OAPE_ExternalTimeSettingValid_Time;
			break;
		// ���ԑюw��.
		case TYPE_CSRAPrecheckPeriodSetting_Period:
			p_req->s_SendTimeSetting.uc_TimeSettingValid = OAPE_ExternalTimeSettingValid_Zone;
			break;
		// ��L�ȊO.
		default:
			OAPD_EXT_TRACE_ERROR("s_CSRASetting.m_e_PrecheckPeriodSetting error.");
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
			pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			return false;
	}
	// ���ԑ�.
	unsigned char uc_TimeZone = 0x00;
	unsigned char uc_cnt = 0;
	for( uc_cnt = 0; uc_cnt < TYPD_CSRAPrecheck_TimePeriodNum; uc_cnt++ ){
		if( s_CSRASetting.m_b_SendingOKPeriod[ s_PrecheckTimeZone[uc_cnt].si_NvdTimeZone ] ){
			uc_TimeZone |= s_PrecheckTimeZone[uc_cnt].uc_OapTimeZone;
		}
	}
	p_req->s_SendTimeSetting.uc_TimeZone = uc_TimeZone;
	// ��.
	p_req->s_SendTimeSetting.sc_Hour = s_CSRASetting.m_c_PrecheckTime.sc_Hour;
	// ��.
	p_req->s_SendTimeSetting.sc_Minute = s_CSRASetting.m_c_PrecheckTime.sc_Minute;
	

	// --------------------------------------------------------------------------------------------------.
	// �Ĕ��M�ݒ�.
	// --------------------------------------------------------------------------------------------------.
	// �Ĕ��M�Ԋu�i���j.
// MFP�Ǘ��Z�p�J��v5[KRQ-335][CSRA�ڑ�][AccuRev:1027271] start.
	p_req->s_RedialSetting.sc_Interval = s_CSRASetting.m_us_RetryIntervalMin;
// MFP�Ǘ��Z�p�J��v5[KRQ-335][CSRA�ڑ�][AccuRev:1027271] end.
	// �ő�Ĕ��M��.
	p_req->s_RedialSetting.sc_RetryCnt = s_CSRASetting.m_uc_RetryCount;
	
	// --------------------------------------------------------------------------------------------------.
	// �̎�ID.
	// --------------------------------------------------------------------------------------------------.
	p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;

	// --------------------------------------------------------------------------------------------------.
	// �~�σt�@�C����.
	// --------------------------------------------------------------------------------------------------.
	// ��.
	p_req->s_AccumulateFileCnt.uc_Day = p_notify->s_AccumulateFileCnt.uc_Day;
	// �T.
	p_req->s_AccumulateFileCnt.uc_Week = p_notify->s_AccumulateFileCnt.uc_Week;
	// ��.
	p_req->s_AccumulateFileCnt.uc_Month = p_notify->s_AccumulateFileCnt.uc_Month;

	// --------------------------------------------------------------------------------------------------.
	// ���M����(MFP����).
	// --------------------------------------------------------------------------------------------------.
	TYPC_Time c_SendTime;
	Bool b_SetTime = False;
	pc_CSRASetting->getNextSendingTime( &c_SendTime, &b_SetTime );
	// ��.
	p_req->s_CreateTimeSetting.sc_Hour = c_SendTime.sc_Hour;
	// ��.
	p_req->s_CreateTimeSetting.sc_Minute = c_SendTime.sc_Minute;

	// --------------------------------------------------------------------------------------------------.
	// �ʒm���ꂽ�����^�X�NID�ƕR�t���ĕێ�����.
	// --------------------------------------------------------------------------------------------------.
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping={};
	s_Mapping.uc_CheckConnection = p_notify->uc_PrecheckType.get();
	OAPC_ExtPdmMappingID::getInstance().setPdmMappingID(VR_taskIdSelf(),s_Mapping);

	return true;
}

/**
 * @brief PdmPreCheck��executeFinish_impl(DevReq)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_notify	�C�x���g.
 * @param[out]p_req		DevReq���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::executeFinish_impl( int appNo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_0::executeFinish_impl()" );
	return true;
}

// -------------------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��executeInit_impl(DevRes)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_res		DevRes���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::executeInit_impl( int appNo, const OAPS_DevResPdmPreCheck* p_res )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_0::executeInit_impl()" );
	return true;
}

/**
 * @brief PdmPreCheck��execute_impl(DevRes)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_res		DevRes���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::execute_impl(int appNo, const OAPS_DevResPdmPreCheck* p_res)
{
	OAPD_EXT_TRACE_SCOPE("OAPC_PdmPreCheck_1_0::execute_impl()");

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �v���`�F�b�N���ʒǉ����.
	TYPE_CSRAPrecheckResultAddInfo e_CSRAPrecheckResultAddInfo = 0x00000000;
	// �^�X�NID�ƕR�t���ĕێ����Ă����ڑ��m�F�����擾.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
		return false;
	}

	// �������ʂ͏ȗ��s��.
	if( p_res->s_Result.empty() ){
		// �������ʂ͏ȗ��s��.
		s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
		s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
		pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
		OAPD_EXT_TRACE_ERROR("s_Result empty.");
		return false;
	}

	// �������ʂ�NACK�̏ꍇ.
	if( !p_res->s_Result.uc_ResultInfo.empty() ){
		if( OAPE_ExternalResult_ResultInfo_Ack != p_res->s_Result.uc_ResultInfo.get() ){ 
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Oap | p_res->s_Result.s_ErrorInfo.uc_Code.get();
			pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			OAPD_EXT_TRACE_ERROR("s_Result.uc_ResultInfo empty.");
			return false;
		}
	}

	// �v���`�F�b�N�̏ꍇ. �T�[�o�[���A���ʂ��Ȃ��ꍇ�̓G���[.
	if( TYPE_CSRAPrecheckType_Precheck == e_PrecheckType ){
		if( p_res->uc_CheckKind.empty() || p_res->s_ServerSettingInfo.empty() ){
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
			pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			OAPD_EXT_TRACE_ERROR("PrecheckData empty.");
			return false;
		}
	}

	// --------------------------------------------------------------------------------------------------.
	// CSRA�v���`�F�b�N���ʁA�T�[�o�[���A�҂�����.
	// --------------------------------------------------------------------------------------------------.
	// �v���`�F�b�N�̏ꍇ.
	if( TYPE_CSRAPrecheckType_Precheck == e_PrecheckType ){
		// �T�[�o�[����ݒ�.
		switch( p_res->uc_CheckKind.get() ){
			// ����.
			case OAPE_ExternalCSRACheckKind_Now:
				// �`�F�b�N����.
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_SendingOK;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_SendNow;
				// CSRA�T�[�o�[���.
				extStrCopy( s_CSRAPrecheckResultInfo.m_s_CSRAServerInfo.m_sc_URL, p_res->s_ServerSettingInfo.sc_ServerUrl.get(), OAPD_EXTERNAL_PRECHECK_ADDRESS_MAXSTRING+1 );
				extStrCopy( s_CSRAPrecheckResultInfo.m_s_CSRAServerInfo.m_sc_UserName, p_res->s_ServerSettingInfo.sc_UserName.get(), OAPD_EXTERNAL_PRECHECK_USERNAME_MAXSTRING+1 );
				extStrCopy( s_CSRAPrecheckResultInfo.m_s_CSRAServerInfo.m_sc_Password, p_res->s_ServerSettingInfo.sc_Password.get(), OAPD_EXTERNAL_PRECHECK_PASSWORD_MAXSTRING+1 );
				break;
			// �҂����Ԏw��.
			case OAPE_ExternalCSRACheckKind_Wait:
				// �`�F�b�N����.
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_DelayPrecheck;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_SendWait;
				// �҂�����.
				s_CSRAPrecheckResultInfo.m_us_DelayTime = p_res->s_ConnectTimeInfo.ul_Minute.get();
				break;
			// �X�L�b�v.
			case OAPE_ExternalCSRACheckKind_Skip:
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_SendSkip;
				break;
			// ��L�ȊO.
			default:
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
				pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
				OAPD_EXT_TRACE_ERROR("uc_CheckKind error.");
				return false;
		}
	}else{
		// �ڑ��m�F�̏ꍇ.
		s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_None;
		s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_None;
	}

	// --------------------------------------------------------------------------------------------------.
	// ������.
	// --------------------------------------------------------------------------------------------------.
	// ���Ԋu�w��.
	if( !p_res->s_DailyCycleSetting.uc_IntervalDate.empty() ){
		s_CSRAPrecheckResultInfo.m_uc_CycleDay = p_res->s_DailyCycleSetting.uc_IntervalDate.get();
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCycleDay;
	}
	// �擾�R�}���h�ݒ�(��).
	if( !p_res->s_DailyCycleSetting.sc_CsraCommandList.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_CommandDay, p_res->s_DailyCycleSetting.sc_CsraCommandList.get(), OAPD_EXTERNAL_CMD_CSRA_MAXSTRING+1 );
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCommandDay;
	}

	// --------------------------------------------------------------------------------------------------.
	// �T����.
	// --------------------------------------------------------------------------------------------------.
	// �j���w��.
	if( !p_res->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek.empty() ){
		switch( p_res->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek.get() ){
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Sun:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Sun;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Mon:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Mon;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Tue:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Tue;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Wed:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Wed;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Thu:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Thu;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Fri:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Fri;
			break;
		// �y.
		case OAPE_ExternalDesignatedDayOfWeek_Sat:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Sat;
			break;
		// ��L�ȊO.
		default:
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
			pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			OAPD_EXT_TRACE_ERROR("s_WeeklyCycleSetting error.");
			return false;
		}
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCycleWday;
	}
	// �擾�R�}���h�ݒ�(�T).
	if( !p_res->s_WeeklyCycleSetting.sc_CsraCommandList.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_CommandWday, p_res->s_WeeklyCycleSetting.sc_CsraCommandList.get(), OAPD_EXTERNAL_CMD_CSRA_MAXSTRING+1 );
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCommandWday;
	}

	// --------------------------------------------------------------------------------------------------.
	// ������.
	// --------------------------------------------------------------------------------------------------.
	// ���t�w��.
	if( !p_res->s_MonthlyCycleSetting.uc_DesignatedDay.empty() ){
		s_CSRAPrecheckResultInfo.m_uc_CycleMonth = p_res->s_MonthlyCycleSetting.uc_DesignatedDay.get();
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCycleMonth;
	}
	// �擾�R�}���h�ݒ�(��).
	if( !p_res->s_MonthlyCycleSetting.sc_CsraCommandList.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_CommandMonth, p_res->s_MonthlyCycleSetting.sc_CsraCommandList.get(), OAPD_EXTERNAL_CMD_CSRA_MAXSTRING+1 );
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCommandMonth;
	}

	// --------------------------------------------------------------------------------------------------.
	// �����w��/���ԑюw��.
	// --------------------------------------------------------------------------------------------------.
	if( !p_res->s_SendTimeSetting.uc_TimeSettingValid.empty() ){
		if( OAPE_ExternalTimeSettingValid_Zone == p_res->s_SendTimeSetting.uc_TimeSettingValid.get() ){
			// ���ԑюw��.
			s_CSRAPrecheckResultInfo.m_e_PrecheckPeriodSetting = TYPE_CSRAPrecheckPeriodSetting_Period;
			if( !p_res->s_SendTimeSetting.uc_TimeZone.empty() ){
				unsigned char uc_TimeZone = p_res->s_SendTimeSetting.uc_TimeZone.get();
				unsigned char uc_cnt = 0;
				for( uc_cnt = 0; uc_cnt < TYPD_CSRAPrecheck_TimePeriodNum; uc_cnt++ ){
					if( 0x00 != ( uc_TimeZone & s_PrecheckTimeZone[uc_cnt].uc_OapTimeZone ) ){
						s_CSRAPrecheckResultInfo.m_b_SendingOKPeriod[s_PrecheckTimeZone[uc_cnt].si_NvdTimeZone] = True;
					}
				}
				e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeSendingOKPeriod;
			}
		}else{
			// �����w��.
			s_CSRAPrecheckResultInfo.m_e_PrecheckPeriodSetting = TYPE_CSRAPrecheckPeriodSetting_Time;
			if( ( !p_res->s_SendTimeSetting.sc_Hour.empty() ) && ( !p_res->s_SendTimeSetting.sc_Minute.empty() ) ){
				s_CSRAPrecheckResultInfo.m_c_NewPrecheckTime.sc_Hour = p_res->s_SendTimeSetting.sc_Hour.get();
				s_CSRAPrecheckResultInfo.m_c_NewPrecheckTime.sc_Minute = p_res->s_SendTimeSetting.sc_Minute.get();
				e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangePrecheckTime;
			}
		}
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangePrecheckPeriodSetting;
	}

	// --------------------------------------------------------------------------------------------------.
	// �Ĕ��M�ݒ�.
	// --------------------------------------------------------------------------------------------------.
	if( !p_res->s_RedialSetting.sc_RetryCnt.empty() ){
		s_CSRAPrecheckResultInfo.m_uc_RetryCount = p_res->s_RedialSetting.sc_RetryCnt.get();
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeRetryCount;
	}
	if( !p_res->s_RedialSetting.sc_Interval.empty() ){	
// MFP�Ǘ��Z�p�J��v5[KRQ-335][CSRA�ڑ�][AccuRev:1027271] start.
		s_CSRAPrecheckResultInfo.m_us_RetryIntervalMin = p_res->s_RedialSetting.sc_Interval.get();
// MFP�Ǘ��Z�p�J��v5[KRQ-335][CSRA�ڑ�][AccuRev:1027271] end.
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeRetryIntervalMin;
	}
	
	// --------------------------------------------------------------------------------------------------.
	// �̎Ж��ݒ�.
	// --------------------------------------------------------------------------------------------------.
	if( !p_res->sc_SalesCompanyName.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_SalesComapnyName, p_res->sc_SalesCompanyName.get(), OAPD_EXTERNAL_SalesCompanyName_MAXSTRING+1 );
	}
	
	// --------------------------------------------------------------------------------------------------.
	// CSRA�v���`�F�b�N���ʒǉ����.
	// --------------------------------------------------------------------------------------------------.
	s_CSRAPrecheckResultInfo.m_e_PrecheckResultAddInfo = e_CSRAPrecheckResultAddInfo;

	// �v���`�F�b�N���{���ʂ�����.
	pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	return true;
}

/**
 * @brief PdmPreCheck��executeFinish_impl(DevRes)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_res		DevRes���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::executeFinish_impl( int appNo, const OAPS_DevResPdmPreCheck* p_res )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_0::executeFinish_impl()" );
	return true;
}

// -------------------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��timeup_impl�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No. 
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::timeup_impl( int appNo )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_0::timeup_impl()" );

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �^�X�NID�ƕR�t���ĕێ����Ă����ڑ��m�F�����擾.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
		return false;
	}

	// �v���`�F�b�N���{���ʂ�����.
	s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
	s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_Timeout;
	pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	return true;
}
// -------------------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��proxy_timeup_impl�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No. 
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::proxy_timeup_impl( int appNo )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_0::proxy_timeup_impl()" );

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �^�X�NID�ƕR�t���ĕێ����Ă����ڑ��m�F�����擾.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
		return false;
	}

	// �v���`�F�b�N���{���ʂ�����.
	s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
	s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_Timeout;
	pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	return true;
}

/**
 * @brief PdmPreCheck��mio_error_impl�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No. 
 * @param[in] mio_error	MIO�G���[No. 
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::mio_error_impl( int appNo, int32_t mio_error )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_0::mio_error_impl()" );

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �^�X�NID�ƕR�t���ĕێ����Ă����ڑ��m�F�����擾.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
		return false;
	}

	// �v���`�F�b�N���{���ʂ�����.
	s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
	s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Mio_ERROR;
	for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_MioErrorTable) / sizeof(struct OAPC_MioErrorTable); uc_Cnt++ ) {
		if( mio_error == s_MioErrorTable[uc_Cnt].sl_Mio ) {
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = s_MioErrorTable[uc_Cnt].ui_Oap;
			break;
		}
	}
	
	pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	return true;
}

// -------------------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��server_impl�������s��.
 * 
 * @param[in] i_AppNo		�A�v��No. 
 * @param[in] saddr			�T�[�o���.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::server_impl( int appNo, ServerAddress& saddr )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_0::server_impl()" );

	if( False == getPrecheckServerInfo( saddr._ip, &saddr._port, &saddr._ssl, &saddr._e_CertOption ) ){
		OAPD_EXT_TRACE_ERROR( "getPrecheckServerInfo error." );
		return false;
	}

	return true;
}
// ---------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��isDevReqMime_impl�������s��.
 * 
 * @return Mime�̎g�p�L��(true/false).
 */ 
template<>
bool OAPC_PdmPreCheck_1_0::isDevReqMime_impl()
{
	return false;
}

template<>
void OAPC_CheckDevRes<OAPS_DevResPdmPreCheck>::Absorb(){
}

template<>
bool OAPC_CheckDevRes<OAPS_DevResPdmPreCheck>::checkWSDL(int appNo)
{
	bool b_Result = false;			// �߂�l.
	unsigned char   wsdlReturn;
	wsdlReturn=OAPD_WSDL_CHECK_OK;

	// �ȉ��A�^�O�`�F�b�N.
	do{
		// s_Result(�ȗ��s��)--------------------------------------------------------------------------.
		if( _ps_res->s_Result.empty() ){
			wsdlReturn = OAPD_WSDL_EMPTY_ERROR;
			OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->Result.");
			break;
		}

		// s_Result.uc_ResultInfo(�ȗ��s��)------------------------------------------------------------.
		wsdlReturn = EnumWsdlCheck(
				_ps_res->s_Result.uc_ResultInfo.get(),
				!(_ps_res->s_Result.uc_ResultInfo.empty()),
				OAPD_WSDL_EMPTY_NG,
				1, 2,
				OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
				OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
				0);
		if(OAPD_WSDL_CHECK_OK != wsdlReturn){
			OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->Result.ResultInfo");
			break;
		}

		// s_ServerSettingInfo(�ȗ���)-----------------------------------------------------------------.
		if( !_ps_res->s_ServerSettingInfo.empty() ){

// MFP�Ǘ��Z�p�J��v5[RQ-710][CSRA�ڑ�][AccuRev:1029005] start.
			// s_ServerSettingInfo.sc_ServerUrl(�ȗ��s��)----------------------------------------------.
			wsdlReturn = StringWsdlCheck(
					_ps_res->s_ServerSettingInfo.sc_ServerUrl.get(),
					!(_ps_res->s_ServerSettingInfo.sc_ServerUrl.empty()),
					OAPD_WSDL_EMPTY_NG,
					1, 254,
					254,
					OAPD_STRING_TYPE_FULLCOUNT, 
					127,
					0);
// MFP�Ǘ��Z�p�J��v5[RQ-710][CSRA�ڑ�][AccuRev:1029005] end.
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResDcaResponseNotification->s_ServerSettingInfo.sc_ServerUrl");
				break;
			}

			// s_ServerSettingInfo.sc_UserName(�ȗ��s��)----------------------------------------------.
			wsdlReturn = StringWsdlCheck(
					_ps_res->s_ServerSettingInfo.sc_UserName.get(),
					!(_ps_res->s_ServerSettingInfo.sc_UserName.empty()),
					OAPD_WSDL_EMPTY_NG,
					1, 192,
					192,
					OAPD_STRING_TYPE_FULLCOUNT, 
					96,
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResDcaResponseNotification->s_ServerSettingInfo.sc_UserName");
				break;
			}

			// s_ServerSettingInfo.sc_Password(�ȗ���)------------------------------------------------.
			wsdlReturn = StringWsdlCheck(
					_ps_res->s_ServerSettingInfo.sc_Password.get(),
					!(_ps_res->s_ServerSettingInfo.sc_Password.empty()),
					OAPD_WSDL_EMPTY_OK,
					0, 64,
					64,
					OAPD_STRING_TYPE_FULLCOUNT, 
					96,
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResDcaResponseNotification->s_ServerSettingInfo.sc_Password");
				break;
			}
		}

		// uc_CheckKind(�ȗ���)-----------------------------------------------------------------------.
		wsdlReturn = EnumWsdlCheck(
				_ps_res->uc_CheckKind.get(),
				!(_ps_res->uc_CheckKind.empty()),
				OAPD_WSDL_EMPTY_OK,
				// 1, 3,
				1, 4,																// �Ǘ��V�X�e���������J��[RQ-811][�v���d�l1] 2020/10/07 Sky��m��.
				OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
				OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
				0);
		if(OAPD_WSDL_CHECK_OK != wsdlReturn){
			OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->uc_CheckKind");
			break;
		}

		// s_ConnectTimeInfo(�ȗ���)-----------------------------------------------------------------.
		if( !_ps_res->s_ConnectTimeInfo.empty() ){

			// s_ConnectTimeInfo.ul_Minute(�ȗ���)---------------------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_ConnectTimeInfo.ul_Minute.get(),
					!(_ps_res->s_ConnectTimeInfo.ul_Minute.empty()),
					OAPD_WSDL_EMPTY_OK,
					1, 99999,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_ConnectTimeInfo.ul_Minute");
				break;
			}
		}

		// s_DailyCycleSetting(�ȗ���)----------------------------------------------------------------.
		if( !_ps_res->s_DailyCycleSetting.empty() ){

// MFP�Ǘ��Z�p�J��v5[RQ-710][CSRA�ڑ�][AccuRev:1029002] start.
			// s_DailyCycleSetting.uc_IntervalDate(�ȗ���)--------------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_DailyCycleSetting.uc_IntervalDate.get(),
					!(_ps_res->s_DailyCycleSetting.uc_IntervalDate.empty()),
					OAPD_WSDL_EMPTY_OK,
					1, 6,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
// MFP�Ǘ��Z�p�J��v5[RQ-710][CSRA�ڑ�][AccuRev:1029002] end.
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_DailyCycleSetting.uc_IntervalDate");
				break;
			}

			// s_DailyCycleSetting.sc_CsraCommandList(�ȗ���)-----------------------------------------.
			wsdlReturn = StringWsdlCheck(
					_ps_res->s_DailyCycleSetting.sc_CsraCommandList.get(),
					!(_ps_res->s_DailyCycleSetting.sc_CsraCommandList.empty()),
					OAPD_WSDL_EMPTY_OK,
					0, 2807,
					2807,
					OAPD_STRING_TYPE_FULLCOUNT, 
					1403,
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_DailyCycleSetting.sc_CsraCommandList");
				break;
			}
		}

		// s_WeeklyCycleSetting(�ȗ���)---------------------------------------------------------------.
		if( !_ps_res->s_WeeklyCycleSetting.empty() ){

			// s_WeeklyCycleSetting.uc_DesignatedDayOfWeek(�ȗ���)------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek.get(),
					!(_ps_res->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek.empty()),
					OAPD_WSDL_EMPTY_OK,
					1, 7,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek");
				break;
			}

			// s_WeeklyCycleSetting.sc_CsraCommandList(�ȗ���)----------------------------------------.
			wsdlReturn = StringWsdlCheck(
					_ps_res->s_WeeklyCycleSetting.sc_CsraCommandList.get(),
					!(_ps_res->s_WeeklyCycleSetting.sc_CsraCommandList.empty()),
					OAPD_WSDL_EMPTY_OK,
					0, 2807,
					2807,
					OAPD_STRING_TYPE_FULLCOUNT, 
					1403,
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_WeeklyCycleSetting.sc_CsraCommandList");
				break;
			}
		}

		// s_MonthlyCycleSetting(�ȗ���)--------------------------------------------------------------.
		if( !_ps_res->s_MonthlyCycleSetting.empty() ){

			// s_MonthlyCycleSetting.uc_DesignatedDay(�ȗ���)-----------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_MonthlyCycleSetting.uc_DesignatedDay.get(),
					!(_ps_res->s_MonthlyCycleSetting.uc_DesignatedDay.empty()),
					OAPD_WSDL_EMPTY_OK,
					1, 28,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_MonthlyCycleSetting.uc_DesignatedDay");
				break;
			}

			// s_MonthlyCycleSetting.sc_CsraCommandList(�ȗ���)---------------------------------------.
			wsdlReturn = StringWsdlCheck(
					_ps_res->s_MonthlyCycleSetting.sc_CsraCommandList.get(),
					!(_ps_res->s_MonthlyCycleSetting.sc_CsraCommandList.empty()),
					OAPD_WSDL_EMPTY_OK,
					0, 2807,
					2807,
					OAPD_STRING_TYPE_FULLCOUNT, 
					1403,
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_MonthlyCycleSetting.sc_CsraCommandList");
				break;
			}
		}

		// s_SendTimeSetting(�ȗ���)-----------------------------------------------------------------.
		if( !_ps_res->s_SendTimeSetting.empty()) {

			// s_SendTimeSetting.uc_TimeSettingValid(�ȗ���)-----------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_SendTimeSetting.uc_TimeSettingValid.get(),
					!(_ps_res->s_SendTimeSetting.uc_TimeSettingValid.empty()),
					OAPD_WSDL_EMPTY_OK,
					1, 2,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_SendTimeSetting.uc_TimeSettingValid");
				break;
			}

			// s_SendTimeSetting.uc_TimeZone(�ȗ���)-------------------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_SendTimeSetting.uc_TimeZone.get(),
					!(_ps_res->s_SendTimeSetting.uc_TimeZone.empty()),
					OAPD_WSDL_EMPTY_OK,
					0, 63,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_SendTimeSetting.uc_TimeZone");
				break;
			}

			// s_SendTimeSetting.sc_Hour(�ȗ���)-----------------------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_SendTimeSetting.sc_Hour.get(),
					!(_ps_res->s_SendTimeSetting.sc_Hour.empty()),
					OAPD_WSDL_EMPTY_OK,
					0, 23,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_SendTimeSetting.sc_Hour");
				break;
			}

			// s_SendTimeSetting.sc_Minute(�ȗ���)---------------------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_SendTimeSetting.sc_Minute.get(),
					!(_ps_res->s_SendTimeSetting.sc_Minute.empty()),
					OAPD_WSDL_EMPTY_OK,
					0, 59,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_SendTimeSetting.sc_Minute");
				break;
			}
		}

		// s_RedialSetting(�ȗ���)-------------------------------------------------------------------.
		if( ( !_ps_res->s_RedialSetting.empty()) ){

			// s_RedialSetting.sc_Interval(�ȗ���)---------------------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_RedialSetting.sc_Interval.get(),
					!(_ps_res->s_RedialSetting.sc_Interval.empty()),
					OAPD_WSDL_EMPTY_OK,
					10, 1440,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_RedialSetting.sc_Interval");
				break;
			}

			// s_RedialSetting.sc_RetryCnt(�ȗ���)---------------------------------------------------.
			wsdlReturn = EnumWsdlCheck(
					_ps_res->s_RedialSetting.sc_RetryCnt.get(),
					!(_ps_res->s_RedialSetting.sc_RetryCnt.empty()),
					OAPD_WSDL_EMPTY_OK,
					0, 99,
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					OAPD_ENUMTABLE_NOTUSED, OAPD_ENUMTABLE_NOTUSED, 
					0);
			if(OAPD_WSDL_CHECK_OK != wsdlReturn){
				OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->s_RedialSetting.sc_RetryCnt");
				break;
			}
		}
		
		// sc_SalesCompanyName(�ȗ��s��)------------------------------------------------------------.
		wsdlReturn = StringWsdlCheck(
					_ps_res->sc_SalesCompanyName.get(),
					!(_ps_res->sc_SalesCompanyName.empty()),
// �Ǘ��V�X�e���������J�� �v���d�l�@ 2020/07/07 Sky���J START.
//					OAPD_WSDL_EMPTY_NG,
					OAPD_WSDL_EMPTY_OK,
// �Ǘ��V�X�e���������J�� �v���d�l�@ 2020/07/07 Sky���J END.
					1, 20,
					20,
					OAPD_STRING_TYPE_FULLCOUNT, 
					10,
					0);
		if(OAPD_WSDL_CHECK_OK != wsdlReturn){
			OAPD_EXT_TRACE_WARNING("WSDL_Error...DevResPdmPreCheck->sc_SalesCompanyName");
			break;
		}
		
		b_Result = true;

	}while (0);

	if ( true != b_Result ) {

		// �v���`�F�b�N����.
		TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};

		// �^�X�NID�ƕR�t���ĕێ����Ă����ڑ��m�F�����擾.
		TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
		OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
		OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
		if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
			e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
		}
// �Ǘ��V�X�e���������J�� �v���d�l�@ 2020/07/07 Sky���J START.
		// �ʐM���.
		s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = TYPE_PrecheckCommunicationType_Regular;
		for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_CommunicationType) / sizeof(struct OAPC_CommunicationType); uc_Cnt++ ) {
			if( s_Mapping.uc_CommunicationType == s_CommunicationType[uc_Cnt].ui_Oap ) {
				s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = s_CommunicationType[uc_Cnt].uc_Sys;
				break;
			}
		}
// �Ǘ��V�X�e���������J�� �v���d�l�@ 2020/07/07 Sky���J END.

		APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
		if( NULL == pc_CSRAControl ){
			OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
			OAPD_ASSERT( 0 );		// �t�@�C�������擾�ł��Ȃ����߁A�ȍ~�̏����ɉe�����ł�̂ŁAAssert����.
			b_Result = false;
		}

		s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
		s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;

		// �v���`�F�b�N���ʉ���.
		pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	}

	return b_Result;
}

// �Ǘ��V�X�e���������J��[RQ-811][�v���d�l1] 2020/07/15 Sky��m�� START.
/**
 * @brief PdmPreCheck��executeInit_impl(DevReq)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_notify	�C�x���g.
 * @param[out]p_req		DevReq���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::executeInit_impl( int appNo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_1::executeInit_impl()" );
	return OAPC_PdmPreCheck_1_0::executeInit_impl(appNo, p_notify, p_req);
}

/**
 * @brief PdmPreCheck��execute_impl(DevReq)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_notify	�C�x���g.
 * @param[out]p_req		DevReq���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::execute_impl( int appNo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_1::execute_impl()" );

    // ---------------------------------------------------------------------------------------------------------------------------------------------------------------.
	// Ver1.1�Œǉ����鏈����1�ł́A�ʐM��ʂ��擾���A�����res_Precheck�̈���(s_CSRAPrecheckResultInfo)�ɃZ�b�g����res_Precheck���Ăяo��.
	// �]���̃g�����U�N�V���������̂悤�ɁA�OVer���Ăяo������Ɍ�Ver�̏��������s����d�g�݂��ƁA���res_Precheck�𓊂��Ă��܂����ߏC�����e�����f����Ȃ�.
	// �܂��A��Ɍ�Ver�̏��������s���Ă���OVer���Ăяo���ꍇ���ƁA����̒ǉ����������f����Ȃ�.
	// (�ʐM��ʃ^�O���Z�b�g������Ԃ�s_CSRAPrecheckResultInfo��OVer�ֈ����p�������A����̃t���[�����[�N�ł͕s�\.)
	// ���̂��߁AVer1.1�ł�1.0�̏������ہX�R�[�f�B���O������ŐV�K������ǉ����Ă���.
	// ---------------------------------------------------------------------------------------------------------------------------------------------------------------.

	if( NULL == p_notify || NULL == p_req ){
		OAPD_EXT_TRACE_FATAL("parameter error.");
		return false;
	}
	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �ڑ��m�F.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == p_notify->uc_PrecheckType.get() ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	// �C���X�^���X���擾.
	APIC_SystemSetting* pc_SystemSetting = APIC_SystemSetting::newInstance();
	APIC_MailSendSetting* pc_MailSendSetting = APIC_MailSendSetting::newInstance();
	APIC_CSRASetting* pc_CSRASetting = APIC_CSRASetting::newInstance();
	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
    APIC_Rds  *pc_Rds = APIC_Rds::newInstance();

	if( NULL == pc_SystemSetting
			|| NULL == pc_MailSendSetting
			|| NULL == pc_CSRASetting
			|| NULL == pc_CSRAControl
			|| NULL == pc_Rds ){
		OAPD_EXT_TRACE_FATAL("SystemIF::newInstance error.");
		return false;
	}

    // --------------------------------------------------------------------------------------------------.
    // �ʐM���.
    // --------------------------------------------------------------------------------------------------.
    p_req->uc_CommunicationType = p_notify->uc_CommunicationType;
    // CommonAPI�ɓn���ʐM��ʂ��Z�b�g���Ă���.
    s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = TYPE_PrecheckCommunicationType_Regular;
    for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_CommunicationType) / sizeof(struct OAPC_CommunicationType); uc_Cnt++ ) {
        if( p_notify->uc_CommunicationType == s_CommunicationType[uc_Cnt].ui_Oap ) {
            s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = s_CommunicationType[uc_Cnt].uc_Sys;
            break;
        }
    }
    
    // --------------------------------------------------------------------------------------------------.
    // �t�@���N�V�����o�[�W����.
    // --------------------------------------------------------------------------------------------------.
    p_req->s_FunctionVersion.uc_ApplicationType = p_notify->s_FunctionVersion.uc_ApplicationType;
    p_req->s_FunctionVersion.ss_Major = p_notify->s_FunctionVersion.ss_Major;
    p_req->s_FunctionVersion.ss_Minor = p_notify->s_FunctionVersion.ss_Minor;

    // --------------------------------------------------------------------------------------------------.
    // MFP�̏��.
    // --------------------------------------------------------------------------------------------------.
    if( False == getPdmMfpInfo( &p_req->s_MfpInfo ) ){
        OAPD_EXT_TRACE_ERROR("getPdmMfpInfo error.");
        s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
        s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Other;
        pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
        return false;
    }
    
    // --------------------------------------------------------------------------------------------------.
    // �����ݒ�.
    // --------------------------------------------------------------------------------------------------.
    // �N��������.
    TYPC_Time c_time = pc_SystemSetting->getSystemTime();
    p_req->s_DateTimeSetting.ss_Year   = c_time.ss_Year;						// �N.
    p_req->s_DateTimeSetting.sc_Month  = c_time.sc_Month;						// ��.
    p_req->s_DateTimeSetting.sc_Day    = c_time.sc_Day;							// ��.
    p_req->s_DateTimeSetting.sc_Hour   = c_time.sc_Hour;						// ��.
    p_req->s_DateTimeSetting.sc_Minute = c_time.sc_Minute;						// ��.

    // �^�C���]�[��.
    TYPC_HourMinute c_HourMinute = pc_MailSendSetting->getTimeZone();
    p_req->s_DateTimeSetting.s_TimeZone.sc_Hour   = c_HourMinute.sc_Hour;		// �^�C���]�[��(��).
    p_req->s_DateTimeSetting.s_TimeZone.sc_Minute = c_HourMinute.sc_Minute;		// �^�C���]�[��(��).

    // ------------------------------------------------------------------------------------------------------------------------------------------------------.
    // �ʒm���ꂽ�����^�X�NID�ƕR�t���ĕێ�����.
    // timeup�����N�������ꍇ��Sys�ɒʐM��ʂ�Ԃ��K�v�����邪�Atimeup�̃t���[�����[�N�ł�p_Notify���g���Ȃ����߁A�^�X�NID�ƕR�Â��ĕێ����Ă������ŕԂ��d�g�݂����.
    // ------------------------------------------------------------------------------------------------------------------------------------------------------.
    OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping={};
    s_Mapping.uc_CheckConnection = static_cast<unsigned char>(p_notify->uc_PrecheckType.get());
    s_Mapping.uc_CommunicationType = static_cast<unsigned char>(p_notify->uc_CommunicationType.get());
    if( False == OAPC_ExtPdmMappingID::getInstance().setPdmMappingID(VR_taskIdSelf(),s_Mapping) )
    {
        OAPD_EXT_TRACE_ERROR("setPdmMappingID failed.");
        s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
        s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Other;
        pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
        return false;
    }

    // ��������́A�ʐM��ʖ��ɕK�v�ƂȂ�^�O�����ꂼ���`.
	if( OAPE_External_PrecheckCommunicationType_Immediate == p_notify->uc_CommunicationType.get() ) {
        // �����v���p�̃v���`�F�b�N�T�[�o�[�����擾.
        TYPS_RdsPreCheckServerInfo s_RdsPreCheckServerInfo = {};
        pc_Rds->getPreCheckServerInfo( &s_RdsPreCheckServerInfo );

        // --------------------------------------------------------------------------------------------------.
        // ���[�U�[���A�p�X���[�h.
        // --------------------------------------------------------------------------------------------------.
        // ���[�U�[��.
        p_req->sc_UserName = s_RdsPreCheckServerInfo.m_sc_UserName;

        // �p�X���[�h.
        p_req->sc_Password = s_RdsPreCheckServerInfo.m_sc_Password;

// 2021/01/20 Sky��� [OP_BTS-30824][RQ-811]�̎�ID�̒ǉ� START.
// �Ǘ��V�X�e���������J�� RQ-893 [OP_BTS-33548] 2021/05/13 Sky���J START.
//		// CSRA�f�[�^���t�ݒ��� �擾.
//		TYPS_CSRASetting s_CSRASetting = {};
//		APIC_CSRASetting::newInstance()->getCSRASetting( &s_CSRASetting );
//
//		// CSRA�����ڑ��ς݂̏ꍇ.
//		if ( True == s_CSRASetting.m_b_Enable ) {
//			p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;	// �ݒ肳��Ă���̎�ID���^�O�ɃZ�b�g����.
//		} else {
//			p_req->us_SalesCompanyID = 0;									// �Œ�l0���Z�b�g����.
//		}
		TYPS_CSRASetting s_CSRASetting = {};
		TYPE_CSRASettingComMode e_CSRACommMode = APIC_CSRASetting::newInstance()->getCSRASettingComMode();
		switch ( e_CSRACommMode ) {
		case TYPE_CSRASettingComMode_TwoWay:	// CSRA = �g�p����i�o�����j�̏ꍇ.
			pc_CSRASetting->getCSRASetting( &s_CSRASetting );
			p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;	// �ݒ肳��Ă���̎�ID���^�O�ɃZ�b�g����.
			break;
		case TYPE_CSRASettingComMode_OneWay:	// CSRA = �g�p����i�Е����j�̏ꍇ.
			pc_CSRASetting->getCSRASetting( &s_CSRASetting, TYPE_CSRASettingComMode_OneWay );
			p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;	// �ݒ肳��Ă���̎�ID���^�O�ɃZ�b�g����.
			break;
		// 2023/03/08 FPT-TuanDA33�yIT6_2.3�z�yOP_BTS-39639�zADD Start.
		case TYPE_CSRASettingComMode_OneWay_CN:	// CSRA = �g�p����i�Е���:CN�j�̏ꍇ.
			pc_CSRASetting->getCSRASetting( &s_CSRASetting, TYPE_CSRASettingComMode_OneWay_CN );
			p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;	// �ݒ肳��Ă���̎�ID���^�O�ɃZ�b�g����.
			break;
		// 2023/03/08 FPT-TuanDA33�yIT6_2.3�z�yOP_BTS-39639�zADD End.
		default:								// CSRA = �g�p���Ȃ��i�܂��́A�O�q�ȊO�j.
			p_req->us_SalesCompanyID = 0;										// �Œ�l0���^�O�ɃZ�b�g����.
			break;
		}
// �Ǘ��V�X�e���������J�� RQ-893 [OP_BTS-33548] 2021/05/13 Sky���J END.
// 2021/01/20 Sky��� [OP_BTS-30824][RQ-811]�̎�ID�̒ǉ� END.

    }
    else if (OAPE_External_PrecheckCommunicationType_Regular == p_notify->uc_CommunicationType.get() ) {
        // ������CSRA�ڑ��p�̃v���`�F�b�N�T�[�o�[�����擾.
        TYPS_CSRAPrecheckServerInfo s_CSRAPrecheckServerInfo = {};
        pc_CSRASetting->getCSRAPrecheckServerInfoSetting( &s_CSRAPrecheckServerInfo );
        // NVD����CSRA�̐ݒ�����擾.
        TYPS_CSRASetting s_CSRASetting = {};
        pc_CSRASetting->getCSRASetting( &s_CSRASetting );
        TYPS_CSRASendInfo s_CSRASendInfo = {};
        pc_CSRASetting->getCSRASendInfo( &s_CSRASendInfo );


        // --------------------------------------------------------------------------------------------------.
        // ���[�U�[���A�p�X���[�h.
        // --------------------------------------------------------------------------------------------------.
        // ���[�U�[��.
        p_req->sc_UserName = s_CSRAPrecheckServerInfo.m_sc_UserName;

        // �p�X���[�h.
        p_req->sc_Password = s_CSRAPrecheckServerInfo.m_sc_Password;

        // --------------------------------------------------------------------------------------------------.
        // ��������(�O��). 
        // --------------------------------------------------------------------------------------------------.
        // ���ʂƃG���[�R�[�h.
        if( 0x00 == s_CSRASendInfo.m_us_PrecheckResult ){
            p_req->s_Result.uc_ResultInfo = OAPE_ExternalResult_ResultInfo_Ack;
        }else{
            p_req->s_Result.uc_ResultInfo = OAPE_ExternalResult_ResultInfo_Nack;
            p_req->s_Result.s_ErrorInfo.uc_Code  = s_CSRASendInfo.m_us_PrecheckResult;
        }

        // --------------------------------------------------------------------------------------------------.
        // �v���`�F�b�N���g���C��.
        // --------------------------------------------------------------------------------------------------.
        p_req->us_PreCheckRetryCnt = s_CSRASendInfo.m_uc_PrecheckRetryCnt;

        // --------------------------------------------------------------------------------------------------.
        // �f�[�^���M���g���C��.
        // --------------------------------------------------------------------------------------------------.
        p_req->us_SendDataRetryCnt = s_CSRASendInfo.m_uc_SendingRetryCnt;

        // --------------------------------------------------------------------------------------------------.
        // �T�[�o�[����̏㏑���֎~�ݒ�.
        // --------------------------------------------------------------------------------------------------.
        if( s_CSRASetting.m_b_SettingOverwrite ){
            // �㏑���\.
            p_req->uc_OverwriteProhibition = OAPE_ExternalPreCheckServerSettingOverwrite_Allow;
        }else{
            // �㏑���֎~.
            p_req->uc_OverwriteProhibition = OAPE_ExternalPreCheckServerSettingOverwrite_Prohibit;
        }

        // --------------------------------------------------------------------------------------------------.
        // �ڑ��m�F�t���O.
        // --------------------------------------------------------------------------------------------------.
        p_req->uc_CheckConnection = p_notify->uc_PrecheckType;

        // --------------------------------------------------------------------------------------------------.
        // �擾�R�}���h�ݒ�(��).
        // --------------------------------------------------------------------------------------------------.
        // ���Ԋu.
        p_req->s_DailyCycleSetting.uc_IntervalDate = s_CSRASetting.m_uc_CycleDay;
        // �R�}���h(��).
        p_req->s_DailyCycleSetting.sc_CsraCommandList = s_CSRASendInfo.m_sc_CommandDay;

        // --------------------------------------------------------------------------------------------------.
        // �擾�R�}���h�ݒ�(�T).
        // --------------------------------------------------------------------------------------------------.
        // �j��.
        switch( s_CSRASetting.m_e_CycleWday ){
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Sun:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Sun;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Mon:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Mon;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Tue:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Tue;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Wed:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Wed;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Thu:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Thu;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Fri:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Fri;
                break;
            // �y.
            case TYPE_CSRAPrecheckCycleWdat_Sat:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Sat;
                break;
            // ��L�ȊO.
            default:
                OAPD_EXT_TRACE_ERROR("s_CSRASetting.m_e_CycleWday error.");
                s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
                s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
                pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
                return false;
        }
        // �R�}���h(�T).
        p_req->s_WeeklyCycleSetting.sc_CsraCommandList = s_CSRASendInfo.m_sc_CommandWday;

        // --------------------------------------------------------------------------------------------------.
        // �擾�R�}���h�ݒ�(��).
        // --------------------------------------------------------------------------------------------------.
        // ��.
        p_req->s_MonthlyCycleSetting.uc_DesignatedDay = s_CSRASetting.m_uc_CycleMonth;
        // �R�}���h(��).
        p_req->s_MonthlyCycleSetting.sc_CsraCommandList = s_CSRASendInfo.m_sc_CommandMonth;

        // --------------------------------------------------------------------------------------------------.
        // ���M����.
        // --------------------------------------------------------------------------------------------------.
        // �����w��/���ԑюw��.
        switch( s_CSRASetting.m_e_PrecheckPeriodSetting ){
            // �����w��.
            case TYPE_CSRAPrecheckPeriodSetting_Time:
                p_req->s_SendTimeSetting.uc_TimeSettingValid = OAPE_ExternalTimeSettingValid_Time;
                break;
            // ���ԑюw��.
            case TYPE_CSRAPrecheckPeriodSetting_Period:
                p_req->s_SendTimeSetting.uc_TimeSettingValid = OAPE_ExternalTimeSettingValid_Zone;
                break;
            // ��L�ȊO.
            default:
                OAPD_EXT_TRACE_ERROR("s_CSRASetting.m_e_PrecheckPeriodSetting error.");
                s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
                s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
                pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
                return false;
        }
        // ���ԑ�.
        unsigned char uc_TimeZone = 0x00;
        unsigned char uc_cnt = 0;
        for( uc_cnt = 0; uc_cnt < TYPD_CSRAPrecheck_TimePeriodNum; uc_cnt++ ){
            if( s_CSRASetting.m_b_SendingOKPeriod[ s_PrecheckTimeZone[uc_cnt].si_NvdTimeZone ] ){
                uc_TimeZone |= s_PrecheckTimeZone[uc_cnt].uc_OapTimeZone;
            }
        }
        p_req->s_SendTimeSetting.uc_TimeZone = uc_TimeZone;
        // ��.
        p_req->s_SendTimeSetting.sc_Hour = s_CSRASetting.m_c_PrecheckTime.sc_Hour;
        // ��.
        p_req->s_SendTimeSetting.sc_Minute = s_CSRASetting.m_c_PrecheckTime.sc_Minute;
        
        // --------------------------------------------------------------------------------------------------.
        // �Ĕ��M�ݒ�.
        // --------------------------------------------------------------------------------------------------.
        // �Ĕ��M�Ԋu�i���j.
        p_req->s_RedialSetting.sc_Interval = s_CSRASetting.m_us_RetryIntervalMin;
        // �ő�Ĕ��M��.
        p_req->s_RedialSetting.sc_RetryCnt = s_CSRASetting.m_uc_RetryCount;
        
        // --------------------------------------------------------------------------------------------------.
        // �̎�ID.
        // --------------------------------------------------------------------------------------------------.
        p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;

        // --------------------------------------------------------------------------------------------------.
        // �~�σt�@�C����.
        // --------------------------------------------------------------------------------------------------.
        // ��.
        p_req->s_AccumulateFileCnt.uc_Day = p_notify->s_AccumulateFileCnt.uc_Day;
        // �T.
        p_req->s_AccumulateFileCnt.uc_Week = p_notify->s_AccumulateFileCnt.uc_Week;
        // ��.
        p_req->s_AccumulateFileCnt.uc_Month = p_notify->s_AccumulateFileCnt.uc_Month;

        // --------------------------------------------------------------------------------------------------.
        // ���M����(MFP����).
        // --------------------------------------------------------------------------------------------------.
        TYPC_Time c_SendTime;
        Bool b_SetTime = False;
        pc_CSRASetting->getNextSendingTime( &c_SendTime, &b_SetTime );
        // ��.
        p_req->s_CreateTimeSetting.sc_Hour = c_SendTime.sc_Hour;
        // ��.
        p_req->s_CreateTimeSetting.sc_Minute = c_SendTime.sc_Minute;

    } else {
		// �����ɂ�����ɂ��Y�����Ȃ��ꍇ.
	}

	return true;
}

/**
 * @brief PdmPreCheck��executeFinish_impl(DevReq)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_notify	�C�x���g.
 * @param[out]p_req		DevReq���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::executeFinish_impl( int appNo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_1::executeFinish_impl()" );
	return OAPC_PdmPreCheck_1_0::executeFinish_impl(appNo, p_notify, p_req);
}

// -------------------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��executeInit_impl(DevRes)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_res		DevRes���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::executeInit_impl( int appNo, const OAPS_DevResPdmPreCheck* p_res )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_1::executeInit_impl()" );
	return OAPC_PdmPreCheck_1_0::executeInit_impl(appNo, p_res);
}

/**
 * @brief PdmPreCheck��execute_impl(DevRes)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_res		DevRes���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::execute_impl(int appNo, const OAPS_DevResPdmPreCheck* p_res)
{
	OAPD_EXT_TRACE_SCOPE("OAPC_PdmPreCheck_1_1::execute_impl()");

	// ---------------------------------------------------------------------------------------------------------------------------------------------------------------.
	// Ver1.1�Œǉ����鏈����1�ł́A�^�X�NID�ƕR�Â��ĕێ����Ă����ʐM��ʂ��擾���A�����res_Precheck�̈���(s_CSRAPrecheckResultInfo)�ɃZ�b�g����res_Precheck���Ăяo��.
	// �]���̃g�����U�N�V���������̂悤�ɁA�OVer���Ăяo������Ɍ�Ver�̏��������s����d�g�݂��ƁA���res_Precheck�𓊂��Ă��܂����ߏC�����e�����f����Ȃ�.
	// �܂��A��Ɍ�Ver�̏��������s���Ă���OVer���Ăяo���ꍇ���ƁA����̒ǉ����������f����Ȃ�.
	// (�ʐM��ʃ^�O���Z�b�g������Ԃ�s_CSRAPrecheckResultInfo��OVer�ֈ����p�������A����̃t���[�����[�N�ł͕s�\.)
	// ���̂��߁AVer1.1�ł�1.0�̏������ہX�R�[�f�B���O������ŐV�K������ǉ����Ă���.
	// ---------------------------------------------------------------------------------------------------------------------------------------------------------------.

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �v���`�F�b�N���ʒǉ����.
	TYPE_CSRAPrecheckResultAddInfo e_CSRAPrecheckResultAddInfo = 0x00000000;
	// �^�X�NID�ƕR�t���ĕێ����Ă��������擾.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	// �ʐM���.
	s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = TYPE_PrecheckCommunicationType_Regular;
	for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_CommunicationType) / sizeof(struct OAPC_CommunicationType); uc_Cnt++ ) {
		if( s_Mapping.uc_CommunicationType == s_CommunicationType[uc_Cnt].ui_Oap ) {
			s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = s_CommunicationType[uc_Cnt].uc_Sys;
			break;
		}
	}

	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
		return false;
	}

	// �������ʂ͏ȗ��s��.
	if( p_res->s_Result.empty() ){
		// �������ʂ͏ȗ��s��.
		s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
		s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
		pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
		OAPD_EXT_TRACE_ERROR("s_Result empty.");
		return false;
	}

	// �������ʂ�NACK�̏ꍇ.
	if( !p_res->s_Result.uc_ResultInfo.empty() ){
		if( OAPE_ExternalResult_ResultInfo_Ack != p_res->s_Result.uc_ResultInfo.get() ){ 
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Oap | p_res->s_Result.s_ErrorInfo.uc_Code.get();
			pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			OAPD_EXT_TRACE_ERROR("s_Result.uc_ResultInfo empty.");
			return false;
		}
	}

	// �v���`�F�b�N�̏ꍇ. �T�[�o�[���A���ʂ��Ȃ��ꍇ�̓G���[.
	if( TYPE_CSRAPrecheckType_Precheck == e_PrecheckType ){
		if( p_res->uc_CheckKind.empty() || p_res->s_ServerSettingInfo.empty() ){
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
			pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			OAPD_EXT_TRACE_ERROR("PrecheckData empty.");
			return false;
		}
	}

	// --------------------------------------------------------------------------------------------------.
	// CSRA�v���`�F�b�N���ʁA�T�[�o�[���A�҂�����.
	// --------------------------------------------------------------------------------------------------.
	// �v���`�F�b�N�̏ꍇ.
	if( TYPE_CSRAPrecheckType_Precheck == e_PrecheckType ){
		// �T�[�o�[����ݒ�.
		switch( p_res->uc_CheckKind.get() ){
			// ����.
			case OAPE_ExternalCSRACheckKind_Now:
				// �`�F�b�N����.
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_SendingOK;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_SendNow;
				// CSRA�T�[�o�[���.
				extStrCopy( s_CSRAPrecheckResultInfo.m_s_CSRAServerInfo.m_sc_URL, p_res->s_ServerSettingInfo.sc_ServerUrl.get(), OAPD_EXTERNAL_PRECHECK_ADDRESS_MAXSTRING+1 );
				extStrCopy( s_CSRAPrecheckResultInfo.m_s_CSRAServerInfo.m_sc_UserName, p_res->s_ServerSettingInfo.sc_UserName.get(), OAPD_EXTERNAL_PRECHECK_USERNAME_MAXSTRING+1 );
				extStrCopy( s_CSRAPrecheckResultInfo.m_s_CSRAServerInfo.m_sc_Password, p_res->s_ServerSettingInfo.sc_Password.get(), OAPD_EXTERNAL_PRECHECK_PASSWORD_MAXSTRING+1 );
				break;
			// �҂����Ԏw��.
			case OAPE_ExternalCSRACheckKind_Wait:
				// �`�F�b�N����.
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_DelayPrecheck;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_SendWait;
				// �҂�����.
				s_CSRAPrecheckResultInfo.m_us_DelayTime = static_cast<ushort>(p_res->s_ConnectTimeInfo.ul_Minute.get());
				break;
			// �X�L�b�v.
			case OAPE_ExternalCSRACheckKind_Skip:
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_SendSkip;
				break;
			// ���M�s��.
			case OAPE_ExternalCSRACheckKind_Error:
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_UnableSend;
				break;
			// ��L�ȊO.
			default:
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
				pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
				OAPD_EXT_TRACE_ERROR("uc_CheckKind error.");
				return false;
		}
	}else{
		// �ڑ��m�F�̏ꍇ.
		s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_None;
		s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_None;
	}

	// --------------------------------------------------------------------------------------------------.
	// ������.
	// --------------------------------------------------------------------------------------------------.
	// ���Ԋu�w��.
	if( !p_res->s_DailyCycleSetting.uc_IntervalDate.empty() ){
		s_CSRAPrecheckResultInfo.m_uc_CycleDay = static_cast<uchar>(p_res->s_DailyCycleSetting.uc_IntervalDate.get());
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCycleDay;
	}
	// �擾�R�}���h�ݒ�(��).
	if( !p_res->s_DailyCycleSetting.sc_CsraCommandList.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_CommandDay, p_res->s_DailyCycleSetting.sc_CsraCommandList.get(), OAPD_EXTERNAL_CMD_CSRA_MAXSTRING+1 );
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCommandDay;
	}

	// --------------------------------------------------------------------------------------------------.
	// �T����.
	// --------------------------------------------------------------------------------------------------.
	// �j���w��.
	if( !p_res->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek.empty() ){
		switch( p_res->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek.get() ){
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Sun:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Sun;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Mon:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Mon;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Tue:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Tue;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Wed:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Wed;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Thu:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Thu;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Fri:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Fri;
			break;
		// �y.
		case OAPE_ExternalDesignatedDayOfWeek_Sat:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Sat;
			break;
		// ��L�ȊO.
		default:
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
			pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			OAPD_EXT_TRACE_ERROR("s_WeeklyCycleSetting error.");
			return false;
		}
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCycleWday;
	}
	// �擾�R�}���h�ݒ�(�T).
	if( !p_res->s_WeeklyCycleSetting.sc_CsraCommandList.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_CommandWday, p_res->s_WeeklyCycleSetting.sc_CsraCommandList.get(), OAPD_EXTERNAL_CMD_CSRA_MAXSTRING+1 );
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCommandWday;
	}

	// --------------------------------------------------------------------------------------------------.
	// ������.
	// --------------------------------------------------------------------------------------------------.
	// ���t�w��.
	if( !p_res->s_MonthlyCycleSetting.uc_DesignatedDay.empty() ){
		s_CSRAPrecheckResultInfo.m_uc_CycleMonth = static_cast<uchar>(p_res->s_MonthlyCycleSetting.uc_DesignatedDay.get());
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCycleMonth;
	}
	// �擾�R�}���h�ݒ�(��).
	if( !p_res->s_MonthlyCycleSetting.sc_CsraCommandList.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_CommandMonth, p_res->s_MonthlyCycleSetting.sc_CsraCommandList.get(), OAPD_EXTERNAL_CMD_CSRA_MAXSTRING+1 );
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCommandMonth;
	}

	// --------------------------------------------------------------------------------------------------.
	// �����w��/���ԑюw��.
	// --------------------------------------------------------------------------------------------------.
	if( !p_res->s_SendTimeSetting.uc_TimeSettingValid.empty() ){
		if( OAPE_ExternalTimeSettingValid_Zone == p_res->s_SendTimeSetting.uc_TimeSettingValid.get() ){
			// ���ԑюw��.
			s_CSRAPrecheckResultInfo.m_e_PrecheckPeriodSetting = TYPE_CSRAPrecheckPeriodSetting_Period;
			if( !p_res->s_SendTimeSetting.uc_TimeZone.empty() ){
				unsigned char uc_TimeZone = static_cast<unsigned char>(p_res->s_SendTimeSetting.uc_TimeZone.get());
				unsigned char uc_cnt = 0;
				for( uc_cnt = 0; uc_cnt < TYPD_CSRAPrecheck_TimePeriodNum; uc_cnt++ ){
					if( 0x00 != ( uc_TimeZone & s_PrecheckTimeZone[uc_cnt].uc_OapTimeZone ) ){
						s_CSRAPrecheckResultInfo.m_b_SendingOKPeriod[s_PrecheckTimeZone[uc_cnt].si_NvdTimeZone] = True;
					}
				}
				e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeSendingOKPeriod;
			}
		}else{
			// �����w��.
			s_CSRAPrecheckResultInfo.m_e_PrecheckPeriodSetting = TYPE_CSRAPrecheckPeriodSetting_Time;
			if( ( !p_res->s_SendTimeSetting.sc_Hour.empty() ) && ( !p_res->s_SendTimeSetting.sc_Minute.empty() ) ){
				s_CSRAPrecheckResultInfo.m_c_NewPrecheckTime.sc_Hour = static_cast<schar>(p_res->s_SendTimeSetting.sc_Hour.get());
				s_CSRAPrecheckResultInfo.m_c_NewPrecheckTime.sc_Minute = static_cast<schar>(p_res->s_SendTimeSetting.sc_Minute.get());
				e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangePrecheckTime;
			}
		}
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangePrecheckPeriodSetting;
	}

	// --------------------------------------------------------------------------------------------------.
	// �Ĕ��M�ݒ�.
	// --------------------------------------------------------------------------------------------------.
	if( !p_res->s_RedialSetting.sc_RetryCnt.empty() ){
		s_CSRAPrecheckResultInfo.m_uc_RetryCount = static_cast<uchar>(p_res->s_RedialSetting.sc_RetryCnt.get());
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeRetryCount;
	}
	if( !p_res->s_RedialSetting.sc_Interval.empty() ){	
		s_CSRAPrecheckResultInfo.m_us_RetryIntervalMin = static_cast<ushort>(p_res->s_RedialSetting.sc_Interval.get());
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeRetryIntervalMin;
	}
	
	// --------------------------------------------------------------------------------------------------.
	// �̎Ж��ݒ�.
	// --------------------------------------------------------------------------------------------------.
	if( !p_res->sc_SalesCompanyName.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_SalesComapnyName, p_res->sc_SalesCompanyName.get(), OAPD_EXTERNAL_SalesCompanyName_MAXSTRING+1 );
	}
	
	// --------------------------------------------------------------------------------------------------.
	// CSRA�v���`�F�b�N���ʒǉ����.
	// --------------------------------------------------------------------------------------------------.
	s_CSRAPrecheckResultInfo.m_e_PrecheckResultAddInfo = e_CSRAPrecheckResultAddInfo;

	// �v���`�F�b�N���{���ʂ�����.
	pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	return true;

}

/**
 * @brief PdmPreCheck��executeFinish_impl(DevRes)�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No.
 * @param[in] p_res		DevRes���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::executeFinish_impl( int appNo, const OAPS_DevResPdmPreCheck* p_res )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_1::executeFinish_impl()" );
	return OAPC_PdmPreCheck_1_0::executeFinish_impl(appNo, p_res);
}

// -------------------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��timeup_impl�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No. 
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::timeup_impl( int appNo )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_1::timeup_impl()" );

	// OAPC_PdmPreCheck_1_1::execute_impl�Ɠ��l�̗��R�ŁAVer1.0�Ɠ����������R�[�f�B���O������ŐV�K�����������Ă���.

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �^�X�NID�ƕR�t���ĕێ����Ă��������擾.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	// �ʐM���.
	s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = TYPE_PrecheckCommunicationType_Regular;
	for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_CommunicationType) / sizeof(struct OAPC_CommunicationType); uc_Cnt++ ) {
		if( s_Mapping.uc_CommunicationType == s_CommunicationType[uc_Cnt].ui_Oap ) {
			s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = s_CommunicationType[uc_Cnt].uc_Sys;
			break;
		}
	}

	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
		return false;
	}

	// �v���`�F�b�N���{���ʂ�����.
	s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
	s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_Timeout;
	pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	return true;
}

// -------------------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��proxy_timeup_impl�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No. 
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::proxy_timeup_impl( int appNo )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_1::proxy_timeup_impl()" );

	// OAPC_PdmPreCheck_1_1::execute_impl�Ɠ��l�̗��R�ŁAVer1.0�Ɠ����������R�[�f�B���O������ŐV�K�����������Ă���.

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �^�X�NID�ƕR�t���ĕێ����Ă��������擾.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	// �ʐM���.
	s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = TYPE_PrecheckCommunicationType_Regular;
	for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_CommunicationType) / sizeof(struct OAPC_CommunicationType); uc_Cnt++ ) {
		if( s_Mapping.uc_CommunicationType == s_CommunicationType[uc_Cnt].ui_Oap ) {
			s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = s_CommunicationType[uc_Cnt].uc_Sys;
			break;
		}
	}

	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
		return false;
	}

	// �v���`�F�b�N���{���ʂ�����.
	s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
	s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_Timeout;
	pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	return true;
}

/**
 * @brief PdmPreCheck��mio_error_impl�������s��.
 * 
 * @param[in] i_AppNo	�A�v��No. 
 * @param[in] mio_error	MIO�G���[No. 
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::mio_error_impl( int appNo, int32_t mio_error )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_1::mio_error_impl()" );

	// OAPC_PdmPreCheck_1_1::execute_impl�Ɠ��l�̗��R�ŁAVer1.0�Ɠ����������R�[�f�B���O������ŐV�K�����������Ă���.

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �^�X�NID�ƕR�t���ĕێ����Ă��������擾.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	// �ʐM���.
	s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = TYPE_PrecheckCommunicationType_Regular;
	for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_CommunicationType) / sizeof(struct OAPC_CommunicationType); uc_Cnt++ ) {
		if( s_Mapping.uc_CommunicationType == s_CommunicationType[uc_Cnt].ui_Oap ) {
			s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = s_CommunicationType[uc_Cnt].uc_Sys;
			break;
		}
	}

	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
		return false;
	}

	// �v���`�F�b�N���{���ʂ�����.
	s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
	s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Mio_ERROR;
	for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_MioErrorTable) / sizeof(struct OAPC_MioErrorTable); uc_Cnt++ ) {
		if( mio_error == s_MioErrorTable[uc_Cnt].sl_Mio ) {
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = s_MioErrorTable[uc_Cnt].ui_Oap;
			break;
		}
	}
	
	pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	return true;
}

// -------------------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��server_impl�������s��.
 * 
 * @param[in] i_AppNo		�A�v��No. 
 * @param[in] saddr			�T�[�o���.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::server_impl( int appNo, ServerAddress& saddr )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_1::server_impl()" );

	// �^�X�NID��R�Â��Ă���ʐM��ʂ��擾.
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().refPdmMappingID(VR_taskIdSelf(), s_Mapping);

	// �擾�����ʐM��ʂɂ���Đݒ��𕪊򂷂�.
	if ( OAPE_External_PrecheckCommunicationType_Immediate == s_Mapping.uc_CommunicationType ) {
// �Ǘ��V�X�e���������J��(OP_BTS-29293)  2020/10/29 Sky���J START.
//		return getPrecheckServerInfoForImmediate( saddr._ip, &saddr._port, &saddr._ssl, &saddr._e_CertOption );
		return getPrecheckServerInfoForImmediate( saddr._ip, &saddr._port, &saddr._ssl, &saddr._e_CertOption, &saddr.m_ui32_Timeout );
// �Ǘ��V�X�e���������J��(OP_BTS-29293)  2020/10/29 Sky���J END.
	} else {
		// ������CSRA�ڑ��̏ꍇ�A�ߋ�Ver1_0�̏������Ăяo��.
		return OAPC_PdmPreCheck_1_0::server_impl( appNo, saddr );
	}
}

// ---------------------------------------------------------------- 
/**
 * @brief PdmPreCheck��isDevReqMime_impl�������s��.
 * 
 * @return Mime�̎g�p�L��(true/false).
 */ 
template<>
bool OAPC_PdmPreCheck_1_1::isDevReqMime_impl()
{
	return OAPC_PdmPreCheck_1_0::isDevReqMime_impl();
}

// �Ǘ��V�X�e���������J��[RQ-811][�v���d�l1] 2020/07/15 Sky��m�� END.
// �Ǘ��V�X�e���������J�� RQ-811 �v���d�l2-b 2020/12/8 Sky���J START.
/**
 * @brief PdmPreCheck��executeInit_impl(DevReq)�������s��.
 * 
 * @param[in] appNo		�A�v��No.
 * @param[in] p_notify	�C�x���g.
 * @param[out]p_req		DevReq���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_2::executeInit_impl( int appNo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_2::executeInit_impl()" );
	return OAPC_PdmPreCheck_1_1::executeInit_impl(appNo, p_notify, p_req);
}

/**
 * @brief PdmPreCheck��execute_impl(DevReq)�������s��.
 * 
 * @param[in] appNo		�A�v��No.
 * @param[in] p_notify	�C�x���g.
 * @param[out]p_req		DevReq���b�Z�[�W�\����.
 * @return ��������.
 */ 
bool setDevReqPdmPreCheck_1_1( TYPS_CSRAPrecheckResultInfo& s_CSRAPrecheckResultInfo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "setDevReqPdmPreCheck_1_1()" );

	if( NULL == p_notify || NULL == p_req ){
		OAPD_EXT_TRACE_FATAL("parameter error.");
		return false;
	}

	// �C���X�^���X���擾.
    APIC_Rds* pc_Rds = APIC_Rds::newInstance();
	APIC_CSRASetting* pc_CSRASetting = APIC_CSRASetting::newInstance();
	APIC_SystemSetting* pc_SystemSetting = APIC_SystemSetting::newInstance();
	APIC_MailSendSetting* pc_MailSendSetting = APIC_MailSendSetting::newInstance();

	if ( NULL == pc_Rds
			|| NULL == pc_CSRASetting
			|| NULL == pc_SystemSetting
			|| NULL == pc_MailSendSetting ) {
		OAPD_EXT_TRACE_FATAL("SystemIF::newInstance error.");
		return false;
	}

    // --------------------------------------------------------------------------------------------------.
    // �t�@���N�V�����o�[�W����.
    // --------------------------------------------------------------------------------------------------.
    p_req->s_FunctionVersion.uc_ApplicationType = p_notify->s_FunctionVersion.uc_ApplicationType;
    p_req->s_FunctionVersion.ss_Major = p_notify->s_FunctionVersion.ss_Major;
    p_req->s_FunctionVersion.ss_Minor = p_notify->s_FunctionVersion.ss_Minor;

    // --------------------------------------------------------------------------------------------------.
    // ���[�U�[���A�p�X���[�h.
    // --------------------------------------------------------------------------------------------------.
	if( OAPE_External_PrecheckCommunicationType_Immediate == p_notify->uc_CommunicationType.get() ) {
        // �����v���p�̃v���`�F�b�N�T�[�o�[�����擾.
        TYPS_RdsPreCheckServerInfo s_RdsPreCheckServerInfo = {};
        pc_Rds->getPreCheckServerInfo( &s_RdsPreCheckServerInfo );
        p_req->sc_UserName = s_RdsPreCheckServerInfo.m_sc_UserName;
        p_req->sc_Password = s_RdsPreCheckServerInfo.m_sc_Password;
    } else {
	    // ������CSRA�ڑ��p�̃v���`�F�b�N�T�[�o�[�����擾.
	    TYPS_CSRAPrecheckServerInfo s_CSRAPrecheckServerInfo = {};
	    pc_CSRASetting->getCSRAPrecheckServerInfoSetting( &s_CSRAPrecheckServerInfo );
	    p_req->sc_UserName = s_CSRAPrecheckServerInfo.m_sc_UserName;
	    p_req->sc_Password = s_CSRAPrecheckServerInfo.m_sc_Password;
	}

    // --------------------------------------------------------------------------------------------------.
    // MFP�̏��.
    // --------------------------------------------------------------------------------------------------.
    if( False == getPdmMfpInfo( &p_req->s_MfpInfo ) ){
        OAPD_EXT_TRACE_ERROR("getPdmMfpInfo error.");
        s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
        s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Other;
        return false;
    }
    
    // --------------------------------------------------------------------------------------------------.
    // �ʐM���.
    // --------------------------------------------------------------------------------------------------.
    p_req->uc_CommunicationType = p_notify->uc_CommunicationType;

    // --------------------------------------------------------------------------------------------------.
    // �����ݒ�.
    // --------------------------------------------------------------------------------------------------.
    // �N��������.
    TYPC_Time c_time = pc_SystemSetting->getSystemTime();
    p_req->s_DateTimeSetting.ss_Year   = c_time.ss_Year;						// �N.
    p_req->s_DateTimeSetting.sc_Month  = c_time.sc_Month;						// ��.
    p_req->s_DateTimeSetting.sc_Day    = c_time.sc_Day;							// ��.
    p_req->s_DateTimeSetting.sc_Hour   = c_time.sc_Hour;						// ��.
    p_req->s_DateTimeSetting.sc_Minute = c_time.sc_Minute;						// ��.

    // �^�C���]�[��.
    TYPC_HourMinute c_HourMinute = pc_MailSendSetting->getTimeZone();
    p_req->s_DateTimeSetting.s_TimeZone.sc_Hour   = c_HourMinute.sc_Hour;		// �^�C���]�[��(��).
    p_req->s_DateTimeSetting.s_TimeZone.sc_Minute = c_HourMinute.sc_Minute;		// �^�C���]�[��(��).
	
	// �Ǘ��V�X�e���������J�� RQ-893 [OP_BTS-33055] 2021/05/06 Sky�勴 START.
	// �����v���̏ꍇ�A�̎�ID�͏ȗ��s��.
	if ( OAPE_External_PrecheckCommunicationType_Immediate == p_notify->uc_CommunicationType.get() ) {
// �Ǘ��V�X�e���������J�� RQ-893 [OP_BTS-33055] 2021/05/13 Sky���J START.
//		// CSRA�̐ڑ���Ԃ��擾.
//		TYPS_CSRASetting s_CSRASetting = {};
//		pc_CSRASetting->getCSRASetting( &s_CSRASetting );
//		// CSRA�ڑ��ς̏ꍇ.
//		if ( True == s_CSRASetting.m_b_Enable ) {
//			p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;	// �ݒ肳��Ă���̎�ID���^�O�ɃZ�b�g����.
//		// CSRA���ڑ��̏ꍇ.
//		} else {
//			p_req->us_SalesCompanyID = 0;									// �Œ�l0���^�O�ɃZ�b�g����.
//		}
		TYPS_CSRASetting s_CSRASetting = {};
		TYPE_CSRASettingComMode e_CSRACommMode = APIC_CSRASetting::newInstance()->getCSRASettingComMode();
		switch ( e_CSRACommMode ) {
		case TYPE_CSRASettingComMode_TwoWay:	// CSRA = �g�p����i�o�����j�̏ꍇ.
			pc_CSRASetting->getCSRASetting( &s_CSRASetting );
			p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;	// �ݒ肳��Ă���̎�ID���^�O�ɃZ�b�g����.
			break;
		case TYPE_CSRASettingComMode_OneWay:	// CSRA = �g�p����i�Е����j�̏ꍇ.
			pc_CSRASetting->getCSRASetting( &s_CSRASetting, TYPE_CSRASettingComMode_OneWay );
			p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;	// �ݒ肳��Ă���̎�ID���^�O�ɃZ�b�g����.
			break;
		// 2023/03/08 FPT-TuanDA33�yIT6_2.3�z�yOP_BTS-39639�zADD Start.
		case TYPE_CSRASettingComMode_OneWay_CN:	// CSRA = �g�p����i�Е���:CN�j�̏ꍇ.
			pc_CSRASetting->getCSRASetting( &s_CSRASetting, TYPE_CSRASettingComMode_OneWay_CN );
			p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;	// �ݒ肳��Ă���̎�ID���^�O�ɃZ�b�g����.
			break;
		// 2023/03/08 FPT-TuanDA33�yIT6_2.3�z�yOP_BTS-39639�zADD End.
		default:								// CSRA = �g�p���Ȃ��i�܂��́A�O�q�ȊO�j.
			p_req->us_SalesCompanyID = 0;										// �Œ�l0���^�O�ɃZ�b�g����.
			break;
		}
// �Ǘ��V�X�e���������J�� RQ-893 [OP_BTS-33055] 2021/05/13 Sky���J END.
	}
	//if ( OAPE_External_PrecheckCommunicationType_Regular == p_notify->uc_CommunicationType.get() ) {
	else if ( OAPE_External_PrecheckCommunicationType_Regular == p_notify->uc_CommunicationType.get() ) {
	// �Ǘ��V�X�e���������J�� RQ-893 [OP_BTS-33055] 2021/05/06 Sky�勴 END.	
        // ������CSRA�ڑ��p�̃v���`�F�b�N�T�[�o�[�����擾.
        TYPS_CSRAPrecheckServerInfo s_CSRAPrecheckServerInfo = {};
        pc_CSRASetting->getCSRAPrecheckServerInfoSetting( &s_CSRAPrecheckServerInfo );
        // NVD����CSRA�̐ݒ�����擾.
        TYPS_CSRASetting s_CSRASetting = {};
        pc_CSRASetting->getCSRASetting( &s_CSRASetting );
        TYPS_CSRASendInfo s_CSRASendInfo = {};
        pc_CSRASetting->getCSRASendInfo( &s_CSRASendInfo );

        // --------------------------------------------------------------------------------------------------.
        // ��������(�O��). 
        // --------------------------------------------------------------------------------------------------.
        // ���ʂƃG���[�R�[�h.
        if( 0x00 == s_CSRASendInfo.m_us_PrecheckResult ){
            p_req->s_Result.uc_ResultInfo = OAPE_ExternalResult_ResultInfo_Ack;
        }else{
            p_req->s_Result.uc_ResultInfo = OAPE_ExternalResult_ResultInfo_Nack;
            p_req->s_Result.s_ErrorInfo.uc_Code  = s_CSRASendInfo.m_us_PrecheckResult;
        }

        // --------------------------------------------------------------------------------------------------.
        // �v���`�F�b�N���g���C��.
        // --------------------------------------------------------------------------------------------------.
        p_req->us_PreCheckRetryCnt = s_CSRASendInfo.m_uc_PrecheckRetryCnt;

        // --------------------------------------------------------------------------------------------------.
        // �f�[�^���M���g���C��.
        // --------------------------------------------------------------------------------------------------.
        p_req->us_SendDataRetryCnt = s_CSRASendInfo.m_uc_SendingRetryCnt;

        // --------------------------------------------------------------------------------------------------.
        // �T�[�o�[����̏㏑���֎~�ݒ�.
        // --------------------------------------------------------------------------------------------------.
        if( s_CSRASetting.m_b_SettingOverwrite ){
            // �㏑���\.
            p_req->uc_OverwriteProhibition = OAPE_ExternalPreCheckServerSettingOverwrite_Allow;
        }else{
            // �㏑���֎~.
            p_req->uc_OverwriteProhibition = OAPE_ExternalPreCheckServerSettingOverwrite_Prohibit;
        }

        // --------------------------------------------------------------------------------------------------.
        // �ڑ��m�F�t���O.
        // --------------------------------------------------------------------------------------------------.
        p_req->uc_CheckConnection = p_notify->uc_PrecheckType;

        // --------------------------------------------------------------------------------------------------.
        // �擾�R�}���h�ݒ�(��).
        // --------------------------------------------------------------------------------------------------.
        // ���Ԋu.
        p_req->s_DailyCycleSetting.uc_IntervalDate = s_CSRASetting.m_uc_CycleDay;
        // �R�}���h(��).
        p_req->s_DailyCycleSetting.sc_CsraCommandList = s_CSRASendInfo.m_sc_CommandDay;

        // --------------------------------------------------------------------------------------------------.
        // �擾�R�}���h�ݒ�(�T).
        // --------------------------------------------------------------------------------------------------.
        // �j��.
        switch( s_CSRASetting.m_e_CycleWday ){
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Sun:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Sun;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Mon:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Mon;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Tue:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Tue;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Wed:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Wed;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Thu:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Thu;
                break;
            // ��.
            case TYPE_CSRAPrecheckCycleWdat_Fri:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Fri;
                break;
            // �y.
            case TYPE_CSRAPrecheckCycleWdat_Sat:
                p_req->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek = OAPE_ExternalDesignatedDayOfWeek_Sat;
                break;
            // ��L�ȊO.
            default:
                OAPD_EXT_TRACE_ERROR("s_CSRASetting.m_e_CycleWday error.");
                s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
                s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
                return false;
        }
        // �R�}���h(�T).
        p_req->s_WeeklyCycleSetting.sc_CsraCommandList = s_CSRASendInfo.m_sc_CommandWday;

        // --------------------------------------------------------------------------------------------------.
        // �擾�R�}���h�ݒ�(��).
        // --------------------------------------------------------------------------------------------------.
        // ��.
        p_req->s_MonthlyCycleSetting.uc_DesignatedDay = s_CSRASetting.m_uc_CycleMonth;
        // �R�}���h(��).
        p_req->s_MonthlyCycleSetting.sc_CsraCommandList = s_CSRASendInfo.m_sc_CommandMonth;

        // --------------------------------------------------------------------------------------------------.
        // ���M����.
        // --------------------------------------------------------------------------------------------------.
        // �����w��/���ԑюw��.
        switch( s_CSRASetting.m_e_PrecheckPeriodSetting ){
            // �����w��.
            case TYPE_CSRAPrecheckPeriodSetting_Time:
                p_req->s_SendTimeSetting.uc_TimeSettingValid = OAPE_ExternalTimeSettingValid_Time;
                break;
            // ���ԑюw��.
            case TYPE_CSRAPrecheckPeriodSetting_Period:
                p_req->s_SendTimeSetting.uc_TimeSettingValid = OAPE_ExternalTimeSettingValid_Zone;
                break;
            // ��L�ȊO.
            default:
                OAPD_EXT_TRACE_ERROR("s_CSRASetting.m_e_PrecheckPeriodSetting error.");
                s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
                s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
                return false;
        }
        // ���ԑ�.
        unsigned char uc_TimeZone = 0x00;
        unsigned char uc_cnt = 0;
        for( uc_cnt = 0; uc_cnt < TYPD_CSRAPrecheck_TimePeriodNum; uc_cnt++ ){
            if( s_CSRASetting.m_b_SendingOKPeriod[ s_PrecheckTimeZone[uc_cnt].si_NvdTimeZone ] ){
                uc_TimeZone |= s_PrecheckTimeZone[uc_cnt].uc_OapTimeZone;
            }
        }
        p_req->s_SendTimeSetting.uc_TimeZone = uc_TimeZone;
        // ��.
        p_req->s_SendTimeSetting.sc_Hour = s_CSRASetting.m_c_PrecheckTime.sc_Hour;
        // ��.
        p_req->s_SendTimeSetting.sc_Minute = s_CSRASetting.m_c_PrecheckTime.sc_Minute;
        
        // --------------------------------------------------------------------------------------------------.
        // �Ĕ��M�ݒ�.
        // --------------------------------------------------------------------------------------------------.
        // �Ĕ��M�Ԋu�i���j.
        p_req->s_RedialSetting.sc_Interval = s_CSRASetting.m_us_RetryIntervalMin;
        // �ő�Ĕ��M��.
        p_req->s_RedialSetting.sc_RetryCnt = s_CSRASetting.m_uc_RetryCount;
        
        // --------------------------------------------------------------------------------------------------.
        // �~�σt�@�C����.
        // --------------------------------------------------------------------------------------------------.
        // ��.
        p_req->s_AccumulateFileCnt.uc_Day = p_notify->s_AccumulateFileCnt.uc_Day;
        // �T.
        p_req->s_AccumulateFileCnt.uc_Week = p_notify->s_AccumulateFileCnt.uc_Week;
        // ��.
        p_req->s_AccumulateFileCnt.uc_Month = p_notify->s_AccumulateFileCnt.uc_Month;

        // --------------------------------------------------------------------------------------------------.
        // ���M����(MFP����).
        // --------------------------------------------------------------------------------------------------.
        TYPC_Time c_SendTime;
        Bool b_SetTime = False;
        pc_CSRASetting->getNextSendingTime( &c_SendTime, &b_SetTime );
        // ��.
        p_req->s_CreateTimeSetting.sc_Hour = c_SendTime.sc_Hour;
        // ��.
        p_req->s_CreateTimeSetting.sc_Minute = c_SendTime.sc_Minute;

        // --------------------------------------------------------------------------------------------------.
        // �̎�ID.
        // --------------------------------------------------------------------------------------------------.
        p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;
	}

	return true;
}

bool setDevReqPdmPreCheck_1_2( TYPS_CSRAPrecheckResultInfo& s_CSRAPrecheckResultInfo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "setDevReqPdmPreCheck_1_2()" );

	if( NULL == p_notify || NULL == p_req ){
		OAPD_EXT_TRACE_FATAL("parameter error.");
		return false;
	}

	// �C���X�^���X���擾.
	APIC_CSRASetting* pc_CSRASetting = APIC_CSRASetting::newInstance();

	if( NULL == pc_CSRASetting ) {
		OAPD_EXT_TRACE_FATAL("SystemIF::newInstance error.");
		return false;
	}

	if (OAPE_External_PrecheckCommunicationType_Report == p_notify->uc_CommunicationType.get() ) {

        // NVD����CSRA�̐ݒ�����擾.
        TYPS_CSRASetting s_CSRASetting = {};
        pc_CSRASetting->getCSRASetting( &s_CSRASetting );

        // --------------------------------------------------------------------------------------------------.
        // �~�σt�@�C����.
        // --------------------------------------------------------------------------------------------------.
        // ���|�[�g���M.
        p_req->uc_AccumulateFileCntCSRCReport = p_notify->uc_AccumulateFileCntCSRCReport;

        // --------------------------------------------------------------------------------------------------.
        // �̎�ID.
        // --------------------------------------------------------------------------------------------------.
        p_req->us_SalesCompanyID = s_CSRASetting.m_us_SalesCompanyID;
	}

	return true;
}

template<>
bool OAPC_PdmPreCheck_1_2::execute_impl( int appNo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_2::execute_impl()" );

	if( NULL == p_notify || NULL == p_req ){
		OAPD_EXT_TRACE_FATAL("parameter error.");
		return false;
	}
	// �C���X�^���X���擾.
	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if ( NULL == pc_CSRAControl ) {
		OAPD_EXT_TRACE_FATAL("SystemIF::newInstance error.");
		return false;
	}

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};
	// �ڑ��m�F.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == p_notify->uc_PrecheckType.get() ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

    // --------------------------------------------------------------------------------------------------.
    // �ʐM���.
    // --------------------------------------------------------------------------------------------------.
    p_req->uc_CommunicationType = p_notify->uc_CommunicationType;
    // CommonAPI�ɓn���ʐM��ʂ��Z�b�g���Ă���.
    s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = TYPE_PrecheckCommunicationType_Regular;
    for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_CommunicationType) / sizeof(struct OAPC_CommunicationType); uc_Cnt++ ) {
        if( p_notify->uc_CommunicationType == s_CommunicationType[uc_Cnt].ui_Oap ) {
            s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = s_CommunicationType[uc_Cnt].uc_Sys;
            break;
        }
    }
    
	do {

		if ( true != setDevReqPdmPreCheck_1_1( s_CSRAPrecheckResultInfo, p_notify, p_req ) ) {
	        pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			return false;
		}

		if ( true != setDevReqPdmPreCheck_1_2( s_CSRAPrecheckResultInfo, p_notify, p_req ) ) {
	        pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
			return false;
		}

	} while (0);

    // ------------------------------------------------------------------------------------------------------------------------------------------------------.
    // �ʒm���ꂽ�����^�X�NID�ƕR�t���ĕێ�����.
    // timeup�����N�������ꍇ��Sys�ɒʐM��ʂ�Ԃ��K�v�����邪�Atimeup�̃t���[�����[�N�ł�p_Notify���g���Ȃ����߁A�^�X�NID�ƕR�Â��ĕێ����Ă������ŕԂ��d�g�݂����.
    // ------------------------------------------------------------------------------------------------------------------------------------------------------.
    OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping={};
    s_Mapping.uc_CheckConnection = static_cast<unsigned char>(p_notify->uc_PrecheckType.get());
    s_Mapping.uc_CommunicationType = static_cast<unsigned char>(p_notify->uc_CommunicationType.get());
    if( False == OAPC_ExtPdmMappingID::getInstance().setPdmMappingID(VR_taskIdSelf(),s_Mapping) )
    {
        OAPD_EXT_TRACE_ERROR("setPdmMappingID failed.");
        s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
        s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Other;
        pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );
        return false;
    }

	return true;
}

/**
 * @brief PdmPreCheck��executeFinish_impl(DevReq)�������s��.
 * 
 * @param[in] appNo		�A�v��No.
 * @param[in] p_notify	�C�x���g.
 * @param[out]p_req		DevReq���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_2::executeFinish_impl( int appNo, const OAPS_NotifyPdmPreCheck* p_notify, OAPS_DevReqPdmPreCheck* p_req )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_2::executeFinish_impl()" );
	return OAPC_PdmPreCheck_1_1::executeFinish_impl(appNo, p_notify, p_req);
}

/**
 * @brief PdmPreCheck��executeInit_impl(DevRes)�������s��.
 * 
 * @param[in] appNo		�A�v��No.
 * @param[in] p_res		DevRes���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_2::executeInit_impl( int appNo, const OAPS_DevResPdmPreCheck* p_res )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_2::executeInit_impl()" );
	return OAPC_PdmPreCheck_1_1::executeInit_impl(appNo, p_res);
}

/**
 * @brief PdmPreCheck��execute_impl(DevRes)�������s��.
 * 
 * @param[in] appNo		�A�v��No.
 * @param[in] p_res		DevRes���b�Z�[�W�\����.
 * @return ��������.
 */ 
bool getDevResPdmPreCheck_1_1( TYPE_CSRAPrecheckType e_PrecheckType, TYPS_CSRAPrecheckResultInfo& s_CSRAPrecheckResultInfo, const OAPS_DevResPdmPreCheck* p_res )
{
	OAPD_EXT_TRACE_SCOPE("getDevResPdmPreCheck_1_1()");

	// �v���`�F�b�N���ʒǉ����.
	TYPE_CSRAPrecheckResultAddInfo e_CSRAPrecheckResultAddInfo = TYPE_CSRAPrecheckResultAddInfo_None;

	// �������ʂ͏ȗ��s��.
	if( p_res->s_Result.empty() ){
		// �������ʂ͏ȗ��s��.
		s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
		s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
		OAPD_EXT_TRACE_ERROR("s_Result empty.");
		return false;
	}

	// �������ʂ�NACK�̏ꍇ.
	if( !p_res->s_Result.uc_ResultInfo.empty() ){
		if( OAPE_ExternalResult_ResultInfo_Ack != p_res->s_Result.uc_ResultInfo.get() ){ 
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Oap | p_res->s_Result.s_ErrorInfo.uc_Code.get();
			OAPD_EXT_TRACE_ERROR("s_Result.uc_ResultInfo empty.");
			return false;
		}
	}

	// �v���`�F�b�N�̏ꍇ. �T�[�o�[���A���ʂ��Ȃ��ꍇ�̓G���[.
	if( TYPE_CSRAPrecheckType_Precheck == e_PrecheckType ){
		if( p_res->uc_CheckKind.empty() || p_res->s_ServerSettingInfo.empty() ){
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
			OAPD_EXT_TRACE_ERROR("PrecheckData empty.");
			return false;
		}
	}

	// --------------------------------------------------------------------------------------------------.
	// CSRA�v���`�F�b�N���ʁA�T�[�o�[���A�҂�����.
	// --------------------------------------------------------------------------------------------------.
	// �v���`�F�b�N�̏ꍇ.
	if( TYPE_CSRAPrecheckType_Precheck == e_PrecheckType ){

		// �T�[�o�[����ݒ�.
		switch( p_res->uc_CheckKind.get() ){
			// ����.
			case OAPE_ExternalCSRACheckKind_Now:
				// �`�F�b�N����.
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_SendingOK;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_SendNow;
				// CSRA�T�[�o�[���.
				extStrCopy( s_CSRAPrecheckResultInfo.m_s_CSRAServerInfo.m_sc_URL, p_res->s_ServerSettingInfo.sc_ServerUrl.get(), OAPD_EXTERNAL_PRECHECK_ADDRESS_MAXSTRING+1 );
				extStrCopy( s_CSRAPrecheckResultInfo.m_s_CSRAServerInfo.m_sc_UserName, p_res->s_ServerSettingInfo.sc_UserName.get(), OAPD_EXTERNAL_PRECHECK_USERNAME_MAXSTRING+1 );
				extStrCopy( s_CSRAPrecheckResultInfo.m_s_CSRAServerInfo.m_sc_Password, p_res->s_ServerSettingInfo.sc_Password.get(), OAPD_EXTERNAL_PRECHECK_PASSWORD_MAXSTRING+1 );
				break;
			// �҂����Ԏw��.
			case OAPE_ExternalCSRACheckKind_Wait:
				// �`�F�b�N����.
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_DelayPrecheck;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_SendWait;
				// �҂�����.
				s_CSRAPrecheckResultInfo.m_us_DelayTime = static_cast<ushort>(p_res->s_ConnectTimeInfo.ul_Minute.get());
				break;
			// �X�L�b�v.
			case OAPE_ExternalCSRACheckKind_Skip:
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_SendSkip;
				break;
			// ���M�s��.
			case OAPE_ExternalCSRACheckKind_Error:
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_UnableSend;
				break;
			// ��L�ȊO.
			default:
				s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
				s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
				OAPD_EXT_TRACE_ERROR("uc_CheckKind error.");
				return false;
		}
	}else{
		// �ڑ��m�F�̏ꍇ.
		s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_None;
		s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Normal_None;
	}

	// --------------------------------------------------------------------------------------------------.
	// ������.
	// --------------------------------------------------------------------------------------------------.
	// ���Ԋu�w��.
	if( !p_res->s_DailyCycleSetting.uc_IntervalDate.empty() ){
		s_CSRAPrecheckResultInfo.m_uc_CycleDay = static_cast<uchar>(p_res->s_DailyCycleSetting.uc_IntervalDate.get());
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCycleDay;
	}
	// �擾�R�}���h�ݒ�(��).
	if( !p_res->s_DailyCycleSetting.sc_CsraCommandList.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_CommandDay, p_res->s_DailyCycleSetting.sc_CsraCommandList.get(), OAPD_EXTERNAL_CMD_CSRA_MAXSTRING+1 );
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCommandDay;
	}

	// --------------------------------------------------------------------------------------------------.
	// �T����.
	// --------------------------------------------------------------------------------------------------.
	// �j���w��.
	if( !p_res->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek.empty() ){
		switch( p_res->s_WeeklyCycleSetting.uc_DesignatedDayOfWeek.get() ){
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Sun:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Sun;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Mon:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Mon;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Tue:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Tue;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Wed:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Wed;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Thu:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Thu;
			break;
		// ��.
		case OAPE_ExternalDesignatedDayOfWeek_Fri:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Fri;
			break;
		// �y.
		case OAPE_ExternalDesignatedDayOfWeek_Sat:
			s_CSRAPrecheckResultInfo.m_e_CycleWday = TYPE_CSRAPrecheckCycleWdat_Sat;
			break;
		// ��L�ȊO.
		default:
			s_CSRAPrecheckResultInfo.m_e_PrecheckResult = TYPE_CSRAPrecheckResult_Error;
			s_CSRAPrecheckResultInfo.m_ul_ErrorCode = OAPD_PdmPreCheck_ErrorCode_Error_TagError;
			OAPD_EXT_TRACE_ERROR("s_WeeklyCycleSetting error.");
			return false;
		}
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCycleWday;
	}
	// �擾�R�}���h�ݒ�(�T).
	if( !p_res->s_WeeklyCycleSetting.sc_CsraCommandList.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_CommandWday, p_res->s_WeeklyCycleSetting.sc_CsraCommandList.get(), OAPD_EXTERNAL_CMD_CSRA_MAXSTRING+1 );
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCommandWday;
	}

	// --------------------------------------------------------------------------------------------------.
	// ������.
	// --------------------------------------------------------------------------------------------------.
	// ���t�w��.
	if( !p_res->s_MonthlyCycleSetting.uc_DesignatedDay.empty() ){
		s_CSRAPrecheckResultInfo.m_uc_CycleMonth = static_cast<uchar>(p_res->s_MonthlyCycleSetting.uc_DesignatedDay.get());
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCycleMonth;
	}
	// �擾�R�}���h�ݒ�(��).
	if( !p_res->s_MonthlyCycleSetting.sc_CsraCommandList.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_CommandMonth, p_res->s_MonthlyCycleSetting.sc_CsraCommandList.get(), OAPD_EXTERNAL_CMD_CSRA_MAXSTRING+1 );
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeCommandMonth;
	}

	// --------------------------------------------------------------------------------------------------.
	// �����w��/���ԑюw��.
	// --------------------------------------------------------------------------------------------------.
	if( !p_res->s_SendTimeSetting.uc_TimeSettingValid.empty() ){
		if( OAPE_ExternalTimeSettingValid_Zone == p_res->s_SendTimeSetting.uc_TimeSettingValid.get() ){
			// ���ԑюw��.
			s_CSRAPrecheckResultInfo.m_e_PrecheckPeriodSetting = TYPE_CSRAPrecheckPeriodSetting_Period;
			if( !p_res->s_SendTimeSetting.uc_TimeZone.empty() ){
				unsigned char uc_TimeZone = p_res->s_SendTimeSetting.uc_TimeZone.get();
				unsigned char uc_cnt = 0;
				for( uc_cnt = 0; uc_cnt < TYPD_CSRAPrecheck_TimePeriodNum; uc_cnt++ ){
					if( 0x00 != ( uc_TimeZone & s_PrecheckTimeZone[uc_cnt].uc_OapTimeZone ) ){
						s_CSRAPrecheckResultInfo.m_b_SendingOKPeriod[s_PrecheckTimeZone[uc_cnt].si_NvdTimeZone] = True;
					}
				}
				e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeSendingOKPeriod;
			}
		}else{
			// �����w��.
			s_CSRAPrecheckResultInfo.m_e_PrecheckPeriodSetting = TYPE_CSRAPrecheckPeriodSetting_Time;
			if( ( !p_res->s_SendTimeSetting.sc_Hour.empty() ) && ( !p_res->s_SendTimeSetting.sc_Minute.empty() ) ){
				s_CSRAPrecheckResultInfo.m_c_NewPrecheckTime.sc_Hour = static_cast<schar>(p_res->s_SendTimeSetting.sc_Hour.get());
				s_CSRAPrecheckResultInfo.m_c_NewPrecheckTime.sc_Minute = static_cast<schar>(p_res->s_SendTimeSetting.sc_Minute.get());
				e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangePrecheckTime;
			}
		}
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangePrecheckPeriodSetting;
	}

	// --------------------------------------------------------------------------------------------------.
	// �Ĕ��M�ݒ�.
	// --------------------------------------------------------------------------------------------------.
	if( !p_res->s_RedialSetting.sc_RetryCnt.empty() ){
		s_CSRAPrecheckResultInfo.m_uc_RetryCount = static_cast<uchar>(p_res->s_RedialSetting.sc_RetryCnt.get());
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeRetryCount;
	}
	if( !p_res->s_RedialSetting.sc_Interval.empty() ){	
		s_CSRAPrecheckResultInfo.m_us_RetryIntervalMin = static_cast<ushort>(p_res->s_RedialSetting.sc_Interval.get());
		e_CSRAPrecheckResultAddInfo |= TYPE_CSRAPrecheckResultAddInfo_ChangeRetryIntervalMin;
	}
	
	// --------------------------------------------------------------------------------------------------.
	// �̎Ж��ݒ�.
	// --------------------------------------------------------------------------------------------------.
	if( !p_res->sc_SalesCompanyName.empty() ){
		extStrCopy( s_CSRAPrecheckResultInfo.m_sc_SalesComapnyName, p_res->sc_SalesCompanyName.get(), OAPD_EXTERNAL_SalesCompanyName_MAXSTRING+1 );
	}
	
	// --------------------------------------------------------------------------------------------------.
	// CSRA�v���`�F�b�N���ʒǉ����.
	// --------------------------------------------------------------------------------------------------.
	s_CSRAPrecheckResultInfo.m_e_PrecheckResultAddInfo = e_CSRAPrecheckResultAddInfo;

	return true;
}

template<>
bool OAPC_PdmPreCheck_1_2::execute_impl(int appNo, const OAPS_DevResPdmPreCheck* p_res)
{
	OAPD_EXT_TRACE_SCOPE("OAPC_PdmPreCheck_1_2::execute_impl()");

	bool b_Result = false;

	// �v���`�F�b�N����.
	TYPS_CSRAPrecheckResultInfo s_CSRAPrecheckResultInfo = {};

	// �^�X�NID�ƕR�t���ĕێ����Ă��������擾.
	TYPE_CSRAPrecheckType e_PrecheckType = TYPE_CSRAPrecheckType_Precheck;
	OAPC_ExtPdmMappingID::OAPS_PdmMappingIDInfo s_Mapping = {};
	OAPC_ExtPdmMappingID::getInstance().getPdmMappingID(VR_taskIdSelf(), s_Mapping);
	if( OAPE_ExternalPreCheckServerConnectionCheck_Enable == s_Mapping.uc_CheckConnection ){
		e_PrecheckType = TYPE_CSRAPrecheckType_Connection;
	}

	APIC_CSRAControl* pc_CSRAControl = APIC_CSRAControl::newInstance();
	if( NULL == pc_CSRAControl ){
		OAPD_EXT_TRACE_FATAL("APIC_CSRAControl::newInstance error.");
		return false;
	}

	// �ʐM���.
	s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = TYPE_PrecheckCommunicationType_Regular;
	for( uchar uc_Cnt = 0; uc_Cnt < sizeof(s_CommunicationType) / sizeof(struct OAPC_CommunicationType); uc_Cnt++ ) {
		if( s_Mapping.uc_CommunicationType == s_CommunicationType[uc_Cnt].ui_Oap ) {
			s_CSRAPrecheckResultInfo.m_e_PreCheckCommunicationType = s_CommunicationType[uc_Cnt].uc_Sys;
			break;
		}
	}

	do {

		// Ver1.1.�̏���.
		if ( true != getDevResPdmPreCheck_1_1( e_PrecheckType, s_CSRAPrecheckResultInfo, p_res ) ) {
			break;
		}

		b_Result = true;

	} while (0);

	// �v���`�F�b�N���{���ʂ�����.
	pc_CSRAControl->res_Precheck( e_PrecheckType, s_CSRAPrecheckResultInfo );

	return b_Result;

}

/**
 * @brief PdmPreCheck��executeFinish_impl(DevRes)�������s��.
 * 
 * @param[in] appNo		�A�v��No.
 * @param[in] p_res		DevRes���b�Z�[�W�\����.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_2::executeFinish_impl( int appNo, const OAPS_DevResPdmPreCheck* p_res )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_2::executeFinish_impl()" );
	return OAPC_PdmPreCheck_1_1::executeFinish_impl(appNo, p_res);
}

/**
 * @brief PdmPreCheck��timeup_impl�������s��.
 * 
 * @param[in] appNo		�A�v��No. 
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_2::timeup_impl( int appNo )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_2::timeup_impl()" );
	return OAPC_PdmPreCheck_1_1::timeup_impl( appNo );
}

/**
 * @brief PdmPreCheck��proxy_timeup_impl�������s��.
 * 
 * @param[in] appNo		�A�v��No. 
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_2::proxy_timeup_impl( int appNo )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_2::proxy_timeup_impl()" );
	return OAPC_PdmPreCheck_1_1::proxy_timeup_impl( appNo );
}

/**
 * @brief PdmPreCheck��mio_error_impl�������s��.
 * 
 * @param[in] appNo		�A�v��No. 
 * @param[in] mio_error	MIO�G���[No. 
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_2::mio_error_impl( int appNo, int32_t mio_error )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_2::mio_error_impl()" );
	return OAPC_PdmPreCheck_1_1::mio_error_impl( appNo, mio_error );
}

/**
 * @brief PdmPreCheck��server_impl�������s��.
 * 
 * @param[in] appNo			�A�v��No. 
 * @param[in] saddr			�T�[�o���.
 * @return ��������.
 */ 
template<>
bool OAPC_PdmPreCheck_1_2::server_impl( int appNo, ServerAddress& saddr )
{
	OAPD_EXT_TRACE_SCOPE( "OAPC_PdmPreCheck_1_2::server_impl()" );
	return OAPC_PdmPreCheck_1_1::server_impl( appNo, saddr );
}

/**
 * @brief PdmPreCheck��isDevReqMime_impl�������s��.
 * 
 * @return Mime�̎g�p�L��(true/false).
 */ 
template<>
bool OAPC_PdmPreCheck_1_2::isDevReqMime_impl()
{
	return OAPC_PdmPreCheck_1_1::isDevReqMime_impl();
}
// �Ǘ��V�X�e���������J�� RQ-811 �v���d�l2-b 2020/12/8 Sky���J END.
