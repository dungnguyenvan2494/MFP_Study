//�N���X-----------------------------------------------------------------------------------------------------------------.
// �t�@�C�� : CHOP_A030114200_�����F���ݒ�.
//-----------------------------------------------------------------------------------------------------------------------.
#define	SIZE( table )	( sizeof( table ) / sizeof( PDisplayParts* ) )
#include <panel/plibh/plibh_CLCD2/PNLC_StackManJobSpec.h>
#include <panel/plibh/plibhg/pdpcomb.h>
#include <panel/ppcg/ppcg_PD/ppcg_PD.h>
#include <panel/pcgscanfax/pcgscanfax_PD/pcgscanfax_A030114200.h>
#ifdef DEF_LCD_7INCH
#include "PD/A030114200_7inch.cpp"
#else
#include "PD/A030114200.cpp"
#endif
//PanelDesigner�Ή�------------------------------------------------------------------------------------------------------.
// ��ʊJ�n����.
void PA030114200::startGamen()
{
	bl_PanelDesigner = True;						// PanelDesigner�Ή�.
	PCGC_ScanFaxReadSetDetailComLib::startGamen();	// �e�N���X�ďo��(������s��Ȃ���PopupWindow���\�����Ȃ�).
// �R�[���o�b�N�֐��̓o�^.
	ATTACH_OBSERVER( PA030114200, gp_A030114200, PA030114200::prOnOff, A030114200_Rbt1001, Bool, short );				// ON/OFF.
	ATTACH_OBSERVER( PA030114200, gp_A030114200, PA030114200::prLanguage, A030114200_Rbt1002, Bool, short );			// ����I��.
	ATTACH_OBSERVER( PA030114200, gp_A030114200, PA030114200::prOutputKindDOCX, A030114200_Rbt1003, Bool, short );		// �o�͌`��(DOCX).
	ATTACH_OBSERVER( PA030114200, gp_A030114200, PA030114200::prOutputKindXLSX, A030114200_Rbt1004, Bool, short );		// �o�͌`��(XLSX).
	ATTACH_OBSERVER( PA030114200, gp_A030114200, PA030114200::prRotationCorrect, A030114200_Btn0009, Bool, Bool );		// ��]�␳.
	ATTACH_OBSERVER( PA030114200, gp_A030114200, PA030114200::prOk, A030114200_Btn0007, Bool, Bool );					// OK.
	ATTACH_OBSERVER( PA030114200, gp_A030114200, PA030114200::prCancel, A030114200_Btn0005, Bool, Bool );				// �L�����Z��.
	setOkButtonForFunctionBadge( &A030114200_Btn0007 ); // �@�\�o�b�`�{�^���������ɑ�ւ��������s���n�j�L�[��o�^.
// �ϐ����̏������������L�ڂ���.
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	TYPE_LanguageOcr e_LanguageOcr[ TYPD_LanguageListNum ];																//	�I���\����̎擾�̈�̏�����.
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {
		e_LanguageOcr[ i ] = TYPE_LanguageOcrNone;
	}
	PnlComGetSearchablePDFSetting()->getDownloadCompLangList( e_LanguageOcr );											//	�I���\����̎擾.
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {																		//	��ʑ��̈�e�[�u���̏�����.
		m_pst_LangTbl[ i ] = NULL;
	}
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {
		if ( e_LanguageOcr[ i ] == TYPE_LanguageOcrNone ) {
			continue;
		}
		for( short j = 0; j < us_SearchableLanguageIdSize; j++ ) {
			if( st_SearchableLanguageId[ j ].e_Language == e_LanguageOcr[ i ] ) {
				m_pst_LangTbl[ i ] = const_cast<struct PNLS_SearchableLanguage*>( &st_SearchableLanguageId[ j ] );
			}
		}
	}
	m_bl_Backup = False;
// �����ɍ\���ɂ��\���������L�ڂ���.
	static COnOffButtonObjectAdd* const tbl_LanguageButton[] = { &A030114200_Btn0017, &A030114200_Btn0019, &A030114200_Btn0021, &A030114200_Btn0023, &A030114200_Btn0025, &A030114200_Btn0027, &A030114200_Btn0029, &A030114200_Btn0031, &A030114200_Btn0033, };
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {																		//	����L�[�̕\��/��\��.
		if ( NULL == m_pst_LangTbl[ i ] ) {
			tbl_LanguageButton[ i ]->showEnable( False );
		} else {
			tbl_LanguageButton[ i ]->showEnable( True );
			tbl_LanguageButton[ i ]->changeText( m_pst_LangTbl[ i ]->us_TextId );
		}
	}
//comment2021/04/16 Sky���c[IT6_2.2][OP_BTS-30704]PPTX�I�����o�͌`����I���ł���悤�ɏC��.
	A030114200_Rbt1003.showEnable( False );																				// �o�͌`��(DOCX,PPTX).
	A030114200_Rbt1004.showEnable( False );																				// �o�͌`��(XLSX).
	A030114200_Gra0004.showEnable( True );	A030114200_Txt0045.showEnable( True );
	switch( pc_Send->c_ComSend.getFileFormat() ) {
		case TYPE_FileFormatDOCX:	A030114200_Rbt1003.showEnable( True );	break;										// �o�͌`��(DOCX).
		case TYPE_FileFormatXLSX:	A030114200_Rbt1004.showEnable( True );	break;										// �o�͌`��(XLSX).
//comment2021/04/16 Sky���c[IT6_2.2][OP_BTS-30704]PPTX�I�����o�͌`����I���ł���悤�ɏC��.
		case TYPE_FileFormatOfficeOpenXML:																				// �o�͌`��(PPTX).
			A030114200_Rbt1003.showEnable( True );
			A030114200_Btn0035.showEnable( False );
			break;
		default:					A030114200_Gra0004.showEnable( False );	A030114200_Txt0045.showEnable( False );	break;
	}
// �����ɉ�ʂ̏������������L�ڂ���.
	A030114200_Rbt1001.setN( ( True == c_OfficeOpenXml.getOcrOn() ) ? 0 : 1, True );
	A030114200_Cmp1000.setNowPopupGamen( PNLE_ScanFaxCharacterRecognition );
	setupGamenAtButtonOn();																								// �{�^���n�m���̕\�����i�̃Z�b�g�A�b�v.
}
// �{�^���n�m���̕\�����i�̃Z�b�g�A�b�v.
void PA030114200::setupGamenAtButtonOn()
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	A030114200_Rbt1002.setN( -1 );																						// ����I��.
	for( short i = 0; i < TYPD_LanguageListNum; i++ ) {
		if( NULL == m_pst_LangTbl[ i ] ) {
			continue;
		}
		if( m_pst_LangTbl[ i ]->e_Language == c_OfficeOpenXml.getLanguage() ) {
			A030114200_Rbt1002.setN( i );																				// ����I��.
			break;
		}
	}
	switch( c_OfficeOpenXml.getOutPutFormat() ) {																		// �o�͌`���̑I��\��.
		case TYPE_OutPutFormat_Text_Priority:	A030114200_Rbt1003.setN( 0 );	A030114200_Rbt1004.setN( -1 );			//	�����D��.
//comment2021/04/16 Sky���c[IT6_2.2][OP_BTS-30704]PPTX�I�����o�͌`����I���ł���悤�ɏC��.
			if(TYPE_FileFormatOfficeOpenXML == pc_Send->c_ComSend.getFileFormat()){
				A030114200_Rbt1003.setN( -1 );
			}
			break;
		case TYPE_OutPutFormat_Image_Priority:	A030114200_Rbt1003.setN( 1 );	A030114200_Rbt1004.setN( -1 );	break;	//	�摜�D��.
		case TYPE_OutPutFormat_Image_Text:		A030114200_Rbt1003.setN( 2 );	A030114200_Rbt1004.setN( 0 );	break;	//	�摜�ƕ���.
		case TYPE_OutPutFormat_Text:			A030114200_Rbt1003.setN( -1 );	A030114200_Rbt1004.setN( 1 );	break;	//	�����̂�.
	}
	A030114200_Btn0009.setN( c_OfficeOpenXml.getRotationCorrection() );													//	�␳����E���Ȃ��L�[.
}
// ON/OFF.
Bool PA030114200::prOnOff( short n )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	if( n == 0 ) {
		if( False == setOfficeOpenXmlOn( pc_JobFax, m_pst_LangTbl, &m_c_OfficeOpenXml, m_bl_Backup ) ) {		// OCR�����F���̐ݒ��On�ɂ���.
			return	False;
		}
	} else {
		m_bl_Backup = True;																								// ��ʕ\������On����Off�ւ̐ؑւ����s��ꂽ�����L�^���Ă���.
		m_c_OfficeOpenXml = c_OfficeOpenXml;																			// �ݒ�On����OfficeOpenXML�f�[�^��ۑ�.
		cancel( CNK_OCRSetting, CNK_Size, pc_JobFax );															// OCR�����F���ݒ��Off.
	}
	return	True;
}
// ����I��.
Bool PA030114200::prLanguage( short n )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	c_OfficeOpenXml.setLanguage( m_pst_LangTbl[ n ]->e_Language );
	pc_Send->setOfficeOpenXml( c_OfficeOpenXml );
	return	True;
}
// �o�͌`��(DOCX).
Bool PA030114200::prOutputKindDOCX( short n )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	switch( n ) {
		case 0:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Text_Priority );		break;							// �����D��.
		case 1:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Image_Priority );	break;							// �摜�D��.
		case 2:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Image_Text );		break;							// �摜�ƕ���.
	}
	pc_Send->setOfficeOpenXml( c_OfficeOpenXml );
	return	True;
}
// �o�͌`��(XLSX).
Bool PA030114200::prOutputKindXLSX( short n )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	switch( n ) {
		case 0:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Image_Text );	break;								//	�摜�ƕ���.
		case 1:	c_OfficeOpenXml.setOutPutFormat( TYPE_OutPutFormat_Text );			break;								//	����.
	}
	pc_Send->setOfficeOpenXml( c_OfficeOpenXml );
	return	True;
}
// ��]�␳.
Bool PA030114200::prRotationCorrect( Bool on )
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return False; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	c_OfficeOpenXml.setRotationCorrection( on );
	pc_Send->setOfficeOpenXml( c_OfficeOpenXml );
	return	True;
}
// OK.
Bool PA030114200::prOk( Bool on )
{
	procOkSetup();																										//	�ݒ�I�����ʏ���.
	return	True;
}
// �L�����Z��.
Bool PA030114200::prCancel( Bool on )
{
	PNLC_StackManJobSpec::newInstance()->rollbackJobSpec();																//	�ݒ�����ɖ߂�.
	return	True;
}
//�]������(��ʊO����)---------------------------------------------------------------------------------------------------.
//	�X�^�[�g.
void PA030114200::procStart( uchar option )
{
	procOkSetup();																										//	�ݒ�I�����ʏ���.
	PCGC_ScanFaxReadSetDetailComLib::procStart( option );
}
//	�X�g�b�v.
void PA030114200::procStop( uchar option )
{
	procOkSetup();																										//	�ݒ�I�����ʏ���.
	PCGC_ScanFaxReadSetDetailComLib::procStop( option );
}
//	�m�F�R�s�[.
void PA030114200::procSampleCopy( uchar option )
{
	procOkSetup();																										//	�ݒ�I�����ʏ���.
	PCGC_ScanFaxReadSetDetailComLib::procSampleCopy( option );
}
//��ʌŗL����-----------------------------------------------------------------------------------------------------------.
//	�ݒ�I�����ʓ����ݒ菈��.
void PA030114200::procOkSetup()
{
	APIC_Job* pc_JobFax = PnlComGetJobFax();
	if( NULL == pc_JobFax ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_JobSpec* pc_JobSpec = pc_JobFax->getJobSpec();
	if( NULL == pc_JobSpec ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_Send* pc_Send = pc_JobSpec->pc_Send;
	if( NULL == pc_Send ) { LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return; }
	TYPC_OfficeOpenXml c_OfficeOpenXml = pc_Send->getOfficeOpenXml();
	if( False == c_OfficeOpenXml.getOcrOn() ) {
		cancel( CNK_OCRSetting, CNK_Size, pc_JobFax );
	}
}
