//------------------------------------------------------------------------------
/**
 * @file pcgwarn_pA0A3455.cpp
 * @brief
 */
//------------------------------------------------------------------------------

//================================================================================================
//  �C���N���[�h�E�t�@�C��.
//================================================================================================
#include "pcgwarn_pA0A3455.h"
#include "pigwarn_pA0A3455.h"
#include "pipwarn_pA0A3455.h"
#include <panel/pcgscanoap/pcgscanoapg/pcgscanoap.h>
#include <panel/pcgauthoap/pcgauthoap_CLCD/pigauthoap1_CLCD.h>
#include <panel/pcgbrowser_ext/pcgbrowser_extg/pigAuthOapBrowserWait.h>


/*================================================================================================
 �}�N���֐��̒�`.
================================================================================================*/

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn).
// ===============================================================================================.

void PCPC_BrowserErrorExt_warn::startGamen( )
{
	POAP_PopupWarningMsgWindowCom::startGamen();
}
// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: setupGamen.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn).
// ===============================================================================================.
uint32_t PCPC_BrowserErrorExt_warn::m_ulErrorCode;
void PCPC_BrowserErrorExt_warn::setupGamen( short option )
{
	POAP_PopupWarningMsgWindowCom::setupGamen( option );
	printLEDControl( False );

	Bak_ErrorCodeLabelExt.showEnable( False );
	Btx_ErrorCodeNumberExt.showEnable( False );

	// �G���[�R�[�h�e�[�u������.
	for( uchar i = 0; i < uc_BrwErrorCodeTbl; i++ ) {
		if( st_BrwErrorCodeTbl[i].ul_ErrorCode == m_ulErrorCode ) {
			// ���b�Z�[�W�ݒ�.
			Tfd_BrowserError.changeText( st_BrwErrorCodeTbl[i].message_symbol );

			// �X�e�[�^�X�R�[�h����.
			if( 0 != st_BrwErrorCodeTbl[i].ss_StatusCode ) {
				// �G���[�R�[�h�o�̓G���A�L��.
				Btx_ErrorCodeNumberExt = st_BrwErrorCodeTbl[i].ss_StatusCode;
				Bak_ErrorCodeLabelExt.showEnable( True );
				Btx_ErrorCodeNumberExt.showEnable( True );
			}
			break;
		}
	} //for.

	// �G���[�R�[�h�e�[�u���s��v��
	if( i == uc_BrwErrorCodeTbl ) {
		Tfd_BrowserError.changeText( s_pMSGConnectionFailedError_W448H052A );
	}
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procOk.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn).
// ===============================================================================================.

void PCPC_BrowserErrorExt_warn::procOk( uchar option )
{
	TYPS_ExtRegistAppInfo* ps_RegistAppInfo;
// Comment 2020/02/12 HCL-Satheesh [IT6_SparrowBK][OP_BTS-16468] Log Addition to find out Browser warning reset process happening or not.
	PNL_LogManager::newInstance()->setGeneralPurposeLog("[BrowserError(OK Press)]", (ulong)0 );
	onlyPanel.resetPanelWarning( PNL_ERROR_BrowserError );

	// �x���t���O�N���A��A���Ɍx�����Ȃ����rebuildGamen���Ă��PNLC_WarningManager::ss_mmbPreGamenWarningNo���X�V���Ă���J�ڂ���.
	if( 0 == onlyPanel.isAllGamenWarning( comPanelJob ) ) {
		rebuildGamen( 0 );
	}

	// �N�����A�v������.
	ps_RegistAppInfo = PnlComGetActiveAplNo();									//�N�����A�v�����擾.
	if( NULL == ps_RegistAppInfo )
	{
		LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return;
	}
	for( int i = 1; i <= TYPD_ExtMaxApplication; i++ ) {
		if( ps_RegistAppInfo->b_AppUseFlag[i - 1] == True ) {					//�w��A�v�����N������.
			// �N����.
			APIC_ExtSetting* extBuf = APIC_ExtSetting::newInstance( i );
			if( NULL ==  extBuf )
			{
				LOGF_debug_PutEventLog( LOGF_DEBUG_EVENT_KIND_ALL, 0, LOGD_DEBUG_LEVEL_UNKNOWN, "Assert Failed!" ); return;
			}
			TYPS_ExtRegistration extRegBuf = extBuf->getApplication();			// �A�v�����擾.

			// �A�v����ʂ̔���.
			if( ( extRegBuf.e_Entry == TYPE_ExtEntryOn ) &&
			    ( ( extRegBuf.s_Version.e_Type == TYPE_ExtTypeBrowserScan )  ||	// Browser(Scan).
			      ( extRegBuf.s_Version.e_Type == TYPE_ExtTypeBrowserPull )  ||	// Browser(Pull).
			      ( extRegBuf.s_Version.e_Type == TYPE_ExtTypeBrowserGeneral ) ) ) {	// �����u���E�U.

				// �A�v���N�����̉�ʂɑJ��.
				nextGamen = ScanOapExtSet.SetEndKeyEvent();

				break;
			}
		}
	}
	// �F�؉�ʂ̐؂�ւ��t���O�ݒ�.
	if( PnlComGetOapAuthenticationAplType() == TYPE_ExtTypeBrowserAuth ) {
		// �����O�C�����.
		if( PnlComGetUser() == NULL && PnlComGetTrack() == NULL ) {
			if( ( 0x112C != m_ulErrorCode )
			    && ( 0x1006 != m_ulErrorCode )
			    && ( 0x1001 != m_ulErrorCode ) //comment 2022/12/14 FPT.ThanhDH5 �yOP_BTS-40120�z�l�b�g���[�N�ڑ����s�̏ꍇ�́A�Ǘ��҃��[�h�֑J�ڂł��Ȃ��A���ԔF�؉����ł��Ȃ����΍�.
			    && ( 0x2000 != m_ulErrorCode )
			    && ( 0x2001 != m_ulErrorCode )
			    && ( 0x10C7 != m_ulErrorCode )
			    && ( 0x10C5 != m_ulErrorCode ) ) {
				// ���[�J���R���e���c�A�N�Z�X�G���[�ADNS�T�[�o�[���ݒ�G���[�A�������[�s���G���[�̏ꍇ�͐ؑւ��s��Ȃ�.
				gp_AuthOapBrowserWait.setBrowserAuthServerChange( True );
			}
			rebuildGamen( 0 );
		}
	}

	for( int j = 1; j <= TYPD_ExtMaxApplication; j++ ) {
		APIC_ExtSetting* extBuf = APIC_ExtSetting::newInstance( j );
		if( NULL == extBuf ) {
			continue; //�擾�ł��Ȃ������ꍇ�͎���.
		}

		// �A�v����ʂ̔���.
		TYPS_ExtRegistration extRegBuf = extBuf->getApplication();			// �A�v�����擾.
		if( ( extRegBuf.e_Entry == TYPE_ExtEntryOn ) && ( extRegBuf.s_Version.e_Type == TYPE_ExtTypeBrowserScrSvr ) )	// Browser(ScrSvr).
		{
			rebuildGamen( 0 ); //��ʍX�V����(��{��ʂɑJ��).
			break;
		}
	}


}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procStart.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procStart( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procStop.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procStop( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: proc10Key.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::proc10Key( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procShrp.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procShrp( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procAster.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procAster( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procClear.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procClear( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procReset.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procReset( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procCopy.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procCopy( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

//===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procFax.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procFax( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

//===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procFaxOnly.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procFaxOnly( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

//===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procBox.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procBox( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}
//===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procUbqPrint.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procUbqPrint( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}


//===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procBrowser.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procBrowser( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}


//===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procJobMemory.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procJobMemory( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

//===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procIntMode.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procIntMode( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

//===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procIDInput.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procIDInput( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procSampleCopy.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procSampleCopy( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procPowerSave.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procPowerSave( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procUtility.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procUtility( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procHelp.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procHelp( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procEnlarge.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procEnlarge( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

// ===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procAccessibility.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procAccessibility( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

//===============================================================================================.
//	Class			: PCPC_BrowserErrorExt_warn   : A0A3455300 Web�u���E�U�[�A�g�G���[.
//	Overview		: procAPPsMenu.
//	Return Value	: void.
//  Remarks			: .
//	Reviews			: .
//	Change History	: .
//  History			: New class for (pcgwarn.cpp - PCPC_BrowserErrorExt_warn ).
// ===============================================================================================.
void PCPC_BrowserErrorExt_warn::procAPPsMenu( uchar option )
{
	setBuzzerType( PCGE_BuzzerType_InputNg );
}

